jit.off()
-- --[[
-- *****************************************************************************************
-- * Program Script Name	:	B738.Z.autostart
-- *
-- * Author Name			:	Alex Unruh, Jim Gregory
-- *
-- *   Revisions:
-- *   -- DATE --	--- REV NO ---		--- DESCRIPTION ---
-- *   
-- *
-- *
-- *
-- *
-- *****************************************************************************************
-- *        COPYRIGHT � 2017 ALEX UNRUH / LAMINAR RESEARCH - ALL RIGHTS RESERVED
-- *****************************************************************************************
-- --]]



-- --*************************************************************************************--
-- --** 					              XLUA GLOBALS              				     **--
-- --*************************************************************************************--

-- --[[

-- SIM_PERIOD - this contains the duration of the current frame in seconds (so it is alway a
-- fraction).  Use this to normalize rates,  e.g. to add 3 units of fuel per second in a
-- per-frame callback you’d do fuel = fuel + 3 * SIM_PERIOD.

-- IN_REPLAY - evaluates to 0 if replay is off, 1 if replay mode is on

-- --]]


-- --*************************************************************************************--
-- --** 					               CONSTANTS                    				 **--
-- --*************************************************************************************--
CAT_HOME = 0
CAT_SETTINGS = 48
CAT_FEATURES = 1
CAT_VOLUME_EQ = 2
CAT_VISUAL_EFFECTS = 3
CAT_REALISM = 4
CAT_OPTIONAL_ACCESS = 5
CAT_CALIBRATION = 6
CAT_HARDWARE = 7
CAT_CONFIG = 8
CAT_CALIBRATE = 9
CAT_ANNOUNC = 41
CAT_ANN_SET = 49
CAT_DEV_TUNE = 98
CAT_CHECKLIST = 10
CAT_CL_PR_PREFLIGHT = 11
CAT_CL_CDU_PREFLIGHT = 12
CAT_CL_CPT_PREFLIGHT = 13
CAT_CL_FO_PREFLIGHT = 14
CAT_CL_BEFORE_START = 15
CAT_CL_PUSHBACK = 16
CAT_CL_ENG_START = 17
CAT_CL_BEFORE_TAXI = 18
CAT_CL_TAKEOFF = 19
CAT_CL_CLIMB_CRUISE = 20
CAT_CL_DESCENT = 21
CAT_CL_APPROACH = 22
CAT_CL_LANDING_ILS = 23
CAT_CL_LANDING_IAN = 24
CAT_CL_LANDING_VNAV = 25
CAT_CL_GOAROUND = 26
CAT_CL_AFTER_LAND = 27
CAT_CL_SHUTDOWN = 28
CAT_CL_SECURE = 29
CAT_LOAD_SAVE = 35
CAT_CFG_PRESETS = 36
CAT_AUDIO_PRESETS = 37
CAT_STATE_PRESETS = 38
CAT_LOAD_SAVE_FLIGHT = 39
CAT_SERVICES = 50
CAT_BP_MENU = 51
CAT_AVITAB = 53
CAT_AVITAB_ACT = 54
CAT_CREDITS = 99
CAT_DOORS = 55
CAT_LIGHTS = 56
CAT_FAILURES = 57
CAT_FAIL_ELEC = 58
CAT_FAIL_HYD = 59
CAT_FAIL_SYS = 60
CAT_FAIL_PRESSURIS = 61
CAT_FAIL_ENG = 62

CAT_FUEL_CG = 33
CAT_PAY_PERF = 44
CAT_PERF_LAND = 45
CAT_PERF_TAKEOFF = 46
CAT_APP_RATING = 70

CAT_OPTION_EXTERIOR = 81
CAT_OPTION_SYSTEMS = 82
CAT_OPTION_DISPLAYS = 83
CAT_OPTION_FMS = 84
CAT_OPTION_AUTOFLIGHT = 85
CAT_OPTION_CALLOUTS = 86
CAT_OPTION_PLACARDS = 87

CAT_AUTO_FLIGHT = 90

--- Arms are in meters -------
-- DEFAULT_ARM = 16.8783		-- 664.5 in
-- MAIN_TANK_ARM = 16.9164		-- 666.0 in
-- CENTER_TANK_ARM = 15.3924	-- 606.0 in
------------------------------

CL_PRELIM = 17
CL_CDU = 3
CL_CPT_PREFLT = 28
CL_FO_PREFLT = 48
CL_BEFORE_START = 5
CL_PUSHBACK = 4
CL_ENG_START = 22	--12
CL_BEFORE_TAXI = 14
CL_TAKEOFF = 24		--25
CL_CLIMB_CRUISE = 9		--8
CL_DESCENT = 8
CL_APPROACH = 8
CL_LANDING_ILS = 12
CL_LANDING_IAN = 12
CL_LANDING_VNAV = 12
CL_GOAROUND = 8
CL_AFTER_LAND = 8
CL_SHUTDOWN = 20
CL_SECURE = 4

CL_PRELIM_D = 19
CL_CDU_D = 34
CL_CPT_PREFLT_D = 28
CL_FO_PREFLT_D = 48
CL_BEFORE_START_D = 10
CL_PUSHBACK_D = 6
CL_ENG_START_D = 22		--12
CL_BEFORE_TAXI_D = 14
CL_TAKEOFF_D = 24		--25
CL_CLIMB_CRUISE_D = 9		--8
CL_DESCENT_D = 8
CL_APPROACH_D = 8
CL_LANDING_ILS_D = 12
CL_LANDING_IAN_D = 12
CL_LANDING_VNAV_D = 12
CL_GOAROUND_D = 8
CL_AFTER_LAND_D = 8
CL_SHUTDOWN_D = 24
CL_SECURE_D = 4


BASE_LIVERY_SET1 = 8
BASE_LIVERY_SET2 = 9
UNKNOWN_LIVERY_SET1 = 0
UNKNOWN_LIVERY_SET2 = 3
LIVERY_NUM = 7

KGS_LBS = 2.204622622

raw_table('livery_txt')
livery_txt = {
	[1] = "united", 
	[2] = "american", 
	[3] = "delta",
	[4] = "ryanair",
	[5] = "ryr",
	[6] = "southwest",
	[7] = "swa"
			}

raw_table('livery_set1')
livery_set1 = {
	[1] = 4,
	[2] = 8,
	[3] = 10,
	[4] = 11,
	[5] = 11,
	[6] = 7,
	[7] = 7
			}

raw_table('livery_set2')
livery_set2 = {
	[1] = 5,
	[2] = 9,
	[3] = 10,
	[4] = 12,
	[5] = 12,
	[6] = 8,
	[7] = 8
			}

LIGHT_PAX_WB = 0
LIGHT_PAX_LAND = 1
LIGHT_PAX_CRUISE = 2
LIGHT_PAX_WM = 3
LIGHT_PAX_NIGHT = 4
LIGHT_PAX_SLEEP = 5

LIGHT_ENTRY_WB = 0
LIGHT_ENTRY_WM = 1

raw_table('mem_axis_value')
mem_axis_value = {}
for ii = 0, 500 do
	-- mem_axis_value = {}
	mem_axis_value[ii] = 0
end

-- ELECTRIC FAILURES
--  0 AC Transfer Bus 1
--  1 AC Transfer Bus 2
--  2 AC Main Bus 1
--  3 AC Main Bus 2
--  4 AC Standby Bus
--  5 AC Ground Service Bus 1
--  6 AC Ground Service Bus 2
--  7 DC Hot Battery Bus
--  8 DC Switched Hot Battery Bus
--  9 DC Battery Bus
-- 10 DC Bus 1
-- 11 DC Bus 2
-- 12 DC Ground Service Bus
-- 13 DC Standby Bus
-- 14 TR1 unit
-- 15 TR2 unit
-- 16 TR3 unit

fail_elec_num = 32
raw_table('fail_elec_tab1')
fail_elec_tab1 = { "AC Buses:", " AC Transfer Bus 1", " AC Transfer Bus 2", " AC Main Bus 1", " AC Main Bus 2", " AC Standby Bus", " AC Ground Service Bus 1", " AC Ground Service Bus 2", " ",
				"DC Buses:", " DC Hot Battery Bus", " DC Switched Hot Battery Bus", " DC Battery Bus", " DC Bus 1", " DC Bus 2", " DC Ground Service Bus", " DC Standby Bus", " ",
				"Units:", " TR1 unit", " TR2 unit", " TR3 unit", "IDGS/GENERATORS:", " IDG1/ENGINE GENERATOR 1", " IDG2/ENGINE GENERATOR 2", " APU GENERATOR", " ",
				"Others:", " BPCU", " Relay BTB1", " Relay BTB2", " Relay TRU3"}
raw_table('fail_elec_tab2')
fail_elec_tab2 = { -1,  0,  1,  2,  3,  4,  5,  6, -1,
				   -1,  7,  8,  9, 10, 11, 12, 13, -1,
				   -1, 14, 15, 16, -1, 17, 18, 19, -1,
				   -1, 20, 21, 22, 23} 

-- HYDRAULIC FAILURES
--  0 - Fail system A
--  1 - Fail system B
--  2 - Fail system Standby
--  3 - Leak system A
--  4 - Leak system B
fail_hyd_num = 7
raw_table('fail_hyd_tab1')
fail_hyd_tab1 = { "Malfunction systems:", " System A", " System B", " System Standby",
                  "Leak fluid:", " System A", " System B" }
raw_table('fail_hyd_tab2')
fail_hyd_tab2 = { -1,  0,  1,  2, -1,  3,  4 }

fail_sys_num = 7
raw_table('fail_sys_tab1')
fail_sys_tab1 = { "Autoland:", " Land2", " Land3", "GPS systems:", " GPS signal (jamming)", " GPS L", " GPS R" }
raw_table('fail_sys_tab2')
fail_sys_tab2 = { -1,  0,  1, -1, 2, 3, 4 }

fail_pressurisation_num = 18
raw_table('fail_pressurisation_tab1')
fail_pressurisation_tab1 = { "Pressurization system:", " Rapid depressurization", " Slowly depressurization", " Outflow valve", " L Pack valve", " R pack valve",
							 " Isolation valve", " Pri pressurization unit", " Alt pressurization unit",
				  "Bleed system:", " Eng1 bleed valve", " Eng2 bleed valve", " APU bleed valve", " Eng1 High stage valve", " Eng2 High stage valve", 
				  " Eng1 Precooler valve", " Eng2 Precooler valve", " APU Pressurization" }
raw_table('fail_pressurisation_tab2')
fail_pressurisation_tab2 = { -1,  0,  1,  2,  3,  4,  5,  9,  10, 
							 -1, 7, 8, 6, 11, 12, 13, 14, 15 }

fail_eng_num = 33
raw_table('fail_eng_tab1')
fail_eng_tab1 = { "Main failures:", " L Engine fire", " R Engine fire", " L Engine Flameout", " R Engine Flameout",
                  " L Engine damage", " R Engine damage", " L Engine separate", " R Engine separate",
				  "Other failures:", " L Engine generator", " R Engine generator", " L Engine oil pump", " R Engine oil pump",
				  " L Engine oil qty", " R Engine oil qty", " EEC1 Flight data", " EEC2 Flight data",
				  " EEC1 Main unit", " EEC2 Main unit", " L Engine Hungstart", " R Engine Hungstart", " L Engine Hotstart", " R Engine Hotstart", " L Engine Birdstrike", " R Engine Birdstrike", " ", 
				  "APU:", " FIRE", " STARTING/RUNNING", " OVERSPEED", " LOW OIL QUANTITY", " LOW OIL PRESSURE"}
raw_table('fail_eng_tab2')
fail_eng_tab2 = { -1, 0, 1, 2, 3, 4, 5, 6, 7, 
				  -1, 8, 9, 10, 11, 12, 13, 14, 15,
				  16, 17, 23, 24, 25, 26, 27, 28, -1, 
				  -1, 18, 19, 20, 21, 22}

raw_table('el_failure_mem')
el_failure_mem = {}
raw_table('hyd_failure_mem')
hyd_failure_mem = {}
raw_table('sys_failure_mem')
sys_failure_mem = {}
raw_table('pressurisation_failure_mem')
pressurisation_failure_mem = {}
raw_table('engine_failure_mem')
engine_failure_mem = {}

failures_changed = 0
raw_table('failure_changed')
failure_changed = {}

for ii = 0, 69 do
	el_failure_mem[ii] = 0
	hyd_failure_mem[ii] = 0
	sys_failure_mem[ii] = 0
	pressurisation_failure_mem[ii] = 0
	engine_failure_mem[ii] = 0
	failure_changed[ii] = 0
end

-- --*************************************************************************************--
-- --** 					            GLOBAL VARIABLES                				 **--
-- --*************************************************************************************--



-- --*************************************************************************************--
-- --** 					            LOCAL VARIABLES                 				 **--
-- --*************************************************************************************--

cg_loc_800 = 16.65732

cat = 0
page = 0
min_page = 0
max_page = 0
checklist_offset = 0

display_update = 0

line_select = 0

raw_table('line')
line = {}
raw_table('line_s')
line_s = {}
raw_table('line_g')
line_g = {}
raw_table('line_a')
line_a = {}
raw_table('line_c')
line_c = {}
raw_table('line_cs')
line_cs = {}
raw_table('line_bs')
line_bs = {}
for ii = 0, 9 do
	line[ii] = ""
	line_s[ii] = ""
	line_g[ii] = ""
	line_a[ii] = ""
	line_c[ii] = ""
	line_cs[ii] = ""
	line_bs[ii] = ""
end

raw_table('item_checked')
item_checked = {}
for ii = 0, 511 do
	item_checked[ii] = 0
end

-- xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])

-- xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])

-- Simply Checklist 183
raw_table('item_sw')
item_sw = 		{145, 125, 140, 146, 147, 148, 150, 76, 77, 151,
				 171, 196, 88, 155, 156, 158, 124, 47, 47, 47,
				 159, 160, 217, 153, 49, 166, 162, 78, 79, 168,
				 168, 80, 41, 66, 67, 502, 507, 505, 503, 56,
				 124, 501, 170, 60, 68, 0, 0, 0, 188, 206,
				 152, 126, 51, 209, 172, 112, 173, 142, 211, 174,
				 143, 122, 129, 215, 213, 55, 200, 102, 111, 109,
				 2, 161, 154, 50, 164, 86, 87, 169, 169, 42,
				 203, 88, 121, 81, 180, 45, 181, 59, 69, 64,
				 182, 63, 183, 0, 0, 0, 147, 47, 45, 41,
				 
				 11, 63, 124, 0, 213, 0, 134, 0, 110, 45, 
				 0, 602, 0, 110, 45, 110, 134, 0, 0, 109,
				 45, 0, 601, 0, 109, 45, 109, 186, 122, 129,
				 215, 134, 136, 139, 112, 109, 501, 0, 503, 508,
				 180, 0, 10, 0, 105, 103, 63, 0, 102, 505,
				 0, 506, 0, 41, 0, 504, 0, 10, 503, 0,
				 9, 7, 109, 121, 504, 0, 102, 211, 0, 160,
				 41, 0, 47, 47, 0, 178, 190, 0, 47, 94,
				 58, 121, 0, 113, 0, 102, 90, 0, 92, 47,
				 6, 41, 0, 504, 70, 503, 109, 502, 71, 0,
				
				 503, 2, 6, 41, 0, 504, 70, 503, 109, 502,
				 71, 0, 503, 2, 3, 0, 2, 504, 70, 503,
				 109, 502, 71, 503, 0, 2, 506, 503, 0, 504,
				 2, 503, 0, 5, 121, 502, 122, 102, 109, 96,
				 503, 63, 124, 112, 501, 91, 106, 126, 127, 128,
				 129, 215, 213, 132, 134, 136, 137, 139, 106, 14,
				 63, 112, 140, 142, 143, 134, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
				}

raw_table('item_sw2')
item_sw2 = 		{0, 112, 141, 0, 0, 149, 0, 0, 0, 0,
				 0, 84, 0, 0, 157, 0, 0, 48, 48, 48,
				 0, 0, 218, 0, 0, 0, 163, 0, 0, 0,
				 0, 0, 43, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 207, 58, 0, 0, 0, 0, 0, 0,
				 205, 208, 0, 210, 0, 0, 0, 0, 0, 175,
				 144, 123, 0, 216, 214, 0, 177, 106, 0, 110,
				 10, 0, 0, 0, 165, 0, 0, 0, 0, 44,
				 0, 0, 0, 0, 0, 46, 0, 61, 0, 65,
				 0, 0, 0, 0, 0, 0, 184, 48, 0, 42,
				 
				 10, 0, 0, 0, 214, 0, 135, 0, 0, 46,
				 0, 0, 0, 0, 0, 0, 135, 0, 0, 0, 
				 46, 0, 0, 0, 0, 0, 0, 187, 123, 0,
				 216, 135, 0, 0, 0, 110, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 117, 0, 0, 119, 0,
				 0, 0, 0, 42, 0, 0, 0, 3, 0, 0,
				 0, 8, 110, 0, 0, 0, 119, 0, 0, 161,
				 42, 0, 48, 48, 0, 0, 191, 0, 48, 95,
				 59, 0, 0, 0, 0, 119, 91, 0, 93, 48,
				 0, 42, 0, 0, 0, 0, 110, 0, 0, 0,
				 
				 0, 0, 0, 42, 0, 0, 0, 0, 110, 0,
				 0, 0, 0, 0, 4, 0, 0, 0, 0, 0,
				 110, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 123, 106, 110, 97,
				 0, 0, 0, 125, 0, 0, 0, 208, 0, 0,
				 0, 216, 214, 133, 135, 0, 138, 0, 0, 15,
				 0, 0, 141, 0, 144, 135, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
				}

-- Detailed checklist
raw_table('item_D_sw')
item_D_sw = 	{145, 125, 140, 146, 147, 148, 150, 76, 77, 151,
				 171, 0, 196, 84, 88, 155, 156, 158, 124, 0,
				 0, 47, 47, 47, 0, 47, 47, 0, 0, 47,
				 47, 47, 47, 0, 47, 0, 47, 47, 0, 0,
				 47, 47, 47, 47, 47, 0, 47, 47, 47, 0,
				 47, 47, 47, 159, 160, 217, 153, 49, 166, 162,
				 78, 79, 168, 168, 80, 41, 66, 67, 502, 507,
				 505, 503, 56, 124, 501, 170, 60, 68, 0, 0,
				 0, 188, 206, 152, 126, 51, 209, 172, 112, 173,
				 142, 211, 174, 143, 122, 129, 215, 213, 55, 200,
				 
				 102, 111, 109, 2, 161, 154, 50, 164, 86, 87,
				 169, 169, 42, 203, 88, 121, 81, 180, 45, 181,
				 61, 69, 64, 182, 63, 183, 0, 0, 0, 147,
				 47, 45, 41, 0, 16, 11, 3, 10, 2, 63,
				 124, 0, 213, 85, 199, 0, 134, 0, 110, 45,
				 0, 602, 0, 110, 45, 110, 0, 0, 0, 109,
				 45, 0, 601, 0, 109, 45, 109, 186, 122, 129,
				 215, 134, 136, 139, 112, 109, 501, 0, 503, 508,
				 180, 0, 10, 0, 105, 103, 63, 0, 102, 505,
				 0, 506, 0, 41, 0, 504, 0, 10, 503, 0,
				 
				 9, 7, 109, 121, 504, 0, 102, 211, 0, 160, 
				 41, 0, 47, 47, 0, 178, 190, 0, 47, 94,
				 58, 121, 0, 113, 0, 102, 90, 0, 92, 47,
				 6, 41, 0, 504, 70, 503, 109, 502, 71, 0,
				 503, 2, 6, 41, 0, 504, 70, 503, 109, 502,
				 71, 0, 503, 2, 3, 0, 2, 504, 70, 503,
				 109, 502, 71, 503, 0, 2, 506, 503, 0, 504,
				 2, 503, 0, 5, 121, 502, 122, 102, 109, 96,
				 503, 63, 124, 0, 185, 82, 501, 91, 106, 126,
				 127, 128, 129, 215, 0, 192, 194, 132, 134, 136,
				 
				 137, 139, 106, 14, 63, 112, 140, 142, 143, 134,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
				}

raw_table('item_D_sw2')
item_D_sw2 = 	{0, 112, 141, 0, 0, 149, 0, 0, 0, 0,
				 0, 0, 0, 54, 0, 0, 157, 0, 0, 0,
				 0, 48, 48, 48, 0, 48, 48, 0, 0, 48,
				 48, 48, 48, 0, 48, 0, 48, 48, 0, 0,
				 48, 48, 48, 48, 48, 0, 48, 48, 48, 0,
				 48, 48, 48, 0, 0, 218, 0, 0, 0, 163,
				 0, 0, 0, 0, 0, 43, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 207, 58, 0, 0, 0,
				 0, 0, 0, 205, 208, 0, 210, 0, 0, 0,
				 0, 0, 175, 144, 123, 0, 216, 214, 0, 177,
				 
				 106, 0, 110, 10, 0, 0, 0, 165, 0, 0,
				 0, 0, 44, 0, 0, 0, 0, 0, 46, 0,
				 59, 0, 65, 0, 0, 0, 0, 0, 0, 184,
				 48, 0, 42, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 214, 0, 46, 0, 135, 0, 0, 46, 
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 46, 0, 0, 0, 0, 0, 0, 187, 123, 0,
				 216, 135, 0, 0, 0, 110, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 117, 0, 0, 119, 0,
				 0, 0, 0, 42, 0, 0, 0, 3, 0, 0,
				 
				 0, 8, 110, 0, 0, 0, 119, 0, 0, 161, 
				 42, 0, 48, 48, 0, 0, 191, 0, 48, 95,
				 59, 0, 0, 0, 0, 119, 91, 0, 93, 48,
				 0, 42, 0, 0, 0, 0, 110, 0, 0, 0,
				 0, 0, 0, 42, 0, 0, 0, 0, 110, 0,
				 0, 0, 0, 0, 4, 0, 0, 0, 0, 0,
				 110, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				 0, 0, 0, 0, 0, 0, 123, 106, 110, 97,
				 0, 0, 0, 0, 201, 83, 0, 0, 0, 208,
				 0, 0, 0, 216, 0, 193, 195, 133, 135, 0,
				 
				 138, 0, 0, 15, 0, 0, 141, 0, 144, 135,
				 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
				}

-- Switches, instruments 150
raw_table('item_x')
item_x = 	{0, 0.028, -0.009, -0.009, -0.072, -0.005, 0.12, 0.157, -0.071, -0.04,
			 -0.103, -0.2, 0.201, -0.178, 0.181, -0.149, 0, 0, 0, 0,
			 0, 0.028, -0.015, -0.015, -0.08, -0.015, 0.14, 0.165, -0.08, -0.049,
			 -0.113, -0.207, 0.207, -0.187, 0.187, -0.168, 0, 0, 0, 0,
			 -0.525, 0.5, -0.3, 0.3, 0.03, 0, -0.18, 0.18, -0.675, 0.675,
			 -0.11, 0.09, 0.095, 0.075, 0.26, 0.1, 0.225, -0.15, 0.15, -0.15,
			 0.15, -0.15, 0, -0.15, 0.15, -0.138, -0.138, -0.15, 0.15, 0.155,
			 -0.27, 0, 0, 0, 0, -0.21, -0.11, -0.32, -0.295, -0.24,
			 0.04, -0.156, -0.062, 0.127, -0.302, 0.27, 0.245, 0.086, -0.15, -0.018,
			 0.017, -0.263, 0.263, -0.333, 0.263, -0.343, 0.254, 0, 0, -0.256,
			
			 0, -0.2, -0.145, -0.093, 0.194, 0.228, 0.254, 0.276, -0.015, 0.102,
			 0.043, -0.068, 0.352, 0, 0, 0, -0.231, 0, -0.176, -0.12,
			 0.05, 0.097, 0.123, -0.08, -0.111, -0.3, -0.097, -0.067, 0.078, 0.142,
			 0.11, 0.3, 0.22, 0.21, 0.308, 0.26, 0.21, 0.308, 0.248, -0.147,
			 -0.075, 0.006, 0.07, 0.15, -0.146, 0.26, 0.19, -0.57, 0.57, -0.225,
			 0, -0.227, -0.89, 0.92, 0.222, 0.232, 0.285, 0.3, -0.212, -0.3,
			 0.3, -0.435, -0.377, 0.435, 0.377, -0.67, -0.295, -0.247, 0.328, 0.066,
			 0.11, 0.117, 0, -0.076, -0.002, 0.25, 0.234, 0.234, -0.052, -0.019,
			 0, 0, 0.105, 0.186, -0.132, -0.156, -0.062, -0.24, 0, -0.405,
			 0.405, 0.064, 0.155, 0.13, 0.092, 0.156, -0.017, -0.29, -0.002, 0.29,
			 
			 -0.087, 0, 0.305, -0.15, -0.295, -0.26, 0.1, -0.22, -0.112, -0.112,
			 0, 0, 0.078, 0.143, 0.127, 0.156, -0.14, 0.14, 0, 0
			}

raw_table('item_y')
item_y = 	{0, -0.27, -0.24, -0.24, -0.25, -0.25, -0.23, -0.23, -0.24, -0.27,
			 -0.27, -0.27, -0.27, -0.251, -0.251, -0.24, 0, 0, 0, 0,
			 0, -0.27, -0.27, -0.27, -0.25, -0.25, -0.25, -0.25, -0.27, -0.27,
			 -0.27, -0.27, -0.27, -0.26, -0.26, -0.26, 0, 0, 0, 0,
			 -0.02, -0.02, -0.02, -0.02, -0.02, -0.2, -0.14, -0.14, 0.01, 0.01,
			 -0.8, -0.55, -0.46, -1.11, -0.73, 0.02, 0.02, -0.77, -0.77, -0.71,
			 -0.71, -1.05, -0.845, -0.84, -0.84, 0, -0.03, -0.93, -0.93, 0.02,
			 0.02, 0, 0, 0, 0, -1.05, -1.17, 0.015, 0.015, 0.015,
			 0.015, -0.55, -0.55, -1.1, -0.9, 0.015, 0.015, -1.05, -1.17, -0.6,
			 -0.6, -0.28, -0.28, -0.275, -0.275, -0.25, -0.25, 0, 0, -0.41,
			
			 0, -0.41, -0.41, -0.41, -0.41, -0.41, -0.41, -0.41, -0.4, -0.4,
			 -0.41, -0.41, -0.12, 0, 0, 0, -0.41, 0, -0.41, -0.41,
			 0, -0.9, -0.9, -0.59, -0.61, -0.53, -0.78, -0.78, -0.79, -0.79,
			 -0.69, -0.775, -0.775, -0.72, -0.72, -0.71, -0.64, -0.64, -0.64, -1.105,
			 -1.105, -0.67, -0.93, -0.93, -0.79, -0.97, -1.15, -1.15, -1.15, -1.18,
			 -1.17, -0.68, -0.44, -0.44, -1.19, -1.13, -1.13, -1.3, 0.01, -0.25,
			 -0.25, 0, 0, 0, 0, -0.05, -0.67, 0.01, 0.01, -0.57,
			 -1.18, -0.63, -0.71, -0.46, -0.46, -0.9, -0.55, -0.5, -0.01, 0.01,
			 -0.71, -0.77, -1.13, -1.94, -0.53, -0.53, -0.53, -0.93, 0, -0.29,
			 -0.29, -0.72, -0.72, -0.72, -0.72, -1.15, -0.55, 0.81, 0.01, -0.5,
			 
			 -0.53, -0.99, -0.08, -1.0, -0.68, -0.73, -0.57, -0.53, -0.655, -0.61,
			 -0.59, 0, -0.7, -0.7, -0.79, -0.79, -0.25, -0.25, 0, 0
			}

raw_table('item_z')
item_z = 	{0, 0.312, 0.325, 0.301, 0.28, 0.28, 0.32, 0.32, 0.325, 0.315,
			 0.304, 0.313, 0.313, 0.285, 0.285, 0.32, 0, 0, 0, 0,
			 0, 0.313, 0.33, 0.308, 0.285, 0.285, 0.33, 0.33, 0.33, 0.313,
			 0.305, 0.313, 0.313, 0.29, 0.29, 0.32, 0, 0, 0, 0,
			 0, 0, 0, 0, 0, -0.2, -0.16, -0.16, 0.03, 0.03,
			 0.75, 0.63, 0.6, 0.87, 0.73, 0.14, 0.135, -0.3, -0.3, -0.3,
			 -0.3, -0.3, -0.3, -0.3, -0.3, 0.04, -0.05, -0.3, -0.3, 0.14,
			 0.115, 0, 0, 0, 0, 0.86, 0.89, 0.103, 0.103, 0.11,
			 0.11, 0.645, 0.645, 0.86, 0.8, 0.103, 0.103, 0.865, 0.89, 0.65,
			 0.65, 0.32, 0.32, 0.322, 0.322, 0.277, 0.277, 0, 0, 0.57,
			
			 0, 0.56, 0.57, 0.57, 0.57, 0.57, 0.57, 0.57, 0.56, 0.56,
			 0.57, 0.56, -0.18, 0, 0, 0, 0.57, 0, 0.56, 0.57,
			 0.14, 0.79, 0.79, -0.185, 0.65, 0.635, 0.73, 0.73, 0.74, 0.74,
			 0.71, 0.735, 0.735, 0.7, 0.7, 0.7, 0.67, 0.67, 0.67, 0.87,
			 0.87, 0.66, 0.81, 0.81, 0.72, 0.82, -0.3, 0.8, 0.8, 0.86,
			 0.887, 0.68, -0.31, -0.31, 0.89, 0.89, 0.89, -0.59, 0.145, 0.31,
			 0.31, 0.12, 0.12, 0.12, 0.12, -0.032, 0.69, 0.149, 0.139, -0.26,
			 0.9, -0.32, 0.71, 0.59, 0.59, 0.78, 0.63, 0.61, 0.127, 0.117,
			 -0.3, -0.3, -0.28, 0.155, 0.61, 0.61, 0.61, 0.82, 0, 0.3,
			 0.3, 0.695, 0.695, 0.695, 0.695, 0.87, 0.64, 0.75, 0.117, 0.61,
			 
			 0.61, -0.3, -0.18, -0.3, 0.68, 0.73, -0.26, 0.635, -0.312, -0.31,
			 0.65, 0, 0.7, 0.7, 0.74, 0.74, 0.3, 0.3, 0, 0
			}

raw_table('max_pax_layout')
max_pax_layout = {160, 180, 187, 189, 138, 215, 214, 180, 179, 174}

info_act = 0
info_act_old = 0
info_pos_tgt = 0

boot_cnt = 0
numpad_ref = 0
numpad_point = 0
tab_numpad_val = ""

cl_active = 0
cl_pos = 0
cl_pos_tgt = 0
cl_cpt_fo = 0

raw_table('flap_detents_txt')
flap_detents_txt = { "UP", " 1", " 2", " 5", "10", "15", "25", "30", "40"}
flap_detents = 0

raw_table('speedbrake_detents_txt')
speedbrake_detents_txt = { "   ARM", "FLIGHT"}
speedbrake_detents = 0

checklist_page = 1

cl_prelim_idx = 0
cl_cdu_idx = cl_prelim_idx + CL_PRELIM
cl_cpt_preflt_idx = cl_cdu_idx + CL_CDU
cl_fo_preflt_idx = cl_cpt_preflt_idx + CL_CPT_PREFLT
cl_before_start_idx = cl_fo_preflt_idx + CL_FO_PREFLT
cl_pushback_idx = cl_before_start_idx + CL_BEFORE_START
cl_eng_start_idx = cl_pushback_idx + CL_PUSHBACK
cl_before_taxi_idx = cl_eng_start_idx + CL_ENG_START
cl_takeoff_idx = cl_before_taxi_idx + CL_BEFORE_TAXI
cl_climb_cruise_idx = cl_takeoff_idx + CL_TAKEOFF
cl_descent_idx = cl_climb_cruise_idx + CL_CLIMB_CRUISE
cl_approach_idx = cl_descent_idx + CL_DESCENT
cl_landing_ils_idx = cl_approach_idx + CL_APPROACH
cl_landing_ian_idx = cl_landing_ils_idx + CL_LANDING_ILS
cl_landing_vnav_idx = cl_landing_ian_idx + CL_LANDING_IAN
cl_goaround_idx = cl_landing_vnav_idx + CL_LANDING_VNAV
cl_after_land_idx = cl_goaround_idx + CL_GOAROUND
cl_shutdown_idx = cl_after_land_idx + CL_AFTER_LAND
cl_secure_idx = cl_shutdown_idx + CL_SHUTDOWN

cl_prelim_idx2 = 0
cl_cdu_idx2 = cl_prelim_idx2 + CL_PRELIM_D
cl_cpt_preflt_idx2 = cl_cdu_idx2 + CL_CDU_D
cl_fo_preflt_idx2 = cl_cpt_preflt_idx2 + CL_CPT_PREFLT_D
cl_before_start_idx2 = cl_fo_preflt_idx2 + CL_FO_PREFLT_D
cl_pushback_idx2 = cl_before_start_idx2 + CL_BEFORE_START_D
cl_eng_start_idx2 = cl_pushback_idx2 + CL_PUSHBACK_D
cl_before_taxi_idx2 = cl_eng_start_idx2 + CL_ENG_START_D
cl_takeoff_idx2 = cl_before_taxi_idx2 + CL_BEFORE_TAXI_D
cl_climb_cruise_idx2 = cl_takeoff_idx2 + CL_TAKEOFF_D
cl_descent_idx2 = cl_climb_cruise_idx2 + CL_CLIMB_CRUISE_D
cl_approach_idx2 = cl_descent_idx2 + CL_DESCENT_D
cl_landing_ils_idx2 = cl_approach_idx2 + CL_APPROACH_D
cl_landing_ian_idx2 = cl_landing_ils_idx2 + CL_LANDING_ILS_D
cl_landing_vnav_idx2 = cl_landing_ian_idx2 + CL_LANDING_IAN_D
cl_goaround_idx2 = cl_landing_vnav_idx2 + CL_LANDING_VNAV_D
cl_after_land_idx2 = cl_goaround_idx2 + CL_GOAROUND_D
cl_shutdown_idx2 = cl_after_land_idx2 + CL_AFTER_LAND_D
cl_secure_idx2 = cl_shutdown_idx2 + CL_SHUTDOWN_D

door_ratio_fwd_L_trg = 0
door_ratio_fwd_R_trg = 0
door_ratio_aft_L_trg = 0
door_ratio_aft_R_trg = 0
door_ratio_aft_cargo_trg = 0
door_ratio_fwd_cargo_trg = 0
door_ratio_emerg1_trg = 0
door_ratio_emerg2_trg = 0
door_ratio_emerg3_trg = 0
door_ratio_emerg4_trg = 0
door_ratio_emerg5_trg = 0
door_ratio_emerg6_trg = 0
door_ratio_aft1_trg = 0
door_ratio_aft2_trg = 0

livery = ""
livery_path = ""
livery_idx = -1

de_ice_apply_time = 0

--req_fuel = 0

zxp = 0
raw_table('zone1_pax')
zone1_pax = {}
raw_table('zone2_pax')
zone2_pax = {}
raw_table('zone3_pax')
zone3_pax = {}
raw_table('zone4_pax')
zone4_pax = {}
raw_table('zone5_pax')
zone5_pax = {}
for zxp = 1, 3 do
	zone1_pax[zxp] = 0
	zone2_pax[zxp] = 0
	zone3_pax[zxp] = 0
	zone4_pax[zxp] = 0
	zone5_pax[zxp] = 0
end
zone_cargo1 = 0
zone_cargo2 = 0
cor_time = 0
req_payload_weight = 0
zone_weight_req = {}
zone_weight_req[0] = 0
zone_weight_req[1] = 0
zone_weight_req[2] = 0
zone_weight_req[3] = 0
zone_weight_req[4] = 0
crew_weight_f_req = 0
crew_weight_r_req = 0
cargo1_weight_req = 0
cargo2_weight_req = 0

full_crew_weight = 0	--1587 -- kg
full_crew_weight_f = 0
full_crew_weight_r = 0

-- Zibo uses a 524 kg base crew allowance in OEW calculations.
-- With this ACF that allowance is already part of the empty/OEW mass, so it must not
-- be written a second time into X-Plane sim/flightmodel/weight/m_fixed.
function physical_crew_payload_weight()
	return math.max(full_crew_weight - 524, 0)
end

shift_xp = 0
gw_tow_state = 0

-- PERF
tora = 2011
clearway = 1005
stopway = 0
slope = 0.15
ae_go = 1616
eo_go = 1627
ae_stop = 1573
a_weight = 50000

perf_arpt = ""
perf_arpt_old = ""
perf_rwy = 0
perf_intx = 0
perf_cond = "DRY"
perf_wind_dir = 0
perf_wind_spd = 0
perf_oat = 15
perf_qnh = 1013
perf_rtg = "OPTIMUM"
perf_atm = "MAX"
perf_flap = "5"
perf_ac = "AUTO"
perf_ai = "OFF"
perf_weight = 0
perf_cg = 0

perf_head_wind = 0
perf_cross_wind = 0

perf_lnd_arpt = ""
perf_lnd_arpt_old = ""
perf_lnd_rwy = 0
perf_lnd_flap = "40"
perf_lnd_ac = "AUTO"
perf_lnd_ai = "OFF"
perf_lnd_brks = "ALL"
perf_lnd_wind_dir = 0
perf_lnd_wind_spd = 0
perf_lnd_oat = 15
perf_lnd_qnh = 1013
perf_lnd_weight = 0
perf_lnd_vref_add = 5
perf_lnd_cond = "DRY"
perf_lnd_reverse = "NO CREDIT"

perf_lnd_head_wind = 0
perf_lnd_cross_wind = 0

perf_ref_rwy_num = 0
raw_table('perf_ref_rwy_list')
perf_ref_rwy_list = {}
raw_table('perf_ref_rwy_list_len')
perf_ref_rwy_list_len = {}
raw_table('perf_ref_rwy_list_hdg')
perf_ref_rwy_list_hdg = {}
perf_ref_rwy_lst_num = 0
raw_table('perf_ref_rwy_lst')
perf_ref_rwy_lst = {}
raw_table('perf_ref_rwy_intx_num')
perf_ref_rwy_intx_num = {}
raw_table('perf_ref_rwy_intx')
perf_ref_rwy_intx = {}
perf_des_rwy_num = 0
raw_table('perf_des_rwy_list')
perf_des_rwy_list = {}
raw_table('perf_des_rwy_list_len')
perf_des_rwy_list_len = {}
raw_table('perf_des_rwy_list_hdg')
perf_des_rwy_list_hdg = {}

landing_rating = 0
app_rating = 0
land_app_rating_tmr = 0
refuel_enable = 0
efb_first_time = 0
land_app_rating = 0
airstair_ratio_tgt = 0

door_locked = 0
emerg_door_locked = 0

f_time = 0

fuel_start = 0
fuel_start_tmr = 0
fuel_end = 0
fuel_end_tmr = 0
fuel_tank_finish_arm = 0
fuel_tank_finish = 0
fuel_term_tmr = 0

display_update_cnt = 0

sam_tick = 0
payload_weight_old = 0

temp_wing_tank_kg = 3905
temp_max_fuel_kg = 20828

was_replay = 0

no_smoke_cycle = false
auto_flight_enable = false
auto_after_land = false
auto_pax_status = 0
auto_cargo_status = 0
auto_fuel_status = 0
auto_pax_tot = 0
auto_cargo_tot = 0
auto_req_fuel = 0
auto_payload_tot = 0
auto_zfw_tot = 0
auto_fuel_timer = 0
auto_pax_timer = 0
auto_cargo_timer = 0
auto_catter_status = 0
auto_catter_timer = 0
zone1_pax_tgt = 0
zone2_pax_tgt = 0
zone3_pax_tgt = 0
zone4_pax_tgt = 0
zone5_pax_tgt = 0
cargo1_tgt = 0
cargo2_tgt = 0

gp_cable_connect = 0

loaded_flight = false
mem_cat = 0
mem_page = 0
mem_min_page = 0
mem_max_page = 0

catering_operate_tmr = 0
belt_operate_tmr = 0
catering2_operate_tmr = 0
belt2_operate_tmr = 0
call_catering = false
call_catering2 = false

turn_around = 0

fireservice_state1 = 0
fireservice_tmr1 = 0
fireservice_tmr1x = 0
fireservice_state2 = 0
fireservice_tmr2 = 0
fireservice_tmr2x = 0

hide_fueltruck = 0

-- --*************************************************************************************--
-- --** 				             FIND X-PLANE DATAREFS            			    	 **--
-- --*************************************************************************************--

simDR_local_time			= find_dataref("sim/time/local_time_sec")
simDR_hide_yoke				= find_dataref("sim/graphics/view/hide_yoke")
simDR_fuel_tank_weight_kg 	= find_dataref("sim/flightmodel/weight/m_fuel")
simDR_total_weight			= find_dataref("sim/flightmodel/weight/m_total")
simDR_payload_weight		= find_dataref("sim/flightmodel/weight/m_fixed")
simDR_acf_m_empty		= find_dataref("sim/aircraft/weight/acf_m_empty")
simDR_payload_stations		= find_dataref("sim/flightmodel/weight/m_stations")

simDR_fuel_weight			= find_dataref("sim/flightmodel/weight/m_fuel_total")

simDR_cg					= find_dataref("sim/flightmodel/misc/cgz_ref_to_default")
simDR_cg_xp12				= find_dataref("sim/flightmodel2/misc/cg_offset_z")
simDR_gear_vert_force		= find_dataref("sim/flightmodel2/gear/tire_vertical_force_n_mtr")
simDR_radio_height_pilot_ft	= find_dataref("sim/cockpit2/gauges/indicators/radio_altimeter_height_ft_pilot")

simDR_pitch_nz 				= find_dataref("sim/joystick/joystick_pitch_nullzone")
simDR_roll_nz 				= find_dataref("sim/joystick/joystick_roll_nullzone")
simDR_yaw_nz 				= find_dataref("sim/joystick/joystick_heading_nullzone")
B738DR_pitch_nz 			= find_dataref("laminar/joystick/joystick_pitch_nullzone")
B738DR_roll_nz 				= find_dataref("laminar/joystick/joystick_roll_nullzone")
B738DR_yaw_nz 				= find_dataref("laminar/joystick/joystick_heading_nullzone")

simDR_head_x				= find_dataref("sim/aircraft/view/acf_peX")
simDR_startup_running 		= find_dataref("sim/operation/prefs/startup_running")

simDR_on_ground				= find_dataref("sim/flightmodel2/gear/on_ground")
simDR_aircraft_groundspeed 	= find_dataref("sim/flightmodel/position/groundspeed")
simDR_livery 				= find_dataref("sim/aircraft/view/acf_livery_path")
simDR_livery_idx			= find_dataref("sim/aircraft/view/acf_livery_index")

simDR_fps_period			= find_dataref("sim/time/framerate_period")
simDR_axis 					= find_dataref("sim/joystick/joystick_axis_values")

simDR_engine_on 			= find_dataref("sim/flightmodel2/engines/engine_is_burning_fuel")
simDR_view_is_external 		= find_dataref("sim/graphics/view/view_is_external")

-- --*************************************************************************************--
-- --** 				               FIND X-PLANE COMMANDS                   	    	 **--
-- --*************************************************************************************--


-- --*************************************************************************************--
-- --** 				              FIND CUSTOM DATAREFS             			    	 **--
-- --*************************************************************************************--

B738DR_parkbrake_remove_chock 	= find_dataref("laminar/B738/fms/parkbrake_remove_chock")
B738DR_toe_brakes_ovr			= find_dataref("laminar/B738/fms/toe_brakes_ovr")
B738DR_throttle_noise			= find_dataref("laminar/B738/fms/throttle_noise")
B738DR_lock_thrust				= find_dataref("laminar/B738/fms/lock_thrust")
B738DR_sync_thrust				= find_dataref("laminar/B738/fms/sync_thrust")
B738DR_nosewheel				= find_dataref("laminar/B738/effects/nosewheel")
B738DR_fuelgauge				= find_dataref("laminar/B738/effects/fuelgauge")
B738DR_track_up					= find_dataref("laminar/B738/fms/track_up")
B738DR_nd_rings					= find_dataref("laminar/B738/effect/nd_rings")
B738DR_flight_ctrl				= find_dataref("laminar/B738/effects/flight_control")
B738DR_brake_temp				= find_dataref("laminar/B738/effects/brake_temp")
B738DR_align_time				= find_dataref("laminar/B738/FMS/align_time")
B738DR_pause_td					= find_dataref("laminar/B738/fms/pause_td")
B738DR_tire_blown				= find_dataref("laminar/B738/effect/tire_blown")
B738DR_kill_windshield			= find_dataref("laminar/B738/perf/kill_windshield")
B738DR_hide_glass 				= find_dataref("laminar/B738/effect/hide_glass")
B738DR_hide_gauges_reflection	= find_dataref("laminar/B738/effect/gauges_reflection")
B738DR_hardware_thr_lever		= find_dataref("laminar/B738/effects/hardware_thr_lever")
B738DR_fmc_units				= find_dataref("laminar/B738/FMS/fmc_units")
B738DR_baro_in_hpa				= find_dataref("laminar/B738/fms/baro_in_hpa")
B738DR_min_baro_radio			= find_dataref("laminar/B738/fms/min_baro_radio")
B738DR_vor_radial				= find_dataref("laminar/B738/fms/vor_radial")
B738DR_fpln_format				= find_dataref("laminar/B738/fms/fpln_format")
B738DR_engine_no_running_state	= find_dataref("laminar/B738/fms/engine_no_running_state")
B738DR_chock_status				= find_dataref("laminar/B738/fms/chock_status")
B738DR_chock_on_startup 		= find_dataref("laminar/B738/fms/chock_on_startup")
B738DR_refuel_time				= find_dataref("laminar/B738/FMS/refuel_time")
B738DR_pax_time					= find_dataref("laminar/B738/FMS/pax_time")
B738DR_cargo_time				= find_dataref("laminar/B738/FMS/cargo_time")
B738DR_catering_time			= find_dataref("laminar/B738/FMS/catering_time")
B738DR_detail_cl				= find_dataref("laminar/B738/FMS/detail_cl")
B738DR_sync_pilot				= find_dataref("laminar/B738/effects/sync_pilot")
B738DR_sync_pilot_isdf			= find_dataref("laminar/B738/effects/sync_pilot_isdf")
B738DR_hide_seats				= find_dataref("laminar/B738/effects/hide_seats")
B738DR_int_gnd_services			= find_dataref("laminar/B738/effects/int_gnd_services")
B738DR_passengers				= find_dataref("laminar/B738/effects/passengers")
B738DR_irs_ding					= find_dataref("laminar/B738/effects/irs_ding")
B738DR_long_led_strobes			= find_dataref("laminar/B738/effects/long_led_strobes")
B738DR_wings_variant			= find_dataref("laminar/B738/wings_variant")
B738DR_satcom_variant			= find_dataref("laminar/B738/satcom_variant")
B738DR_pulse_lite				= find_dataref("laminar/B738/effects/pulse_lite")
B738DR_led_lights				= find_dataref("laminar/B738/led_lights")
B738DR_hud_disable				= find_dataref("laminar/B738/hud_disable")
B738DR_kill_led_lights			= find_dataref("laminar/B738/kill_led_lights")
B738DR_yoke_disco_ap			= find_dataref("laminar/B738/yoke_disco_ap")
B738DR_aoa_ra					= find_dataref("laminar/B738/aoa_ra")
B738DR_yoke_to_center			= find_dataref("laminar/B738/yoke_to_center")
B738DR_yoke_virtual				= find_dataref("laminar/B738/only_virtual_yoke")
B738DR_parkbrake_set			= find_dataref("laminar/B738/parkbrake_set")
B738DR_strobe_cockpit			= find_dataref("laminar/B738/strobe_cockpit")
B738DR_particle_rain			= find_dataref("laminar/B738/particle_rain")
B738DR_fps_enable				= find_dataref("laminar/B738/fps_enable")
B738DR_brunner_enable			= find_dataref("laminar/B738/brunner_enable")
B738DR_com_decimal				= find_dataref("laminar/B738/effects/com_decimal")
B738DR_smart_ap_knob			= find_dataref("laminar/B738/effects/smart_ap_knob")
B738DR_restrict_fms				= find_dataref("laminar/B738/fms/restrict_fms")
B738DR_mmr						= find_dataref("laminar/B738/fms/mmr")
B738DR_mmr_colour				= find_dataref("laminar/B738/fms/mmr_colour")
B738DR_ils_gls_annun			= find_dataref("laminar/B738/fms/ils_gls_annun")
B738DR_no_vcr_switch			= find_dataref("laminar/B738/fms/no_vcr_switch")
B738DR_isfd_rmi					= find_dataref("laminar/B738/isfd_rmi")
B738DR_yaw_damper				= find_dataref("laminar/B738/yaw_damper")
B738DR_gw_entry					= find_dataref("laminar/B738/fms/gw_entry")
B738DR_no_smoking	 			= find_dataref("laminar/B738/fms/no_smoking")
B738DR_aspirated_probe			= find_dataref("laminar/B738/fms/aspirated_probe")
B738DR_ra_callout_disable		= find_dataref("laminar/B738/fms/ra_callout_disable")
B738DR_fmc_input_lag			= find_dataref("laminar/B738/FMS/fmc_input_lag")
B738DR_xhsi_enable				= find_dataref("laminar/B738/xhsi_enable")
B738DR_white_bug				= find_dataref("laminar/B738/white_bug")
B738DR_gp_cable_connect			= find_dataref("laminar/B738/gp_cable_connect")
B738DR_chrono_variant			= find_dataref("laminar/B738/chrono_variant")
B738DR_cust_nav_data			= find_dataref("laminar/B738/effects/cust_nav_data")
B738DR_prior_tx_com				= find_dataref("laminar/B738/effects/prior_tx_com")
B738DR_pfd_fmc_flap_spd			= find_dataref("laminar/B738/pfd_fmc_flap_spd")
B738DR_nd_tcas_range			= find_dataref("laminar/B738/nd_tcas_range")
B738DR_takeoff_hdg				= find_dataref("laminar/B738/takeoff_hdg")
B738DR_go_around_hdg			= find_dataref("laminar/B738/go_around_hdg")
B738DR_init_ref_smart			= find_dataref("laminar/B738/init_ref_smart")
B738DR_std_pax_weight			= find_dataref("laminar/B738/std_pax_weight")
B738DR_std_pax_num				= find_dataref("laminar/B738/std_pax_num")
B738DR_zone_arm					= find_dataref("laminar/B738/zone_arm")
B738DR_pax_layout				= find_dataref("laminar/B738/pax_layout")
B738DR_oew_kg					= find_dataref("laminar/B738/oew_kg")
B738DR_fa_fwd_kg				= find_dataref("laminar/B738/fa_fwd_kg")
B738DR_fa_aft_kg				= find_dataref("laminar/B738/fa_aft_kg")
B738DR_galley_fwd_kg			= find_dataref("laminar/B738/galley_fwd_kg")
B738DR_galley_aft_kg			= find_dataref("laminar/B738/galley_aft_kg")
B738DR_ap_yoke_tolerance		= find_dataref("laminar/B738/FMS/ap_yoke_tolerance")
B738DR_fd_helper				= find_dataref("laminar/B738/fd_helper")
B738DR_cfy_enable				= find_dataref("laminar/B738/cfy_enable")
B738DR_cfy_trim_control			= find_dataref("laminar/B738/cfy_trim_control")
B738DR_sam_enable				= find_dataref("laminar/B738/sam_enable")
B738DR_passengers_hide			= find_dataref("laminar/B738/effects/passengers_hide")
B738DR_disable_fo_callout 		= find_dataref("laminar/b738/fmodpack/disable_fo_callout")
B738DR_fo_callout_var			= find_dataref("laminar/b738/fmodpack/fo_callout_var")
B738DR_vnav_alt_disable			= find_dataref("laminar/B738/fms/vnav_alt_disable")
-- B738DR_vnavalt_althld			= find_dataref("laminar/B738/fms/vnavalt_althld")
B738DR_fd_cam_disable			= find_dataref("laminar/B738/fd_cam_disable")
B738DR_selcal_disable			= find_dataref("laminar/B738/selcal_disable")
B738DR_manip_yoke				= find_dataref("laminar/B738/manip_yoke")
B738DR_manip_throttle			= find_dataref("laminar/B738/manip_throttle")
B738DR_manip_flaps				= find_dataref("laminar/B738/manip_flaps")
B738DR_manip_speedbrake			= find_dataref("laminar/B738/manip_speedbrake")
B738DR_manip_trimwheel			= find_dataref("laminar/B738/manip_trimwheel")
B738DR_manip_park_brake			= find_dataref("laminar/B738/manip_park_brake")
B738DR_manip_stab_trim			= find_dataref("laminar/B738/manip_stab_trim")
B738DR_manip_fuelcutout			= find_dataref("laminar/B738/manip_fuelcutout")
B738DR_manip_horn_cutout		= find_dataref("laminar/B738/manip_horn_cutout")

B738DR_def_clb_alt				= find_dataref("laminar/B738/def_clb_alt")
B738DR_def_clb_alt2				= find_dataref("laminar/B738/def_clb_alt2")
B738DR_def_cut_alt				= find_dataref("laminar/B738/def_cut_alt")
B738DR_def_accel_alt			= find_dataref("laminar/B738/def_accel_alt")
B738DR_def_eo_accel_alt			= find_dataref("laminar/B738/def_eo_accel_alt")

B738DR_plus_hundred				= find_dataref("laminar/B738/plus_hundred")
B738DR_vorloc_lnav				= find_dataref("laminar/B738/vorloc_lnav")
B738DR_fmc_type					= find_dataref("laminar/B738/fmc_type")
B738DR_raas						= find_dataref("laminar/B738/raas")
B738DR_not_airstairs			= find_dataref("laminar/B738/not_airstairs")
B738DR_use_ext_airstairs		= find_dataref("laminar/B738/use_ext_airstairs")
B738DR_yoke_input				= find_dataref("laminar/B738/yoke_input")

B738DR_engine_start_auto		= find_dataref("laminar/B738/engine_start_auto")
B738DR_probe_heat_auto			= find_dataref("laminar/B738/probe_heat_auto")
B738DR_autoland_install			= find_dataref("laminar/B738/autoland_install")
B738DR_nps_disable				= find_dataref("laminar/B738/nps_disable")
B738DR_ian_not_install			= find_dataref("laminar/B738/ian_install")
B738DR_autosave					= find_dataref("laminar/B738/autosave")
B738DR_fuel_pumps_off_placard	= find_dataref("laminar/B738/fuel_pumps_off_placard")
B738DR_cat3_placard				= find_dataref("laminar/B738/cat3_placard")
B738DR_brakes_placard			= find_dataref("laminar/B738/brakes_placard")
B738DR_ff_eicas					= find_dataref("laminar/B738/ff_eicas")
B738DR_digital_press_panel		= find_dataref("laminar/B738/digital_press_panel")
B738DR_no_rte2					= find_dataref("laminar/B738/no_rte2")
B738DR_gs_on_pfd				= find_dataref("laminar/B738/gs_on_pfd")
B738DR_spd_intv_but				= find_dataref("laminar/B738/spd_intv_but")
B738DR_alt_intv_but				= find_dataref("laminar/B738/alt_intv_but")
B738DR_vanish_y					= find_dataref("laminar/B738/vanish_y")
B738DR_old_mcp					= find_dataref("laminar/B738/old_mcp")
B738DR_rmi						= find_dataref("laminar/B738/rmi")
B738DR_sfp						= find_dataref("laminar/B738/sfp")
B738DR_at_wakeup				= find_dataref("laminar/B738/pfd/at_wakeup")
B738DR_plan_fuel				= find_dataref("laminar/B738/plan_fuel")
B738DR_oil_qty_pct_qts			= find_dataref("laminar/B738/oil_qty_pct_qts")
B738DR_vnav_wakeup_idle			= find_dataref("laminar/B738/vnav_wakeup_idle")
B738DR_nd_arpt_rw_lenght		= find_dataref("laminar/B738/nd_arpt_rw_lenght")
B738DR_guarded_covers			= find_dataref("laminar/B738/guarded_covers")
B738DR_ra_radio_altimeter		= find_dataref("laminar/B738/ra_radio_altimeter")
B738DR_ra_decision_height		= find_dataref("laminar/B738/ra_decision_height")
B738DR_ra_500_1000_baro			= find_dataref("laminar/B738/ra_500_1000_baro")
B738DR_missed_app_colour		= find_dataref("laminar/B738/missed_app_colour")
B738DR_high_alt_ldg				= find_dataref("laminar/B738/high_alt_ldg")
B738DR_ra_minimums				= find_dataref("laminar/B738/ra_minimums")
B738DR_vnav_common				= find_dataref("laminar/B738/vnav_common")
B738DR_ext_payload				= find_dataref("laminar/B738/ext_payload")
-- B738DR_eicas_full_n1			= find_dataref("laminar/B738/eicas_full_n1")
B738DR_eicas_n1_num				= find_dataref("laminar/B738/eicas_n1_num")
B738DR_double_derate			= find_dataref("laminar/B738/double_derate")
B738DR_single_cue_fd			= find_dataref("laminar/B738/single_cue_fd")
B738DR_fmc_beep_sound			= find_dataref("laminar/B738/fmc_beep_sound")
B738DR_vnav_baro_comp			= find_dataref("laminar/B738/vnav_baro_comp")
B738DR_lpv_install				= find_dataref("laminar/B738/lpv_install")
B738DR_app_ref_2nd_page			= find_dataref("laminar/B738/app_ref_2nd_page")
B738DR_gs_before_loc			= find_dataref("laminar/B738/gs_before_loc")

B738DR_max_rnd_fail				= find_dataref("laminar/b738/max_rnd_fail")
B738DR_add_fix_pgs				= find_dataref("laminar/b738/add_fix_pgs")
B738DR_def_app_rnp				= find_dataref("laminar/B738/def_app_rnp")
B738DR_def_dme_update			= find_dataref("laminar/B738/def_dme_update")
B738DR_cmu						= find_dataref("laminar/B738/cmu")
B738DR_cpdlc					= find_dataref("laminar/B738/cpdlc")
B738DR_online_network			= find_dataref("laminar/B738/online_network")
B738DR_metar_source				= find_dataref("laminar/B738/metar_source")

B738DR_pause_load_flt			= find_dataref("laminar/b738/pause_load_flt")

vanish_y_status					= find_dataref("laminar/b738/vanish_y_status")
B738DR_raas_not_installed		= create_dataref("laminar/B738/raas_not_installed", "number")
B738DR_xraas_installed			= find_dataref("laminar/B738/xraas_installed")

B738DR_probe_heat_tat			= create_dataref("laminar/B738/probe_heat_tat", "number")

file_path					= find_dataref("zibomod/Aircraft_Path")
B738DR_kill_old_mcp			= create_dataref("laminar/B738/kill_old_mcp", "number")
B738DR_cb_d9				= find_dataref("laminar/B738/cb/d9")

B738DR_fuel_start			= create_dataref("laminar/B738/fmod/fuel_start", "number")
B738DR_fuel_start2			= create_dataref("laminar/B738/fmod/fuel_start2", "number")
B738DR_fuel_end				= create_dataref("laminar/B738/fmod/fuel_end", "number")
B738DR_fuel_terminated		= create_dataref("laminar/B738/fmod/fuel_terminated", "number")

-- FMOD by AudioBird XP
B738DR_enable_pax_boarding	= find_dataref("laminar/b738/fmodpack/fmod_pax_boarding_on")
B738DR_enable_gyro			= find_dataref("laminar/b738/fmodpack/fmod_woodpecker_on")
B738DR_enable_crew			= find_dataref("laminar/b738/fmodpack/fmod_crew_on")
B738DR_enable_chatter		= find_dataref("laminar/b738/fmodpack/fmod_chatter_on")
B738DR_airport_set 			= find_dataref("laminar/b738/fmodpack/fmod_airport_set")
B738DR_vol_int_ducker 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_ducker")
B738DR_vol_int_eng 			= find_dataref("laminar/b738/fmodpack/fmod_vol_int_eng")
B738DR_vol_int_start 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_start")
B738DR_vol_int_ac 			= find_dataref("laminar/b738/fmodpack/fmod_vol_int_ac")
B738DR_vol_int_gyro 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_gyro")
B738DR_vol_int_roll 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_roll")
B738DR_vol_int_bump 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_bump")
B738DR_vol_int_pax 			= find_dataref("laminar/b738/fmodpack/fmod_vol_int_pax")
B738DR_vol_int_pax_applause = find_dataref("laminar/b738/fmodpack/fmod_pax_applause_on")
B738DR_enable_mutetrim		= find_dataref("laminar/b738/fmodpack/fmod_mutetrim_on")
B738DR_vol_airport			= find_dataref("laminar/b738/fmodpack/fmod_vol_airport")
B738DR_xp_int_vol			= find_dataref("laminar/b738/fmodpack/fmod_xp_int_vol")
B738DR_vol_int_XP 			= find_dataref("sim/operation/sound/interior_volume_ratio")

B738DR_enable_fmc_mute_on 	= find_dataref("laminar/b738/fmodpack/fmod_enable_fmc_mute_on")
B738DR_vol_PM 				= find_dataref("laminar/b738/fmodpack/fmod_vol_PM")
B738DR_vol_int_wind_vol 	= find_dataref("laminar/b738/fmodpack/fmod_vol_int_wind")
B738DR_vol_crew 			= find_dataref("laminar/b738/fmodpack/fmod_vol_crew")
B738DR_announcement_set 	= find_dataref("laminar/b738/fmodpack/fmod_announcement_set")
B738DR_pa_announc_set		= find_dataref("laminar/b738/fmodpack/pa_announ_set")
play_welcome_msg 			= find_dataref("laminar/b738/fmodpack/play_welcome_msg") 
play_cruise_msg 			= find_dataref("laminar/b738/fmodpack/play_cruise_msg") 
play_descent_msg 			= find_dataref("laminar/b738/fmodpack/play_descent_msg")
play_preland_msg 			= find_dataref("laminar/b738/fmodpack/play_preland_msg")
play_turbulence_msg 		= find_dataref("laminar/b738/fmodpack/play_turbulence_msg")
eq_high 					= find_dataref("laminar/b738/fmodpack/fmod_eq_high")
eq_mid 						= find_dataref("laminar/b738/fmodpack/fmod_eq_mid")
eq_low 						= find_dataref("laminar/b738/fmodpack/fmod_eq_low")
start_leg 					= find_dataref("laminar/b738/fmodpack/fmod_start_leg")
end_leg 					= find_dataref("laminar/b738/fmodpack/fmod_end_leg")
play_cargo 					= find_dataref("laminar/b738/fmodpack/fmod_play_cargo")
B738DR_vol_computer 		= find_dataref("laminar/b738/fmodpack/fmod_vol_computer")

B738DR_vol_FAC 				= find_dataref("laminar/b738/fmodpack/fmod_vol_FAC")
B738DR_vol_weather 			= find_dataref("laminar/b738/fmodpack/fmod_vol_weather")
B738DR_TO_trigger 			= find_dataref("laminar/b738/fmodpack/TO_trigger")
B738DR_vol_int_trim 		= find_dataref("laminar/b738/fmodpack/fmod_vol_int_trim")
is_command_cabindoor_closed = find_dataref("laminar/b738/fmodpack/cabindoor_closed")

B738DR_mute_switches		= find_dataref("laminar/B738/mute_switches")
B738DR_TO_airside			= find_dataref("laminar/b738/fmodpack/TO_airside")
B738DR_msg_airside			= find_dataref("laminar/b738/fmodpack/msg_airside")

B738DR_joy_axis_flap_lever	= find_dataref("laminar/B738/axis/flap_lever")
B738DR_joy_axis_heading 	= find_dataref("laminar/B738/axis/heading")
B738DR_joy_axis_pitch 		= find_dataref("laminar/B738/axis/pitch")
B738DR_joy_axis_roll 		= find_dataref("laminar/B738/axis/roll")
B738DR_flap_detents			= find_dataref("laminar/B738/fms/flap_detents")
B738DR_flap_detents_thr		= find_dataref("laminar/B738/fms/flap_detents_thr")
simDR_heading_ratio2		= find_dataref("sim/cockpit2/controls/yoke_heading_ratio")
simDR_pitch_ratio2			= find_dataref("sim/cockpit2/controls/yoke_pitch_ratio")
simDR_roll_ratio2			= find_dataref("sim/cockpit2/controls/yoke_roll_ratio")


B738DR_cust_axis_speedbrake			= find_dataref("laminar/B738/flt_ctrls/speedbrake")
B738DR_cust_axis_flaps				= find_dataref("laminar/B738/flt_ctrls/flaps")
B738DR_cust_axis_speedbrake_arm		= find_dataref("laminar/B738/flt_ctrls/speedbrake_arm")
B738DR_cust_axis_speedbrake_flight	= find_dataref("laminar/B738/flt_ctrls/speedbrake_flight")
B738DR_cust_axis_speedbrake_noise	= find_dataref("laminar/B738/flt_ctrls/speedbrake_noise")
B738DR_cust_axis_flaps_mapped		= find_dataref("laminar/B738/flt_ctrls/flaps_mapped")
B738DR_cust_axis_speedbrake_mapped	= find_dataref("laminar/B738/flt_ctrls/speedbrake_mapped")
B738DR_cust_axis_flaps_reverse		= find_dataref("laminar/B738/flt_ctrls/flaps_reverse")
B738DR_cust_axis_speedbrake_reverse	= find_dataref("laminar/B738/flt_ctrls/speedbrake_reverse")
B738DR_cust_axis_landgear			= find_dataref("laminar/B738/flt_ctrls/landgear")
B738DR_cust_axis_landgear_mapped	= find_dataref("laminar/B738/flt_ctrls/landgear_mapped")
B738DR_cust_axis_landgear_off		= find_dataref("laminar/B738/flt_ctrls/landgear_off")
B738DR_cust_axis_landgear_reverse	= find_dataref("laminar/B738/flt_ctrls/landgear_reverse")
B738DR_cust_axis_mixture1			= find_dataref("laminar/B738/flt_ctrls/mixture1")
B738DR_cust_axis_mixture2			= find_dataref("laminar/B738/flt_ctrls/mixture2")
B738DR_cust_axis_mixture1_mapped	= find_dataref("laminar/B738/flt_ctrls/mixture1_mapped")
B738DR_cust_axis_mixture2_mapped	= find_dataref("laminar/B738/flt_ctrls/mixture2_mapped")
B738DR_cust_axis_mixture1_reverse	= find_dataref("laminar/B738/flt_ctrls/mixture1_reverse")
B738DR_cust_axis_mixture2_reverse	= find_dataref("laminar/B738/flt_ctrls/mixture2_reverse")


gpu_deployed 						= find_dataref("laminar/B738/fmod/gpu_deployed")
gpu_test_enable						= find_dataref("laminar/B738/fms/gpu_test_enable")
B738DR_de_ice_truck_available 		= find_dataref("laminar/B738/de_ice_truck_available")
B738DR_ils_gls_inop					= create_dataref("laminar/B738/ils_gls_inop", "number")

B738DR_dev_tune						= find_dataref("zibomod/dev_tune")
B738DR_debug						= find_dataref("zibomod/Debug")
enable_cg = 1
B738DR_shift_cg_mac					= find_dataref("zibomod/shift_cg_mac")
B738DR_shift_cg_mac_gnd				= find_dataref("zibomod/shift_cg_mac_gnd")
simDR_cg_z_mac 						= find_dataref("sim/flightmodel2/misc/cg_offset_z_mac")

B738DR_aileron1_spd1				= find_dataref("laminar/B738/flight_model/aileron1_spd1")
B738DR_aileron1_spd2				= find_dataref("laminar/B738/flight_model/aileron1_spd2")
B738DR_aileron1_rat1				= find_dataref("laminar/B738/flight_model/aileron1_rat1")
B738DR_aileron1_rat2				= find_dataref("laminar/B738/flight_model/aileron1_rat2")
B738DR_aileron2_spd1				= find_dataref("laminar/B738/flight_model/aileron2_spd1")
B738DR_aileron2_spd2				= find_dataref("laminar/B738/flight_model/aileron2_spd2")
B738DR_aileron2_rat1				= find_dataref("laminar/B738/flight_model/aileron2_rat1")
B738DR_aileron2_rat2				= find_dataref("laminar/B738/flight_model/aileron2_rat2")
B738DR_elevator1_spd1				= find_dataref("laminar/B738/flight_model/elevator1_spd1")
B738DR_elevator1_spd2				= find_dataref("laminar/B738/flight_model/elevator1_spd2")
B738DR_elevator1_rat1				= find_dataref("laminar/B738/flight_model/elevator1_rat1")
B738DR_elevator1_rat2				= find_dataref("laminar/B738/flight_model/elevator1_rat2")
B738DR_elevator2_spd1				= find_dataref("laminar/B738/flight_model/elevator2_spd1")
B738DR_elevator2_spd2				= find_dataref("laminar/B738/flight_model/elevator2_spd2")
B738DR_elevator2_rat1				= find_dataref("laminar/B738/flight_model/elevator2_rat1")
B738DR_elevator2_rat2				= find_dataref("laminar/B738/flight_model/elevator2_rat2")
B738DR_rudder1_spd1					= find_dataref("laminar/B738/flight_model/rudder1_spd1")
B738DR_rudder1_spd2					= find_dataref("laminar/B738/flight_model/rudder1_spd2")
B738DR_rudder1_rat1					= find_dataref("laminar/B738/flight_model/rudder1_rat1")
B738DR_rudder1_rat2					= find_dataref("laminar/B738/flight_model/rudder1_rat2")
B738DR_rudder2_spd1					= find_dataref("laminar/B738/flight_model/rudder2_spd1")
B738DR_rudder2_spd2					= find_dataref("laminar/B738/flight_model/rudder2_spd2")
B738DR_rudder2_rat1					= find_dataref("laminar/B738/flight_model/rudder2_rat1")
B738DR_rudder2_rat2					= find_dataref("laminar/B738/flight_model/rudder2_rat2")
B738DR_spoiler1_spd1				= find_dataref("laminar/B738/flight_model/spoiler1_spd1")
B738DR_spoiler1_spd2				= find_dataref("laminar/B738/flight_model/spoiler1_spd2")
B738DR_spoiler1_rat1				= find_dataref("laminar/B738/flight_model/spoiler1_rat1")
B738DR_spoiler1_rat2				= find_dataref("laminar/B738/flight_model/spoiler1_rat2")
B738DR_spoiler2_spd1				= find_dataref("laminar/B738/flight_model/spoiler2_spd1")
B738DR_spoiler2_spd2				= find_dataref("laminar/B738/flight_model/spoiler2_spd2")
B738DR_spoiler2_rat1				= find_dataref("laminar/B738/flight_model/spoiler2_rat1")
B738DR_spoiler2_rat2				= find_dataref("laminar/B738/flight_model/spoiler2_rat2")
B738DR_brk_spoiler1_spd1			= find_dataref("laminar/B738/flight_model/brk_spoiler1_spd1")
B738DR_brk_spoiler1_spd2			= find_dataref("laminar/B738/flight_model/brk_spoiler1_spd2")
B738DR_brk_spoiler1_rat1			= find_dataref("laminar/B738/flight_model/brk_spoiler1_rat1")
B738DR_brk_spoiler1_rat2			= find_dataref("laminar/B738/flight_model/brk_spoiler1_rat2")
B738DR_brk_spoiler2_spd1			= find_dataref("laminar/B738/flight_model/brk_spoiler2_spd1")
B738DR_brk_spoiler2_spd2			= find_dataref("laminar/B738/flight_model/brk_spoiler2_spd2")
B738DR_brk_spoiler2_rat1			= find_dataref("laminar/B738/flight_model/brk_spoiler2_rat1")
B738DR_brk_spoiler2_rat2			= find_dataref("laminar/B738/flight_model/brk_spoiler2_rat2")
B738DR_def_aileron1_dn				= find_dataref("laminar/B738/flight_model/def_aileron1_dn")
B738DR_def_aileron1_up				= find_dataref("laminar/B738/flight_model/def_aileron1_up")
B738DR_def_aileron2_dn				= find_dataref("laminar/B738/flight_model/def_aileron2_dn")
B738DR_def_aileron2_up				= find_dataref("laminar/B738/flight_model/def_aileron2_up")
B738DR_def_elevator1_dn				= find_dataref("laminar/B738/flight_model/def_elevator1_dn")
B738DR_def_elevator1_up				= find_dataref("laminar/B738/flight_model/def_elevator1_up")
B738DR_def_elevator2_dn				= find_dataref("laminar/B738/flight_model/def_elevator2_dn")
B738DR_def_elevator2_up				= find_dataref("laminar/B738/flight_model/def_elevator2_up")
B738DR_def_rudder1_dn				= find_dataref("laminar/B738/flight_model/def_rudder1_dn")
B738DR_def_rudder1_up				= find_dataref("laminar/B738/flight_model/def_rudder1_up")
B738DR_def_rudder2_dn				= find_dataref("laminar/B738/flight_model/def_rudder2_dn")
B738DR_def_rudder2_up				= find_dataref("laminar/B738/flight_model/def_rudder2_up")
B738DR_def_spoiler1_roll			= find_dataref("laminar/B738/flight_model/def_spoiler1_roll")
B738DR_def_spoiler1_brk				= find_dataref("laminar/B738/flight_model/def_spoiler1_brk")
B738DR_def_spoiler2_roll			= find_dataref("laminar/B738/flight_model/def_spoiler2_roll")
B738DR_def_spoiler2_brk				= find_dataref("laminar/B738/flight_model/def_spoiler2_brk")
B738DR_def_speedbrake1_flt			= find_dataref("laminar/B738/flight_model/def_speedbrake1_flt")
B738DR_def_speedbrake1_gnd			= find_dataref("laminar/B738/flight_model/def_speedbrake1_gnd")
B738DR_def_speedbrake2_flt			= find_dataref("laminar/B738/flight_model/def_speedbrake2_flt")
B738DR_def_speedbrake2_gnd			= find_dataref("laminar/B738/flight_model/def_speedbrake2_gnd")
B738DR_def_elevator_trim_dn			= find_dataref("laminar/B738/flight_model/def_elevator_trim_dn")
B738DR_def_elevator_trim_up			= find_dataref("laminar/B738/flight_model/def_elevator_trim_up")
B738DR_def_flap_1					= find_dataref("laminar/B738/flight_model/def_flap_1")
B738DR_def_flap_2					= find_dataref("laminar/B738/flight_model/def_flap_2")
B738DR_def_flap_5					= find_dataref("laminar/B738/flight_model/def_flap_5")
B738DR_def_flap_10					= find_dataref("laminar/B738/flight_model/def_flap_10")
B738DR_def_flap_15					= find_dataref("laminar/B738/flight_model/def_flap_15")
B738DR_def_flap_25					= find_dataref("laminar/B738/flight_model/def_flap_25")
B738DR_def_flap_30					= find_dataref("laminar/B738/flight_model/def_flap_30")
B738DR_def_flap_40					= find_dataref("laminar/B738/flight_model/def_flap_40")
B738DR_pitch_input_coef_1			= find_dataref("laminar/B738/flight_model/pitch_input_coef_1")
B738DR_pitch_input_coef_2			= find_dataref("laminar/B738/flight_model/pitch_input_coef_2")
B738DR_roll_input_coef_1			= find_dataref("laminar/B738/flight_model/roll_input_coef_1")
B738DR_roll_input_coef_2			= find_dataref("laminar/B738/flight_model/roll_input_coef_2")
B738DR_yaw_input_coef_1				= find_dataref("laminar/B738/flight_model/yaw_input_coef_1")
B738DR_yaw_input_coef_2				= find_dataref("laminar/B738/flight_model/yaw_input_coef_2")
B738DR_def_elevator1_tab_ratio		= find_dataref("laminar/B738/flight_model/def_elevator1_tab_ratio")
B738DR_def_elevator2_tab_ratio		= find_dataref("laminar/B738/flight_model/def_elevator2_tab_ratio")
B738DR_stab_trim_units				= find_dataref("laminar/B738/flight_model/stab_trim_units")
B738DR_flap_cl						= find_dataref("laminar/B738/flight_model/flap_cl")
B738DR_flap_cd						= find_dataref("laminar/B738/flight_model/flap_cd")
B738DR_flap_cm						= find_dataref("laminar/B738/flight_model/flap_cm")
B738DR_flap2_cl						= find_dataref("laminar/B738/flight_model/flap2_cl")
B738DR_flap2_cd						= find_dataref("laminar/B738/flight_model/flap2_cd")
B738DR_flap2_cm						= find_dataref("laminar/B738/flight_model/flap2_cm")
B738DR_flt_idle_thr1				= find_dataref("zibomod/engine_model/flt_idle_thr1")
B738DR_flt_idle_thr2				= find_dataref("zibomod/engine_model/flt_idle_thr2")
B738DR_flt_idle_thr3				= find_dataref("zibomod/engine_model/flt_idle_thr3")
B738DR_flt_idle_thr4				= find_dataref("zibomod/engine_model/flt_idle_thr4")
B738DR_flt_idle_thr5				= find_dataref("zibomod/engine_model/flt_idle_thr5")
B738DR_app_idle_thr1				= find_dataref("zibomod/engine_model/app_idle_thr1")
B738DR_app_idle_thr2				= find_dataref("zibomod/engine_model/app_idle_thr2")
B738DR_app_idle_thr3				= find_dataref("zibomod/engine_model/app_idle_thr3")
B738DR_app_idle_thr4				= find_dataref("zibomod/engine_model/app_idle_thr4")
B738DR_app_idle_thr5				= find_dataref("zibomod/engine_model/app_idle_thr5")
B738DR_eng_fan_drag_ratio			= find_dataref("zibomod/engine_model/eng_fan_drag_ratio")
B738DR_flt_idle_sigma2				= find_dataref("zibomod/engine_model/flt_idle_sigma2")
B738DR_flt_idle_sigma3				= find_dataref("zibomod/engine_model/flt_idle_sigma3")
B738DR_flt_idle_sigma4				= find_dataref("zibomod/engine_model/flt_idle_sigma4")
B738DR_flt_idle_sigma5				= find_dataref("zibomod/engine_model/flt_idle_sigma5")
B738DR_mach_trim_ratio				= find_dataref("laminar/B738/flight_model/mach_trim_ratio")
B738DR_mach_trim_spd1				= find_dataref("laminar/B738/flight_model/mach_trim_spd1")
B738DR_mach_trim_spd2				= find_dataref("laminar/B738/flight_model/mach_trim_spd2")

B738DR_def_aileron_rate 			= find_dataref("laminar/B738/flight_model/def_aileron_rate")
B738DR_def_elevator_rate 			= find_dataref("laminar/B738/flight_model/def_elevator_rate")
B738DR_def_rudder_rate 				= find_dataref("laminar/B738/flight_model/def_rudder_rate")
B738DR_def_spoiler_rate 			= find_dataref("laminar/B738/flight_model/def_spoiler_rate")
B738DR_def_brakes_rate 				= find_dataref("laminar/B738/flight_model/def_brakes_rate")
B738DR_def_aileron_flaps_rate		= find_dataref("laminar/B738/flight_model/def_aileron_flaps_rate")
B738DR_def_spoiler_flaps_rate 		= find_dataref("laminar/B738/flight_model/def_spoiler_flaps_rate")

B738DR_idle_mach_reduction			= find_dataref("zibomod/engine_model/idle_mach_reduction")
B738DR_bypass						= find_dataref("zibomod/engine_model/bypass")
B738DR_inlet						= find_dataref("zibomod/engine_model/inlet")
B738DR_shock_mach					= find_dataref("zibomod/engine_model/shock_mach")
B738DR_curve02_coef1				= find_dataref("zibomod/engine_model/curve02_coef1")
B738DR_curve02_coef2				= find_dataref("zibomod/engine_model/curve02_coef2")
B738DR_curve02_coef3				= find_dataref("zibomod/engine_model/curve02_coef3")
B738DR_curve02_coef4				= find_dataref("zibomod/engine_model/curve02_coef4")
B738DR_curve02_coef5				= find_dataref("zibomod/engine_model/curve02_coef5")
B738DR_curve02_coef6				= find_dataref("zibomod/engine_model/curve02_coef6")
B738DR_curve02_type					= find_dataref("zibomod/engine_model/curve02_type")
B738DR_static_thrust				= find_dataref("zibomod/engine_model/static_thrust")

B738DR_idle_sfc						= find_dataref("zibomod/engine_model/idle_sfc")
B738DR_sfc							= find_dataref("zibomod/engine_model/sfc")
B738DR_sfc_coef						= find_dataref("zibomod/engine_model/sfc_coef")

simDR_engine_thr					= find_dataref("sim/flightmodel/forces/faxil_prop")
simDR_ff							= find_dataref("sim/flightmodel/engine/ENGN_FF_")

B738DR_roll_dmp 					= find_dataref("zibomod/roll_dmp")
B738DR_pitch_dmp 					= find_dataref("zibomod/pitch_dmp")
B738DR_yaw_dmp 						= find_dataref("zibomod/yaw_dmp")

B738DR_fms_test3					= find_dataref("laminar/B738/fms/test3")
B738DR_fms_test4					= find_dataref("laminar/B738/fms/test4")
B738DR_fms_test5					= find_dataref("laminar/B738/fms/test5")
B738DR_fms_test6					= find_dataref("laminar/B738/fms/test6")
B738DR_fms_test7					= find_dataref("laminar/B738/fms/test7")
B738DR_fms_test8					= find_dataref("laminar/B738/fms/test8")

B738CMD_save_tune 			= find_command("laminar/B738/flight_model/save_tune")


B738DR_JAR_copilot 					= find_dataref("laminar/b738/jar_copilot")

B738DR_air_ground_sensor				= find_dataref("laminar/B738/air_ground_sensor")
B738DR_thrust1_leveler					= find_dataref("laminar/B738/engine/thrust1_leveler")
B738DR_thrust2_leveler					= find_dataref("laminar/B738/engine/thrust2_leveler")
B738DR_cabin_pressure_diff				= find_dataref("laminar/B738/cabin_pressure_diff")
B738DR_mixture_ratio1 					= find_dataref("laminar/B738/engine/mixture_ratio1")
B738DR_mixture_ratio2 					= find_dataref("laminar/B738/engine/mixture_ratio2")
B738DR_flap_lever						= find_dataref("laminar/B738/flt_ctrls/flap_lever")
B738DR_speedbrake_lever 				= find_dataref("laminar/B738/flt_ctrls/speedbrake_lever")
B738DR_gear_handle_pos 					= find_dataref("laminar/B738/controls/gear_handle_down")
B738DR_reverse_lever1					= find_dataref("laminar/B738/flt_ctrls/reverse_lever1")
B738DR_reverse_lever2					= find_dataref("laminar/B738/flt_ctrls/reverse_lever2")
B738DR_yoke_pitch						= find_dataref("laminar/yoke/pitch")
B738DR_yoke_pitch2						= find_dataref("laminar/yoke/pitch2")

B738DR_position_light_switch_pos 		= find_dataref("laminar/B738/toggle_switch/position_light_pos")
B738DR_no_smoking_pos					= find_dataref("laminar/B738/toggle_switch/no_smoking_pos")
simDR_beacon_lights_on					= find_dataref("sim/cockpit2/switches/beacon_on")
B738DR_parking_brake_pos				= find_dataref("laminar/B738/parking_brake_pos")

-- AviTab
avitab_powered 				= find_dataref("avitab/panel_powered")
avitab_enabled 				= find_dataref("avitab/panel_enabled")
avitab_brightness			= find_dataref("avitab/brightness")
avitab_menu					= find_dataref("avitab/is_in_menu")
function DRavitab_installed_handl() end
function DRbp_installed_handl() end
avitab_installed			= create_dataref("laminar/B738/avitab_installed", "number", DRavitab_installed_handl)
bp_installed				= create_dataref("laminar/B738/bp_installed", "number", DRbp_installed_handl)

function DRavitab_ctrl_override_handl() end
avitab_ctrl_override		= create_dataref("laminar/B738/avitab_ctrl_override", "number", DRavitab_ctrl_override_handl)

B738DR_73x					= find_dataref("laminar/B738/73x")

set_pax_lighting 			= find_dataref("737x/cabin/set_pax_lighting")
set_entry_lighting 			= find_dataref("737u/cabin/set_entry_lighting")

B738DR_state_cmd 			= find_dataref("laminar/B738/state_cmd")
B738DR_state_cmd2 			= find_dataref("laminar/B738/state_cmd2")
B738DR_state_cmd3 			= find_dataref("laminar/B738/state_cmd3")

B738DR_failure_save				= create_dataref("laminar/B738/tab/failure_save", "number")
B738DR_el_failure				= find_dataref("laminar/B738/failure/electric")
B738DR_hyd_failure				= find_dataref("laminar/B738/failure/hydraulic")
B738DR_sys_failure				= find_dataref("laminar/B738/failure/system")
B738DR_pressurisation_failure 	= find_dataref("laminar/B738/failure/pressurisation")
B738DR_engine_failure 			= find_dataref("laminar/B738/failure/engine")
B738DR_rst_fail_available2		= find_dataref("laminar/B738/system/rst_fail_available2")

B738DR_dest_fuel			= find_dataref("laminar/B738/fms/dest_fuel")
B738DR_calc_to_cg			= find_dataref("laminar/B738/fms/calc_to_cg")

B738DR_autogate_nearest		= find_dataref("laminar/B738/autogate_nearest")
B738DR_autogate_gpu 			= find_dataref("laminar/B738/autogate_gpu")
B738DR_jetway_nearest			= find_dataref("laminar/B738/jetway_nearest")

B738DR_fms_test1			= find_dataref("laminar/B738/fms/test1")

B738_legs_num			= find_dataref("laminar/B738/vnav/legs_num")
B738DR_fms_legs			= find_dataref("laminar/B738/fms/legs")
B738DR_ils_runway0 		= find_dataref("laminar/B738/pfd/ils_runway0")
B738DR_ils_runway 		= find_dataref("laminar/B738/pfd/ils_runway")

B738DR_ref_list_rwy_icao	= find_dataref("laminar/B738/fms/ref_list_rwy_icao")
B738DR_ref_list_rwy			= find_dataref("laminar/B738/fms/ref_list_rwy")
B738DR_ref_list_rwy_len		= find_dataref("laminar/B738/fms/ref_list_rwy_len")
B738DR_ref_list_rwy_hdg		= find_dataref("laminar/B738/fms/ref_list_rwy_hdg")
B738DR_des_list_rwy_icao	= find_dataref("laminar/B738/fms/des_list_rwy_icao")
B738DR_des_list_rwy			= find_dataref("laminar/B738/fms/des_list_rwy")
B738DR_des_list_rwy_len		= find_dataref("laminar/B738/fms/des_list_rwy_len")
B738DR_des_list_rwy_hdg		= find_dataref("laminar/B738/fms/des_list_rwy_hdg")

B738DR_load_save			= find_dataref("laminar/B738/load_save")
B738DR_load_save2			= find_dataref("laminar/B738/load_save2")
B738DR_efb					= find_dataref("laminar/B738/efb")

B738DR_b737_variant			= find_dataref("zibomod/b737_variant")
simDR_int_ver				= find_dataref("sim/version/xplane_internal_version")
simDR_OAT					= find_dataref("sim/cockpit2/temperature/outside_air_temp_degc")
simDR_TAT					= find_dataref("sim/cockpit2/temperature/outside_air_LE_temp_degc")
B738DR_fuel_temp_real			= find_dataref("laminar/B738/engine/fuel_temp_real")
B738DR_center_tank_kgs_c	= find_dataref("laminar/B738/fuel/center_tank_kgs_c")
B738DR_temp_left_tank		= create_dataref("laminar/B738/engine/temp_left_tank", "number")
B738DR_temp_right_tank		= create_dataref("laminar/B738/engine/temp_right_tank", "number")
B738DR_temp_center_tank		= create_dataref("laminar/B738/engine/temp_center_tank", "number")

B738DR_arrow_3d_override	= find_dataref("laminar/B738/arrow_3d/override")
B738DR_arrow_3d_kill		= find_dataref("laminar/B738/arrow_3d/kill")
B738DR_arrow_3d_x			= find_dataref("laminar/B738/arrow_3d/x")
B738DR_arrow_3d_y			= find_dataref("laminar/B738/arrow_3d/y")
B738DR_arrow_3d_z			= find_dataref("laminar/B738/arrow_3d/z")
B738DR_arrow_3d_rotate		= find_dataref("laminar/B738/arrow_3d/rotate")
B738DR_arrow_3d_item		= find_dataref("laminar/B738/arrow_3d/item")
B738DR_arrow_3d_kill2		= find_dataref("laminar/B738/arrow_3d/kill2")
B738DR_arrow_3d_x2			= find_dataref("laminar/B738/arrow_3d/x2")
B738DR_arrow_3d_y2			= find_dataref("laminar/B738/arrow_3d/y2")
B738DR_arrow_3d_z2			= find_dataref("laminar/B738/arrow_3d/z2")
B738DR_arrow_3d_rotate2		= find_dataref("laminar/B738/arrow_3d/rotate2")
B738DR_arrow_3d_item2		= find_dataref("laminar/B738/arrow_3d/item2")
B738DR_arrow_3d_helper		= find_dataref("laminar/B738/arrow_3d/arrow_3d_helper")

B738DR_arrow_3d_item_number		= create_dataref("laminar/B738/arrow_3d/item_number", "number")

-- --*************************************************************************************--
-- --** 				              FIND CUSTOM COMMANDS              			     **--
-- --*************************************************************************************--

B738CMD_change_units 			= find_command("laminar/B738/fms/change_units")

-- FMOD by AudioBird XP
B738CMD_enable_pax_boarding 	= find_command("laminar/b738/fmodpack/pax_board")
B738CMD_enable_gyro 			= find_command("laminar/b738/fmodpack/fmod_woodpecker_on")
B738CMD_enable_crew				= find_command("laminar/b738/fmodpack/fmod_crew_on")
B738CMD_enable_chatter 			= find_command("laminar/b738/fmodpack/pax_talk")
B738CMD_airport_set 			= find_command("laminar/b738/fmodpack/fmod_airport_set")
B738CMD_vol_int_ducker 			= find_command("laminar/b738/fmodpack/fmod_vol_int_ducker")
B738CMD_vol_int_eng 			= find_command("laminar/b738/fmodpack/fmod_vol_int_eng")
B738CMD_vol_int_start 			= find_command("laminar/b738/fmodpack/fmod_vol_int_start")
B738CMD_vol_int_ac 				= find_command("laminar/b738/fmodpack/fmod_vol_int_ac")
B738CMD_vol_int_gyro 			= find_command("laminar/b738/fmodpack/fmod_vol_int_gyro")
B738CMD_vol_int_roll			= find_command("laminar/b738/fmodpack/fmod_vol_int_roll")
B738CMD_vol_int_bump			= find_command("laminar/b738/fmodpack/fmod_vol_int_bump")
B738CMD_vol_int_pax				= find_command("laminar/b738/fmodpack/fmod_vol_int_pax")
B738CMD_vol_int_pax_applause	= find_command("laminar/b738/fmodpack/fmod_pax_applause_on")
B738CMD_vol_int_wind			= find_command("laminar/b738/fmodpack/fmod_vol_int_wind")
B738CMD_enable_mutetrim 		= find_command("laminar/b738/fmodpack/fmod_mutetrim_on")
B738CMD_vol_int_XP				= find_command("laminar/b738/fmodpack/fmod_vol_int_XP")
B738CMD_vol_airport				= find_command("laminar/b738/fmodpack/fmod_vol_airport")
B738CMD_announcement_set 		= find_command("laminar/b738/fmodpack/fmod_announcement_set")

B738_eq_high 				= find_command("laminar/b738/fmodpack/fmod_eq_high")
B738_eq_mid 				= find_command("laminar/b738/fmodpack/fmod_eq_mid")
B738_eq_low 				= find_command("laminar/b738/fmodpack/fmod_eq_low")
B738_end_leg 				= find_command("laminar/b738/fmodpack/fmod_end_leg")
B738_start_leg 				= find_command("laminar/b738/fmodpack/fmod_start_leg")
B738CMD_play_cargo 			= find_command("laminar/b738/fmodpack/fmod_play_cargo")
B738CMD_vol_crew			= find_command("laminar/b738/fmodpack/fmod_vol_crew")	
B738CMD_vol_PM				= find_command("laminar/b738/fmodpack/fmod_vol_PM")	
B738CMD_play_welcome		= find_command("laminar/b738/fmodpack/play_welcome_msg")
B738CMD_play_cruise			= find_command("laminar/b738/fmodpack/play_cruise_msg")
B738CMD_play_descent		= find_command("laminar/b738/fmodpack/play_descent_msg")
B738CMD_play_preland		= find_command("laminar/b738/fmodpack/play_preland_msg")
B738CMD_play_turbulence		= find_command("laminar/b738/fmodpack/play_turbulence_msg")
B738CMD_enable_fmc_mute_on 	= find_command("laminar/b738/fmodpack/fmod_enable_fmc_mute_on")
B738CMD_vol_computer		= find_command("laminar/b738/fmodpack/fmod_vol_computer")

B738CMD_vol_FAC				= find_command("laminar/b738/fmodpack/fmod_vol_FAC")
B738CMD_vol_weather 		= find_command("laminar/b378/fmodpack/fmod_vol_weather")
B738CMD_switch_TO_trigger 	= find_command("laminar/b738/fmodpack/CMD_switch_TO_trigger")
B738CMD_vol_int_trim		= find_command("laminar/b738/fmodpack/fmod_vol_int_trim")

B738CMD_chock_toggle		= find_command("laminar/B738/toggle_switch/chock")
B738CMD_pause_td_toggle		= find_command("laminar/B738/toggle_switch/pause_td")
B738CMD_change_payload		= find_command("laminar/B738/fms/change_payload")
B738CMD_update_factory		= find_command("laminar/B738/fms/update_factory")

B738CMD_save_config 		= find_command("laminar/B738/fms/save_config_audio")
B738CMD_reset_cfg_audio 	= find_command("laminar/B738/fms/reset_config_audio")
B738CMD_reset_cfg			= find_command("laminar/B738/fms/reset_config")
B738CMD_reset_audio			= find_command("laminar/B738/fms/reset_audio")

B738CMD_load_cfg99 			= find_command("laminar/B738/fms/load_cfg99")

B738CMD_load_cfg1 			= find_command("laminar/B738/fms/load_cfg1")
B738CMD_load_cfg2 			= find_command("laminar/B738/fms/load_cfg2")
B738CMD_load_cfg3 			= find_command("laminar/B738/fms/load_cfg3")
B738CMD_load_cfg4 			= find_command("laminar/B738/fms/load_cfg4")
B738CMD_save_cfg1 			= find_command("laminar/B738/fms/save_cfg1")
B738CMD_save_cfg2 			= find_command("laminar/B738/fms/save_cfg2")
B738CMD_save_cfg3 			= find_command("laminar/B738/fms/save_cfg3")
B738CMD_save_cfg4 			= find_command("laminar/B738/fms/save_cfg4")


B738CMD_load_audio1 		= find_command("laminar/B738/fms/load_audio1")
B738CMD_load_audio2 		= find_command("laminar/B738/fms/load_audio2")
B738CMD_load_audio3 		= find_command("laminar/B738/fms/load_audio3")
B738CMD_load_audio4 		= find_command("laminar/B738/fms/load_audio4")
B738CMD_save_audio1 		= find_command("laminar/B738/fms/save_audio1")
B738CMD_save_audio2 		= find_command("laminar/B738/fms/save_audio2")
B738CMD_save_audio3 		= find_command("laminar/B738/fms/save_audio3")
B738CMD_save_audio4 		= find_command("laminar/B738/fms/save_audio4")

B738CMD_set_flap_up 		= find_command("laminar/B738/fms/set_flap_up")
B738CMD_set_flap_1 			= find_command("laminar/B738/fms/set_flap_1")
B738CMD_set_flap_2 			= find_command("laminar/B738/fms/set_flap_2")
B738CMD_set_flap_5 			= find_command("laminar/B738/fms/set_flap_5")
B738CMD_set_flap_10 		= find_command("laminar/B738/fms/set_flap_10")
B738CMD_set_flap_15 		= find_command("laminar/B738/fms/set_flap_15")
B738CMD_set_flap_25 		= find_command("laminar/B738/fms/set_flap_25")
B738CMD_set_flap_30 		= find_command("laminar/B738/fms/set_flap_30")
B738CMD_set_flap_40 		= find_command("laminar/B738/fms/set_flap_40")

-- BetterPushback commands
BP_CMD_connect_first		= find_command("BetterPushback/connect_first")
BP_CMD_disconnect			= find_command("BetterPushback/disconnect")
BP_CMD_reconnect			= find_command("BetterPushback/reconnect")
BP_CMD_start				= find_command("BetterPushback/start")
BP_CMD_start_planner		= find_command("BetterPushback/start_planner")
BP_CMD_stop					= find_command("BetterPushback/stop")
BP_CMD_stop_planner			= find_command("BetterPushback/stop_planner")

--AviTab commands
avitab_CMD_app_charts			= find_command("AviTab/app_charts")
avitab_CMD_app_airports			= find_command("AviTab/app_airports")
avitab_CMD_app_routes			= find_command("AviTab/app_routes")
avitab_CMD_app_maps				= find_command("AviTab/app_maps")
avitab_CMD_app_plane_manual		= find_command("AviTab/app_plane_manual")
avitab_CMD_app_notes			= find_command("AviTab/app_notes")
avitab_CMD_app_about			= find_command("AviTab/app_about")

-- Cabin lighting
B738CMD_pax_white_bright 	= find_command("laminar/B738/cabin/pax_white_bright")
B738CMD_pax_to_landing	 	= find_command("laminar/B738/cabin/pax_to_landing")
B738CMD_pax_cruise		 	= find_command("laminar/B738/cabin/pax_cruise")
B738CMD_pax_white_medium 	= find_command("laminar/B738/cabin/pax_white_medium")
B738CMD_pax_night_sleep 	= find_command("laminar/B738/cabin/pax_night_sleep")
B738CMD_entry_white_bright 	= find_command("laminar/B738/cabin/entry_white_bright")
B738CMD_entry_white_medium 	= find_command("laminar/B738/cabin/entry_white_medium")

B738CMD_rst_fail				= find_command("laminar/B738/system/rst_fail")
B738CMD_enable_rnd_fail			= find_command("laminar/B738/system/enable_rnd_fail")
B738CMD_disable_rnd_fail		= find_command("laminar/B738/system/disable_rnd_fail")

B738CMD_jetways_toggle			= find_command("sim/ground_ops/jetway")
B738CMD_service_plane			= find_command("sim/ground_ops/service_plane")
B738CMD_open_fdd 				= find_command("laminar/B738/push_button/flt_dk_door_open")

-- --*************************************************************************************--
-- --** 				        CREATE READ-ONLY CUSTOM DATAREFS               	         **--
-- --*************************************************************************************--

B738DR_tab_line00 			= create_dataref("laminar/B738/tab/line00", "string")
B738DR_tab_line01 			= create_dataref("laminar/B738/tab/line01", "string")
B738DR_tab_line02 			= create_dataref("laminar/B738/tab/line02", "string")
B738DR_tab_line03 			= create_dataref("laminar/B738/tab/line03", "string")
B738DR_tab_line04 			= create_dataref("laminar/B738/tab/line04", "string")
B738DR_tab_line05 			= create_dataref("laminar/B738/tab/line05", "string")
B738DR_tab_line06 			= create_dataref("laminar/B738/tab/line06", "string")
B738DR_tab_line07 			= create_dataref("laminar/B738/tab/line07", "string")
B738DR_tab_line08 			= create_dataref("laminar/B738/tab/line08", "string")
B738DR_tab_line09 			= create_dataref("laminar/B738/tab/line09", "string")

B738DR_tab_line00s 			= create_dataref("laminar/B738/tab/line00s", "string")
B738DR_tab_line01s 			= create_dataref("laminar/B738/tab/line01s", "string")
B738DR_tab_line02s 			= create_dataref("laminar/B738/tab/line02s", "string")
B738DR_tab_line03s 			= create_dataref("laminar/B738/tab/line03s", "string")
B738DR_tab_line04s 			= create_dataref("laminar/B738/tab/line04s", "string")
B738DR_tab_line05s 			= create_dataref("laminar/B738/tab/line05s", "string")
B738DR_tab_line06s 			= create_dataref("laminar/B738/tab/line06s", "string")
B738DR_tab_line07s 			= create_dataref("laminar/B738/tab/line07s", "string")
B738DR_tab_line08s 			= create_dataref("laminar/B738/tab/line08s", "string")
B738DR_tab_line09s 			= create_dataref("laminar/B738/tab/line09s", "string")

B738DR_tab_line00g 			= create_dataref("laminar/B738/tab/line00g", "string")
B738DR_tab_line01g 			= create_dataref("laminar/B738/tab/line01g", "string")
B738DR_tab_line02g 			= create_dataref("laminar/B738/tab/line02g", "string")
B738DR_tab_line03g 			= create_dataref("laminar/B738/tab/line03g", "string")
B738DR_tab_line04g 			= create_dataref("laminar/B738/tab/line04g", "string")
B738DR_tab_line05g 			= create_dataref("laminar/B738/tab/line05g", "string")
B738DR_tab_line06g 			= create_dataref("laminar/B738/tab/line06g", "string")
B738DR_tab_line07g 			= create_dataref("laminar/B738/tab/line07g", "string")
B738DR_tab_line08g 			= create_dataref("laminar/B738/tab/line08g", "string")
B738DR_tab_line09g 			= create_dataref("laminar/B738/tab/line09g", "string")

B738DR_tab_line01a 			= create_dataref("laminar/B738/tab/line01a", "string")
B738DR_tab_line02a 			= create_dataref("laminar/B738/tab/line02a", "string")
B738DR_tab_line03a 			= create_dataref("laminar/B738/tab/line03a", "string")
B738DR_tab_line04a 			= create_dataref("laminar/B738/tab/line04a", "string")
B738DR_tab_line05a 			= create_dataref("laminar/B738/tab/line05a", "string")
B738DR_tab_line06a 			= create_dataref("laminar/B738/tab/line06a", "string")
B738DR_tab_line07a 			= create_dataref("laminar/B738/tab/line07a", "string")
B738DR_tab_line08a 			= create_dataref("laminar/B738/tab/line08a", "string")
B738DR_tab_line09a 			= create_dataref("laminar/B738/tab/line09a", "string")

B738DR_tab_line00c 			= create_dataref("laminar/B738/tab/line00c", "string")
B738DR_tab_line01c 			= create_dataref("laminar/B738/tab/line01c", "string")
B738DR_tab_line02c 			= create_dataref("laminar/B738/tab/line02c", "string")
B738DR_tab_line03c 			= create_dataref("laminar/B738/tab/line03c", "string")
B738DR_tab_line04c 			= create_dataref("laminar/B738/tab/line04c", "string")
B738DR_tab_line05c 			= create_dataref("laminar/B738/tab/line05c", "string")
B738DR_tab_line06c 			= create_dataref("laminar/B738/tab/line06c", "string")
B738DR_tab_line07c 			= create_dataref("laminar/B738/tab/line07c", "string")
B738DR_tab_line08c 			= create_dataref("laminar/B738/tab/line08c", "string")
B738DR_tab_line09c 			= create_dataref("laminar/B738/tab/line09c", "string")

B738DR_tab_line00cs 		= create_dataref("laminar/B738/tab/line00cs", "string")
B738DR_tab_line01cs 		= create_dataref("laminar/B738/tab/line01cs", "string")
B738DR_tab_line02cs 		= create_dataref("laminar/B738/tab/line02cs", "string")
B738DR_tab_line03cs 		= create_dataref("laminar/B738/tab/line03cs", "string")
B738DR_tab_line04cs 		= create_dataref("laminar/B738/tab/line04cs", "string")
B738DR_tab_line05cs 		= create_dataref("laminar/B738/tab/line05cs", "string")
B738DR_tab_line06cs 		= create_dataref("laminar/B738/tab/line06cs", "string")
B738DR_tab_line07cs 		= create_dataref("laminar/B738/tab/line07cs", "string")
B738DR_tab_line08cs 		= create_dataref("laminar/B738/tab/line08cs", "string")
B738DR_tab_line09cs 		= create_dataref("laminar/B738/tab/line09cs", "string")

B738DR_tab_line00bs 		= create_dataref("laminar/B738/tab/line00bs", "string")
B738DR_tab_line01bs 		= create_dataref("laminar/B738/tab/line01bs", "string")
B738DR_tab_line02bs 		= create_dataref("laminar/B738/tab/line02bs", "string")
B738DR_tab_line03bs 		= create_dataref("laminar/B738/tab/line03bs", "string")
B738DR_tab_line04bs 		= create_dataref("laminar/B738/tab/line04bs", "string")
B738DR_tab_line05bs 		= create_dataref("laminar/B738/tab/line05bs", "string")
B738DR_tab_line06bs 		= create_dataref("laminar/B738/tab/line06bs", "string")
B738DR_tab_line07bs 		= create_dataref("laminar/B738/tab/line07bs", "string")
B738DR_tab_line08bs 		= create_dataref("laminar/B738/tab/line08bs", "string")
B738DR_tab_line09bs 		= create_dataref("laminar/B738/tab/line09bs", "string")

B738DR_tab_boot_active		= create_dataref("laminar/B738/tab/boot_active", "number")
B738DR_tab_boot_show		= create_dataref("laminar/B738/tab/boot_show", "array[5]")
B738DR_tab_page_info_pos	= create_dataref("laminar/B738/tab/page_info_pos", "number")
B738DR_tab_page_info_time	= create_dataref("laminar/B738/tab/page_info_time", "string")

B738DR_tab_menu_page		= create_dataref("laminar/B738/tab/menu_page", "number")
B738DR_tab_menu_mark		= create_dataref("laminar/B738/tab/menu_mark", "array[8]")
B738DR_tab_item				= create_dataref("laminar/B738/tab/item", "array[9]")
B738DR_tab_item_checked		= create_dataref("laminar/B738/tab/item_checked", "array[9]")
B738DR_tab_cg_pos			= create_dataref("laminar/B738/tab/cg_pos", "number")
B738DR_bgnd_fuel 			= create_dataref("laminar/B738/tab/bgnd_fuel", "number")
B738DR_bgnd_perf_lnd		= create_dataref("laminar/B738/tab/bgnd_perf_lnd", "number")
B738DR_bgnd_perf_to			= create_dataref("laminar/B738/tab/bgnd_perf_to", "number")
B738DR_tab_autoload			= create_dataref("laminar/B738/tab/autoload", "number")
B738DR_autoload_on			= find_dataref("laminar/B738/autoload_on")

B738DR_tab_numpad_act		= create_dataref("laminar/B738/tab/numpad_act", "number")
B738DR_tab_numpad_val		= create_dataref("laminar/B738/tab/numpad_val", "string")
B738DR_tab_numpad_spec1		= create_dataref("laminar/B738/tab/numpad_spec1", "number")
B738DR_tab_numpad_spec2		= create_dataref("laminar/B738/tab/numpad_spec2", "number")

-- manipulators
B738DR_tab_line_manip		= create_dataref("laminar/B738/tab_manip/line", "array[10]")
B738DR_tab_menu_manip		= create_dataref("laminar/B738/tab_manip/menu", "array[8]")
B738DR_tab_nav_manip		= create_dataref("laminar/B738/tab_manip/nav", "number")
B738DR_tab_nav2_manip		= create_dataref("laminar/B738/tab_manip/nav2", "number")
B738DR_tab_info_manip		= create_dataref("laminar/B738/tab_manip/info", "number")
B738DR_tab_perf_manip		= create_dataref("laminar/B738/tab_manip/perf", "array[16]")

B738DR_cl_manip_enable		= create_dataref("laminar/B738/checklist/manip_enable", "number")
B738DR_tab_arrows_enable	= create_dataref("laminar/B738/tab/arrows_enable", "number")
B738DR_tab_static			= create_dataref("laminar/B738/tab/static", "number")

B738DR_tab_credits			= create_dataref("laminar/B738/tab/credits", "number")
B738DR_tab_page				= create_dataref("laminar/B738/tab/page", "number")
B738DR_tab_power			= create_dataref("laminar/B738/tab/power", "number")

-- PERF TOOL
B738DR_perf_clearway		= create_dataref("laminar/B738/tab/perf_clearway", "number")
B738DR_perf_clearway_show	= create_dataref("laminar/B738/tab/perf_clearway_show", "number")
B738DR_perf_stopway			= create_dataref("laminar/B738/tab/perf_stopway", "number")
B738DR_perf_stopway_show	= create_dataref("laminar/B738/tab/perf_stopway_show", "number")

B738DR_perf_ab1				= create_dataref("laminar/B738/tab/perf_ab1", "number")
B738DR_perf_ab2				= create_dataref("laminar/B738/tab/perf_ab2", "number")
B738DR_perf_ab3				= create_dataref("laminar/B738/tab/perf_ab3", "number")
B738DR_perf_ma				= create_dataref("laminar/B738/tab/perf_ma", "number")
B738DR_perf_mm				= create_dataref("laminar/B738/tab/perf_mm", "number")
B738DR_perf_ad				= create_dataref("laminar/B738/tab/perf_ad", "number")
B738DR_perf_on_rwy			= create_dataref("laminar/B738/tab/perf_on_rwy", "number")
B738DR_perf_out_rwy			= create_dataref("laminar/B738/tab/perf_out_rwy", "number")

B738DR_perf_ab1_state		= create_dataref("laminar/B738/tab/perf_ab1_state", "number")
B738DR_perf_ab2_state		= create_dataref("laminar/B738/tab/perf_ab2_state", "number")
B738DR_perf_ab3_state		= create_dataref("laminar/B738/tab/perf_ab3_state", "number")
B738DR_perf_ma_state		= create_dataref("laminar/B738/tab/perf_ma_state", "number")
B738DR_perf_mm_state		= create_dataref("laminar/B738/tab/perf_mm_state", "number")

B738DR_tab_arrows_left		= create_dataref("laminar/B738/tab/arrows_left", "number")
B738DR_tab_arrows_right		= create_dataref("laminar/B738/tab/arrows_right", "number")

-- SERVICES

B738DR_hide_gpu 			= find_dataref("laminar/B738/gpu_hide")


-- -- DOORS
door_ratio_fwd_L 		= find_dataref("737u/doors/L1")
door_ratio_fwd_R 		= find_dataref("737u/doors/R1")
door_ratio_aft_L 		= find_dataref("737u/doors/L2")
door_ratio_aft_R 		= find_dataref("737u/doors/R2")
door_ratio_fwd_cargo 	= find_dataref("737u/doors/Fwd_Cargo")
door_ratio_aft_cargo 	= find_dataref("737u/doors/aft_Cargo")

door_ratio_emerg1		= create_dataref("737u/doors/emerg1", "number")
door_ratio_emerg2		= create_dataref("737u/doors/emerg2", "number")
door_ratio_emerg3		= create_dataref("737u/doors/emerg3", "number")
door_ratio_emerg4		= create_dataref("737u/doors/emerg4", "number")
door_ratio_emerg5		= create_dataref("737u/doors/L_mid", "number")
door_ratio_emerg6		= create_dataref("737u/doors/R_mid", "number")
door_ratio_emerg5_lu	= create_dataref("737u/doors/L_aft", "number")
door_ratio_emerg6_lu	= create_dataref("737u/doors/R_aft", "number")

door_ratio_aft1			= create_dataref("737u/doors/aft1", "number")
door_ratio_aft2			= create_dataref("737u/doors/aft2", "number")

door_status				= create_dataref("laminar/B738/doors/status", "array[16]")
door_lock				= create_dataref("laminar/B738/doors/lock", "array[16]")
door_item_hide			= create_dataref("laminar/B738/efb/doors/item_hide", "array[16]")
B738DR_blink			= find_dataref("laminar/B738/autopilot/blink")

-- simDR_bus_battery_on	= find_dataref("sim/cockpit2/electrical/battery_on")
B738DR_airstair_ratio 	= create_dataref("laminar/B738/door/airstair_ratio", "number")
B738DR_hot_batbus_status 	= find_dataref("laminar/B738/electric/hot_batbus_status")
B738DR_batbus_status		= find_dataref("laminar/B738/electric/batbus_status")

B738DR_fps				= create_dataref("laminar/B738/fps", "string")

B738DR_real_cg			= create_dataref("laminar/B738/real_cg", "number")
B738DR_real_cg_mac		= create_dataref("laminar/B738/real_cg_mac", "number")

B738DR_layout_0_hide		= create_dataref("laminar/B738/layout_0_hide", "number")
B738DR_layout_1_hide		= create_dataref("laminar/B738/layout_1_hide", "number")
B738DR_layout_2_hide		= create_dataref("laminar/B738/layout_2_hide", "number")
B738DR_layout_3_hide		= create_dataref("laminar/B738/layout_3_hide", "number")
B738DR_layout_4_hide		= create_dataref("laminar/B738/layout_4_hide", "number")
B738DR_passengers_0_hide	= create_dataref("laminar/B738/effects/passengers_0_hide", "number")
B738DR_passengers_1_hide	= create_dataref("laminar/B738/effects/passengers_1_hide", "number")

B738DR_mac 				= create_dataref("laminar/B738/efb_mac", "number")
B738DR_mac_zfw 			= create_dataref("laminar/B738/efb_mac_zfw", "number")
B738DR_mac_des 			= create_dataref("laminar/B738/efb_mac_des", "number")

B738DR_fuel_pumps_off_show	= create_dataref("laminar/B738/placard/fuel_pumps_off", "number")
B738DR_cat3_show			= create_dataref("laminar/B738/placard/cat3", "number")
B738DR_brakes_show			= create_dataref("laminar/B738/placard/brakes", "number")

function jbr_opt737_handl() end
B738DR_jbr_opt737 = create_dataref("jbr/737opt/ready", "number", jbr_opt737_handl)

JBRDR_737opt_icao			= find_dataref("jbr/737opt/icao")
JBRDR_737opt_runway_list	= find_dataref("jbr/737opt/rwy_list")
JBRDR_737opt_status			= find_dataref("jbr/737opt/status")
JBRDR_737opt_query_input	= find_dataref("jbr/737opt/query_input")
JBRDR_737opt_result			= find_dataref("jbr/737opt/result")

JBRCMD_737opt_fetch_rwy		= find_command("jbr/737opt/fetch_runways")
JBRCMD_737opt_calculate		= find_command("jbr/737opt/calculate")

B738DR_atm_valid			= create_dataref("laminar/B738/efb_atm_valid", "number")

ref_icao_old = ""
jbr_find_rwy_timer = 0
perf_takeoff_err = 0

perf_takeoff_windshear = 0
perf_takeoff_full_valid = 0
perf_takeoff_full_rating = 0
perf_takeoff_full_n1 = 0
perf_takeoff_full_v1 = 0
perf_takeoff_full_vr = 0
perf_takeoff_full_v2 = 0

perf_takeoff_atm_valid = 0
perf_takeoff_atm_rating = 0
perf_takeoff_atm_seltemp = 0
perf_takeoff_atm_n1 = 0
perf_takeoff_atm_v1 = 0
perf_takeoff_atm_vr = 0
perf_takeoff_atm_v2 = 0

perf_takeoff_max_wt = 0
perf_takeoff_vref40 = 0
perf_takeoff_flaps = 0
perf_takeoff_trim = 0

perf_takeoff_rating = 0
perf_takeoff_seltemp = 0
perf_takeoff_n1 = 0
perf_takeoff_v1 = 0
perf_takeoff_vr = 0
perf_takeoff_v2 = 0

perf_takeoff_full = 0

-- --*************************************************************************************--
-- --** 				       READ-WRITE CUSTOM DATAREF HANDLERS     	        	     **--
-- --*************************************************************************************--

function hand1() end
function hand2() end
function hand3() end
function hand4() end
B738DR_tablet_test			= create_dataref("laminar/B738/tablet/test", "number", hand1)
B738DR_tablet_test2			= create_dataref("laminar/B738/tablet/test2", "number", hand2)
B738DR_tablet_test3			= create_dataref("laminar/B738/tablet/test3", "number", hand3)
B738DR_tablet_test4			= create_dataref("laminar/B738/tablet/test4", "number", hand4)

function rotate_tablet()
	local adjust_x1 = 0
	local adjust_x2 = 0
	local adjust_y1 = 0
	local adjust_y2 = 0
	
	if B738DR_tab_pos_x < 0.115 then
		adjust_x1 = B738_rescale(0, -20, 0.115, -80, B738DR_tab_pos_x)
		adjust_x2 = B738_rescale(0, -20, 0.115, -20, B738DR_tab_pos_x)
		B738DR_tab_rot_x = B738_rescale(-0.3, adjust_x1, 0.18, adjust_x2, B738DR_tab_pos_y)
		B738DR_tab_rot_y = 0
	elseif B738DR_tab_pos_x < 0.17 then
		adjust_x1 = B738_rescale(0.115, -80, 0.17, -90, B738DR_tab_pos_x)
		adjust_x2 = B738_rescale(0.115, -20, 0.17, -90, B738DR_tab_pos_x)
		B738DR_tab_rot_x = B738_rescale(-0.3, adjust_x1, 0.18, adjust_x2, B738DR_tab_pos_y)
		B738DR_tab_rot_y = 0
	elseif B738DR_tab_pos_x < 0.338 then
		adjust_x1 = B738_rescale(0.17, -90, 0.338, -110, B738DR_tab_pos_x)
		adjust_x2 = B738_rescale(0.17, -90, 0.338, -170, B738DR_tab_pos_x)
		B738DR_tab_rot_x = B738_rescale(-0.3, adjust_x1, 0.18, adjust_x2, B738DR_tab_pos_y)
		adjust_y1 = B738_rescale(0.17, 0, 0.338, 5, B738DR_tab_pos_x)
		adjust_y2 = B738_rescale(0.17, 0, 0.338, 0, B738DR_tab_pos_x)
		B738DR_tab_rot_y = B738_rescale(-0.3, adjust_y1, 0.18, adjust_y2, B738DR_tab_pos_y)
	else
		adjust_x1 = B738_rescale(0.338, -110, 0.455, -130, B738DR_tab_pos_x)
		adjust_x2 = B738_rescale(0.338, -170, 0.455, -170, B738DR_tab_pos_x)
		B738DR_tab_rot_x = B738_rescale(-0.3, adjust_x1, 0.18, adjust_x2, B738DR_tab_pos_y)
		adjust_y1 = B738_rescale(0.338, 5, 0.455, 3, B738DR_tab_pos_x)
		adjust_y2 = B738_rescale(0.338, 0, 0.455, 0, B738DR_tab_pos_x)
		B738DR_tab_rot_y = B738_rescale(-0.3, adjust_y1, 0.18, adjust_y2, B738DR_tab_pos_y)
	end
	B738DR_tab_pos_z = 0
	
end

function B738DR_tab_pos_x_handler() 
	if B738DR_tab_pos_x < 0.04 then
		if B738DR_tab_pos_y > -0.03 and B738DR_tab_pos_y < 0.03 then
			B738DR_tab_pos_x = 0
			B738DR_tab_pos_y = 0
			B738DR_tab_pos_z = 0
			B738DR_tab_rot_x = 0
			B738DR_tab_rot_y = 0
			B738DR_tab_static = 0
		else
			B738DR_tab_static = 1
			local limit_x = B738_rescale(-0.3, 0.115, 0.18, 0.0, B738DR_tab_pos_y)
			B738DR_tab_pos_x = math.max(B738DR_tab_pos_x, limit_x)
			B738DR_tab_pos_x = math.min(B738DR_tab_pos_x, 0.455)
			rotate_tablet()
		end
	else
		local limit_x = B738_rescale(-0.3, 0.115, 0.18, 0.0, B738DR_tab_pos_y)
		B738DR_tab_pos_x = math.max(B738DR_tab_pos_x, limit_x)
		B738DR_tab_pos_x = math.min(B738DR_tab_pos_x, 0.455)
		B738DR_tab_static = 1
		rotate_tablet()
	end
end

function B738DR_tab_pos_y_handler()
	B738DR_tab_pos_y = math.max(B738DR_tab_pos_y, -0.3)
	B738DR_tab_pos_y = math.min(B738DR_tab_pos_y, 0.18)
	
	
	if B738DR_tab_pos_x < 0.04 then
		if B738DR_tab_pos_y > -0.03 and B738DR_tab_pos_y < 0.03 then
			B738DR_tab_pos_x = 0
			B738DR_tab_pos_y = 0
			B738DR_tab_pos_z = 0
			B738DR_tab_rot_x = 0
			B738DR_tab_rot_y = 0
			B738DR_tab_static = 0
		else
			B738DR_tab_static = 1
			rotate_tablet()
		end
	else
		B738DR_tab_static = 1
		rotate_tablet()
	end
end

function B738DR_tab_pos_z_handler()
	B738DR_tab_pos_z = 0
end

function B738DR_tab_rot_x_handler() end
function B738DR_tab_rot_y_handler() end

function rotate_cl()
	
	B738DR_cl_pos_x = math.min(B738DR_cl_pos_x, 0.42)
	B738DR_cl_pos_x = math.max(B738DR_cl_pos_x, -0.42)
	
	local min_pos = -0.32
	if B738DR_cl_pos_x > 0.34 then
		min_pos = -0.385
	elseif B738DR_cl_pos_x > 0.19 then
		min_pos = B738_rescale(0.19, -0.35, 0.34, -0.385, B738DR_cl_pos_x)
	elseif B738DR_cl_pos_x > 0 then
		min_pos = B738_rescale(0, -0.32, 0.19, -0.35, B738DR_cl_pos_x)
	elseif B738DR_cl_pos_x > -0.19 then
		min_pos = B738_rescale(-0.19, -0.35, 0, -0.32, B738DR_cl_pos_x)
	elseif B738DR_cl_pos_x > -0.34 then
		min_pos = B738_rescale(-0.34, -0.385, -0.19, -0.35, B738DR_cl_pos_x)
	else
		min_pos = -0.385
	end
	
	B738DR_cl_pos_y = math.min(B738DR_cl_pos_y, min_pos)
	B738DR_cl_pos_y = math.max(B738DR_cl_pos_y, -0.6)
	
	if simDR_head_x > 0.15 then
		cl_cpt_fo = 1
	elseif simDR_head_x < -0.15 then
		cl_cpt_fo = 0
	end
	
	local add_rot = 0
	if cl_cpt_fo == 0 then
		-- Captain
		if B738DR_cl_pos_x < 0 then
			B738DR_cl_rot_y = B738_rescale(-0.42, 0, 0, 35, B738DR_cl_pos_x)
		else
			B738DR_cl_rot_y = B738_rescale(0, 35, 0.3, 60, B738DR_cl_pos_x)
		end
		if B738DR_cl_pos_x < -0.16 then
			add_rot = B738_rescale(-0.42, 0, -0.16, 12, B738DR_cl_pos_x)
		else
			add_rot = B738_rescale(-0.16, 12, 0.3, 20, B738DR_cl_pos_x)
		end
		add_rot = B738_rescale(-0.6, add_rot, -0.32, 0, B738DR_cl_pos_y)
		B738DR_cl_rot_y = B738DR_cl_rot_y + add_rot
	else
		-- First Officier
		if B738DR_cl_pos_x > 0 then
			B738DR_cl_rot_y = B738_rescale(0, -35, 0.42, 0, B738DR_cl_pos_x)
		else
			B738DR_cl_rot_y = B738_rescale(-0.42, -60, 0, -35, B738DR_cl_pos_x)
		end
		if B738DR_cl_pos_x > 0.16 then
			add_rot = B738_rescale(0.16, -12, 0.42, 0, B738DR_cl_pos_x)
		else
			add_rot = B738_rescale(-0.42, -20, 0.16, -12, B738DR_cl_pos_x)
		end
		add_rot = B738_rescale(-0.6, add_rot, -0.32, 0, B738DR_cl_pos_y)
		B738DR_cl_rot_y = B738DR_cl_rot_y + add_rot
	end
end


function B738DR_cl_pos_x_handler()
	if cl_active == 2 then
		rotate_cl()
	end
end

function B738DR_cl_pos_y_handler()
	if cl_active == 2 then
		rotate_cl()
	end
end
function B738DR_cl_pos_z_handler()
	if cl_active == 2 then
		rotate_cl()
	end
end

function B738DR_cl_rot_x_handler() end
function B738DR_cl_rot_y_handler() end

-- adjust EFB stand
function adjust_z2()
	local adjust_z1 = B738_rescale(-20, 35, 12, 30, B738DR_tab_adjust_y)
	local adjust_z2 = B738_rescale(-20, -30, 12, -30, B738DR_tab_adjust_y)
	B738DR_tab_adjust_z = B738_rescale(-40, adjust_z1, 40, adjust_z2, B738DR_tab_adjust_x)
end

function B738DR_tab_adjust_x_handler()
	B738DR_tab_adjust_x = math.min(B738DR_tab_adjust_x, 40)
	B738DR_tab_adjust_x = math.max(B738DR_tab_adjust_x, -40)
	adjust_z2()
end

function B738DR_tab_adjust_y_handler()
	B738DR_tab_adjust_y = math.min(B738DR_tab_adjust_y, 12)
	B738DR_tab_adjust_y = math.max(B738DR_tab_adjust_y, -20)
	adjust_z2()
end

function B738DR_tab_adjust_z_handler()
	adjust_z2()
end

function B738DR_hud_stow_handler() end
function B738DR_engine_air_start_handler() end
function B738DR_engine_air_n2_rise1_handler() end
function B738DR_engine_air_n2_rise2_handler() end

-- --*************************************************************************************--
-- --** 				       CREATE READ-WRITE CUSTOM DATAREFS                         **--
-- --*************************************************************************************--

B738DR_tab_pos_x			= create_dataref("laminar/B738/tab/pos_x", "number", B738DR_tab_pos_x_handler)
B738DR_tab_pos_y			= create_dataref("laminar/B738/tab/pos_y", "number", B738DR_tab_pos_y_handler)
B738DR_tab_pos_z			= create_dataref("laminar/B738/tab/pos_z", "number", B738DR_tab_pos_z_handler)

B738DR_tab_rot_x			= create_dataref("laminar/B738/tab/rot_x", "number", B738DR_tab_rot_x_handler)
B738DR_tab_rot_y			= create_dataref("laminar/B738/tab/rot_y", "number", B738DR_tab_rot_y_handler)

B738DR_cl_pos_x			= create_dataref("laminar/B738/checklist/pos_x", "number", B738DR_cl_pos_x_handler)
B738DR_cl_pos_y			= create_dataref("laminar/B738/checklist/pos_y", "number", B738DR_cl_pos_y_handler)
B738DR_cl_pos_z			= create_dataref("laminar/B738/checklist/pos_z", "number", B738DR_cl_pos_z_handler)

B738DR_cl_rot_x			= create_dataref("laminar/B738/checklist/rot_x", "number", B738DR_cl_rot_x_handler)
B738DR_cl_rot_y			= create_dataref("laminar/B738/checklist/rot_y", "number", B738DR_cl_rot_y_handler)

B738DR_tab_adjust_x			= create_dataref("laminar/B738/tab/adjust_x", "number", B738DR_tab_adjust_x_handler)
B738DR_tab_adjust_y			= create_dataref("laminar/B738/tab/adjust_y", "number", B738DR_tab_adjust_y_handler)
B738DR_tab_adjust_z			= create_dataref("laminar/B738/tab/adjust_z", "number", B738DR_tab_adjust_z_handler)

function B738DR_fo_tab_pos_x_handler() end
function B738DR_fo_tab_pos_y_handler() end
function B738DR_fo_tab_pos_z_handler() end
function B738DR_fo_tab_rot_x_handler() end
function B738DR_fo_tab_rot_y_handler() end

function adjust_fo_z2()
	local adjust_z1 = B738_rescale(-20, 70, 0, 60, B738DR_fo_tab_adjust_y)
	local adjust_z2 = B738_rescale(-20, 20, 0, 20, B738DR_fo_tab_adjust_y)
	B738DR_fo_tab_adjust_z = B738_rescale(-40, adjust_z1, 13.2, adjust_z2, B738DR_fo_tab_adjust_x)
end

function B738DR_fo_tab_adjust_x_handler()
	B738DR_fo_tab_adjust_x = math.min(B738DR_fo_tab_adjust_x, 13.2)
	B738DR_fo_tab_adjust_x = math.max(B738DR_fo_tab_adjust_x, -40)
	adjust_fo_z2()
end

function B738DR_fo_tab_adjust_y_handler()
	B738DR_fo_tab_adjust_y = math.min(B738DR_fo_tab_adjust_y, 0)
	B738DR_fo_tab_adjust_y = math.max(B738DR_fo_tab_adjust_y, -20)
	adjust_fo_z2()
end

function B738DR_fo_tab_adjust_z_handler()
	adjust_fo_z2()
end

B738DR_fo_tab_static		= create_dataref("laminar/B738/tab/fo_static", "number")

B738DR_fo_tab_pos_x			= create_dataref("laminar/B738/tab/fo_pos_x", "number", B738DR_fo_tab_pos_x_handler)
B738DR_fo_tab_pos_y			= create_dataref("laminar/B738/tab/fo_pos_y", "number", B738DR_fo_tab_pos_y_handler)
B738DR_fo_tab_pos_z			= create_dataref("laminar/B738/tab/fo_pos_z", "number", B738DR_fo_tab_pos_z_handler)

B738DR_fo_tab_rot_x			= create_dataref("laminar/B738/tab/fo_rot_x", "number", B738DR_fo_tab_rot_x_handler)
B738DR_fo_tab_rot_y			= create_dataref("laminar/B738/tab/fo_rot_y", "number", B738DR_fo_tab_rot_y_handler)

B738DR_fo_tab_adjust_x		= create_dataref("laminar/B738/tab/fo_adjust_x", "number", B738DR_fo_tab_adjust_x_handler)
B738DR_fo_tab_adjust_y		= create_dataref("laminar/B738/tab/fo_adjust_y", "number", B738DR_fo_tab_adjust_y_handler)
B738DR_fo_tab_adjust_z		= create_dataref("laminar/B738/tab/fo_adjust_z", "number", B738DR_fo_tab_adjust_z_handler)


B738DR_hud_stow				= create_dataref("laminar/B738/HUD/HUD_stow", "number", B738DR_hud_stow_handler)

function B738DR_landing_rating_handler() end
B738DR_landing_rating		= create_dataref("laminar/B738/flight/landing_rating", "number", B738DR_landing_rating_handler)
B738DR_landing_rating_show	= create_dataref("laminar/B738/flight/landing_rating_show", "number")

function B738DR_approach_rating_handler() end
B738DR_approach_rating		= create_dataref("laminar/B738/flight/approach_rating", "number", B738DR_approach_rating_handler)
B738DR_approach_rating_show	= create_dataref("laminar/B738/flight/approach_rating_show", "number")
B738DR_app_rating_param		= find_dataref("laminar/B738/flight/app_rating_param")

B738DR_engine_air_start		= create_dataref("laminar/B738/engine/engine_air_start", "number", B738DR_engine_air_start_handler)
B738DR_engine_air_n2_rise1	= create_dataref("laminar/B738/engine/engine_air_n2_rise1", "number", B738DR_engine_air_n2_rise1_handler)
B738DR_engine_air_n2_rise2	= create_dataref("laminar/B738/engine/engine_air_n2_rise2", "number", B738DR_engine_air_n2_rise2_handler)
B738DR_hide_asu				= create_dataref("laminar/B738/engine/hide_asu", "number")
B738DR_hide_airstairs		= create_dataref("laminar/B738/airstairs_hide", "number")
B738DR_hide_fueltruck		= create_dataref("laminar/B738/fueltruck_hide", "number")
B738DR_hide_fwd_stairs		= create_dataref("laminar/B738/fwd_stairs_hide", "number")
B738DR_hide_aft_stairs		= create_dataref("laminar/B738/aft_stairs_hide", "number")
B738DR_cones_hide			= find_dataref("laminar/B738/fms/cones_hide")
B738DR_hide_catering		= create_dataref("laminar/B738/catering_hide", "number")
B738DR_hide_catering2		= create_dataref("laminar/B738/catering2_hide", "number")
B738DR_catering_operate		= find_dataref("laminar/B738/catering_operate")
B738DR_catering2_operate	= find_dataref("laminar/B738/catering2_operate")
B738DR_hide_belt			= create_dataref("laminar/B738/belt_hide", "number")
B738DR_hide_belt2			= create_dataref("laminar/B738/belt2_hide", "number")
-- B738DR_belt_operate			= find_dataref("laminar/B738/belt_operate")
B738DR_hide_pax_bus			= create_dataref("laminar/B738/pax_bus_hide", "number")
B738DR_hide_pax_bus2		= create_dataref("laminar/B738/pax_bus2_hide", "number")
B738DR_fueltruck_operate	= find_dataref("laminar/B738/fueltruck_operate")
B738DR_pax_bus_operate		= find_dataref("laminar/B738/pax_bus_operate")
B738DR_pax_bus2_operate		= find_dataref("laminar/B738/pax_bus2_operate")

function amb_handl() end
B738DR_hide_ambulance		= create_dataref("laminar/B738/ambulance_hide", "number", amb_handl)

function fs_handl() end
B738DR_hide_firestriker		= create_dataref("laminar/B738/firestriker_hide", "number", fs_handl)
function fs2_handl() end
B738DR_hide_firestriker2	= create_dataref("laminar/B738/firestriker2_hide", "number", fs2_handl)

B738DR_water_stream1		= create_dataref("laminar/B738/water_stream1/act", "number")
B738DR_water_stream2		= create_dataref("laminar/B738/water_stream2/act", "number")
B738DR_firestriker_operate	= find_dataref("laminar/B738/firestriker_operate")
B738DR_firestriker2_operate	= find_dataref("laminar/B738/firestriker2_operate")
simDR_eng1_fire				= find_dataref("sim/operation/failures/rel_engfir0")
simDR_eng2_fire				= find_dataref("sim/operation/failures/rel_engfir1")
simDR_eng_running			= find_dataref("sim/flightmodel/engine/ENGN_running")
simDR_gear_deploy			= find_dataref("sim/aircraft/parts/acf_gear_deploy")
simDR_crashed				= find_dataref("sim/flightmodel2/misc/has_crashed")
B738DR_nearest_apt_dist		= find_dataref("laminar/B738/nearest_apt_dist")

B738DR_airstairs_angle1			= create_dataref("laminar/B738/airstairs/angle1", "number")
simDR_vert_deflect				= find_dataref("sim/flightmodel2/gear/tire_vertical_deflection_mtr")
B738DR_fueltruck_shift_x		= create_dataref("laminar/B738/fueltruck/shift_x", "number")
B738DR_fueltruck_shift_y		= create_dataref("laminar/B738/fueltruck/shift_y", "number")
B738DR_fueltruck_shift_z		= create_dataref("laminar/B738/fueltruck/shift_z", "number")

--function B738DR_de_ice_truck_pos_handler() end
--B738DR_de_ice_truck_pos 	= create_dataref("laminar/B738/de_ice_truck/pos", "array[6]", B738DR_de_ice_truck_pos_handler)
B738DR_de_ice_truck_pos 	= create_dataref("laminar/B738/de_ice_truck/pos", "array[6]")
B738DR_de_ice_truck_hide	= create_dataref("laminar/B738/de_ice_truck/hide", "number")
B738DR_de_ice_truck_act		= create_dataref("laminar/B738/de_ice_truck/act", "number")
--B738DR_de_ice_truck_act		= find_dataref("laminar/B738/de_ice_truck/act")


B738DR_asu_test 			= find_dataref("laminar/B738/asu_test")
B738DR_fueltruck_test		= find_dataref("laminar/B738/fueltruck_test")
B738DR_cones_test 			= find_dataref("laminar/B738/cones_test")
B738DR_deicetruck_test		= find_dataref("laminar/B738/deicetruck_test")
B738DR_fwd_stairs_test		= find_dataref("laminar/B738/fwd_stairs_test")
B738DR_aft_stairs_test		= find_dataref("laminar/B738/aft_stairs_test")


B738DR_oew_cg				= create_dataref("laminar/B738/tab/oew_cg", "number")
B738DR_oew_weight			= create_dataref("laminar/B738/tab/oew_weight", "number")
B738DR_oew_str				= create_dataref("laminar/B738/tab/oew_str", "string")
B738DR_tow_cg				= create_dataref("laminar/B738/tab/tow_cg", "number")
B738DR_tow_weight			= create_dataref("laminar/B738/tab/tow_weight", "number")
B738DR_tow_str				= create_dataref("laminar/B738/tab/tow_str", "string")
B738DR_lw_cg				= create_dataref("laminar/B738/tab/lw_cg", "number")
B738DR_lw_weight			= create_dataref("laminar/B738/tab/lw_weight", "number")
B738DR_lw_str				= create_dataref("laminar/B738/tab/lw_str", "string")
B738DR_zfw_cg				= create_dataref("laminar/B738/tab/zfw_cg", "number")
B738DR_zfw_weight			= create_dataref("laminar/B738/tab/zfw_weight", "number")
B738DR_zfw_str				= create_dataref("laminar/B738/tab/zfw_str", "string")

function B738DR_ui_manip_handl() end
B738DR_ui_manip			= create_dataref("laminar/B738/tab/ui_manip", "number", B738DR_ui_manip_handl)

B738DR_no_eyebrow_kill		= find_dataref("laminar/B738/tab/no_eyebrow_kill")
B738DR_no_aft_exit_kill		= find_dataref("laminar/B738/tab/no_aft_exit_kill")
B738DR_no_pip_kill			= find_dataref("laminar/B738/tab/no_pip_kill")

B738DR_eyebrow_kill			= find_dataref("laminar/B738/tab/eyebrow_kill")
B738DR_aft_exit_kill		= find_dataref("laminar/B738/tab/aft_exit_kill")
B738DR_pip_kill				= find_dataref("laminar/B738/tab/pip_kill")


B738DR_fuel_cutoff_sw		= find_dataref("laminar/B738/fuel_cutoff_switches")
B738DR_clock_variant		= find_dataref("laminar/B738/clock_variant")
B738DR_efb_colorize			= find_dataref("laminar/B738/tab/efb_colorize")
B738DR_efb_brightness		= find_dataref("laminar/B738/tab/efb_brightness")
B738DR_hyd_compensator		= find_dataref("laminar/B738/hyd_compensator_cartidge")
B738DR_ctr_fuel_pump_auto	= find_dataref("laminar/B738/ctr_fuel_pump_auto")

B738DR_ac_switch_colour		= find_dataref("laminar/B738/ac_switch_colour")
B738DR_panel_cab_ready		= find_dataref("laminar/B738/panel_cab_ready")
B738DR_fd_call_light		= find_dataref("laminar/B738/fd_call_light")
B738DR_pa_in_use_light		= find_dataref("laminar/B738/pa_in_use_light")


simDR_sun_pitch				= find_dataref("sim/graphics/scenery/sun_pitch_degrees")
B738DR_efb_night_mode		= create_dataref("laminar/B738/tab/efb_night_mode", "number")

function B738DR_req_fuel_handl() end
B738DR_req_fuel				= create_dataref("laminar/B738/tab/req_fuel", "number", B738DR_req_fuel_handl)

function B738DR_zone1_payload_handl() 
	local shouldUpdate = false
	for zxp = 1, 3 do
		if zone1_pax[zxp] ~= B738DR_zone1_payload[zxp-1] then
			shouldUpdate = true
			zone1_pax[zxp] = B738DR_zone1_payload[zxp-1]
		end
	end

	if shouldUpdate then
		update_payload()
	end
end
function B738DR_zone2_payload_handl() 
	local shouldUpdate = false
	for zxp = 1, 3 do
		if zone2_pax[zxp] ~= B738DR_zone2_payload[zxp-1] then
			shouldUpdate = true
			zone2_pax[zxp] = B738DR_zone2_payload[zxp-1]
		end
	end

	if shouldUpdate then
		update_payload()
	end
end
function B738DR_zone3_payload_handl() 
	local shouldUpdate = false
	for zxp = 1, 3 do
		if zone3_pax[zxp] ~= B738DR_zone3_payload[zxp-1] then
			shouldUpdate = true
			zone3_pax[zxp] = B738DR_zone3_payload[zxp-1]
		end
	end

	if shouldUpdate then
		update_payload()
	end
end
function B738DR_zone4_payload_handl() 
	local shouldUpdate = false
	for zxp = 1, 3 do
		if zone4_pax[zxp] ~= B738DR_zone4_payload[zxp-1] then
			shouldUpdate = true
			zone4_pax[zxp] = B738DR_zone4_payload[zxp-1]
		end
	end

	if shouldUpdate then
		update_payload()
	end
end
function B738DR_zone5_payload_handl() 
	local shouldUpdate = false
	for zxp = 1, 3 do
		if zone5_pax[zxp] ~= B738DR_zone5_payload[zxp-1] then
			shouldUpdate = true
			zone5_pax[zxp] = B738DR_zone5_payload[zxp-1]
		end
	end

	if shouldUpdate then
		update_payload()
	end
end
function B738DR_zone_cargo1_payload_handl() 
	if zone_cargo1 ~= B738DR_zone_cargo1_payload then
		zone_cargo1 = B738DR_zone_cargo1_payload
		update_payload()
	end 
end
function B738DR_zone_cargo2_payload_handl() 
	if zone_cargo2 ~= B738DR_zone_cargo2_payload then
		zone_cargo2 = B738DR_zone_cargo2_payload
		update_payload()
	end 
end
B738DR_zone1_payload			= create_dataref("laminar/B738/tab/zone1_payload", "array[3]", B738DR_zone1_payload_handl)
B738DR_zone2_payload			= create_dataref("laminar/B738/tab/zone2_payload", "array[3]", B738DR_zone2_payload_handl)
B738DR_zone3_payload			= create_dataref("laminar/B738/tab/zone3_payload", "array[3]", B738DR_zone3_payload_handl)
B738DR_zone4_payload			= create_dataref("laminar/B738/tab/zone4_payload", "array[3]", B738DR_zone4_payload_handl)
B738DR_zone5_payload			= create_dataref("laminar/B738/tab/zone5_payload", "array[3]", B738DR_zone5_payload_handl)
B738DR_zone_cargo1_payload		= create_dataref("laminar/B738/tab/zone_cargo1_payload", "number", B738DR_zone_cargo1_payload_handl)
B738DR_zone_cargo2_payload		= create_dataref("laminar/B738/tab/zone_cargo2_payload", "number", B738DR_zone_cargo2_payload_handl)

function zone_weight_handl() end
B738DR_zone_weight				= create_dataref("laminar/B738/tab/zone_weight", "array[5]", zone_weight_handl)

B738DR_disable_fo_pilot			= create_dataref("laminar/B738/pilots/disable_fo_pilot", "number")

B738DR_auto_flight 				= create_dataref("laminar/B738/tab/auto_flight", "number")

-- --*************************************************************************************--
-- --** 				             CUSTOM COMMAND HANDLERS            			     **--
-- --*************************************************************************************--

function B738_hud_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_hud_disable == 0 then
			if B738DR_hud_stow == 0 then
				B738DR_hud_stow = 1
			else
				B738DR_hud_stow = 0
			end
		end
	end
end

function B738_tab_info_CMDhandler(phase, duration)
	if phase == 0 then
		if info_act == 0 then
			info_act = 1
		else
			info_act = 0
		end
	end
end

function B738_tab_home_CMDhandler(phase, duration)
	if phase == 0 then
		if info_act ~= 0 then
			info_act = 0
		elseif failures_changed ~= 0 then
			B738DR_failure_save = 2
			failures_changed = 0
			display_update = 1
		elseif B738DR_failure_save == 0 then
			cat = CAT_HOME
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
			clr_item()
			-- close numpad
			B738DR_tab_numpad_act = 0
			B738DR_tab_numpad_spec1 = 0
			B738DR_tab_numpad_spec2 = 0
			B738DR_tab_numpad_val = ""
			tab_numpad_val = ""
			numpad_ref = 0
			numpad_point = 0
			checklist_page = 1
			B738DR_tab_nav2_manip = 1
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 0
			end
		end
	end
end

function B738_tab_back_CMDhandler(phase, duration)
	if phase == 0 then
		if info_act ~= 0 then
			info_act = 0
		elseif failures_changed ~= 0 then
			B738DR_failure_save = 1
			failures_changed = 0
			display_update = 1
		elseif B738DR_failure_save == 0 then
			if cat >= CAT_FEATURES  and cat <= CAT_CALIBRATE then
				cat = CAT_SETTINGS
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif cat == CAT_LOAD_SAVE or cat == CAT_ANNOUNC or cat == CAT_CHECKLIST 
			or cat == CAT_CREDITS or cat == CAT_SERVICES or cat == CAT_AVITAB or cat == CAT_PAY_PERF or cat == CAT_OPTIONAL_ACCESS then
				cat = CAT_HOME
				page = 1
				min_page = 1
				max_page = 2
				checklist_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 1
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					avitab_enabled = 0
				end
				if cat == CAT_CREDITS then
					if B738DR_b737_variant < 0 then
						B738DR_tab_credits = 0
					else
						B738DR_tab_credits = 1
					end
				end
			elseif cat == CAT_SETTINGS or cat == CAT_FAILURES or cat == CAT_DEV_TUNE then
				cat = CAT_HOME
				page = 2
				min_page = 1
				max_page = 2
				checklist_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 1
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					avitab_enabled = 0
				end
			elseif cat == CAT_AVITAB_ACT then
				cat = CAT_AVITAB
				display_update = 1
				B738DR_tab_nav2_manip = 0
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					avitab_enabled = 0
				end
			elseif cat == CAT_FUEL_CG or cat == CAT_PERF_LAND or cat == CAT_PERF_TAKEOFF or cat == CAT_APP_RATING or cat == CAT_AUTO_FLIGHT then
				cat = CAT_PAY_PERF
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			elseif cat == CAT_BP_MENU or cat == CAT_DOORS or cat == CAT_LIGHTS then
				cat = CAT_SERVICES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			elseif cat == CAT_FAIL_ELEC or cat == CAT_FAIL_HYD or cat == CAT_FAIL_SYS or cat == CAT_FAIL_PRESSURIS or cat == CAT_FAIL_ENG then
				cat = CAT_FAILURES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			elseif cat == CAT_ANN_SET then
				cat = CAT_ANNOUNC
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif cat >= CAT_CL_PR_PREFLIGHT and cat <= CAT_CL_SECURE then
				cat = CAT_CHECKLIST
				--page = 1
				page = checklist_page
				min_page = 1
				max_page = 3
				display_update = 1
				B738DR_tab_nav2_manip = 2
			elseif cat == CAT_CFG_PRESETS or cat == CAT_AUDIO_PRESETS or cat == CAT_STATE_PRESETS or cat == CAT_LOAD_SAVE_FLIGHT then
				cat = CAT_LOAD_SAVE
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif cat == CAT_OPTION_EXTERIOR or cat == CAT_OPTION_SYSTEMS or cat == CAT_OPTION_DISPLAYS 
			or cat == CAT_OPTION_FMS or cat == CAT_OPTION_AUTOFLIGHT or cat == CAT_OPTION_CALLOUTS or cat == CAT_OPTION_PLACARDS then
				cat = CAT_OPTIONAL_ACCESS
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			end
			clr_item()
			-- close numpad
			B738DR_tab_numpad_act = 0
			B738DR_tab_numpad_spec1 = 0
			B738DR_tab_numpad_spec2 = 0
			B738DR_tab_numpad_val = ""
			tab_numpad_val = ""
			numpad_ref = 0
			numpad_point = 0
		end
	end
end

function clr_items_spec(xfrom, xto)
	if xto > xfrom then
		for i = xfrom, xto-1 do
			item_checked[i] = 0
		end
	end
end

function B738_tab_spec_CMDhandler(phase, duration)
	if phase == 0 then
		if cat == CAT_HOME then
			cat = CAT_CREDITS
			page = 1
			min_page = 1
			max_page = 1
			checklist_page = 1
			B738DR_tab_nav2_manip = 0
			if B738DR_b737_variant < 0 then
				B738DR_tab_credits = 0
			else
				B738DR_tab_credits = 1
			end
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_about:once()
			end
		elseif cat == CAT_CHECKLIST then
			clr_items_spec(0, 511)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_prelim_idx, cl_prelim_idx + CL_PRELIM)
			else
				clr_items_spec(cl_prelim_idx2, cl_prelim_idx2 + CL_PRELIM_D)
			end
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_cdu_idx, cl_cdu_idx + CL_CDU)
			else
				clr_items_spec(cl_cdu_idx2, cl_cdu_idx2 + CL_CDU_D)
			end
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_cpt_preflt_idx, cl_cpt_preflt_idx + CL_CPT_PREFLT)
			else
				clr_items_spec(cl_cpt_preflt_idx2, cl_cpt_preflt_idx2 + CL_CPT_PREFLT_D)
			end
		elseif cat == CAT_CL_FO_PREFLIGHT then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_fo_preflt_idx, cl_fo_preflt_idx + CL_FO_PREFLT)
			else
				clr_items_spec(cl_fo_preflt_idx2, cl_fo_preflt_idx2 + CL_FO_PREFLT_D)
			end
		elseif cat == CAT_CL_BEFORE_START then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_before_start_idx, cl_before_start_idx + CL_BEFORE_START)
			else
				clr_items_spec(cl_before_start_idx2, cl_before_start_idx2 + CL_BEFORE_START_D)
			end
		elseif cat == CAT_CL_PUSHBACK then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_pushback_idx, cl_pushback_idx + CL_PUSHBACK)
			else
				clr_items_spec(cl_pushback_idx2, cl_pushback_idx2 + CL_PUSHBACK_D)
			end
		elseif cat == CAT_CL_ENG_START then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_eng_start_idx, cl_eng_start_idx + CL_ENG_START)
			else
				clr_items_spec(cl_eng_start_idx2, cl_eng_start_idx2 + CL_ENG_START_D)
			end
		elseif cat == CAT_CL_BEFORE_TAXI then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_before_taxi_idx, cl_before_taxi_idx + CL_BEFORE_TAXI)
			else
				clr_items_spec(cl_before_taxi_idx2, cl_before_taxi_idx2 + CL_BEFORE_TAXI_D)
			end
		elseif cat == CAT_CL_TAKEOFF then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_takeoff_idx, cl_takeoff_idx + CL_TAKEOFF)
			else
				clr_items_spec(cl_takeoff_idx2, cl_takeoff_idx2 + CL_TAKEOFF_D)
			end
		elseif cat == CAT_CL_CLIMB_CRUISE then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_climb_cruise_idx, cl_climb_cruise_idx + CL_CLIMB_CRUISE)
			else
				clr_items_spec(cl_climb_cruise_idx2, cl_climb_cruise_idx2 + CL_CLIMB_CRUISE_D)
			end
		elseif cat == CAT_CL_DESCENT then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_descent_idx, cl_descent_idx + CL_DESCENT)
			else
				clr_items_spec(cl_descent_idx2, cl_descent_idx2 + CL_DESCENT_D)
			end
		elseif cat == CAT_CL_APPROACH then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_approach_idx, cl_approach_idx + CL_APPROACH)
			else
				clr_items_spec(cl_approach_idx2, cl_approach_idx2 + CL_APPROACH_D)
			end
		elseif cat == CAT_CL_LANDING_ILS then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_landing_ils_idx, cl_landing_ils_idx + CL_LANDING_ILS)
			else
				clr_items_spec(cl_landing_ils_idx2, cl_landing_ils_idx2 + CL_LANDING_ILS_D)
			end
		elseif cat == CAT_CL_LANDING_IAN then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_landing_ian_idx, cl_landing_ian_idx + CL_LANDING_IAN)
			else
				clr_items_spec(cl_landing_ian_idx2, cl_landing_ian_idx2 + CL_LANDING_IAN_D)
			end
		elseif cat == CAT_CL_LANDING_VNAV then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_landing_vnav_idx, cl_landing_vnav_idx + CL_LANDING_VNAV)
			else
				clr_items_spec(cl_landing_vnav_idx2, cl_landing_vnav_idx2 + CL_LANDING_VNAV_D)
			end
		elseif cat == CAT_CL_GOAROUND then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_goaround_idx, cl_goaround_idx + CL_GOAROUND)
			else
				clr_items_spec(cl_goaround_idx2, cl_goaround_idx2 + CL_GOAROUND_D)
			end
		elseif cat == CAT_CL_AFTER_LAND then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_after_land_idx, cl_after_land_idx + CL_AFTER_LAND)
			else
				clr_items_spec(cl_after_land_idx2, cl_after_land_idx2 + CL_AFTER_LAND_D)
			end
		elseif cat == CAT_CL_SHUTDOWN then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_shutdown_idx, cl_shutdown_idx + CL_SHUTDOWN)
			else
				clr_items_spec(cl_shutdown_idx2, cl_shutdown_idx2 + CL_SHUTDOWN_D)
			end
		elseif cat == CAT_CL_SECURE then
			if B738DR_detail_cl == 0 then
				clr_items_spec(cl_secure_idx, cl_secure_idx + CL_SECURE)
			else
				clr_items_spec(cl_secure_idx2, cl_secure_idx2 + CL_SECURE_D)
			end
		end
		display_update = 1
	end
end

function B738_tab_line0_CMDhandler(phase, duration)
	if phase == 0 then
		page = 1
		display_update = 1
		line_select = 0
	end
end

function B738_tab_line1_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 1 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line2_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 2 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line3_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 3 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line4_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 4 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line5_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 5 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line6_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 6 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line7_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 7 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line8_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 8 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_line9_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 9 + ((page - 1) * 9)
		if cat == CAT_HARDWARE then
			cmd_hardware(xcmd)
		-- elseif cat == CAT_OPTIONAL_ACCESS then
			-- cmd_optional(xcmd)
		elseif cat == CAT_OPTION_EXTERIOR then
			cmd_option_exterior(xcmd)
		elseif cat == CAT_OPTION_SYSTEMS then
			cmd_option_systems(xcmd)
		elseif cat == CAT_OPTION_DISPLAYS then
			cmd_option_displays(xcmd)
		elseif cat == CAT_OPTION_FMS then
			cmd_option_fms(xcmd)
		elseif cat == CAT_OPTION_AUTOFLIGHT then
			cmd_option_autoflight(xcmd)
		elseif cat == CAT_OPTION_CALLOUTS then
			cmd_option_callouts(xcmd)
		elseif cat == CAT_OPTION_PLACARDS then
			cmd_option_placards(xcmd)
		elseif cat == CAT_REALISM then
			cmd_realism(xcmd)
		elseif cat == CAT_VISUAL_EFFECTS then
			cmd_visual(xcmd)
		elseif cat == CAT_CONFIG then
			cmd_config(xcmd)
		elseif cat == CAT_DEV_TUNE then
			cmd_dev_tune(xcmd)
		elseif cat == CAT_FEATURES then
			cmd_feature(xcmd)
		elseif cat == CAT_VOLUME_EQ then
			cmd_volume_eq(xcmd)
		elseif cat == CAT_ANN_SET then
			cmd_ann_set(xcmd)
		elseif cat == CAT_CL_PR_PREFLIGHT then
			cmd_cl_pf(xcmd)
		elseif cat == CAT_CL_CDU_PREFLIGHT then
			cmd_cl_cdu_pf(xcmd)
		elseif cat == CAT_CL_CPT_PREFLIGHT then
			cmd_cl_cpt_pf(xcmd)
		elseif cat == CAT_CL_FO_PREFLIGHT then
			cmd_cl_fo_pf(xcmd)
		elseif cat == CAT_CL_BEFORE_START then
			cmd_cl_bs(xcmd)
		elseif cat == CAT_CL_PUSHBACK then
			cmd_cl_pushback(xcmd)
		elseif cat == CAT_CL_ENG_START then
			cmd_cl_eng_start(xcmd)
		elseif cat == CAT_CL_BEFORE_TAXI then
			cmd_cl_before_taxi(xcmd)
		elseif cat == CAT_CL_TAKEOFF then
			cmd_cl_takeoff(xcmd)
		elseif cat == CAT_CL_CLIMB_CRUISE then
			cmd_cl_climb_cruise(xcmd)
		elseif cat == CAT_CL_DESCENT then
			cmd_cl_descent(xcmd)
		elseif cat == CAT_CL_APPROACH then
			cmd_cl_approach(xcmd)
		elseif cat == CAT_CL_LANDING_ILS then
			cmd_cl_landing_ils(xcmd)
		elseif cat == CAT_CL_LANDING_IAN then
			cmd_cl_landing_ian(xcmd)
		elseif cat == CAT_CL_LANDING_VNAV then
			cmd_cl_landing_vnav(xcmd)
		elseif cat == CAT_CL_GOAROUND then
			cmd_cl_go_around(xcmd)
		elseif cat == CAT_CL_AFTER_LAND then
			cmd_cl_after_land(xcmd)
		elseif cat == CAT_CL_SHUTDOWN then
			cmd_cl_shutdown(xcmd)
		elseif cat == CAT_CL_SECURE then
			cmd_cl_secure(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_fuel_cg(xcmd)
		elseif cat == CAT_AUTO_FLIGHT then
			cmd_auto_flight(xcmd)
		elseif cat == CAT_PERF_LAND then
			cmd_perf_land(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff(xcmd)
		-- elseif cat == CAT_DOORS then
			-- cmd_doors(xcmd)
		elseif cat == CAT_LIGHTS then
			cmd_lights(xcmd)
		elseif cat == CAT_CALIBRATE then
			cmd_calibration(xcmd)
		elseif cat == CAT_FAIL_ELEC then
			cmd_fail_elec(xcmd)
		elseif cat == CAT_FAIL_HYD then
			cmd_fail_hyd(xcmd)
		elseif cat == CAT_FAIL_SYS then
			cmd_fail_sys(xcmd)
		elseif cat == CAT_FAIL_PRESSURIS then
			cmd_fail_pressurisation(xcmd)
		elseif cat == CAT_FAIL_ENG then
			cmd_fail_eng(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf1_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 1 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf2_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 2 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf3_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 3 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf4_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 4 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf5_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 5 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf6_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 6 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf7_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 7 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf8_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 8 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf9_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 9 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf10_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 10 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf11_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 11 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf12_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 12 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf13_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 13 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf14_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 14 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf15_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 15 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_perf16_CMDhandler(phase, duration)
	if phase == 0 then
		local xcmd = 16 + ((page - 1) * 16)
		if cat == CAT_PERF_LAND then
			cmd_perf_land2(xcmd)
		elseif cat == CAT_PERF_TAKEOFF then
			cmd_perf_takeoff2(xcmd)
		elseif cat == CAT_FUEL_CG then
			cmd_perf_fuel_cg(xcmd)
		end
		display_update = 1
	end
end

function B738_tab_menu1_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if cat == CAT_SETTINGS then
			cat = CAT_OPTIONAL_ACCESS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_HOME then
			if page == 1 then
				cat = CAT_ANNOUNC
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif page == 2 then
				cat = CAT_SETTINGS
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			end
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(1)
			else
				cmd_doors(9)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_SERVICES then
			cmd_services(1)
		elseif cat == CAT_PAY_PERF then
			cat = CAT_FUEL_CG
			page = 1
			min_page = 1
			max_page = 4
			display_update = 1
			B738DR_tab_nav2_manip = 0
		elseif cat == CAT_BP_MENU then
			cmd_bp(1)
		elseif cat == CAT_ANNOUNC then
			cmd_announc(1)
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_charts:once()
			end
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_PR_PREFLIGHT
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 2
					checklist_offset = cl_prelim_idx
					checklist_act_page(cl_prelim_idx, cl_prelim_idx + CL_PRELIM - 1)
				else
					max_page = 3
					checklist_offset = cl_prelim_idx2
					checklist_act_page(cl_prelim_idx2, cl_prelim_idx2 + CL_PRELIM_D - 1)
				end
			elseif page == 2 then
				cat = CAT_CL_TAKEOFF
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 3
					checklist_offset = cl_takeoff_idx
				else
					max_page = 3
					checklist_offset = cl_takeoff_idx2
				end
			elseif page == 3 then
				cat = CAT_CL_AFTER_LAND
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_after_land_idx
				else
					max_page = 1
					checklist_offset = cl_after_land_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_LOAD_SAVE then
			cmd_load_save(1)
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(1)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(1)
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(1)
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			cmd_load_save_flight(1)
		elseif cat == CAT_FAILURES then
			cat = CAT_FAIL_ELEC
			page = 1
			min_page = 1
			max_page = 4
			display_update = 1
			B738DR_tab_nav2_manip = 0
			failures_changed = 0
			read_failures(0)
		elseif cat == CAT_OPTIONAL_ACCESS then
			cat = CAT_OPTION_EXTERIOR
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		end
		line_select = 0
	end
end

function B738_tab_menu2_CMDhandler(phase, duration) 
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if cat == CAT_SETTINGS then
			cat = CAT_HARDWARE
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
		elseif cat == CAT_HOME then
			if page == 1 then
				cmd_home(2)
			end
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(2)
			else
				cmd_doors(10)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_PAY_PERF then
			cat = CAT_PERF_TAKEOFF
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
			B738DR_tab_nav2_manip = 0
		elseif cat == CAT_SERVICES then
			cmd_services(2)
		elseif cat == CAT_BP_MENU then
			cmd_bp(2)
		elseif cat == CAT_ANNOUNC then
			cmd_announc(2)
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_airports:once()
			end
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_CDU_PREFLIGHT
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_cdu_idx
				else
					max_page = 4
					checklist_offset = cl_cdu_idx2
				end
			elseif page == 2 then
				cat = CAT_CL_CLIMB_CRUISE
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_climb_cruise_idx
				else
					max_page = 1
					checklist_offset = cl_climb_cruise_idx2
				end
			elseif page == 3 then
				cat = CAT_CL_SHUTDOWN
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 3
					checklist_offset = cl_shutdown_idx
				else
					max_page = 3
					checklist_offset = cl_shutdown_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_LOAD_SAVE then
			cat = CAT_CFG_PRESETS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(2)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(2)
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(2)
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			cmd_load_save_flight(2)
		elseif cat == CAT_FAILURES then
			cat = CAT_FAIL_HYD
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
			B738DR_tab_nav2_manip = 0
			failures_changed = 0
			read_failures(1)
		elseif cat == CAT_OPTIONAL_ACCESS then
			cat = CAT_OPTION_SYSTEMS
			page = 1
			min_page = 1
			max_page = 4
			display_update = 1
		end
		line_select = 0
	end
end

function B738_tab_menu3_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if cat == CAT_SETTINGS then
			cat = CAT_REALISM
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
		elseif cat == CAT_HOME then
			if page == 1 then
				cmd_home(3)
			end
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(3)
			else
				cmd_doors(11)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_ANNOUNC then
			cmd_announc(3)
		elseif cat == CAT_PAY_PERF then
			cat = CAT_PERF_LAND
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
			B738DR_tab_nav2_manip = 0
		elseif cat == CAT_SERVICES then
			if bp_installed == 1 then
				cat = CAT_BP_MENU
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			end
		elseif cat == CAT_BP_MENU then
			cmd_bp(3)
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_routes:once()
			end
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_CPT_PREFLIGHT
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 4
					checklist_offset = cl_cpt_preflt_idx
				else
					max_page = 4
					checklist_offset = cl_cpt_preflt_idx2
				end
			elseif page == 2 then
				cat = CAT_CL_DESCENT
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_descent_idx
				else
					max_page = 1
					checklist_offset = cl_descent_idx2
				end
			elseif page == 3 then
				cat = CAT_CL_SECURE
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_secure_idx
				else
					max_page = 1
					checklist_offset = cl_secure_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_LOAD_SAVE then
			cat = CAT_AUDIO_PRESETS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(3)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(3)
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(3)
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			cmd_load_save_flight(3)
		elseif cat == CAT_FAILURES then
			cat = CAT_FAIL_SYS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
			B738DR_tab_nav2_manip = 0
			failures_changed = 0
			read_failures(2)
		elseif cat == CAT_OPTIONAL_ACCESS then
			cat = CAT_OPTION_DISPLAYS
			page = 1
			min_page = 1
			max_page = 3
			display_update = 1
		end
		line_select = 0
	end
end

function B738_tab_menu4_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if cat == CAT_SETTINGS then
			cat = CAT_VISUAL_EFFECTS
			page = 1
			min_page = 1
			max_page = 3
			display_update = 1
		elseif cat == CAT_ANNOUNC then
			cmd_announc(4)
		elseif cat == CAT_BP_MENU then
			cmd_bp(4)
		elseif cat == CAT_HOME then
			if page == 1 then
				cat = CAT_PAY_PERF
				page = 1
				min_page = 1
				max_page = 1
			elseif page == 2 then
				cat = CAT_FAILURES
				page = 1
				min_page = 1
				max_page = 1
				B738DR_tab_nav2_manip = 0
			end
			display_update = 1
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(4)
			else
				cmd_doors(12)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_maps:once()
			end
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_FO_PREFLIGHT
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 6
					checklist_offset = cl_fo_preflt_idx
				else
					max_page = 6
					checklist_offset = cl_fo_preflt_idx2
				end
			elseif page == 2 then
				cat = CAT_CL_APPROACH
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_approach_idx
				else
					max_page = 1
					checklist_offset = cl_approach_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_SERVICES then
			cmd_services(4)
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(4)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(4)
		elseif cat == CAT_LOAD_SAVE then
			cat = CAT_STATE_PRESETS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(4)
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			cmd_load_save_flight(4)
		elseif cat == CAT_FAILURES then
			cat = CAT_FAIL_PRESSURIS
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
			B738DR_tab_nav2_manip = 0
			failures_changed = 0
			read_failures(3)
		elseif cat == CAT_PAY_PERF then
			if B738DR_approach_rating ~= 0 and simDR_aircraft_groundspeed < 30 then
				cat = CAT_APP_RATING
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			end
		elseif cat == CAT_OPTIONAL_ACCESS then
			cat = CAT_OPTION_FMS
			page = 1
			min_page = 1
			max_page = 3
			display_update = 1
		end
		line_select = 0
	end
end

function B738_tab_menu5_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if cat == CAT_SETTINGS then
			cat = CAT_CONFIG
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
		elseif cat == CAT_LOAD_SAVE then
			cmd_load_save(5)
		elseif cat == CAT_ANNOUNC then
			cmd_announc(5)
		elseif cat == CAT_BP_MENU then
			cmd_bp(5)
		elseif cat == CAT_HOME then
			cat = CAT_CHECKLIST
			page = 1
			min_page = 1
			max_page = 3
			display_update = 1
			B738DR_tab_nav2_manip = 2
		elseif cat == CAT_PAY_PERF then
			--**** FUEL TRUCK ***--
			-- cmd_services(7)
			cmd_pay_perf(5)
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_BEFORE_START
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_before_start_idx
				else
					max_page = 2
					checklist_offset = cl_before_start_idx2
				end
			elseif page == 2 then
				cat = CAT_CL_LANDING_ILS
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 2
					checklist_offset = cl_landing_ils_idx
				else
					max_page = 2
					checklist_offset = cl_landing_ils_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(5)
			else
				cmd_doors(13)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_SERVICES then
			cmd_services(5)
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(5)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(5)
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(5)
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			clr_menu_mark()
			if is_timer_scheduled(menu_mark_timer) == true then
				stop_timer(menu_mark_timer)
			end
			B738DR_tab_menu_mark[4] = 1
			run_after_time(menu_mark_timer, 0.4)
			cmd_load_save_flight(5)
		elseif cat == CAT_OPTIONAL_ACCESS then
			cat = CAT_OPTION_AUTOFLIGHT
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_FAILURES then
			cat = CAT_FAIL_ENG
			page = 1
			min_page = 1
			max_page = 4
			display_update = 1
			B738DR_tab_nav2_manip = 0
			failures_changed = 0
			read_failures(4)
		end
		line_select = 0
	end
end

function B738_tab_menu6_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if B738DR_autoload_on ~= 0 then
			-- yes autoload
			B738DR_autoload_on = 0
			display_update = 1
			B738DR_load_save = 2
			B738DR_load_save2 = 9
		elseif B738DR_failure_save ~= 0 then
			-- yes failure save
			if cat == CAT_FAIL_ELEC then
				write_failures(0)
			elseif cat == CAT_FAIL_HYD then
				write_failures(1)
			elseif cat == CAT_FAIL_SYS then
				write_failures(2)
			elseif cat == CAT_FAIL_PRESSURIS then
				write_failures(3)
			elseif cat == CAT_FAIL_ENG then
				write_failures(4)
			end
			if B738DR_failure_save == 1 then
				-- to FAILURES
				cat = CAT_FAILURES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			else
				-- to HOME
				cat = CAT_HOME
				page = 1
				min_page = 1
				max_page = 2
				display_update = 1
				clr_item()
				-- close numpad
				B738DR_tab_numpad_act = 0
				B738DR_tab_numpad_spec1 = 0
				B738DR_tab_numpad_spec2 = 0
				B738DR_tab_numpad_val = ""
				tab_numpad_val = ""
				numpad_ref = 0
				numpad_point = 0
				checklist_page = 1
				B738DR_tab_nav2_manip = 1
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					avitab_enabled = 0
				end
			end
			B738DR_failure_save = 0
			B738DR_tab_nav_manip = 1
			B738DR_tab_info_manip = 1
		else
			if cat == CAT_SETTINGS then
				cat = CAT_FEATURES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif cat == CAT_HOME then
				cat = CAT_SERVICES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			elseif cat == CAT_DOORS then
				if page == 1 then
					cmd_doors(6)
				else
					cmd_doors(14)
				end
				min_page = 1
				max_page = 2
			elseif cat == CAT_BP_MENU then
				cmd_bp(6)
			elseif cat == CAT_LOAD_SAVE then
				cmd_load_save(6)
			elseif cat == CAT_CFG_PRESETS then
				cmd_cfg_presets(6)
			elseif cat == CAT_AUDIO_PRESETS then
				cmd_audio_presets(6)
			elseif cat == CAT_CHECKLIST then
				B738DR_tab_nav2_manip = 2
				if page == 1 then
					cat = CAT_CL_PUSHBACK
					page = 1
					min_page = 1
					if B738DR_detail_cl == 0 then
						max_page = 1
						checklist_offset = cl_pushback_idx
					else
						max_page = 1
						checklist_offset = cl_pushback_idx2
					end
				elseif page == 2 then
					cat = CAT_CL_LANDING_IAN
					page = 1
					min_page = 1
					if B738DR_detail_cl == 0 then
						max_page = 2
						checklist_offset = cl_landing_ian_idx
					else
						max_page = 2
						checklist_offset = cl_landing_ian_idx2
					end
				end
				display_update = 1
			elseif cat == CAT_SERVICES then
				cmd_services(6)
			elseif cat == CAT_STATE_PRESETS then
				cmd_state_presets(6)
			elseif cat == CAT_LOAD_SAVE_FLIGHT then
				clr_menu_mark()
				if is_timer_scheduled(menu_mark_timer) == true then
					stop_timer(menu_mark_timer)
				end
				B738DR_tab_menu_mark[5] = 1
				run_after_time(menu_mark_timer, 0.4)
				cmd_load_save_flight(6)
			elseif cat == CAT_OPTIONAL_ACCESS then
				cat = CAT_OPTION_CALLOUTS
				page = 1
				min_page = 1
				max_page = 3
				display_update = 1
			elseif cat == CAT_FAILURES then
				-- enable random failures
				clr_menu_mark()
				if is_timer_scheduled(menu_mark_timer) == true then
					stop_timer(menu_mark_timer)
				end
				B738DR_tab_menu_mark[5] = 1
				run_after_time(menu_mark_timer, 0.4)
				B738CMD_enable_rnd_fail:once()
			end
		end
		line_select = 0
	end
end

function B738_tab_menu7_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		if B738DR_autoload_on ~= 0 then
			-- no autoload
			B738DR_autoload_on = 0
			display_update = 1
		elseif B738DR_failure_save ~= 0 then
			--  no Failures save
			if B738DR_failure_save == 1 then
				-- to FAILURES
				cat = CAT_FAILURES
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
				B738DR_tab_nav2_manip = 0
			else
				-- to HOME
				cat = CAT_HOME
				page = 1
				min_page = 1
				max_page = 2
				display_update = 1
				clr_item()
				-- close numpad
				B738DR_tab_numpad_act = 0
				B738DR_tab_numpad_spec1 = 0
				B738DR_tab_numpad_spec2 = 0
				B738DR_tab_numpad_val = ""
				tab_numpad_val = ""
				numpad_ref = 0
				numpad_point = 0
				checklist_page = 1
				B738DR_tab_nav2_manip = 1
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					avitab_enabled = 0
				end
			end
			B738DR_failure_save = 0
			B738DR_tab_nav_manip = 1
			B738DR_tab_info_manip = 1
		else
			if cat == CAT_HOME then
				if avitab_installed == 1 and avitab_ctrl_override == 0 then
					cat = CAT_AVITAB
					page = 1
					min_page = 1
					max_page = 1
					display_update = 1
					B738DR_tab_nav2_manip = 0
				end
			elseif cat == CAT_DOORS then
				if page == 1 then
					cmd_doors(7)
				else
					cmd_doors(15)
				end
				min_page = 1
				max_page = 2
			elseif cat == CAT_BP_MENU then
				cmd_bp(7)
			elseif cat == CAT_LOAD_SAVE then
				cmd_load_save(7)
			elseif cat == CAT_SETTINGS then
				cat = CAT_VOLUME_EQ
				page = 1
				min_page = 1
				max_page = 2
				display_update = 1
			elseif cat == CAT_CFG_PRESETS then
				cmd_cfg_presets(7)
			elseif cat == CAT_AUDIO_PRESETS then
				cmd_audio_presets(7)
			elseif cat == CAT_CHECKLIST then
				B738DR_tab_nav2_manip = 2
				if page == 1 then
					cat = CAT_CL_ENG_START
					page = 1
					min_page = 1
					if B738DR_detail_cl == 0 then
						max_page = 3
						checklist_offset = cl_eng_start_idx
					else
						max_page = 3
						checklist_offset = cl_eng_start_idx2
					end
				elseif page == 2 then
					cat = CAT_CL_LANDING_VNAV
					page = 1
					min_page = 1
					if B738DR_detail_cl == 0 then
						max_page = 2
						checklist_offset = cl_landing_vnav_idx
					else
						max_page = 2
						checklist_offset = cl_landing_vnav_idx2
					end
				end
				display_update = 1
			elseif cat == CAT_SERVICES then
				cat = CAT_DOORS
				page = 1
				min_page = 1
				max_page = 2
				display_update = 1
				-- --**** FUEL TRUCK ***--
				-- cmd_services(7)
			elseif cat == CAT_STATE_PRESETS then
				cmd_state_presets(7)
			elseif cat == CAT_LOAD_SAVE_FLIGHT then
				clr_menu_mark()
				if is_timer_scheduled(menu_mark_timer) == true then
					stop_timer(menu_mark_timer)
				end
				B738DR_tab_menu_mark[6] = 1
				run_after_time(menu_mark_timer, 0.4)
				cmd_load_save_flight(7)
			elseif cat == CAT_OPTIONAL_ACCESS then
				cat = CAT_OPTION_PLACARDS
				page = 1
				min_page = 1
				max_page = 1
				display_update = 1
			elseif cat == CAT_FAILURES then
				-- disable random failures
				clr_menu_mark()
				if is_timer_scheduled(menu_mark_timer) == true then
					stop_timer(menu_mark_timer)
				end
				B738DR_tab_menu_mark[6] = 1
				run_after_time(menu_mark_timer, 0.4)
				B738CMD_disable_rnd_fail:once()
			end
		end
		line_select = 0
	end
end

function B738_tab_menu8_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_nav2_manip = 0
		-- if cat == CAT_HOME then
			-- cat = CAT_LOAD_SAVE
			-- page = 1
			-- min_page = 1
			-- max_page = 1
			-- display_update = 1
		if cat == CAT_HOME then
			if page == 1 then
				cat = CAT_LOAD_SAVE
				page = 1
				min_page = 1
				max_page = 1
			elseif page == 2 then
				cat = CAT_DEV_TUNE
				page = 1
				min_page = 1
				max_page = 25
			end
			display_update = 1
		elseif cat == CAT_DOORS then
			if page == 1 then
				cmd_doors(8)
			else
				cmd_doors(16)
			end
			min_page = 1
			max_page = 2
		elseif cat == CAT_BP_MENU then
			cmd_bp(8)
		elseif cat == CAT_ANNOUNC then
			cat = CAT_ANN_SET
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
		elseif cat == CAT_CFG_PRESETS then
			cmd_cfg_presets(8)
		elseif cat == CAT_AUDIO_PRESETS then
			cmd_audio_presets(8)
		elseif cat == CAT_SETTINGS then
			cat = CAT_CALIBRATE
			page = 1
			min_page = 1
			max_page = 3
			display_update = 1
		elseif cat == CAT_AVITAB then
			cat = CAT_AVITAB_ACT
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_enabled = 1
				avitab_CMD_app_about:once()
			end
		elseif cat == CAT_CHECKLIST then
			B738DR_tab_nav2_manip = 2
			if page == 1 then
				cat = CAT_CL_BEFORE_TAXI
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 2
					checklist_offset = cl_before_taxi_idx
				else
					max_page = 2
					checklist_offset = cl_before_taxi_idx2
				end
			elseif page == 2 then
				cat = CAT_CL_GOAROUND
				page = 1
				min_page = 1
				if B738DR_detail_cl == 0 then
					max_page = 1
					checklist_offset = cl_goaround_idx
				else
					max_page = 1
					checklist_offset = cl_goaround_idx2
				end
			end
			display_update = 1
		elseif cat == CAT_SERVICES then
			cat = CAT_LIGHTS
			page = 1
			min_page = 1
			max_page = 1
			display_update = 1
			-- cmd_services(8)
		elseif cat == CAT_STATE_PRESETS then
			cmd_state_presets(8)
		elseif cat == CAT_LOAD_SAVE then
			cat = CAT_LOAD_SAVE_FLIGHT
			page = 1
			min_page = 1
			max_page = 2
			display_update = 1
		elseif cat == CAT_LOAD_SAVE_FLIGHT then
			clr_menu_mark()
			if is_timer_scheduled(menu_mark_timer) == true then
				stop_timer(menu_mark_timer)
			end
			B738DR_tab_menu_mark[7] = 1
			run_after_time(menu_mark_timer, 0.4)
			cmd_load_save_flight(8)
		elseif cat == CAT_FAILURES then
			-- reset failures
			B738CMD_rst_fail:start()
		elseif cat == CAT_PAY_PERF then
				cat = CAT_AUTO_FLIGHT
				page = 1
				min_page = 1
				max_page = 2
				display_update = 1
				B738DR_tab_nav2_manip = 0
		end
		line_select = 0
	elseif phase == 2 then
		if cat == CAT_FAILURES then
			B738CMD_rst_fail:stop()
		end
	end
end

function B738_tab_left_CMDhandler(phase, duration)
	local temp = 0
  if phase == 0 then
		if info_act ~= 0 then
			info_act = 0
		else
			if cat == CAT_CREDITS then
				
				temp = B738DR_tab_credits
				reset_autoupdate()
				if B738DR_b737_variant < 0 then
					if temp == 0 then
						B738DR_tab_credits = 2
					elseif temp == 1 then
						B738DR_tab_credits = 0
					elseif temp == 2 then
						B738DR_tab_credits = 3
					elseif temp == 3 then
						B738DR_tab_credits = 4
					else
						B738DR_tab_credits = 1
					end
				else
					B738DR_tab_credits = 1
				end
			elseif page > min_page then
				page = page - 1
				display_update = 1
				if cat == CAT_CHECKLIST then
					checklist_page = page
				end
			end
		end
	end
end

function B738_tab_right_CMDhandler(phase, duration)
	local temp = 0
	if phase == 0 then
		if info_act ~= 0 then
			info_act = 0
		else
			if cat == CAT_CREDITS then
				temp = B738DR_tab_credits
				reset_autoupdate()
				if B738DR_b737_variant < 0 then
					if temp == 0 then
						B738DR_tab_credits = 1
					elseif temp == 1 then
						B738DR_tab_credits = 2
					elseif temp == 2 then
						B738DR_tab_credits = 3
					elseif temp == 3 then
						B738DR_tab_credits = 4
					else
						B738DR_tab_credits = 0
					end
				else
					B738DR_tab_credits = 1
				end
			elseif page < max_page then
				page = page + 1
				display_update = 1
				if cat == CAT_CHECKLIST then
					checklist_page = page
				end
			end
		end
	end
end

function B738_numpad_close_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_tab_numpad_act = 0
		B738DR_tab_numpad_spec1 = 0
		B738DR_tab_numpad_spec2 = 0
		B738DR_tab_numpad_val = ""
		tab_numpad_val = ""
		numpad_ref = 0
		numpad_point = 0
		display_update = 1
	end
end

function B738_numpad_clr_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_tab_numpad_val == "Error" then
			B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
		else
			local strlen = string.len(tab_numpad_val)
			if strlen > 0 then
				if string.sub(tab_numpad_val, -1, -1) == "." then
					numpad_point = numpad_point - 1
					numpad_point = math.max(numpad_point, 0)
				end
				tab_numpad_val = string.sub(tab_numpad_val, 1, -2)
				if numpad_ref >= 11 and numpad_ref <= 15 then
					B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
				else
					B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
				end
			end
		end
		check_numpad_spec1()
	elseif phase == 1 then
		if duration > 1 then
			B738DR_tab_numpad_val = ""
			tab_numpad_val = ""
			numpad_point = 0
			check_numpad_spec1()
		end
	end
end

function B738_numpad_minus_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref < 11 or numpad_ref > 15 then
			if numpad_ref == 18 then
				if strlen > 0 then
					if string.sub(tab_numpad_val, 1, 1) == "P" then
						tab_numpad_val = string.sub(tab_numpad_val, 2, -1)
					else
						tab_numpad_val = "P" .. tab_numpad_val
					end
				else
					tab_numpad_val = "Random"
				end
			elseif numpad_ref < 26 or numpad_ref > 30 then
				-- except accel, climb, cutback...
				if string.sub(tab_numpad_val, 1, 1) == "-" then
					tab_numpad_val = string.sub(tab_numpad_val, 2, -1)
				else
					tab_numpad_val = "-" .. tab_numpad_val
				end
			end
			B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
		end
		check_numpad_spec1()
	end
end

function check_numpad_spec1()
	if numpad_ref == 18 then
		if tab_numpad_val == "" then
			B738DR_tab_numpad_spec1 = 1
		else
			if string.sub(tab_numpad_val, 1, 1) ~= "R" then
				B738DR_tab_numpad_spec1 = 2
			end
		end
	else
		B738DR_tab_numpad_spec1 = 0
	end
end

function B738_numpad_enter_CMDhandler(phase, duration)
	if phase == 0 then
		local result_ok = 0
		local ll = 0
		local kk = tonumber(tab_numpad_val)
		local pax_weight = 0
		local pax_weight_zone = 0
		local max_cargo = 0
		
		local max_payload_kg = 79016
		local max_payload_lb = 174200
		local empty_kg = 43000
		local empty_lb = 91300
		local wing_tank_kg = temp_wing_tank_kg		--3907
		local max_fuel_kg = temp_max_fuel_kg		--20876
		local max_fuel_lb = max_fuel_kg * KGS_LBS
		
		local valid_spd = false
		local valid_ratio = false
		
		if B738DR_b737_variant == 0 then
			--800
			max_payload_kg = 79242		--79016
			max_payload_lb = 174700		--174200
			empty_kg = 41510			--43000
			empty_lb = 91514			--91300
			wing_tank_kg = 3907			--3913.6
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 1 then
			--900
			max_payload_kg = 74615		--79016
			max_payload_lb = 164500		--174200
			empty_kg = 42900			--43000
			empty_lb = 94580			--91300
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 2 then
			--700
			max_payload_kg = 70080
			max_payload_lb = 154500
			empty_kg = 37648			--37600
			empty_lb = 83000			--82800
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 3 then
			--600
			max_payload_kg = 56472		--65544
			max_payload_lb = 124500		--144500
			empty_kg = 36378			--36300
			empty_lb = 80200			--80000
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 4 then
			--900ER
			max_payload_kg = 85139
			max_payload_lb = 187700
			empty_kg = 44676			--44600
			empty_lb = 98495			--98320
			wing_tank_kg = 3907
			max_fuel_kg = 23800
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_73x == 1 then
			-- 900
			max_payload_kg = 85000
			max_payload_lb = 187700
			empty_kg = 42500
			empty_lb = 93600
			wing_tank_kg = 3907	--3913.6
		elseif B738DR_73x == 2 then
			-- 700
			max_payload_kg = 70000
			max_payload_lb = 154500
			empty_kg = 37600
			empty_lb = 83000
			wing_tank_kg = 3907	--3913.6
		end
		local both_wing_kg = wing_tank_kg * 2
		local both_wing_lb = both_wing_kg * KGS_LBS
		
		local pax_m = 0
		local pax_w = 0
		local pax_ch = 0
		local std_pax_weight = 0
		
		local req_fuel_tmp = 0
		
		if numpad_ref == 1 or numpad_ref == 300 then
			-- entry fuel
			if kk ~= nil then
				for ll = 1, string.len(tab_numpad_val) do
					if string.sub(tab_numpad_val, ll, ll) == "." then
						kk = kk * 1000
						break
					end
				end
				if B738DR_fmc_units == 0 then
					if kk >= 1 and kk <= max_fuel_lb then
						if B738DR_refuel_time == 2 then
							if numpad_ref == 1 then
								if refuel_enable ~= 0 or B738DR_dev_tune ~= 0 then
									if kk > both_wing_lb then
										simDR_fuel_tank_weight_kg[0] = wing_tank_kg
										simDR_fuel_tank_weight_kg[2] = wing_tank_kg
										simDR_fuel_tank_weight_kg[1] = (kk - both_wing_lb) / KGS_LBS
									else
										simDR_fuel_tank_weight_kg[0] = (kk / 2) / KGS_LBS
										simDR_fuel_tank_weight_kg[2] = (kk / 2) / KGS_LBS
										simDR_fuel_tank_weight_kg[1] = 0
									end
									B738CMD_change_payload:once()
								end
								req_fuel_tmp = 0
							else
								req_fuel_tmp = kk / KGS_LBS
							end
						else
							req_fuel_tmp = kk / KGS_LBS
							
							if numpad_ref == 1 then
								local left_fuel = simDR_fuel_tank_weight_kg[0]
								local center_fuel = simDR_fuel_tank_weight_kg[1]
								local right_fuel = simDR_fuel_tank_weight_kg[2]
								local total_fuel = left_fuel + center_fuel + right_fuel
								if string.format("%6d", total_fuel) == string.format("%6d", req_fuel_tmp) then
									req_fuel_tmp = 0
								end
							end
						end
						result_ok = 1
					end
				else
					if kk >= 1 and kk <= max_fuel_kg then
						if B738DR_refuel_time == 2 then
							if numpad_ref == 1 then
								if refuel_enable ~= 0 or B738DR_dev_tune ~= 0 then
									if kk > both_wing_kg then
										simDR_fuel_tank_weight_kg[0] = wing_tank_kg
										simDR_fuel_tank_weight_kg[2] = wing_tank_kg
										simDR_fuel_tank_weight_kg[1] = (kk - both_wing_kg)
									else
										simDR_fuel_tank_weight_kg[0] = (kk / 2)
										simDR_fuel_tank_weight_kg[2] = (kk / 2)
										simDR_fuel_tank_weight_kg[1] = 0
									end
									B738CMD_change_payload:once()
								end
								req_fuel_tmp = 0
							else
								req_fuel_tmp = kk
							end
						else
							req_fuel_tmp = kk
							
							if numpad_ref == 1 then
								local left_fuel = simDR_fuel_tank_weight_kg[0]
								local center_fuel = simDR_fuel_tank_weight_kg[1]
								local right_fuel = simDR_fuel_tank_weight_kg[2]
								local total_fuel = left_fuel + center_fuel + right_fuel
								if string.format("%6d", total_fuel) == string.format("%6d", req_fuel_tmp) then
									req_fuel_tmp = 0
								end
							end
						end
						result_ok = 1
					end
				end
			else
				req_fuel_tmp = 0
				result_ok = 1
			end
			if numpad_ref == 1 then
				B738DR_req_fuel = req_fuel_tmp
			else
				auto_req_fuel = req_fuel_tmp
			end
			
		elseif numpad_ref == 2 then
			-- entry CG
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					ll = kk * 2.54
				else
					ll = kk
					kk = kk * 0.3937
				end
				if ll >= -130 and ll <= 266.6 then
					-- if simDR_int_ver < 120000 then
						simDR_cg = ll / 100
					-- else
						-- simDR_cg_xp12 = (ll / 100) + 0.03704
					-- end
					result_ok = 1
				end
			end
		elseif numpad_ref == 3 then
			-- pitch null zone
			if kk ~= nil then
				if kk >= 0 and kk <= 30 then
					B738DR_pitch_nz = kk / 100
					if simDR_int_ver < 120000 then
						simDR_pitch_nz = B738DR_pitch_nz
					end
					result_ok = 1
				end
			end
		elseif numpad_ref == 4 then
			-- roll null zone
			if kk ~= nil then
				if kk >= 0 and kk <= 30 then
					B738DR_roll_nz = kk / 100
					if simDR_int_ver < 120000 then
						simDR_roll_nz = B738DR_roll_nz
					end
					result_ok = 1
				end
			end
		elseif numpad_ref == 5 then
			-- yaw null zone
			if kk ~= nil then
				if kk >= 0 and kk <= 30 then
					B738DR_yaw_nz = kk / 100
					if simDR_int_ver < 120000 then
						simDR_yaw_nz = B738DR_yaw_nz
					end
					result_ok = 1
				end
			end
		elseif numpad_ref == 6 then
			-- custom flap axis
			if kk == nil then
				B738DR_cust_axis_flaps_mapped = -1
			elseif kk >= 0 and kk < 500 then
				kk = math.floor(kk)
				B738DR_cust_axis_flaps_mapped = kk
			else
				B738DR_cust_axis_flaps_mapped = -1
			end
			result_ok = 1
		elseif numpad_ref == 7 then
			-- custom speedbrake axis
			if kk == nil then
				B738DR_cust_axis_speedbrake_mapped = -1
			elseif kk >= 0 and kk < 500 then
				kk = math.floor(kk)
				B738DR_cust_axis_speedbrake_mapped = kk
			else
				B738DR_cust_axis_speedbrake_mapped = -1
			end
			result_ok = 1
		elseif numpad_ref == 8 then
			-- custom landinggear axis
			if kk == nil then
				B738DR_cust_axis_landgear_mapped = -1
			elseif kk >= 0 and kk < 500 then
				kk = math.floor(kk)
				B738DR_cust_axis_landgear_mapped = kk
			else
				B738DR_cust_axis_landgear_mapped = -1
			end
			result_ok = 1
		elseif numpad_ref == 9 then
			-- custom mixture1 axis
			if kk == nil then
				B738DR_cust_axis_mixture1_mapped = -1
			elseif kk >= 0 and kk < 500 then
				kk = math.floor(kk)
				B738DR_cust_axis_mixture1_mapped = kk
			else
				B738DR_cust_axis_mixture1_mapped = -1
			end
			result_ok = 1
		elseif numpad_ref == 10 then
			-- custom mixture2 axis
			if kk == nil then
				B738DR_cust_axis_mixture2_mapped = -1
			elseif kk >= 0 and kk < 500 then
				kk = math.floor(kk)
				B738DR_cust_axis_mixture2_mapped = kk
			else
				B738DR_cust_axis_mixture2_mapped = -1
			end
			result_ok = 1
		elseif numpad_ref == 11 then
			-- zone 1 pax
			pax_m, pax_w, pax_ch = pax_input(tab_numpad_val)
			if pax_m ~= -1 then
				kk = pax_m + pax_w + pax_ch
				if kk >= 0 and kk <= B738DR_std_pax_num[0] then
					zone1_pax[1] = pax_m
					zone1_pax[2] = pax_w
					zone1_pax[3] = pax_ch
					pax_weight = 0
					pax_weight_zone = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
						pax_weight_zone = pax_weight_zone + zone1_pax[zxp] * std_pax_weight
					end
					pax_weight = pax_weight + zone_cargo1 + zone_cargo2 + pax_weight_zone
					
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 12 then
			-- zone 2 pax
			pax_m, pax_w, pax_ch = pax_input(tab_numpad_val)
			if pax_m ~= -1 then
				kk = pax_m + pax_w + pax_ch
				if kk >= 0 and kk <= B738DR_std_pax_num[1] then
					zone2_pax[1] = pax_m
					zone2_pax[2] = pax_w
					zone2_pax[3] = pax_ch
					pax_weight = 0
					pax_weight_zone = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
						pax_weight_zone = pax_weight_zone + zone2_pax[zxp] * std_pax_weight
					end
					pax_weight = pax_weight + zone_cargo1 + zone_cargo2 + pax_weight_zone
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 13 then
			-- zone 3 pax
			pax_m, pax_w, pax_ch = pax_input(tab_numpad_val)
			if pax_m ~= -1 then
				kk = pax_m + pax_w + pax_ch
				kk = math.floor(kk)
				if kk >= 0 and kk <= B738DR_std_pax_num[2] then
					zone3_pax[1] = pax_m
					zone3_pax[2] = pax_w
					zone3_pax[3] = pax_ch
					pax_weight = 0
					pax_weight_zone = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
						pax_weight_zone = pax_weight_zone + zone3_pax[zxp] * std_pax_weight
					end
					pax_weight = pax_weight + zone_cargo1 + zone_cargo2 + pax_weight_zone
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 14 then
			-- zone 4 pax
			pax_m, pax_w, pax_ch = pax_input(tab_numpad_val)
			if pax_m ~= -1 then
				kk = pax_m + pax_w + pax_ch
				if kk >= 0 and kk <= B738DR_std_pax_num[3] then
					zone4_pax[1] = pax_m
					zone4_pax[2] = pax_w
					zone4_pax[3] = pax_ch
					pax_weight = 0
					pax_weight_zone = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
						pax_weight_zone = pax_weight_zone + zone4_pax[zxp] * std_pax_weight
					end
					pax_weight = pax_weight + zone_cargo1 + zone_cargo2 + pax_weight_zone
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 15 then
			-- zone 5 pax
			pax_m, pax_w, pax_ch = pax_input(tab_numpad_val)
			if pax_m ~= -1 then
				kk = pax_m + pax_w + pax_ch
				if kk >= 0 and kk <= B738DR_std_pax_num[4] then
					zone5_pax[1] = pax_m
					zone5_pax[2] = pax_w
					zone5_pax[3] = pax_ch
					pax_weight = 0
					pax_weight_zone = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight_zone = pax_weight_zone + zone5_pax[zxp] * std_pax_weight
					end
					pax_weight = pax_weight + zone_cargo1 + zone_cargo2 + pax_weight_zone
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 16 then
			-- zone cargo 1 Fwd
			if kk ~= nil then
				kk = math.floor(kk)
				if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
					max_cargo = 1927
				elseif B738DR_73x == 2 then
					max_cargo = 1927
				else
					max_cargo = 3560
				end
				if B738DR_fmc_units == 0 then
					max_cargo = max_cargo * KGS_LBS
				end
				if kk >= 0 and kk <= max_cargo then
					pax_weight = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
					end
					if B738DR_fmc_units == 0 then
						kk = kk / KGS_LBS
					end
					pax_weight = pax_weight + zone_cargo2 + kk
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					zone_cargo1 = kk
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 17 then
			-- zone cargo 2 Aft
			if kk ~= nil then
				kk = math.floor(kk)
				if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
					max_cargo = 3172
				elseif B738DR_73x == 2 then
					max_cargo = 3172
				else
					max_cargo = 4850
				end
				if B738DR_fmc_units == 0 then
					max_cargo = max_cargo * KGS_LBS
				end
				if kk >= 0 and kk <= max_cargo then
					pax_weight = 0
					for zxp = 1, 3 do
						std_pax_weight = B738DR_std_pax_weight[zxp-1]
						pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
						pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
					end
					if B738DR_fmc_units == 0 then
						kk = kk / KGS_LBS
					end
					pax_weight = pax_weight + zone_cargo1 + kk
					req_payload_weight = pax_weight + physical_crew_payload_weight()
					zone_cargo2 = kk
					
					fill_zone_weight_req()
					crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
					crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
					cargo1_weight_req = zone_cargo1
					cargo2_weight_req = zone_cargo2
					
					result_ok = 1
					B738CMD_change_payload:once()
				end
			end
		elseif numpad_ref == 18 then
			-- total payload
			if kk == nil then
				if tab_numpad_val == "Random" then
					local int, frac = math.modf(os.clock())
					local seed = math.random(1, frac*1000.0)
					math.randomseed(seed)
					if B738DR_fmc_units == 0 then
						kk = math.floor(math.random(0, 55417))
					else
						kk = math.floor(math.random(0, 25137))
					end
					tab_numpad_val = tostring(kk)
				end
			end
			result_ok = total_payload_entry(tab_numpad_val)
		elseif numpad_ref == 19 then
			-- male std weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if kk >= 55.1 and kk <= 210 then
						B738DR_std_pax_weight[0] = math.floor(kk / KGS_LBS * 10) / 10
						result_ok = 1
						update_payload()
					end
				else
					if kk >= 25 and kk <= 95.2 then
						B738DR_std_pax_weight[0] = math.floor(kk * 10) / 10
						result_ok = 1
						update_payload()
					end
				end
			end
		elseif numpad_ref == 20 then
			-- female std weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if kk >= 55.1 and kk <= 210 then
						B738DR_std_pax_weight[1] = math.floor(kk / KGS_LBS * 10) / 10
						result_ok = 1
						update_payload()
					end
				else
					if kk >= 25 and kk <= 95.2 then
						B738DR_std_pax_weight[1] = math.floor(kk * 10) / 10
						result_ok = 1
						update_payload()
					end
				end
			end
		elseif numpad_ref == 21 then
			-- kids std weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if kk >= 55.1 and kk <= 210 then
						B738DR_std_pax_weight[2] = math.floor(kk / KGS_LBS * 10) / 10
						result_ok = 1
						update_payload()
					end
				else
					if kk >= 25 and kk <= 95.2 then
						B738DR_std_pax_weight[2] = math.floor(kk * 10) / 10
						result_ok = 1
						update_payload()
					end
				end
			end
		elseif numpad_ref == 22 then
			-- FA fwd weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if kk >= 0 and kk <= 460 then
						B738DR_fa_fwd_kg = math.floor(kk / KGS_LBS * 10) / 10
						result_ok = 1
						update_payload()
					end
				else
					if kk >= 0 and kk <= 208.6 then
						B738DR_fa_fwd_kg = math.floor(kk * 10) / 10
						result_ok = 1
						update_payload()
					end
				end
			end
		elseif numpad_ref == 23 then
			-- FA aft weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if kk >= 0 and kk <= 460 then
						B738DR_fa_aft_kg = math.floor(kk / KGS_LBS * 10) / 10
						result_ok = 1
						update_payload()
					end
				else
					if kk >= 0 and kk <= 208.6 then
						B738DR_fa_aft_kg = math.floor(kk * 10) / 10
						result_ok = 1
						update_payload()
					end
				end
			end
		elseif numpad_ref == 24 then
			-- galleys F weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
						if kk >= 0 and kk <= 2145 then
							B738DR_galley_fwd_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					elseif B738DR_73x == 2 then
						if kk >= 0 and kk <= 2145 then
							B738DR_galley_fwd_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					else
						if kk >= 0 and kk <= 2595 then
							B738DR_galley_fwd_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					end
				else
					if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
						if kk >= 0 and kk <= 972 then
							B738DR_galley_fwd_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					elseif B738DR_73x == 2 then
						if kk >= 0 and kk <= 972 then
							B738DR_galley_fwd_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					else
						if kk >= 0 and kk <= 1177 then
							B738DR_galley_fwd_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					end
				end
			end
		elseif numpad_ref == 25 then
			-- galleys R weight
			if kk ~= nil then
				if B738DR_fmc_units == 0 then
					if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
						if kk >= 0 and kk <= 2400 then
							B738DR_galley_aft_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					elseif B738DR_73x == 2 then
						if kk >= 0 and kk <= 2400 then
							B738DR_galley_aft_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					else
						if kk >= 0 and kk <= 2700 then
							B738DR_galley_aft_kg = math.floor(kk / KGS_LBS * 10) / 10
							result_ok = 1
							update_payload()
						end
					end
				else
					if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
						if kk >= 0 and kk <= 1088 then
							B738DR_galley_aft_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					elseif B738DR_73x == 2 then
						if kk >= 0 and kk <= 1088 then
							B738DR_galley_aft_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					else
						if kk >= 0 and kk <= 1225 then
							B738DR_galley_aft_kg = math.floor(kk * 10) / 10
							result_ok = 1
							update_payload()
						end
					end
				end
			end
		elseif numpad_ref == 202 then
			-- wind
			local wnd_tmp = tonumber(tab_numpad_val)
			if wnd_tmp ~= nil then
				if wnd_tmp == 0 then
					perf_wind_dir = 0
					perf_wind_spd = 0
					result_ok = 1
				elseif wnd_tmp >= -200 and wnd_tmp <= 200 then
					perf_wind_dir = -1
					perf_wind_spd = wnd_tmp
					result_ok = 1
				end
			elseif string.len(tab_numpad_val) > 4 then
				if string.sub(tab_numpad_val, 4, 4) == "/" then
					kk = tonumber(string.sub(tab_numpad_val, 1, 3))
					if kk ~= nil then
						if kk >= 0 and kk <= 360 then
							perf_wind_dir = kk
							kk = tonumber(string.sub(tab_numpad_val, 5, -1))
							if kk ~= nil then
								if kk >= 0 and kk <= 200 then
									perf_wind_spd = kk
									result_ok = 1
									-- calc_perf_wind()
								end
							end
						end
					end
				end
			elseif string.len(tab_numpad_val) == 0 then
				perf_wind_spd = 0
				result_ok = 1
			end
		elseif numpad_ref == 203 then
			-- OAT
			if kk ~= nil then
				perf_oat = kk
				result_ok = 1
			end
		elseif numpad_ref == 204 then
			-- QNH
			if kk ~= nil then
				if kk >= 0 and kk <= 1355 then
					perf_qnh = kk
					result_ok = 1
				end
			end
		elseif numpad_ref == 205 then
			-- TOW
			if kk ~= nil then
				if string.len(tab_numpad_val) > 1 then
					for jj = 1, string.len(tab_numpad_val) do
						if string.sub(tab_numpad_val, jj, jj) == "." then
							kk = kk * 1000
							break
						end
					end
				end
				if B738DR_fmc_units == 0 then
					if kk >= 40000 * KGS_LBS and kk <= 80000 * KGS_LBS then
						perf_weight = kk / KGS_LBS
						result_ok = 1
					end
				else
					if kk >= 40000 and kk <= 80000 then
						perf_weight = kk
						result_ok = 1
					end
				end
			end
		elseif numpad_ref == 206 then
			-- CG
			if kk ~= nil then
				if kk >= 6 and kk <= 36 then	--0 .. 40
					perf_cg = kk
					result_ok = 1
				end
			end
		elseif numpad_ref == 209 then
			-- wind
			if string.len(tab_numpad_val) > 4 then
				if string.sub(tab_numpad_val, 4, 4) == "/" then
					kk = tonumber(string.sub(tab_numpad_val, 1, 3))
					if kk ~= nil then
						if kk >= 0 and kk <= 360 then
							perf_lnd_wind_dir = kk
							kk = tonumber(string.sub(tab_numpad_val, 5, -1))
							if kk ~= nil then
								if kk >= 0 and kk <= 200 then
									perf_lnd_wind_spd = kk
									result_ok = 1
									calc_perf_lnd_wind()
								end
							end
						end
					end
				end
			elseif string.len(tab_numpad_val) == 0 then
				perf_lnd_wind_spd = 0
				result_ok = 1
			end
		elseif numpad_ref == 210 then
			-- OAT
			if kk ~= nil then
				perf_lnd_oat = kk
				result_ok = 1
			end
		elseif numpad_ref == 211 then
			-- QNH
			if kk ~= nil then
				if kk >= 0 and kk <= 1355 then
					perf_lnd_qnh = kk
					result_ok = 1
				end
			end
		elseif numpad_ref == 212 then
			-- LW
			if kk ~= nil then
				if string.len(tab_numpad_val) > 1 then
					for jj = 1, string.len(tab_numpad_val) do
						if string.sub(tab_numpad_val, jj, jj) == "." then
							kk = kk * 1000
							break
						end
					end
				end
				if B738DR_fmc_units == 0 then
					if kk >= 40000 * KGS_LBS and kk <= 80000 * KGS_LBS then
						perf_lnd_weight = kk / KGS_LBS
						result_ok = 1
					end
				else
					if kk >= 40000 and kk <= 80000 then
						perf_lnd_weight = kk
						result_ok = 1
					end
				end
			end
		elseif numpad_ref == 213 then
			-- CG
			if kk ~= nil then
				if kk >= 0 and kk <= 20 then
					perf_lnd_vref_add = math.floor(kk)
					result_ok = 1
				end
			end
		--- **** TEMPORARY **** ---
		elseif numpad_ref == 100 then
			if kk ~= nil then
				tora = kk
				result_ok = 1
			end
		elseif numpad_ref == 101 then
			if kk ~= nil then
				clearway = kk
				result_ok = 1
			end
		elseif numpad_ref == 102 then
			if kk ~= nil then
				stopway = kk
				result_ok = 1
			end
		--- **** TEMPORARY **** ---
		elseif numpad_ref == 26 then
			-- climb thrust
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 800 and kk <= 9999 then
					B738DR_def_clb_alt = kk
					result_ok = 1
					B738CMD_update_factory:once()
				end
			end
		elseif numpad_ref == 27 then
			-- climb restore thrust
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 800 and kk <= 9999 then
					B738DR_def_clb_alt2 = kk
					result_ok = 1
					B738CMD_update_factory:once()
				end
			end
		elseif numpad_ref == 28 then
			-- cutback thrust
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 800 and kk <= 9999 then
					B738DR_def_cut_alt = kk
					result_ok = 1
					B738CMD_update_factory:once()
				end
			end
		elseif numpad_ref == 29 then
			-- acceleration height
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 400 and kk <= 9999 then
					B738DR_def_accel_alt = kk
					result_ok = 1
					B738CMD_update_factory:once()
				end
			end
		elseif numpad_ref == 30 then
			-- EO acceleration height
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 400 and kk <= 9999 then
					B738DR_def_eo_accel_alt = kk
					result_ok = 1
					B738CMD_update_factory:once()
				end
			end
		elseif numpad_ref == 31 then
			-- VNAV Wakeup idle speed
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 5 and kk <= 15 then
					B738DR_vnav_wakeup_idle = kk
					result_ok = 1
				end
			end
		elseif numpad_ref == 32 then
			-- ND Airport filter
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 0 and kk <= 4000 then
					B738DR_nd_arpt_rw_lenght = kk
					result_ok = 1
				end
			end
		elseif numpad_ref == 301 then
			-- pax
			if kk ~= nil then
				-- if B738DR_pax_layout == 0 then
					-- req_fuel_tmp = 160
				-- elseif B738DR_pax_layout == 1 then
					-- req_fuel_tmp = 180
				-- else
					-- req_fuel_tmp = 189
				-- end
				if B738DR_pax_layout < 0 or B738DR_pax_layout > 9 then
					req_fuel_tmp = 189
				else
					req_fuel_tmp = max_pax_layout[B738DR_pax_layout + 1]
				end
				
				kk = math.floor(kk)
				if kk >= 0 and kk <= req_fuel_tmp then
					auto_pax_tot = kk
					auto_zfw_tot = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0] + auto_cargo_tot
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref == 302 then
			-- cargo
			if kk ~= nil then
				-- if B738DR_pax_layout == 0 then
					-- req_fuel_tmp = 160
				-- elseif B738DR_pax_layout == 1 then
					-- req_fuel_tmp = 180
				-- else
					-- req_fuel_tmp = 189
				-- end
				if B738DR_fmc_units == 0 then
					kk = kk / KGS_LBS
				end
				kk = math.floor(kk)
				if kk >= 0 and kk <= 8410 then
					auto_cargo_tot = kk
					auto_zfw_tot = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0] + auto_cargo_tot
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref == 500 then
			-- vanish_y
			if kk ~= nil then
				kk = math.floor(kk)
				if kk >= 400 and kk <= 600 then
					B738DR_vanish_y = kk
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref == 600 then
			-- shift CG MAC
			if kk ~= nil then
				if kk >= -30 and kk <= 30 then
					B738DR_shift_cg_mac = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref == 601 then
			-- shift CG MAC GND
			if kk ~= nil then
				if kk >= -30 and kk <= 30 then
					B738DR_shift_cg_mac_gnd = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref >= 926 and numpad_ref <= 927 then
			-- ratio
			if kk ~= nil then
				if kk >= 0  and kk <= 1 then
					if numpad_ref == 926 then
						B738DR_def_elevator1_tab_ratio = kk
					elseif numpad_ref == 927 then
						B738DR_def_elevator2_tab_ratio = kk
					end
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref >= 900 and numpad_ref <= 936 then
			-- deg
			if kk ~= nil then
				if kk >= 0 and kk <= 90 then
					if numpad_ref == 902 then
						B738DR_def_aileron1_dn = kk
					elseif numpad_ref == 903 then
						B738DR_def_aileron1_up = kk
					elseif numpad_ref == 904 then
						B738DR_def_aileron2_dn = kk
					elseif numpad_ref == 905 then
						B738DR_def_aileron2_up = kk
					elseif numpad_ref == 906 then
						B738DR_def_elevator1_dn = kk
					elseif numpad_ref == 907 then
						B738DR_def_elevator1_up = kk
					elseif numpad_ref == 908 then
						B738DR_def_elevator2_dn = kk
					elseif numpad_ref == 909 then
						B738DR_def_elevator2_up = kk
					elseif numpad_ref == 911 then
						B738DR_def_rudder1_dn = kk
					elseif numpad_ref == 912 then
						B738DR_def_rudder1_up = kk
					elseif numpad_ref == 913 then
						B738DR_def_rudder2_dn = kk
					elseif numpad_ref == 914 then
						B738DR_def_rudder2_up = kk
					elseif numpad_ref == 915 then
						B738DR_def_spoiler1_roll = kk
					elseif numpad_ref == 916 then
						B738DR_def_spoiler1_brk = kk
					elseif numpad_ref == 917 then
						B738DR_def_spoiler2_roll = kk
					elseif numpad_ref == 918 then
						B738DR_def_spoiler2_brk = kk
					elseif numpad_ref == 920 then
						B738DR_def_speedbrake1_flt = kk
					elseif numpad_ref == 921 then
						B738DR_def_speedbrake1_gnd = kk
					elseif numpad_ref == 922 then
						B738DR_def_speedbrake2_flt = kk
					elseif numpad_ref == 923 then
						B738DR_def_speedbrake2_gnd = kk
					elseif numpad_ref == 924 then
						B738DR_def_elevator_trim_dn = kk
					elseif numpad_ref == 925 then
						B738DR_def_elevator_trim_up = kk
					elseif numpad_ref == 929 then
						B738DR_def_flap_1 = kk
					elseif numpad_ref == 930 then
						B738DR_def_flap_2 = kk
					elseif numpad_ref == 931 then
						B738DR_def_flap_5 = kk
					elseif numpad_ref == 932 then
						B738DR_def_flap_10 = kk
					elseif numpad_ref == 933 then
						B738DR_def_flap_15 = kk
					elseif numpad_ref == 934 then
						B738DR_def_flap_25 = kk
					elseif numpad_ref == 935 then
						B738DR_def_flap_30 = kk
					elseif numpad_ref == 936 then
						B738DR_def_flap_40 = kk
					end
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref >= 937 and numpad_ref <= 990 then
			if kk ~= nil then
				if kk >= -9.9999 and kk <= 9.9999 then
					if numpad_ref == 937 then
						B738DR_flap_cl[0] = kk
					elseif numpad_ref == 938 then
						B738DR_flap_cl[1] = kk
					elseif numpad_ref == 939 then
						B738DR_flap_cl[2] = kk
					elseif numpad_ref == 940 then
						B738DR_flap_cl[3] = kk
					elseif numpad_ref == 941 then
						B738DR_flap_cl[4] = kk
					elseif numpad_ref == 942 then
						B738DR_flap_cl[5] = kk
					elseif numpad_ref == 943 then
						B738DR_flap_cl[6] = kk
					elseif numpad_ref == 944 then
						B738DR_flap_cl[7] = kk
					elseif numpad_ref == 945 then
						B738DR_flap_cl[8] = kk
					elseif numpad_ref == 946 then
						B738DR_flap_cd[0] = kk
					elseif numpad_ref == 947 then
						B738DR_flap_cd[1] = kk
					elseif numpad_ref == 948 then
						B738DR_flap_cd[2] = kk
					elseif numpad_ref == 949 then
						B738DR_flap_cd[3] = kk
					elseif numpad_ref == 950 then
						B738DR_flap_cd[4] = kk
					elseif numpad_ref == 951 then
						B738DR_flap_cd[5] = kk
					elseif numpad_ref == 952 then
						B738DR_flap_cd[6] = kk
					elseif numpad_ref == 953 then
						B738DR_flap_cd[7] = kk
					elseif numpad_ref == 954 then
						B738DR_flap_cd[8] = kk
					elseif numpad_ref == 955 then
						B738DR_flap_cm[0] = kk
					elseif numpad_ref == 956 then
						B738DR_flap_cm[1] = kk
					elseif numpad_ref == 957 then
						B738DR_flap_cm[2] = kk
					elseif numpad_ref == 958 then
						B738DR_flap_cm[3] = kk
					elseif numpad_ref == 959 then
						B738DR_flap_cm[4] = kk
					elseif numpad_ref == 960 then
						B738DR_flap_cm[5] = kk
					elseif numpad_ref == 961 then
						B738DR_flap_cm[6] = kk
					elseif numpad_ref == 962 then
						B738DR_flap_cm[7] = kk
					elseif numpad_ref == 963 then
						B738DR_flap_cm[8] = kk
					elseif numpad_ref == 964 then
						B738DR_flap2_cl[0] = kk
					elseif numpad_ref == 965 then
						B738DR_flap2_cl[1] = kk
					elseif numpad_ref == 966 then
						B738DR_flap2_cl[2] = kk
					elseif numpad_ref == 967 then
						B738DR_flap2_cl[3] = kk
					elseif numpad_ref == 968 then
						B738DR_flap2_cl[4] = kk
					elseif numpad_ref == 969 then
						B738DR_flap2_cl[5] = kk
					elseif numpad_ref == 970 then
						B738DR_flap2_cl[6] = kk
					elseif numpad_ref == 971 then
						B738DR_flap2_cl[7] = kk
					elseif numpad_ref == 972 then
						B738DR_flap2_cl[8] = kk
					elseif numpad_ref == 973 then
						B738DR_flap2_cd[0] = kk
					elseif numpad_ref == 974 then
						B738DR_flap2_cd[1] = kk
					elseif numpad_ref == 975 then
						B738DR_flap2_cd[2] = kk
					elseif numpad_ref == 976 then
						B738DR_flap2_cd[3] = kk
					elseif numpad_ref == 977 then
						B738DR_flap2_cd[4] = kk
					elseif numpad_ref == 978 then
						B738DR_flap2_cd[5] = kk
					elseif numpad_ref == 979 then
						B738DR_flap2_cd[6] = kk
					elseif numpad_ref == 980 then
						B738DR_flap2_cd[7] = kk
					elseif numpad_ref == 981 then
						B738DR_flap2_cd[8] = kk
					elseif numpad_ref == 982 then
						B738DR_flap2_cm[0] = kk
					elseif numpad_ref == 983 then
						B738DR_flap2_cm[1] = kk
					elseif numpad_ref == 984 then
						B738DR_flap2_cm[2] = kk
					elseif numpad_ref == 985 then
						B738DR_flap2_cm[3] = kk
					elseif numpad_ref == 986 then
						B738DR_flap2_cm[4] = kk
					elseif numpad_ref == 987 then
						B738DR_flap2_cm[5] = kk
					elseif numpad_ref == 988 then
						B738DR_flap2_cm[6] = kk
					elseif numpad_ref == 989 then
						B738DR_flap2_cm[7] = kk
					elseif numpad_ref == 990 then
						B738DR_flap2_cm[8] = kk
					end
				end
				B738CMD_save_tune:once()
				result_ok = 1
				view()
			end
		-- elseif numpad_ref >= 955 and numpad_ref <= 999 then
		elseif numpad_ref >= 991 and numpad_ref <= 1035 then
			-- speed and ratio
			if kk ~= nil then
				valid_spd = false
				valid_ratio = false
				if kk >= 0  and kk <= 1 then
					valid_spd = true
					valid_ratio = true
				elseif kk >= 0 and kk <= 999 then
					valid_spd = true
				end
				
				if numpad_ref == 992 and valid_spd == true then
					B738DR_aileron1_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 993 and valid_spd == true then
					B738DR_aileron1_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 994 and valid_ratio == true then
					B738DR_aileron1_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 995 and valid_ratio == true then
					B738DR_aileron1_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 996 and valid_spd == true then
					B738DR_aileron2_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 997 and valid_spd == true then
					B738DR_aileron2_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 998 and valid_ratio == true then
					B738DR_aileron2_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 999 and valid_ratio == true then
					B738DR_aileron2_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1001 and valid_spd == true then
					B738DR_elevator1_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1002 and valid_spd == true then
					B738DR_elevator1_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1003 and valid_ratio == true then
					B738DR_elevator1_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1004 and valid_ratio == true then
					B738DR_elevator1_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1005 and valid_spd == true then
					B738DR_elevator2_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1006 and valid_spd == true then
					B738DR_elevator2_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1007 and valid_ratio == true then
					B738DR_elevator2_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1008 and valid_ratio == true then
					B738DR_elevator2_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1010 and valid_spd == true then
					B738DR_rudder1_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1011 and valid_spd == true then
					B738DR_rudder1_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1012 and valid_ratio == true then
					B738DR_rudder1_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1013 and valid_ratio == true then
					B738DR_rudder1_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1014 and valid_spd == true then
					B738DR_rudder2_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1015 and valid_spd == true then
					B738DR_rudder2_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1016 and valid_ratio == true then
					B738DR_rudder2_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1017 and valid_ratio == true then
					B738DR_rudder2_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1019 and valid_spd == true then
					B738DR_spoiler1_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1020 and valid_spd == true then
					B738DR_spoiler1_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1021 and valid_ratio == true then
					B738DR_spoiler1_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1022 and valid_ratio == true then
					B738DR_spoiler1_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1023 and valid_spd == true then
					B738DR_spoiler2_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1024 and valid_spd == true then
					B738DR_spoiler2_spd2 = kk
					result_ok = 1
					view()
				elseif numpad_ref == 1025 and valid_ratio == true then
					B738DR_spoiler2_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1026 and valid_ratio == true then
					B738DR_spoiler2_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1028 and valid_spd == true then
					B738DR_brk_spoiler1_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1029 and valid_spd == true then
					B738DR_brk_spoiler1_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1030 and valid_ratio == true then
					B738DR_brk_spoiler1_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1031 and valid_ratio == true then
					B738DR_brk_spoiler1_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1032 and valid_spd == true then
					B738DR_brk_spoiler2_spd1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1033 and valid_spd == true then
					B738DR_brk_spoiler2_spd2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1034 and valid_ratio == true then
					B738DR_brk_spoiler2_rat1 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif numpad_ref == 1035 and valid_ratio == true then
					B738DR_brk_spoiler2_rat2 = kk
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		-- elseif numpad_ref >= 983 and numpad_ref <= 990 then
		elseif numpad_ref >= 1036 and numpad_ref <= 1044 then
			-- curve coef
			if kk ~= nil then
				if kk >= -99.99 and kk <= 99.99 then
					-- if numpad_ref == 1037 then
						-- B738DR_roll_input_coef_1 = kk
					-- elseif numpad_ref == 1038 then
						-- B738DR_roll_input_coef_2 = kk
					-- elseif numpad_ref == 1039 then
						-- B738DR_pitch_input_coef_1 = kk
					-- elseif numpad_ref == 1040 then
						-- B738DR_pitch_input_coef_2 = kk
					-- elseif numpad_ref == 1041 then
						-- B738DR_yaw_input_coef_1 = kk
					-- elseif numpad_ref == 1042 then
						-- B738DR_yaw_input_coef_2 = kk
					-- end
					if numpad_ref == 1037 then
						B738DR_def_aileron_rate = kk
					elseif numpad_ref == 1038 then
						B738DR_def_elevator_rate = kk
					elseif numpad_ref == 1039 then
						B738DR_def_rudder_rate = kk
					elseif numpad_ref == 1040 then
						B738DR_def_spoiler_rate = kk
					elseif numpad_ref == 1041 then
						B738DR_def_brakes_rate = kk
					elseif numpad_ref == 1042 then
						B738DR_def_aileron_flaps_rate = kk
					elseif numpad_ref == 1043 then
						B738DR_def_spoiler_flaps_rate = kk
					end
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				end
			end
		elseif numpad_ref >= 1045 and numpad_ref <= 1080 then
			if kk ~= nil then
				if kk >= -1 and kk <= 1 then
					if numpad_ref == 1046 then
						B738DR_flt_idle_thr1 = kk
					elseif numpad_ref == 1047 then
						B738DR_flt_idle_thr2 = kk
					elseif numpad_ref == 1048 then
						B738DR_flt_idle_sigma2 = kk
					elseif numpad_ref == 1049 then
						B738DR_flt_idle_thr3 = kk
					elseif numpad_ref == 1050 then
						B738DR_flt_idle_sigma3 = kk
					elseif numpad_ref == 1051 then
						B738DR_flt_idle_thr4 = kk
					elseif numpad_ref == 1052 then
						B738DR_flt_idle_sigma4 = kk
					elseif numpad_ref == 1053 then
						B738DR_flt_idle_thr5 = kk
					elseif numpad_ref == 1055 then
						B738DR_curve02_coef6 = kk
					elseif numpad_ref == 1056 then
						B738DR_mach_trim_ratio = kk
					elseif numpad_ref == 1057 then
						B738DR_mach_trim_spd1 = kk
					elseif numpad_ref == 1058 then
						B738DR_mach_trim_spd2 = kk
					elseif numpad_ref == 1059 then
						B738DR_app_idle_thr1 = kk
					elseif numpad_ref == 1060 then
						B738DR_app_idle_thr2 = kk
					elseif numpad_ref == 1061 then
						B738DR_app_idle_thr3 = kk
					elseif numpad_ref == 1065 then
						B738DR_bypass = kk
					elseif numpad_ref == 1066 then
						B738DR_inlet = kk
					elseif numpad_ref == 1067 then
						B738DR_shock_mach = kk
					elseif numpad_ref == 1070 then
						B738DR_curve02_coef3 = kk
					elseif numpad_ref == 1071 then
						B738DR_curve02_coef4 = kk
					elseif numpad_ref == 1073 then
						B738DR_idle_sfc = kk
					elseif numpad_ref == 1074 then
						B738DR_sfc = kk
					elseif numpad_ref == 1075 then
						B738DR_sfc_coef = kk
					elseif numpad_ref == 1076 then
						B738DR_curve02_type = math.floor(kk)
					end
					
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif kk >= 0 and kk <= 1 then
					-- if numpad_ref == 1060 then
						-- B738DR_curve02_coef6 = kk
					if numpad_ref == 1055 then
						B738DR_curve02_coef6 = kk
					elseif numpad_ref == 1056 then
						B738DR_mach_trim_ratio = kk
					elseif numpad_ref == 1057 then
						B738DR_mach_trim_spd1 = kk
					elseif numpad_ref == 1058 then
						B738DR_mach_trim_spd2 = kk
					elseif numpad_ref == 1059 then
						B738DR_app_idle_thr1 = kk
					elseif numpad_ref == 1060 then
						B738DR_app_idle_thr2 = kk
					elseif numpad_ref == 1061 then
						B738DR_app_idle_thr3 = kk
					elseif numpad_ref == 1065 then
						B738DR_bypass = kk
					elseif numpad_ref == 1066 then
						B738DR_inlet = kk
					elseif numpad_ref == 1067 then
						B738DR_shock_mach = kk
					elseif numpad_ref == 1070 then
						B738DR_curve02_coef3 = kk
					elseif numpad_ref == 1071 then
						B738DR_curve02_coef4 = kk
					elseif numpad_ref == 1073 then
						B738DR_idle_sfc = kk
					elseif numpad_ref == 1074 then
						B738DR_sfc = kk
					elseif numpad_ref == 1075 then
						B738DR_sfc_coef = kk
					elseif numpad_ref == 1076 then
						B738DR_curve02_type = math.floor(kk)
					end
					
					B738CMD_save_tune:once()
					result_ok = 1
					view()
				elseif kk >= 0 and kk <= 2 then
					-- if numpad_ref == 1061 then
						-- B738DR_eng_fan_drag_ratio = kk
						-- B738CMD_save_tune:once()
						-- result_ok = 1
						-- view()
					if numpad_ref == 1070 then
						B738DR_curve02_coef3 = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					elseif numpad_ref == 1076 then
						B738DR_curve02_type = math.floor(kk)
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					end
				elseif kk >= 1 and kk <= 5 then
					if numpad_ref == 1068 then
						B738DR_curve02_coef1 = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					elseif numpad_ref == 1069 then
						B738DR_curve02_coef2 = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					elseif numpad_ref == 1076 then
						B738DR_curve02_type = math.floor(kk)
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					end
				elseif kk >= 10000 and kk <= 30000 then
					if numpad_ref == 1064 then
						B738DR_static_thrust = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					-- elseif numpad_ref == 1070 then
						-- B738DR_curve02_coef3 = kk
						-- B738CMD_save_tune:once()
						-- result_ok = 1
						-- view()
					end
				end
			end
		elseif numpad_ref >= 1081 and numpad_ref <= 1089 then
			if kk ~= nil then
				if kk >= 0 and kk <= 99999 then
					if numpad_ref == 1082 then
						B738DR_roll_dmp = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					elseif numpad_ref == 1083 then
						B738DR_pitch_dmp = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					elseif numpad_ref == 1084 then
						B738DR_yaw_dmp = kk
						B738CMD_save_tune:once()
						result_ok = 1
						view()
					end
				end
			end
		end
		
		if result_ok == 0 then
			-- Error
			B738DR_tab_numpad_val = "Error"
		else
			-- close numpad
			B738DR_tab_numpad_act = 0
			B738DR_tab_numpad_spec1 = 0
			B738DR_tab_numpad_spec2 = 0
			B738DR_tab_numpad_val = ""
			tab_numpad_val = ""
			numpad_ref = 0
			numpad_point = 0
			display_update = 1
		end
	end
end

function update_payload()
	
	local pax_weight = 0
	local std_pax_weight = 0
	for zxp = 1, 3 do
		std_pax_weight = B738DR_std_pax_weight[zxp-1]
		pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
		pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
		pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
		pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
		pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
	end
	pax_weight = pax_weight + zone_cargo1 + zone_cargo2
	
	-- full_crew_weight = 524 + B738DR_fa_fwd_kg + B738DR_fa_aft_kg + B738DR_galley_fwd_kg + B738DR_galley_aft_kg
	full_crew_weight_f = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
	full_crew_weight_r = B738DR_fa_aft_kg + B738DR_galley_aft_kg
	full_crew_weight = full_crew_weight_f + full_crew_weight_r
	
	if B738DR_b737_variant == 0 then
		--800
		B738DR_oew_kg = simDR_acf_m_empty + math.max(full_crew_weight - 524, 0)
	elseif B738DR_b737_variant == 1 then
		--900
		B738DR_oew_kg = 42900 + full_crew_weight
	elseif B738DR_b737_variant == 2 then
		--700
		B738DR_oew_kg = 37648 + full_crew_weight
	elseif B738DR_b737_variant == 3 then
		--600
		B738DR_oew_kg = 36378 + full_crew_weight
	elseif B738DR_b737_variant == 4 then
		--900ER
		B738DR_oew_kg = 44677 + full_crew_weight
	elseif B738DR_73x == 2 then
		--700
		B738DR_oew_kg = 37648 + full_crew_weight
	else
		B738DR_oew_kg = simDR_acf_m_empty + math.max(full_crew_weight - 524, 0)
	end
	req_payload_weight = pax_weight + physical_crew_payload_weight()
	
	fill_zone_weight_req()
	crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
	crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
	cargo1_weight_req = zone_cargo1
	cargo2_weight_req = zone_cargo2
	
	B738CMD_change_payload:once()
end

function total_payload_entry(in_entry)
	local result_ok = 0
	local ll = 0
	local mm = 0
	local kk = tonumber(in_entry)
	local pax_weight = 0
	local pax_weight_zone = 0
	local max_cargo = 0
	
	local max_payload_only_kg = 25137
	local max_payload_only_lb = 55417
	local empty_kg = 43000
	local empty_lb = 91300
	local wing_tank_kg = temp_wing_tank_kg		--3907
	local max_fuel_kg = temp_max_fuel_kg		--20876
	local max_fuel_lb = max_fuel_kg * KGS_LBS
	local max_payload_kg = 0
	local max_payload_lb = 0
	
	if B738DR_b737_variant == 0 then
		--800
		max_payload_kg = 79242		--79016
		max_payload_lb = 174700		--174200
		empty_kg = 41510			--43000
		empty_lb = 91514			--91300
		wing_tank_kg = 3907			--3913.6
		max_fuel_kg = 20876
		max_fuel_lb = max_fuel_kg * KGS_LBS
	elseif B738DR_b737_variant == 1 then
		--900
		max_payload_kg = 74615		--79016
		max_payload_lb = 164500		--174200
		empty_kg = 42900			--43000
		empty_lb = 94580			--91300
		wing_tank_kg = 3907
		max_fuel_kg = 20876
		max_fuel_lb = max_fuel_kg * KGS_LBS
	elseif B738DR_b737_variant == 2 then
		--700
		max_payload_kg = 70080
		max_payload_lb = 154500
		empty_kg = 37648			--37600
		empty_lb = 83000			--82800
		wing_tank_kg = 3907
		max_fuel_kg = 20876
		max_fuel_lb = max_fuel_kg * KGS_LBS
	elseif B738DR_b737_variant == 3 then
		--600
		max_payload_kg = 56472		--65544
		max_payload_lb = 124500		--144500
		empty_kg = 36378			--36300
		empty_lb = 80200			--80000
		wing_tank_kg = 3907
		max_fuel_kg = 20876
		max_fuel_lb = max_fuel_kg * KGS_LBS
	elseif B738DR_b737_variant == 4 then
		--900ER
		max_payload_kg = 85139
		max_payload_lb = 187700
		empty_kg = 44676			--44600
		empty_lb = 98495			--98320
		wing_tank_kg = 3907
		max_fuel_kg = 23800
		max_fuel_lb = max_fuel_kg * KGS_LBS
	elseif B738DR_73x == 1 then
		-- 900
		max_payload_kg = 85000
		max_payload_lb = 187700
		empty_kg = 42500
		empty_lb = 93600
		wing_tank_kg = 3907	--3913.6
	elseif B738DR_73x == 2 then
		-- 700
		max_payload_kg = 70000
		max_payload_lb = 154500
		empty_kg = 37600
		empty_lb = 83000
		wing_tank_kg = 3907	--3913.6
	end
	
	local std_pax_weight = 0
	
	local jj = 0
	local err = 0
	local pax_priority = 0
	local max_pax = 0
	local max_pax_kg = 0
	
	if kk == nil then
		if string.sub(in_entry, 1, 1) == "P" then
			in_entry = string.sub(in_entry, 2, -1)
			kk = tonumber(in_entry)
			if kk == nil then
				err = 1
			else
				pax_priority = 1
			end
		else
			err = 1
		end
	else
		err = 0
	end
	
	if err == 0 then
		for zxp = 0, 4 do
			max_pax = max_pax + B738DR_std_pax_num[zxp]
		end
		if pax_priority == 0 then
			for jj = 1, string.len(in_entry) do
				if string.sub(in_entry, jj, jj) == "." then
					kk = kk * 1000
					break
				end
			end
			
			if B738DR_fmc_units == 0 then
				if kk >= 0 and kk <= max_payload_only_lb then
					result_ok = 1
				end
			else
				if kk >= 0 and kk <= max_payload_only_kg then
					result_ok = 1
				end
			end
			if result_ok ~= 0 then
				if B738DR_fmc_units == 0 then
					kk = kk / KGS_LBS
				end
				-- ll = kk / max_payload_only_kg
				-- if ll > 1 then
					-- ll = 1
				-- end
				
				max_pax_kg = max_pax * B738DR_std_pax_weight[0]
				mm = kk / max_pax_kg
				if mm > 1 then
					mm = 1
				end
				
				local m_pax_tmp = 0
				local w_pax_tmp = 0
				local ch_pax_tmp = 0
				local pax_weight_tmp = 0
				local pax_ratio_tmp = 0
				
				-- zone 1
				pax_weight_zone = B738DR_std_pax_num[0] * B738DR_std_pax_weight[0] * mm
				m_pax_tmp = math.floor((B738DR_std_pax_num[0] / 2) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[0] * 3 / 8) + 0.5)
				ch_pax_tmp = math.floor((B738DR_std_pax_num[0] * 1 / 8) + 0.5)
				ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[0] - m_pax_tmp - w_pax_tmp)
				ch_pax_tmp = math.max(ch_pax_tmp, 0)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone1_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone1_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone1_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
				else
					m_pax_tmp = math.floor((B738DR_std_pax_num[0] * 2 / 3) + 0.5)
					w_pax_tmp = math.floor((B738DR_std_pax_num[0] * 1 / 3) + 0.5)
					pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
					if pax_weight_zone <= pax_weight_tmp then
						pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
						zone1_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
						zone1_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
						zone1_pax[3] = 0
					else
						zone1_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
						zone1_pax[2] = 0
						zone1_pax[3] = 0
					end
				end
				
				-- zone 2
				pax_weight_zone = B738DR_std_pax_num[1] * B738DR_std_pax_weight[0] * mm
				m_pax_tmp = math.floor((B738DR_std_pax_num[1] / 2) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[1] * 3 / 8) + 0.5)
				ch_pax_tmp = math.floor((B738DR_std_pax_num[1] * 1 / 8) + 0.5)
				ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[1] - m_pax_tmp - w_pax_tmp)
				ch_pax_tmp = math.max(ch_pax_tmp, 0)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone2_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone2_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone2_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
				else
					m_pax_tmp = math.floor((B738DR_std_pax_num[1] * 2 / 3) + 0.5)
					w_pax_tmp = math.floor((B738DR_std_pax_num[1] * 1 / 3) + 0.5)
					pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
					if pax_weight_zone <= pax_weight_tmp then
						pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
						zone2_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
						zone2_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
						zone2_pax[3] = 0
					else
						zone2_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
						zone2_pax[2] = 0
						zone2_pax[3] = 0
					end
				end
				
				-- zone 3
				pax_weight_zone = B738DR_std_pax_num[2] * B738DR_std_pax_weight[0] * mm
				m_pax_tmp = math.floor((B738DR_std_pax_num[2] / 2) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[2] * 3 / 8) + 0.5)
				ch_pax_tmp = math.floor((B738DR_std_pax_num[2] * 1 / 8) + 0.5)
				ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[2] - m_pax_tmp - w_pax_tmp)
				ch_pax_tmp = math.max(ch_pax_tmp, 0)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone3_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone3_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone3_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
				else
					m_pax_tmp = math.floor((B738DR_std_pax_num[2] * 2 / 3) + 0.5)
					w_pax_tmp = math.floor((B738DR_std_pax_num[2] * 1 / 3) + 0.5)
					pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
					if pax_weight_zone <= pax_weight_tmp then
						pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
						zone3_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
						zone3_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
						zone3_pax[3] = 0
					else
						zone3_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
						zone3_pax[2] = 0
						zone3_pax[3] = 0
					end
				end
				
				-- zone 4
				pax_weight_zone = B738DR_std_pax_num[3] * B738DR_std_pax_weight[0] * mm
				m_pax_tmp = math.floor((B738DR_std_pax_num[3] / 2) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[3] * 3 / 8) + 0.5)
				ch_pax_tmp = math.floor((B738DR_std_pax_num[3] * 1 / 8) + 0.5)
				ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[3] - m_pax_tmp - w_pax_tmp)
				ch_pax_tmp = math.max(ch_pax_tmp, 0)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone4_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone4_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone4_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
				else
					m_pax_tmp = math.floor((B738DR_std_pax_num[3] * 2 / 3) + 0.5)
					w_pax_tmp = math.floor((B738DR_std_pax_num[3] * 1 / 3) + 0.5)
					pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
					if pax_weight_zone <= pax_weight_tmp then
						pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
						zone4_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
						zone4_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
						zone4_pax[3] = 0
					else
						zone4_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
						zone4_pax[2] = 0
						zone4_pax[3] = 0
					end
				end
				
				-- zone 5
				pax_weight_zone = B738DR_std_pax_num[4] * B738DR_std_pax_weight[0] * mm
				m_pax_tmp = math.floor((B738DR_std_pax_num[4] / 2) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[4] * 3 / 8) + 0.5)
				ch_pax_tmp = math.floor((B738DR_std_pax_num[4] * 1 / 8) + 0.5)
				ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[4] - m_pax_tmp - w_pax_tmp)
				ch_pax_tmp = math.max(ch_pax_tmp, 0)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone5_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone5_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone5_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
				else
					m_pax_tmp = math.floor((B738DR_std_pax_num[4] * 2 / 3) + 0.5)
					w_pax_tmp = math.floor((B738DR_std_pax_num[4] * 1 / 3) + 0.5)
					pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
					if pax_weight_zone <= pax_weight_tmp then
						pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
						zone5_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
						zone5_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
						zone5_pax[3] = 0
					else
						zone5_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
						zone5_pax[2] = 0
						zone5_pax[3] = 0
					end
				end
				
				pax_weight = 0
				for zxp = 1, 3 do
					std_pax_weight = B738DR_std_pax_weight[zxp-1]
					pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
				end
				
				if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
					ll = kk - pax_weight
					if ll > 5099 then
						ll = 5099
					end
					if ll <= 300 then
						zone_cargo1 = ll
					elseif ll <= 1000 then
						zone_cargo1 = ll
					else
						zone_cargo1 = math.floor((ll * B738_rescale(1000, 0.3, 5099, 0.378, ll)) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.377) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.226) + 0.5) + 1000
					end
					if zone_cargo1 > 1927 then
						zone_cargo1 = 1927
					end
					zone_cargo2 = ll - zone_cargo1
					if zone_cargo2 < 0 then
						zone_cargo2 = 0
					elseif zone_cargo2 > 3172 then
						zone_cargo2 = 3172
					end
				elseif B738DR_73x == 2 then
					ll = kk - pax_weight
					if ll > 5099 then
						ll = 5099
					end
					if ll <= 300 then
						zone_cargo1 = ll
					elseif ll <= 1000 then
						zone_cargo1 = ll
					else
						zone_cargo1 = math.floor((ll * B738_rescale(1000, 0.3, 5099, 0.378, ll)) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.377) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.226) + 0.5) + 1000
					end
					if zone_cargo1 > 1927 then
						zone_cargo1 = 1927
					end
					zone_cargo2 = ll - zone_cargo1
					if zone_cargo2 < 0 then
						zone_cargo2 = 0
					elseif zone_cargo2 > 3172 then
						zone_cargo2 = 3172
					end
				else
					ll = kk - pax_weight
					if ll > 8410 then
						ll = 8410
					end
					if ll <= 300 then
						zone_cargo1 = ll
					elseif ll <= 1000 then
						zone_cargo1 = ll
					else
						zone_cargo1 = math.floor((ll * B738_rescale(1000, 0.3, 8410, 0.423, ll)) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.423) + 0.5)
						-- zone_cargo1 = math.floor((ll * 0.345) + 0.5) + 1000
					end
					if zone_cargo1 > 3560 then
						zone_cargo1 = 3560
					end
					zone_cargo2 = ll - zone_cargo1
					if zone_cargo2 < 0 then
						zone_cargo2 = 0
					elseif zone_cargo2 > 4850 then
						zone_cargo2 = 4850
					end
				end
				pax_weight = pax_weight + zone_cargo1 + zone_cargo2
				req_payload_weight = pax_weight + physical_crew_payload_weight()
				
				fill_zone_weight_req()
				crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
				crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
				cargo1_weight_req = zone_cargo1
				cargo2_weight_req = zone_cargo2
				
				B738CMD_change_payload:once()
			end
		else
			-- only pax / only men
			if kk >= 0 and kk <= max_pax then
				result_ok = 1
				zone1_pax[1] = 0
				zone1_pax[2] = 0
				zone1_pax[3] = 0
				zone2_pax[1] = 0
				zone2_pax[2] = 0
				zone2_pax[3] = 0
				zone3_pax[1] = 0
				zone3_pax[2] = 0
				zone3_pax[3] = 0
				zone4_pax[1] = 0
				zone4_pax[2] = 0
				zone4_pax[3] = 0
				zone5_pax[1] = 0
				zone5_pax[2] = 0
				zone5_pax[3] = 0
				ll = kk / max_pax
				if ll > 1 then
					ll = 1
					zone1_pax[1] = B738DR_std_pax_num[0]
					zone2_pax[1] = B738DR_std_pax_num[1]
					zone3_pax[1] = B738DR_std_pax_num[2]
					zone4_pax[1] = B738DR_std_pax_num[3]
					zone5_pax[1] = B738DR_std_pax_num[4]
				else
					local pax_num_total = 0
					local pax_num = B738DR_std_pax_num[0] * ll
					pax_num = math.min(math.ceil(pax_num), B738DR_std_pax_num[0])
					pax_num_total = pax_num_total + pax_num
					zone1_pax[1] = pax_num
					-- zone 2
					pax_num = B738DR_std_pax_num[1] * ll
					pax_num = math.min(math.ceil(pax_num), B738DR_std_pax_num[1])
					if pax_num + pax_num_total <= kk then
						pax_num_total = pax_num_total + pax_num
						zone2_pax[1] = pax_num
						-- zone 3
						pax_num = B738DR_std_pax_num[2] * ll
						pax_num = math.min(math.ceil(pax_num), B738DR_std_pax_num[2])
						if pax_num + pax_num_total <= kk then
							pax_num_total = pax_num_total + pax_num
							zone3_pax[1] = pax_num
							-- zone 4
							pax_num = B738DR_std_pax_num[3] * ll
							pax_num = math.min(math.ceil(pax_num), B738DR_std_pax_num[3])
							if pax_num + pax_num_total <= kk then
								pax_num_total = pax_num_total + pax_num
								zone4_pax[1] = pax_num
								-- zone 5
								if pax_num_total > kk then
									zone5_pax[1] = pax_num_total - kk
								else
									zone5_pax[1] = kk - pax_num_total
								end
								zone5_pax[1] = math.min(zone5_pax[1], B738DR_std_pax_num[4])
							else
								if pax_num_total > kk then
									zone4_pax[1] = pax_num_total - kk
								else
									zone4_pax[1] = kk - pax_num_total
								end
								zone4_pax[1] = math.min(zone4_pax[1], B738DR_std_pax_num[3])
							end
						else
							if pax_num_total > kk then
								zone3_pax[1] = pax_num_total - kk
							else
								zone3_pax[1] = kk - pax_num_total
							end
							zone3_pax[1] = math.min(zone3_pax[1], B738DR_std_pax_num[2])
						end
					else
						if pax_num_total > kk then
							zone2_pax[1] = pax_num_total - kk
						else
							zone2_pax[1] = kk - pax_num_total
						end
						zone2_pax[1] = math.min(zone2_pax[1], B738DR_std_pax_num[1])
					end
				end
				
				-- set payload
				pax_weight = 0
				for zxp = 1, 3 do
					std_pax_weight = B738DR_std_pax_weight[zxp-1]
					pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
					pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
				end
				pax_weight = pax_weight + zone_cargo1 + zone_cargo2
				req_payload_weight = pax_weight + physical_crew_payload_weight()
				
				fill_zone_weight_req()
				crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
				crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
				cargo1_weight_req = zone_cargo1
				cargo2_weight_req = zone_cargo2
				
				B738CMD_change_payload:once()
			end
		end
	end
	
	return result_ok
end

function pax_input(in_entry)
	-- pax_men == -1 -> Entry Error
	local pax_men = -1
	local pax_women = 0
	local pax_children = 0
	local sep1 = 0
	local sep2 = 0
	local ii = 0
	local entry_len = string.len(in_entry)
	local entry_num = 0
	
	if entry_len > 0 then
		for ii = 1, entry_len do
			if string.sub(in_entry, ii, ii) == "M" then
				sep1 = ii
			end
			if string.sub(in_entry, ii, ii) == "F" then
				sep2 = ii
			end
		end
		if sep1 == 0 and sep2 == 0 then
			-- only men
			entry_num = tonumber(in_entry)
			if entry_num ~= nil then
				pax_men = math.floor(entry_num)
			end
		elseif sep2 == 0 then
			-- only men and women
			entry_num = tonumber(string.sub(in_entry, 1, sep1-1))
			if entry_num == nil then
				pax_men = 0
				entry_num = tonumber(string.sub(in_entry, sep1+1, -1))
				if entry_num ~= nil then
					pax_women = math.floor(entry_num)
				end
			else
				pax_men = math.floor(entry_num)
				entry_num = tonumber(string.sub(in_entry, sep1+1, -1))
				if entry_num ~= nil then
					pax_women = math.floor(entry_num)
				end
			end
		else
			-- men, women and children
			entry_num = tonumber(string.sub(in_entry, 1, sep1-1))
			if entry_num == nil then
				pax_men = 0
				entry_num = tonumber(string.sub(in_entry, sep1+1, sep2-1))
				if entry_num == nil then
					entry_num = tonumber(string.sub(in_entry, sep2+1, -1))
					if entry_num ~= nil then
						pax_children = math.floor(entry_num)
					end
				else
					pax_women = math.floor(entry_num)
					entry_num = tonumber(string.sub(in_entry, sep2+1, -1))
					if entry_num ~= nil then
						pax_children = math.floor(entry_num)
					end
				end
			else
				pax_men = math.floor(entry_num)
				entry_num = tonumber(string.sub(in_entry, sep1+1, sep2-1))
				if entry_num ~= nil then
					pax_women = math.floor(entry_num)
					entry_num = tonumber(string.sub(in_entry, sep2+1, -1))
					if entry_num ~= nil then
						pax_children = math.floor(entry_num)
					end
				end
			end
		end
	end
	
	return pax_men, pax_women, pax_children
end



function sam_payload()

	if simDR_payload_weight ~= payload_weight_old and sam_tick > 4 then
		
		local result_ok = 0
		local ll = 0
		local mm = 0
		local kk = simDR_payload_weight
		local pax_weight = 0
		local pax_weight_zone = 0
		local max_cargo = 0
		
		local max_payload_only_kg = 25137
		local max_payload_only_lb = 55417
		local empty_kg = 43000
		local empty_lb = 91300
		local wing_tank_kg = temp_wing_tank_kg		--3907
		local max_fuel_kg = temp_max_fuel_kg		--20876
		local max_fuel_lb = max_fuel_kg * KGS_LBS
		local max_payload_kg = 0
		local max_payload_lb = 0
		
		if B738DR_b737_variant == 0 then
			--800
			max_payload_kg = 79242		--79016
			max_payload_lb = 174700		--174200
			empty_kg = 41510			--43000
			empty_lb = 91514			--91300
			wing_tank_kg = 3907			--3913.6
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 1 then
			--900
			max_payload_kg = 74615		--79016
			max_payload_lb = 164500		--174200
			empty_kg = 42900			--43000
			empty_lb = 94580			--91300
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 2 then
			--700
			max_payload_kg = 70080
			max_payload_lb = 154500
			empty_kg = 37648			--37600
			empty_lb = 83000			--82800
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 3 then
			--600
			max_payload_kg = 56472		--65544
			max_payload_lb = 124500		--144500
			empty_kg = 36378			--36300
			empty_lb = 80200			--80000
			wing_tank_kg = 3907
			max_fuel_kg = 20876
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_b737_variant == 4 then
			--900ER
			max_payload_kg = 85139
			max_payload_lb = 187700
			empty_kg = 44676			--44600
			empty_lb = 98495			--98320
			wing_tank_kg = 3907
			max_fuel_kg = 23800
			max_fuel_lb = max_fuel_kg * KGS_LBS
		elseif B738DR_73x == 1 then
			-- 900
			max_payload_kg = 85000
			max_payload_lb = 187700
			empty_kg = 42500
			empty_lb = 93600
			wing_tank_kg = 3907	--3913.6
		elseif B738DR_73x == 2 then
			-- 700
			max_payload_kg = 70000
			max_payload_lb = 154500
			empty_kg = 37600
			empty_lb = 83000
			wing_tank_kg = 3907	--3913.6
		end
		
		local std_pax_weight = 0
		
		local jj = 0
		local err = 0
		local pax_priority = 0
		local max_pax = 0
		local max_pax_kg = 0
		
		if kk >= physical_crew_payload_weight() and kk <= max_payload_only_kg then
			result_ok = 1
		end
		
		if result_ok ~= 0 then
			if B738DR_fmc_units == 0 then
				kk = kk / KGS_LBS
			end
			
			max_pax_kg = max_pax * B738DR_std_pax_weight[0]
			mm = kk / max_pax_kg
			if mm > 1 then
				mm = 1
			end
			
			local m_pax_tmp = 0
			local w_pax_tmp = 0
			local ch_pax_tmp = 0
			local pax_weight_tmp = 0
			local pax_ratio_tmp = 0
			
			-- zone 1
			pax_weight_zone = B738DR_std_pax_num[0] * B738DR_std_pax_weight[0] * mm
			m_pax_tmp = math.floor((B738DR_std_pax_num[0] / 2) + 0.5)
			w_pax_tmp = math.floor((B738DR_std_pax_num[0] * 3 / 8) + 0.5)
			ch_pax_tmp = math.floor((B738DR_std_pax_num[0] * 1 / 8) + 0.5)
			ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[0] - m_pax_tmp - w_pax_tmp)
			ch_pax_tmp = math.max(ch_pax_tmp, 0)
			pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
			if pax_weight_zone <= pax_weight_tmp then
				pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
				zone1_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
				zone1_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
				zone1_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
			else
				m_pax_tmp = math.floor((B738DR_std_pax_num[0] * 2 / 3) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[0] * 1 / 3) + 0.5)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone1_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone1_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone1_pax[3] = 0
				else
					zone1_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
					zone1_pax[2] = 0
					zone1_pax[3] = 0
				end
			end
			
			-- zone 2
			pax_weight_zone = B738DR_std_pax_num[1] * B738DR_std_pax_weight[0] * mm
			m_pax_tmp = math.floor((B738DR_std_pax_num[1] / 2) + 0.5)
			w_pax_tmp = math.floor((B738DR_std_pax_num[1] * 3 / 8) + 0.5)
			ch_pax_tmp = math.floor((B738DR_std_pax_num[1] * 1 / 8) + 0.5)
			ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[1] - m_pax_tmp - w_pax_tmp)
			ch_pax_tmp = math.max(ch_pax_tmp, 0)
			pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
			if pax_weight_zone <= pax_weight_tmp then
				pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
				zone2_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
				zone2_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
				zone2_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
			else
				m_pax_tmp = math.floor((B738DR_std_pax_num[1] * 2 / 3) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[1] * 1 / 3) + 0.5)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone2_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone2_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone2_pax[3] = 0
				else
					zone2_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
					zone2_pax[2] = 0
					zone2_pax[3] = 0
				end
			end
			
			-- zone 3
			pax_weight_zone = B738DR_std_pax_num[2] * B738DR_std_pax_weight[0] * mm
			m_pax_tmp = math.floor((B738DR_std_pax_num[2] / 2) + 0.5)
			w_pax_tmp = math.floor((B738DR_std_pax_num[2] * 3 / 8) + 0.5)
			ch_pax_tmp = math.floor((B738DR_std_pax_num[2] * 1 / 8) + 0.5)
			ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[2] - m_pax_tmp - w_pax_tmp)
			ch_pax_tmp = math.max(ch_pax_tmp, 0)
			pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
			if pax_weight_zone <= pax_weight_tmp then
				pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
				zone3_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
				zone3_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
				zone3_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
			else
				m_pax_tmp = math.floor((B738DR_std_pax_num[2] * 2 / 3) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[2] * 1 / 3) + 0.5)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone3_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone3_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone3_pax[3] = 0
				else
					zone3_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
					zone3_pax[2] = 0
					zone3_pax[3] = 0
				end
			end
			
			-- zone 4
			pax_weight_zone = B738DR_std_pax_num[3] * B738DR_std_pax_weight[0] * mm
			m_pax_tmp = math.floor((B738DR_std_pax_num[3] / 2) + 0.5)
			w_pax_tmp = math.floor((B738DR_std_pax_num[3] * 3 / 8) + 0.5)
			ch_pax_tmp = math.floor((B738DR_std_pax_num[3] * 1 / 8) + 0.5)
			ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[3] - m_pax_tmp - w_pax_tmp)
			ch_pax_tmp = math.max(ch_pax_tmp, 0)
			pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
			if pax_weight_zone <= pax_weight_tmp then
				pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
				zone4_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
				zone4_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
				zone4_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
			else
				m_pax_tmp = math.floor((B738DR_std_pax_num[3] * 2 / 3) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[3] * 1 / 3) + 0.5)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone4_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone4_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone4_pax[3] = 0
				else
					zone4_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
					zone4_pax[2] = 0
					zone4_pax[3] = 0
				end
			end
			
			-- zone 5
			pax_weight_zone = B738DR_std_pax_num[4] * B738DR_std_pax_weight[0] * mm
			m_pax_tmp = math.floor((B738DR_std_pax_num[4] / 2) + 0.5)
			w_pax_tmp = math.floor((B738DR_std_pax_num[4] * 3 / 8) + 0.5)
			ch_pax_tmp = math.floor((B738DR_std_pax_num[4] * 1 / 8) + 0.5)
			ch_pax_tmp = math.min(ch_pax_tmp, B738DR_std_pax_num[4] - m_pax_tmp - w_pax_tmp)
			ch_pax_tmp = math.max(ch_pax_tmp, 0)
			pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1] + ch_pax_tmp * B738DR_std_pax_weight[2]
			if pax_weight_zone <= pax_weight_tmp then
				pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
				zone5_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
				zone5_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
				zone5_pax[3] = math.floor(ch_pax_tmp * pax_ratio_tmp)
			else
				m_pax_tmp = math.floor((B738DR_std_pax_num[4] * 2 / 3) + 0.5)
				w_pax_tmp = math.floor((B738DR_std_pax_num[4] * 1 / 3) + 0.5)
				pax_weight_tmp = m_pax_tmp * B738DR_std_pax_weight[0] + w_pax_tmp * B738DR_std_pax_weight[1]
				if pax_weight_zone <= pax_weight_tmp then
					pax_ratio_tmp = pax_weight_zone / pax_weight_tmp
					zone5_pax[1] = math.floor(m_pax_tmp * pax_ratio_tmp)
					zone5_pax[2] = math.floor(w_pax_tmp * pax_ratio_tmp)
					zone5_pax[3] = 0
				else
					zone5_pax[1] = math.floor(pax_weight_zone / B738DR_std_pax_weight[0])
					zone5_pax[2] = 0
					zone5_pax[3] = 0
				end
			end
			
			pax_weight = 0
			for zxp = 1, 3 do
				std_pax_weight = B738DR_std_pax_weight[zxp-1]
				pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
				pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
				pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
				pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
				pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
			end
			
			if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
				ll = (kk - pax_weight) / 5099
				if ll > 1 then
					ll = 1
				end
				zone_cargo1 = 1927 * ll
				zone_cargo2 = 3172 * ll
			elseif B738DR_73x == 2 then
				ll = (kk - pax_weight) / 5099
				if ll > 1 then
					ll = 1
				end
				zone_cargo1 = 1927 * ll
				zone_cargo2 = 3172 * ll
			else
				ll = (kk - pax_weight) / 8410
				if ll > 1 then
					ll = 1
				end
				zone_cargo1 = 3560 * ll
				zone_cargo2 = 4850 * ll
			end
			-- ll = (kk - pax_weight) / 8410
			-- if ll > 1 then
				-- ll = 1
			-- end
			-- zone_cargo1 = 3560 * ll
			-- zone_cargo2 = 4850 * ll
			
			pax_weight = pax_weight + zone_cargo1 + zone_cargo2
			req_payload_weight = pax_weight + physical_crew_payload_weight()
			
			fill_zone_weight_req()
			crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
			crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
			cargo1_weight_req = zone_cargo1
			cargo2_weight_req = zone_cargo2
			
			-- B738CMD_change_payload:once()
			
		elseif kk < physical_crew_payload_weight() then
			-- if B738DR_b737_variant < 0 then
				-- simDR_payload_stations[7] = full_crew_weight_f
				-- simDR_payload_stations[8] = full_crew_weight_r
			-- else
				simDR_payload_weight = physical_crew_payload_weight()
				-- full_crew_weight = 524 + B738DR_fa_fwd_kg + B738DR_fa_aft_kg + B738DR_galley_fwd_kg + B738DR_galley_aft_kg
				full_crew_weight_f = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
				full_crew_weight_r = B738DR_fa_aft_kg + B738DR_galley_aft_kg
				full_crew_weight = full_crew_weight_f + full_crew_weight_r
			-- end
		end
	end
end



-- ROUNDING ---
function roundUpToIncrement(number, increment)

    local y = number / increment
    local q = math.ceil(y)
    local z = q * increment

    return z

end



function B738_mem_axis_value()
	for ii = 0, 500 do
		mem_axis_value[ii] = simDR_axis[ii]
	end
end

function B738_find_axis()
	if B738DR_tab_numpad_act == 1 then
		if numpad_ref >= 6 and numpad_ref <= 10 then
			local delta_axis_value = 0
			
			for ii = 0, 500 do
				delta_axis_value = math.abs(mem_axis_value[ii] - simDR_axis[ii])
				if delta_axis_value > 0.3 then
					if numpad_ref == 6 then
						B738DR_cust_axis_flaps_mapped = ii
					elseif numpad_ref == 7 then
						B738DR_cust_axis_speedbrake_mapped = ii
					elseif numpad_ref == 8 then
						B738DR_cust_axis_landgear_mapped = ii
					elseif numpad_ref == 9 then
						B738DR_cust_axis_mixture1_mapped = ii
					else
						B738DR_cust_axis_mixture2_mapped = ii
					end
					-- close numpad
					B738DR_tab_numpad_act = 0
					B738DR_tab_numpad_spec1 = 0
					B738DR_tab_numpad_spec2 = 0
					B738DR_tab_numpad_val = ""
					tab_numpad_val = ""
					numpad_ref = 0
					numpad_point = 0
					display_update = 1
					break
				end
			end
		end
	end
end

function B738_numpad_comma_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if numpad_point <= 1 and strlen < 7 then
				if numpad_point == 0 then
					tab_numpad_val = tab_numpad_val .. "M"
				else
					tab_numpad_val = tab_numpad_val .. "F"
				end
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
				numpad_point = numpad_point + 1
			end
		else
			if numpad_point == 0 and strlen < 7 then
				if numpad_ref == 202 or numpad_ref == 209 then
					tab_numpad_val = tab_numpad_val .. "/"
				else
					tab_numpad_val = tab_numpad_val .. "."
				end
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
				numpad_point = numpad_point + 1
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_0_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "0"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "0"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_1_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "1"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "1"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_2_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "2"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "2"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_3_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "3"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "3"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_4_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "4"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "4"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_5_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "5"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "5"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_6_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "6"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "6"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_7_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "7"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "7"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_8_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "8"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "8"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_numpad_9_CMDhandler(phase, duration)
	if phase == 0 then
		local strlen = string.len(tab_numpad_val)
		if numpad_ref >= 11 and numpad_ref <= 15 then
			if strlen < 8 then
				tab_numpad_val = tab_numpad_val .. "9"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		else
			if strlen < 7 then
				tab_numpad_val = tab_numpad_val .. "9"
				B738DR_tab_numpad_val = spaces_before(tab_numpad_val, 8)
			end
		end
		check_numpad_spec1()
	end
end

function B738_cl_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if cl_active == 0 then
			cl_pos_tgt = 100
			cl_active = 1
		else
			if cl_active == 1 and cl_pos_tgt == 0 then
				cl_pos_tgt = 100
			else
				cl_pos_tgt = 0
			end
		end
		if simDR_head_x > 0.15 then
			cl_cpt_fo = 1
		elseif simDR_head_x < -0.15 then
			cl_cpt_fo = 0
		end
	end
end

function B738_tab_power_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_tab_power == 0 then
			B738DR_tab_power = 1
			boot_cnt = 0
			reset_efb()
		else
			B738DR_tab_power = 0
			clr_menu_manip()
			clr_line_manip()
			clr_item()
			clr_perf_manip()
			B738DR_tab_nav_manip = 0
			B738DR_tab_info_manip = 0
			B738DR_tab_nav2_manip = 0
			B738DR_tab_arrows_enable = 0
			if is_timer_scheduled(boot_timer) == true then
				stop_timer(boot_timer)
			end
			if avitab_installed == 1 and avitab_ctrl_override == 0 then
				avitab_powered = 0
				avitab_enabled = 0
				avitab_brightness = 1.0
			end
		end
	end
end

function B738_tab_static_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_tab_static == 0 then
			B738DR_tab_pos_x = 0.0315
			B738DR_tab_pos_y = 0.05
			B738DR_tab_pos_z = 0.0
			B738DR_tab_rot_x = -24.5
			B738DR_tab_rot_y = 0.0
			B738DR_tab_static = 1
		end
	end
end

function B738_tab_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_tab_static == 2 then
			B738DR_tab_static = 0
		else
			B738DR_tab_static = 2
		end
	end
end

function B738_fo_tab_static_CMDhandler(phase, duration)
	if phase == 0 then
		-- if B738DR_fo_tab_static == 0 then
			-- B738DR_fo_tab_pos_x = 0.0315
			-- B738DR_fo_tab_pos_y = 0.05
			-- B738DR_fo_tab_pos_z = 0.0
			-- B738DR_fo_tab_rot_x = -24.5
			-- B738DR_fo_tab_rot_y = 0.0
			-- B738DR_fo_tab_static = 1
		-- end
		B738DR_fo_tab_static = 0
	end
end

function B738_fo_tab_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_fo_tab_static == 2 then
			B738DR_fo_tab_static = 0
		else
			B738DR_fo_tab_static = 2
		end
	end
end


-- Doors commands toggle
function B738_door_fwd_L_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_fwd_L_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_fwd_L_trg = 1
			end
		else
			if B738DR_hide_airstairs == 1 or B738DR_not_airstairs == 1 then
				door_ratio_fwd_L_trg = 0
			end
		end
	end
end

function B738_door_fwd_R_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_fwd_R_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_fwd_R_trg = 1
			end
		else
			door_ratio_fwd_R_trg = 0
		end
	end
end

function B738_door_aft_L_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_aft_L_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_aft_L_trg = 1
			end
		else
			door_ratio_aft_L_trg = 0
		end
	end
end

function B738_door_aft_R_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_aft_R_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_aft_R_trg = 1
			end
		else
			door_ratio_aft_R_trg = 0
		end
	end
end

function B738_door_aft_cargo_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_aft_cargo_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_aft_cargo_trg = 1
			end
		else
			door_ratio_aft_cargo_trg = 0
		end
	end
end

function B738_door_fwd_cargo_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_fwd_cargo_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_fwd_cargo_trg = 1
			end
		else
			door_ratio_fwd_cargo_trg = 0
		end
	end
end

function B738_door_emerg1_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg1_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg1_trg = 1
			end
		else
			door_ratio_emerg1_trg = 0
		end
	end
end

function B738_door_emerg2_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg2_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg2_trg = 1
			end
		else
			door_ratio_emerg2_trg = 0
		end
	end
end

function B738_door_emerg3_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg3_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg3_trg = 1
			end
		else
			door_ratio_emerg3_trg = 0
		end
	end
end

function B738_door_emerg4_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg4_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg4_trg = 1
			end
		else
			door_ratio_emerg4_trg = 0
		end
	end
end

function B738_door_emerg5_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg5_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg5_trg = 1
			end
		else
			door_ratio_emerg5_trg = 0
		end
	end
end

function B738_door_emerg6_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_emerg6_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if emerg_door_locked == 0 then
				door_ratio_emerg6_trg = 1
			end
		else
			door_ratio_emerg6_trg = 0
		end
	end
end

function B738_door_aft1_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_aft1_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_aft1_trg = 1
			end
		else
			door_ratio_aft1_trg = 0
		end
	end
end

function B738_door_aft2_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if door_ratio_aft2_trg == 0 then
			-- if is_command_cabindoor_closed == 0 then
			if door_locked == 0 then
				door_ratio_aft2_trg = 1
			end
		else
			door_ratio_aft2_trg = 0
		end
	end
end

function B738_airstairs_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_not_airstairs == 0 then
			if B738DR_b737_variant >= 0 then
				if airstair_ratio_tgt == 0 then
					if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
						if simDR_aircraft_groundspeed < 0.08 and door_ratio_fwd_L ~= 0 then
							airstair_ratio_tgt = 1
						end
					end
				else
					airstair_ratio_tgt = 0
				end
			else
				-- if simDR_bus_battery_on[1] ~= 0 then
				if B738DR_batbus_status ~= 0 then
					if B738DR_hide_airstairs == 0 then
						if door_ratio_fwd_L == 1 then
							B738DR_hide_airstairs = 1
						end
					else
						if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
							if simDR_aircraft_groundspeed < 0.08 and door_ratio_fwd_L ~= 0 then
								B738DR_hide_airstairs = 0
							end
						end
					end
				end
			end
		end
	end
end

function B738_airstairs_ext_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_not_airstairs == 0 then
			if B738DR_b737_variant >= 0 then
				if airstair_ratio_tgt == 0 then
					if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
						if simDR_aircraft_groundspeed < 0.08 then
							airstair_ratio_tgt = 1
						end
					end
				else
					airstair_ratio_tgt = 0
				end
			else
				if B738DR_hot_batbus_status ~= 0 then
					if B738DR_hide_airstairs == 0 then
						B738DR_hide_airstairs = 1
					else
						if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
							if simDR_aircraft_groundspeed < 0.08 then
								B738DR_hide_airstairs = 0
							end
						end
					end
				end
			end
		end
	end
end

function B738_gpu_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_hide_gpu == 0 then
			B738DR_hide_gpu = 1
		else
			if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
				if simDR_aircraft_groundspeed < 0.08 then
					B738DR_hide_gpu = 0
				end
			end
		end
		if B738DR_hide_gpu == 0 then
			gpu_deployed = 1
		else
			gpu_deployed = 0
		end
	end
end

function B738_asu_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_engine_air_start == 0 then
			if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
				if simDR_aircraft_groundspeed < 0.08 then
					B738DR_engine_air_start = 1
					B738DR_hide_asu = 0
				end
			end
		else
			B738DR_engine_air_start = 0
			B738DR_hide_asu = 1
		end
	end
end

function B738_deice_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_de_ice_truck_hide == 0 then
			B738DR_de_ice_truck_hide = 1
			B738DR_de_ice_truck_act = 0
			de_ice_apply_time = 0
		else
			if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
				if simDR_aircraft_groundspeed < 0.08 then
					if B738DR_de_ice_truck_available ~= 0 then
						B738DR_de_ice_truck_hide = 0
						B738DR_de_ice_truck_act = 0
						de_ice_apply_time = 180
					end
				end
			end
		end
	end
end

function B738_fueltruck_toggle_CMDhandler(phase, duration)
	if phase == 0 then
		-- if B738DR_hide_fueltruck == 0 then
		if hide_fueltruck == 0 then
			hide_fueltruck = 1
			B738DR_hide_fueltruck = 1
		else
			if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 then
				if simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1 then
					if simDR_aircraft_groundspeed < 0.08 and B738DR_req_fuel ~= 0 then
						hide_fueltruck = 0
						if B738DR_int_gnd_services == 0 then
							B738DR_hide_fueltruck = 0
						end
					end
				end
			end
		end
	end
end

function B738_entry_payload_CMDhandler(phase, duration)
	if phase == 0 then
		for zxp = 1, 3 do
			zone1_pax[zxp] = B738DR_zone1_payload[zxp-1]
			zone2_pax[zxp] = B738DR_zone2_payload[zxp-1]
			zone3_pax[zxp] = B738DR_zone3_payload[zxp-1]
			zone4_pax[zxp] = B738DR_zone4_payload[zxp-1]
			zone5_pax[zxp] = B738DR_zone5_payload[zxp-1]
		end
		zone_cargo1 = B738DR_zone_cargo1_payload
		zone_cargo2 = B738DR_zone_cargo2_payload
		
		local pax_weight = 0
		local std_pax_weight = 0
		for zxp = 1, 3 do
			std_pax_weight = B738DR_std_pax_weight[zxp-1]
			pax_weight = pax_weight + zone1_pax[zxp] * std_pax_weight
			pax_weight = pax_weight + zone2_pax[zxp] * std_pax_weight
			pax_weight = pax_weight + zone3_pax[zxp] * std_pax_weight
			pax_weight = pax_weight + zone4_pax[zxp] * std_pax_weight
			pax_weight = pax_weight + zone5_pax[zxp] * std_pax_weight
		end
		pax_weight = pax_weight + zone_cargo1 + zone_cargo2
		req_payload_weight = pax_weight + physical_crew_payload_weight()
		
		fill_zone_weight_req()
		crew_weight_f_req = 524 + B738DR_fa_fwd_kg + B738DR_galley_fwd_kg
		crew_weight_r_req = B738DR_fa_aft_kg + B738DR_galley_aft_kg
		cargo1_weight_req = zone_cargo1
		cargo2_weight_req = zone_cargo2
		
		B738CMD_change_payload:once()
	end
end


function fill_zone_weight()
	local weight_tmp = 0
	for ggg = 1, 5 do
		weight_tmp = 0
		for zxp = 1, 3 do
			if ggg == 1 then
				weight_tmp = weight_tmp + B738DR_zone1_payload[zxp-1] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 2 then
				weight_tmp = weight_tmp + B738DR_zone2_payload[zxp-1] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 3 then
				weight_tmp = weight_tmp + B738DR_zone3_payload[zxp-1] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 4 then
				weight_tmp = weight_tmp + B738DR_zone4_payload[zxp-1] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 5 then
				weight_tmp = weight_tmp + B738DR_zone5_payload[zxp-1] * B738DR_std_pax_weight[zxp-1]
			end
		end
		B738DR_zone_weight[ggg-1] = weight_tmp
	end
end

function fill_zone_weight_req()
	local weight_tmp = 0
	for ggg = 1, 5 do
		weight_tmp = 0
		for zxp = 1, 3 do
			if ggg == 1 then
				weight_tmp = weight_tmp + zone1_pax[zxp] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 2 then
				weight_tmp = weight_tmp + zone2_pax[zxp] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 3 then
				weight_tmp = weight_tmp + zone3_pax[zxp] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 4 then
				weight_tmp = weight_tmp + zone4_pax[zxp] * B738DR_std_pax_weight[zxp-1]
			elseif ggg == 5 then
				weight_tmp = weight_tmp + zone5_pax[zxp] * B738DR_std_pax_weight[zxp-1]
			end
		end
		zone_weight_req[ggg] = weight_tmp
	end
end

function B738_load_flight_1_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 1
		B738DR_load_save = 2
	end
end

function B738_load_flight_2_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 2
		B738DR_load_save = 2
	end
end

function B738_load_flight_3_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 3
		B738DR_load_save = 2
	end
end

function B738_load_flight_4_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 4
		B738DR_load_save = 2
	end
end

function B738_load_flight_5_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 5
		B738DR_load_save = 2
	end
end

function B738_load_flight_6_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 6
		B738DR_load_save = 2
	end
end

function B738_load_flight_7_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 7
		B738DR_load_save = 2
	end
end

function B738_load_flight_8_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 8
		B738DR_load_save = 2
	end
end

function B738_save_flight_1_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 1
		B738DR_load_save = 1
	end
end

function B738_save_flight_2_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 2
		B738DR_load_save = 1
	end
end

function B738_save_flight_3_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 3
		B738DR_load_save = 1
	end
end

function B738_save_flight_4_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 4
		B738DR_load_save = 1
	end
end

function B738_save_flight_5_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 5
		B738DR_load_save = 1
	end
end

function B738_save_flight_6_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 6
		B738DR_load_save = 1
	end
end

function B738_save_flight_7_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 7
		B738DR_load_save = 1
	end
end

function B738_save_flight_8_CMDhandler(phase, duration)
	if phase == 0 then
		B738DR_load_save2 = 8
		B738DR_load_save = 1
	end
end


-- --*************************************************************************************--
-- --** 				              CREATE CUSTOM COMMANDS              			     **--
-- --*************************************************************************************--

B738CMD_entry_payload = create_command("laminar/B738/tab/entry_payload", "Entry payload", B738_entry_payload_CMDhandler)

B738CMD_tab_static = create_command("laminar/B738/tab/static", "Detach EFB", B738_tab_static_CMDhandler)
B738CMD_tab_toggle = create_command("laminar/B738/tab/toggle", "Toggle EFB", B738_tab_toggle_CMDhandler)

B738CMD_fo_tab_static = create_command("laminar/B738/tab/fo_static", "Detach EFB", B738_fo_tab_static_CMDhandler)
B738CMD_fo_tab_toggle = create_command("laminar/B738/tab/fo_toggle", "Toggle EFB", B738_fo_tab_toggle_CMDhandler)

B738CMD_tab_info = create_command("laminar/B738/tab/info", "Info", B738_tab_info_CMDhandler)
B738CMD_tab_back = create_command("laminar/B738/tab/back", "Back", B738_tab_back_CMDhandler)
B738CMD_tab_spec = create_command("laminar/B738/tab/spec", "Spec", B738_tab_spec_CMDhandler)
B738CMD_tab_home = create_command("laminar/B738/tab/home", "Home", B738_tab_home_CMDhandler)
B738CMD_tab_power = create_command("laminar/B738/tab/power", "Power on/off", B738_tab_power_CMDhandler)

B738CMD_tab_left = create_command("laminar/B738/tab/left", "Left", B738_tab_left_CMDhandler)
B738CMD_tab_right = create_command("laminar/B738/tab/right", "Right", B738_tab_right_CMDhandler)

B738CMD_tab_menu1 = create_command("laminar/B738/tab/menu1", "Menu 1", B738_tab_menu1_CMDhandler)
B738CMD_tab_menu2 = create_command("laminar/B738/tab/menu2", "Menu 2", B738_tab_menu2_CMDhandler)
B738CMD_tab_menu3 = create_command("laminar/B738/tab/menu3", "Menu 3", B738_tab_menu3_CMDhandler)
B738CMD_tab_menu4 = create_command("laminar/B738/tab/menu4", "Menu 4", B738_tab_menu4_CMDhandler)
B738CMD_tab_menu5 = create_command("laminar/B738/tab/menu5", "Menu 5", B738_tab_menu5_CMDhandler)
B738CMD_tab_menu6 = create_command("laminar/B738/tab/menu6", "Menu 6", B738_tab_menu6_CMDhandler)
B738CMD_tab_menu7 = create_command("laminar/B738/tab/menu7", "Menu 7", B738_tab_menu7_CMDhandler)
B738CMD_tab_menu8 = create_command("laminar/B738/tab/menu8", "Menu 8", B738_tab_menu8_CMDhandler)

B738CMD_tab_line0 = create_command("laminar/B738/tab/line0", "Line 0", B738_tab_line0_CMDhandler)
B738CMD_tab_line1 = create_command("laminar/B738/tab/line1", "Line 1", B738_tab_line1_CMDhandler)
B738CMD_tab_line2 = create_command("laminar/B738/tab/line2", "Line 2", B738_tab_line2_CMDhandler)
B738CMD_tab_line3 = create_command("laminar/B738/tab/line3", "Line 3", B738_tab_line3_CMDhandler)
B738CMD_tab_line4 = create_command("laminar/B738/tab/line4", "Line 4", B738_tab_line4_CMDhandler)
B738CMD_tab_line5 = create_command("laminar/B738/tab/line5", "Line 5", B738_tab_line5_CMDhandler)
B738CMD_tab_line6 = create_command("laminar/B738/tab/line6", "Line 6", B738_tab_line6_CMDhandler)
B738CMD_tab_line7 = create_command("laminar/B738/tab/line7", "Line 7", B738_tab_line7_CMDhandler)
B738CMD_tab_line8 = create_command("laminar/B738/tab/line8", "Line 8", B738_tab_line8_CMDhandler)
B738CMD_tab_line9 = create_command("laminar/B738/tab/line9", "Line 9", B738_tab_line9_CMDhandler)

B738CMD_tab_perf1 = create_command("laminar/B738/tab/perf1", "Perf 1", B738_tab_perf1_CMDhandler)
B738CMD_tab_perf2 = create_command("laminar/B738/tab/perf2", "Perf 2", B738_tab_perf2_CMDhandler)
B738CMD_tab_perf3 = create_command("laminar/B738/tab/perf3", "Perf 3", B738_tab_perf3_CMDhandler)
B738CMD_tab_perf4 = create_command("laminar/B738/tab/perf4", "Perf 4", B738_tab_perf4_CMDhandler)
B738CMD_tab_perf5 = create_command("laminar/B738/tab/perf5", "Perf 5", B738_tab_perf5_CMDhandler)
B738CMD_tab_perf6 = create_command("laminar/B738/tab/perf6", "Perf 6", B738_tab_perf6_CMDhandler)
B738CMD_tab_perf7 = create_command("laminar/B738/tab/perf7", "Perf 7", B738_tab_perf7_CMDhandler)
B738CMD_tab_perf8 = create_command("laminar/B738/tab/perf8", "Perf 8", B738_tab_perf8_CMDhandler)
B738CMD_tab_perf9 = create_command("laminar/B738/tab/perf9", "Perf 9", B738_tab_perf9_CMDhandler)
B738CMD_tab_perf10 = create_command("laminar/B738/tab/perf10", "Perf 10", B738_tab_perf10_CMDhandler)
B738CMD_tab_perf11 = create_command("laminar/B738/tab/perf11", "Perf 11", B738_tab_perf11_CMDhandler)
B738CMD_tab_perf12 = create_command("laminar/B738/tab/perf12", "Perf 12", B738_tab_perf12_CMDhandler)
B738CMD_tab_perf13 = create_command("laminar/B738/tab/perf13", "Perf 13", B738_tab_perf13_CMDhandler)
B738CMD_tab_perf14 = create_command("laminar/B738/tab/perf14", "Perf 14", B738_tab_perf14_CMDhandler)
B738CMD_tab_perf15 = create_command("laminar/B738/tab/perf15", "Perf 15", B738_tab_perf15_CMDhandler)
B738CMD_tab_perf16 = create_command("laminar/B738/tab/perf16", "Perf 16", B738_tab_perf16_CMDhandler)

B738CMD_numpad_close	= create_command("laminar/B738/tab/numpad_close", "Close", B738_numpad_close_CMDhandler)
B738CMD_numpad_clr		= create_command("laminar/B738/tab/numpad_clr", "Clear", B738_numpad_clr_CMDhandler)
B738CMD_numpad_enter	= create_command("laminar/B738/tab/numpad_enter", "Enter", B738_numpad_enter_CMDhandler)
B738CMD_numpad_comma	= create_command("laminar/B738/tab/numpad_comma", "Key comma", B738_numpad_comma_CMDhandler)
B738CMD_numpad_minus	= create_command("laminar/B738/tab/numpad_minus", "Key minus", B738_numpad_minus_CMDhandler)
B738CMD_numpad_0		= create_command("laminar/B738/tab/numpad_0", "Key 0", B738_numpad_0_CMDhandler)
B738CMD_numpad_1		= create_command("laminar/B738/tab/numpad_1", "Key 1", B738_numpad_1_CMDhandler)
B738CMD_numpad_2		= create_command("laminar/B738/tab/numpad_2", "Key 2", B738_numpad_2_CMDhandler)
B738CMD_numpad_3		= create_command("laminar/B738/tab/numpad_3", "Key 3", B738_numpad_3_CMDhandler)
B738CMD_numpad_4		= create_command("laminar/B738/tab/numpad_4", "Key 4", B738_numpad_4_CMDhandler)
B738CMD_numpad_5		= create_command("laminar/B738/tab/numpad_5", "Key 5", B738_numpad_5_CMDhandler)
B738CMD_numpad_6		= create_command("laminar/B738/tab/numpad_6", "Key 6", B738_numpad_6_CMDhandler)
B738CMD_numpad_7		= create_command("laminar/B738/tab/numpad_7", "Key 7", B738_numpad_7_CMDhandler)
B738CMD_numpad_8		= create_command("laminar/B738/tab/numpad_8", "Key 8", B738_numpad_8_CMDhandler)
B738CMD_numpad_9		= create_command("laminar/B738/tab/numpad_9", "Key 9", B738_numpad_9_CMDhandler)

B738CMD_cl_toggle		= create_command("laminar/B738/checklist/toggle", "Checklist toggle", B738_cl_toggle_CMDhandler)

-- Doors commands
B738CMD_door_fwd_L_toggle		= create_command("laminar/B738/door/fwd_L_toggle", "Door FWD Entry toggle", B738_door_fwd_L_toggle_CMDhandler)
B738CMD_door_fwd_R_toggle		= create_command("laminar/B738/door/fwd_R_toggle", "Door FWD Service toggle", B738_door_fwd_R_toggle_CMDhandler)
B738CMD_door_aft_L_toggle		= create_command("laminar/B738/door/aft_L_toggle", "Door AFT Entry toggle", B738_door_aft_L_toggle_CMDhandler)
B738CMD_door_aft_R_toggle		= create_command("laminar/B738/door/aft_R_toggle", "Door AFT Service toggle", B738_door_aft_R_toggle_CMDhandler)
B738CMD_door_fwd_cargo_toggle	= create_command("laminar/B738/door/fwd_cargo_toggle", "Door FWD cargo toggle", B738_door_fwd_cargo_toggle_CMDhandler)
B738CMD_door_aft_cargo_toggle	= create_command("laminar/B738/door/aft_cargo_toggle", "Door AFT cargo toggle", B738_door_aft_cargo_toggle_CMDhandler)

B738CMD_door_emerg1_toggle		= create_command("laminar/B738/door/emerg1_toggle", "Door Right AFT Overwing toggle", B738_door_emerg1_toggle_CMDhandler)
B738CMD_door_emerg2_toggle		= create_command("laminar/B738/door/emerg2_toggle", "Door Right FWD Overwing toggle", B738_door_emerg2_toggle_CMDhandler)
B738CMD_door_emerg3_toggle		= create_command("laminar/B738/door/emerg3_toggle", "Door Left AFT Overwing toggle", B738_door_emerg3_toggle_CMDhandler)
B738CMD_door_emerg4_toggle		= create_command("laminar/B738/door/emerg4_toggle", "Door Left FWD Overwing toggle", B738_door_emerg4_toggle_CMDhandler)
B738CMD_door_emerg5_toggle		= create_command("laminar/B738/door/L_mid_exit_toggle", "Door Left MID Exit toggle", B738_door_emerg5_toggle_CMDhandler)
B738CMD_door_emerg6_toggle		= create_command("laminar/B738/door/R_mid_exit_toggle", "Door Right MID Exit toggle", B738_door_emerg6_toggle_CMDhandler)

B738CMD_door_aft1_toggle		= create_command("laminar/B738/door/aft1_toggle", "Door AFT 1", B738_door_aft1_toggle_CMDhandler)
B738CMD_door_aft2_toggle		= create_command("laminar/B738/door/aft2_toggle", "Door AFT 2", B738_door_aft2_toggle_CMDhandler)

B738CMD_airstairs_toggle		= create_command("laminar/B738/airstairs_toggle", "Airstairs toggle", B738_airstairs_toggle_CMDhandler)
B738CMD_airstairs_ext_toggle	= create_command("laminar/B738/airstairs_ext_toggle", "Airstairs external toggle", B738_airstairs_ext_toggle_CMDhandler)
B738CMD_hud_toggle			= create_command("laminar/B738/hud/hud_toggle", "Stow HUD toggle", B738_hud_toggle_CMDhandler)

B738CMD_gpu_toggle			= create_command("laminar/B738/gpu_toggle", "GPU toggle", B738_gpu_toggle_CMDhandler)
B738CMD_asu_toggle			= create_command("laminar/B738/asu_toggle", "ASU toggle", B738_asu_toggle_CMDhandler)
B738CMD_deice_toggle		= create_command("laminar/B738/deice_truck_toggle", "De-ice truck toggle", B738_deice_toggle_CMDhandler)
B738CMD_fueltruck_toggle	= create_command("laminar/B738/fuel_truck_toggle", "Fuel truck toggle", B738_fueltruck_toggle_CMDhandler)

B738CMD_load_flight_1		= create_command("laminar/B738/tab/load_flight1", "Load flight 1", B738_load_flight_1_CMDhandler)
B738CMD_load_flight_2		= create_command("laminar/B738/tab/load_flight2", "Load flight 2", B738_load_flight_2_CMDhandler)
B738CMD_load_flight_3		= create_command("laminar/B738/tab/load_flight3", "Load flight 3", B738_load_flight_3_CMDhandler)
B738CMD_load_flight_4		= create_command("laminar/B738/tab/load_flight4", "Load flight 4", B738_load_flight_4_CMDhandler)
B738CMD_load_flight_5		= create_command("laminar/B738/tab/load_flight5", "Load flight 5", B738_load_flight_5_CMDhandler)
B738CMD_load_flight_6		= create_command("laminar/B738/tab/load_flight6", "Load flight 6", B738_load_flight_6_CMDhandler)
B738CMD_load_flight_7		= create_command("laminar/B738/tab/load_flight7", "Load flight 7", B738_load_flight_7_CMDhandler)
B738CMD_load_flight_8		= create_command("laminar/B738/tab/load_flight8", "Load flight 8", B738_load_flight_8_CMDhandler)

B738CMD_save_flight_1		= create_command("laminar/B738/tab/save_flight1", "Save flight 1", B738_save_flight_1_CMDhandler)
B738CMD_save_flight_2		= create_command("laminar/B738/tab/save_flight2", "Save flight 2", B738_save_flight_2_CMDhandler)
B738CMD_save_flight_3		= create_command("laminar/B738/tab/save_flight3", "Save flight 3", B738_save_flight_3_CMDhandler)
B738CMD_save_flight_4		= create_command("laminar/B738/tab/save_flight4", "Save flight 4", B738_save_flight_4_CMDhandler)
B738CMD_save_flight_5		= create_command("laminar/B738/tab/save_flight5", "Save flight 5", B738_save_flight_5_CMDhandler)
B738CMD_save_flight_6		= create_command("laminar/B738/tab/save_flight6", "Save flight 6", B738_save_flight_6_CMDhandler)
B738CMD_save_flight_7		= create_command("laminar/B738/tab/save_flight7", "Save flight 7", B738_save_flight_7_CMDhandler)
B738CMD_save_flight_8		= create_command("laminar/B738/tab/save_flight8", "Save flight 8", B738_save_flight_8_CMDhandler)

-- --*************************************************************************************--
-- --** 				             X-PLANE COMMAND HANDLERS               	    	 **--
-- --*************************************************************************************--

-- Doors commands open
function B738_door_fwd_L_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_fwd_L_trg = 1
		end
	end
end

function B738_door_fwd_R_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_fwd_R_trg = 1
		end
	end
end

function B738_door_aft_L_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_aft_L_trg = 1
		end
	end
end

function B738_door_aft_R_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_aft_R_trg = 1
		end
	end
end

function B738_door_aft_cargo_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_aft_cargo_trg = 1
		end
	end
end

function B738_door_fwd_cargo_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_fwd_cargo_trg = 1
		end
	end
end

-- Doors commands close
function B738_door_fwd_L_close_CMDhandler(phase, duration)
	if phase == 0 then
		if B738DR_hide_airstairs == 1 or B738DR_not_airstairs == 1 then
			door_ratio_fwd_L_trg = 0
		end
	end
end

function B738_door_fwd_R_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_fwd_R_trg = 0
	end
end

function B738_door_aft_L_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_aft_L_trg = 0
	end
end

function B738_door_aft_R_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_aft_R_trg = 0
	end
end

function B738_door_aft_cargo_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_aft_cargo_trg = 0
	end
end

function B738_door_fwd_cargo_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_fwd_cargo_trg = 0
	end
end

-- Emergency door
function B738_door_emerg1_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg1_trg = 1
		end
	end
end

function B738_door_emerg2_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg2_trg = 1
		end
	end
end

function B738_door_emerg3_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg3_trg = 1
		end
	end
end

function B738_door_emerg4_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg4_trg = 1
		end
	end
end

function B738_door_emerg5_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg5_trg = 1
		end
	end
end

function B738_door_emerg6_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if emerg_door_locked == 0 then
			door_ratio_emerg6_trg = 1
		end
	end
end

function B738_door_aft1_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_aft1_trg = 1
		end
	end
end

function B738_door_aft2_open_CMDhandler(phase, duration)
	if phase == 0 then
		-- if is_command_cabindoor_closed == 0 then
		if door_locked == 0 then
			door_ratio_aft2_trg = 1
		end
	end
end

function B738_door_emerg1_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg1_trg = 0
	end
end

function B738_door_emerg2_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg2_trg = 0
	end
end

function B738_door_emerg3_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg3_trg = 0
	end
end

function B738_door_emerg4_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg4_trg = 0
	end
end

function B738_door_emerg5_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg5_trg = 0
	end
end

function B738_door_emerg6_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_emerg6_trg = 0
	end
end

function B738_door_aft1_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_aft1_trg = 0
	end
end

function B738_door_aft2_close_CMDhandler(phase, duration)
	if phase == 0 then
		door_ratio_aft2_trg = 0
	end
end

-- --*************************************************************************************--
-- --** 				             REPLACE X-PLANE COMMANDS                  	    	 **--
-- --*************************************************************************************--

-- simCMD_door_open_1			= replace_command("sim/flight_controls/door_open_1", B738_door_fwd_L_open_CMDhandler)
-- simCMD_door_open_2			= replace_command("sim/flight_controls/door_open_2", B738_door_aft_L_open_CMDhandler)
-- simCMD_door_open_3			= replace_command("sim/flight_controls/door_open_3", B738_door_fwd_R_open_CMDhandler)
-- simCMD_door_open_4			= replace_command("sim/flight_controls/door_open_4", B738_door_aft_R_open_CMDhandler)
-- simCMD_door_open_5			= replace_command("sim/flight_controls/door_open_5", B738_door_fwd_cargo_open_CMDhandler)
-- simCMD_door_open_6			= replace_command("sim/flight_controls/door_open_6", B738_door_aft_cargo_open_CMDhandler)

-- simCMD_door_close_1			= replace_command("sim/flight_controls/door_close_1", B738_door_fwd_L_close_CMDhandler)
-- simCMD_door_close_2			= replace_command("sim/flight_controls/door_close_2", B738_door_aft_L_close_CMDhandler)
-- simCMD_door_close_3			= replace_command("sim/flight_controls/door_close_3", B738_door_fwd_R_close_CMDhandler)
-- simCMD_door_close_4			= replace_command("sim/flight_controls/door_close_4", B738_door_aft_R_close_CMDhandler)
-- simCMD_door_close_5			= replace_command("sim/flight_controls/door_close_5", B738_door_fwd_cargo_close_CMDhandler)
-- simCMD_door_close_6			= replace_command("sim/flight_controls/door_close_6", B738_door_aft_cargo_close_CMDhandler)

simCMD_door_open_1			= replace_command("sim/flight_controls/door_open_1", B738_door_fwd_L_open_CMDhandler)
simCMD_door_open_2			= replace_command("sim/flight_controls/door_open_4", B738_door_aft_L_open_CMDhandler)
simCMD_door_open_3			= replace_command("sim/flight_controls/door_open_5", B738_door_fwd_R_open_CMDhandler)
simCMD_door_open_4			= replace_command("sim/flight_controls/door_open_8", B738_door_aft_R_open_CMDhandler)
simCMD_door_open_5			= replace_command("sim/flight_controls/door_open_9", B738_door_fwd_cargo_open_CMDhandler)
simCMD_door_open_6			= replace_command("sim/flight_controls/door_open_10", B738_door_aft_cargo_open_CMDhandler)

simCMD_door_close_1			= replace_command("sim/flight_controls/door_close_1", B738_door_fwd_L_close_CMDhandler)
simCMD_door_close_2			= replace_command("sim/flight_controls/door_close_4", B738_door_aft_L_close_CMDhandler)
simCMD_door_close_3			= replace_command("sim/flight_controls/door_close_5", B738_door_fwd_R_close_CMDhandler)
simCMD_door_close_4			= replace_command("sim/flight_controls/door_close_8", B738_door_aft_R_close_CMDhandler)
simCMD_door_close_5			= replace_command("sim/flight_controls/door_close_9", B738_door_fwd_cargo_close_CMDhandler)
simCMD_door_close_6			= replace_command("sim/flight_controls/door_close_10", B738_door_aft_cargo_close_CMDhandler)

simCMD_door_open_emerg_1	= replace_command("sim/flight_controls/door_open_7", B738_door_emerg1_open_CMDhandler)
simCMD_door_open_emerg_2	= replace_command("sim/flight_controls/door_open_6", B738_door_emerg2_open_CMDhandler)
simCMD_door_open_emerg_3	= replace_command("sim/flight_controls/door_open_3", B738_door_emerg3_open_CMDhandler)
simCMD_door_open_emerg_4	= replace_command("sim/flight_controls/door_open_2", B738_door_emerg4_open_CMDhandler)

B738CMD_door_open_emerg_5	= create_command("laminar/B738/door/L_mid_exit_open", "Door Left MID Exit open", B738_door_emerg5_open_CMDhandler)
B738CMD_door_open_emerg_6	= create_command("laminar/B738/door/R_mid_exit_open", "Door Right MID Exit open", B738_door_emerg6_open_CMDhandler)

simCMD_door_close_emerg_1	= replace_command("sim/flight_controls/door_close_7", B738_door_emerg1_close_CMDhandler)
simCMD_door_close_emerg_2	= replace_command("sim/flight_controls/door_close_6", B738_door_emerg2_close_CMDhandler)
simCMD_door_close_emerg_3	= replace_command("sim/flight_controls/door_close_3", B738_door_emerg3_close_CMDhandler)
simCMD_door_close_emerg_4	= replace_command("sim/flight_controls/door_close_2", B738_door_emerg4_close_CMDhandler)

B738CMD_door_close_emerg_5	= create_command("laminar/B738/door/L_mid_exit_close", "Door Left MID Exit close", B738_door_emerg5_close_CMDhandler)
B738CMD_door_close_emerg_6	= create_command("laminar/B738/door/R_mid_exit_close", "Door Right MID Exit close", B738_door_emerg6_close_CMDhandler)

B738CMD_door_close_aft1			= create_command("laminar/B738/door/aft1_close", "Door Close AFT 1 close", B738_door_aft1_close_CMDhandler)
B738CMD_door_close_aft2			= create_command("laminar/B738/door/aft2_close", "Door Close AFT 2 close", B738_door_aft2_close_CMDhandler)
B738CMD_door_open_aft1			= create_command("laminar/B738/door/aft1_open", "Door Open AFT 1 open", B738_door_aft1_open_CMDhandler)
B738CMD_door_open_aft2			= create_command("laminar/B738/door/aft2_open", "Door Open AFT 2 open", B738_door_aft2_open_CMDhandler)

-- --*************************************************************************************--
-- --** 				              WRAP X-PLANE COMMANDS                  	    	 **--
-- --*************************************************************************************--



-- --*************************************************************************************--
-- --** 					           OBJECT CONSTRUCTORS         		        		 **--
-- --*************************************************************************************--



-- --*************************************************************************************--
-- --** 				                  CREATE OBJECTS              	     			 **--
-- --*************************************************************************************--



-- --*************************************************************************************--
-- --** 				                 SYSTEM FUNCTIONS           	    			 **--
-- --*************************************************************************************--

----- RESCALE FLOAT AND CLAMP TO OUTER LIMITS -------------------------------------------

-- function B738_rescale(in1, out1, in2, out2, x)
    -- if x < in1 then return out1 end
    -- if x > in2 then return out2 end
	-- if in1 == in2 then
		-- return out1
	-- else
		-- return out1 + (out2 - out1) * (x - in1) / (in2 - in1)
	-- end
-- end

function B738_rescale(res1_in, res1_out, res2_in, res2_out, res_x)
	local result = 0
	if res1_in <= res2_in then
		if (res_x < res1_in) then
			result = res1_out
		elseif (res_x > res2_in) then
			result = res2_out
		elseif (res2_in == res1_in) then
			result = res1_out
		else
			result = res1_out + (res2_out - res1_out) * (res_x - res1_in) / (res2_in - res1_in)
		end
	else
		if (res_x > res1_in) then
			result = res1_out
		elseif (res_x < res2_in) then
			result = res2_out
		elseif (res2_in == res1_in) then
			result = res1_out
		else
			result = res1_out + (res2_out - res1_out) * (res_x - res1_in) / (res2_in - res1_in)
		end
	end
	
	return result
end

function B738_set_anim_value(current_value, target, min, max, speed)
	
	local result = 0
	
    if target >= (max - 0.001) and current_value >= (max - 0.01) then
        return max
    elseif target <= (min + 0.001) and current_value <= (min + 0.01) then
        return min
    else
        if current_value == target then
			return target
		else
			result = current_value + ((target - current_value) * (speed * SIM_PERIOD))
			if target > current_value and result > target then
				result = target
			elseif target < current_value and result < target then
				result = target
			end
			return result
		end
    end

end

function B738_set_animation_rate(current_value3, target3, min, max, speed)
	local calc_result = 0
	local calc_speed = speed
	if calc_speed <= 0 then
		calc_speed = 1
	end
	if target3 >= (max - 0.001) and current_value3 >= (max - 0.01) then
        return max
    elseif target3 <= (min + 0.001) and current_value3 <= (min + 0.01) then
        return min
    elseif current_value3 > max then
		return max
    elseif current_value3 < min then
		return min
	elseif current_value3 < target3 then
		calc_result = current_value3 + (SIM_PERIOD / calc_speed)
		if calc_result > target3 then
			calc_result = target3
		end
		return calc_result
	elseif current_value3 > target3 then
		calc_result = current_value3 - (SIM_PERIOD / calc_speed)
		if calc_result < target3 then
			calc_result = target3
		end
		return calc_result
	else
		calc_result = target3
		return calc_result
	end
end

function Angle180(angle)
    return (angle + 180) % 360
end


function spaces_before(strings, max_num)
	local temp_strings = ""
	local num_strings = string.len(strings)
	local num1 = 0
	
	if num_strings > max_num then
		return string.sub(strings, 1, max_num)
	else
		if num_strings == max_num then
			return strings
		else
			temp_strings = strings
			for num1 = num_strings, max_num - 1 do
				temp_strings = " " .. temp_strings
			end
			return temp_strings
		end
	
	end
end

function spaces_after(strings, max_num)
	local temp_strings = ""
	local num_strings = string.len(strings)
	local num1 = 0
	
	if num_strings > max_num then
		return string.sub(strings, 1, max_num)
	else
		if num_strings == max_num then
			return strings
		else
			temp_strings = strings
			for num1 = num_strings, max_num - 1 do
				temp_strings = temp_strings .. " "
			end
			return temp_strings
		end
	
	end
end


function txt_trunc(txt_txt, txt_trunc2)
	
	local result_txt = txt_txt
	if string.len(txt_txt) > txt_trunc2 then
		result_txt = string.sub(txt_txt, 1, txt_trunc2)
	elseif string.len(txt_txt) == 0 then
		result_txt = " "
	end
	
	return result_txt
	
end

function num_pages(page_a, page_m)
	
	local result_txt = ""
	if page_a < 10 then
		if page_m < 10 then
			result_txt = "  " .. string.format("%1d",page_a) .. "/" .. string.format("%1d",page_m)
		else
			result_txt = " " .. string.format("%1d",page_a) .. "/" .. string.format("%2d",page_m)
		end
	else
		if page_m < 10 then
			result_txt = " " .. string.format("%2d",page_a) .. "/" .. string.format("%1d",page_m)
		else
			result_txt = string.format("%2d",page_a) .. "/" .. string.format("%2d",page_m)
		end
	end
	
	return result_txt
	
end

function page_door()
	line_c[0] =   "        DOOR STATUS/COMMANDS          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	local j = 0
	if page == 2 then
		j = 8
	end
	for i = 0, 7 do
		if door_item_hide[i + j] == 0 then
			B738DR_tab_menu_manip[i] = 1
		else
			B738DR_tab_menu_manip[i] = 0
		end
	end
	clr_line_manip()
	clr_perf_manip()
	
end

function page_home()
	line_c[0] =   "               MAIN MENU              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		if is_command_cabindoor_closed == 1 then
			B738DR_tab_menu_manip[2] = 0
		end
		clr_line_manip()
		clr_perf_manip()
	elseif page == 2 then
		-- for i = 0, 3 do
			-- B738DR_tab_menu_manip[i] = 1
		-- end
		-- for i = 4, 7 do
			-- B738DR_tab_menu_manip[i] = 0
		-- end
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 0
		end
		B738DR_tab_menu_manip[0] = 1
		B738DR_tab_menu_manip[3] = 1
		if B738DR_dev_tune ~= 0 then
			B738DR_tab_menu_manip[7] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function page_state_preset()
	line_c[0] =   "       SWITCHES STATE PRESETS         "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function cmd_state_presets(cmd)
	if cmd == 1 then
		-- reset CD
		B738DR_state_cmd2 = 20
	elseif cmd == 2 then
		-- reset TA
		B738DR_state_cmd2 = 21
	elseif cmd == 3 then
		-- load FL1
		B738DR_state_cmd3 = 2
		B738DR_state_cmd2 = 3
		B738DR_state_cmd = ""
	elseif cmd == 4 then
		-- load FL1
		B738DR_state_cmd3 = 3
		B738DR_state_cmd2 = 3
		B738DR_state_cmd = ""
	elseif cmd == 5 then
		-- save CD
		B738DR_state_cmd3 = 0
		B738DR_state_cmd2 = 4
		B738DR_state_cmd = ""
	elseif cmd == 6 then
		-- save TA
		B738DR_state_cmd3 = 1
		B738DR_state_cmd2 = 4
		B738DR_state_cmd = ""
	elseif cmd == 7 then
		-- save FL1
		B738DR_state_cmd3 = 2
		B738DR_state_cmd2 = 4
		B738DR_state_cmd = ""
	elseif cmd == 8 then
		-- save FL2
		B738DR_state_cmd3 = 3
		B738DR_state_cmd2 = 4
		B738DR_state_cmd = ""
	end
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	B738DR_tab_menu_mark[cmd-1] = 1
	run_after_time(menu_mark_timer, 0.4)
end

function page_load_save_flight()
	line_c[0] =   "          LOAD / SAVE FLIGHT          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function cmd_load_save_flight(cmd)
	if page == 1 then
		if cmd == 1 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 1
			B738DR_load_save = 2
		elseif cmd == 2 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 2
			B738DR_load_save = 2
		elseif cmd == 3 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 3
			B738DR_load_save = 2
		elseif cmd == 4 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 4
			B738DR_load_save = 2
		elseif cmd == 5 then
			B738DR_load_save2 = 1
			B738DR_load_save = 1
		elseif cmd == 6 then
			B738DR_load_save2 = 2
			B738DR_load_save = 1
		elseif cmd == 7 then
			B738DR_load_save2 = 3
			B738DR_load_save = 1
		elseif cmd == 8 then
			B738DR_load_save2 = 4
			B738DR_load_save = 1
		end
	else
		if cmd == 1 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 5
			B738DR_load_save = 2
		elseif cmd == 2 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 6
			B738DR_load_save = 2
		elseif cmd == 3 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 7
			B738DR_load_save = 2
		elseif cmd == 4 then
			loaded_flight = true
			mem_cat = CAT_LOAD_SAVE_FLIGHT
			mem_page = page
			mem_min_page = min_page
			mem_max_page = max_page
			B738DR_load_save2 = 8
			B738DR_load_save = 2
		elseif cmd == 5 then
			B738DR_load_save2 = 5
			B738DR_load_save = 1
		elseif cmd == 6 then
			B738DR_load_save2 = 6
			B738DR_load_save = 1
		elseif cmd == 7 then
			B738DR_load_save2 = 7
			B738DR_load_save = 1
		elseif cmd == 8 then
			B738DR_load_save2 = 8
			B738DR_load_save = 1
		end
	end
	-- clr_menu_mark()
	-- if is_timer_scheduled(menu_mark_timer) == true then
		-- stop_timer(menu_mark_timer)
	-- end
	-- B738DR_tab_menu_mark[cmd-1] = 1
	-- run_after_time(menu_mark_timer, 0.4)
end

function page_load_save()
	line_c[0] =   "               LOAD/SAVE              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		--B738DR_tab_menu_manip[3] = 0
		-- B738DR_tab_menu_manip[7] = 0
		clr_line_manip()
		clr_perf_manip()
	end
end

function cmd_load_save(cmd)
	local enable_mark = false
	if cmd == 1 then
		B738CMD_save_config:once()
		enable_mark = true
	elseif cmd == 5 then
		B738CMD_reset_cfg_audio:once()
		enable_mark = true
	elseif cmd == 6 then
		B738CMD_reset_cfg:once()
		enable_mark = true
	elseif cmd == 7 then
		--B738CMD_reset_audio:once()
		--load autosaved flight
		B738DR_autoload_on = 0
		display_update = 1
		B738DR_load_save = 2
		B738DR_load_save2 = 9
		-- enable_mark = false
	end
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	if enable_mark then
		B738DR_tab_menu_mark[cmd-1] = 1
		run_after_time(menu_mark_timer, 0.4)
	end
end

function page_cfg_presets()
	line_c[0] =   "       LOAD/SAVE CONFIG PRESETS       "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1	--1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function cmd_cfg_presets(cmd)
	if cmd == 1 then
		B738CMD_load_cfg1:once()
	elseif cmd == 2 then
		B738CMD_load_cfg2:once()
	elseif cmd == 3 then
		B738CMD_load_cfg3:once()
	elseif cmd == 4 then
		B738CMD_load_cfg4:once()
	elseif cmd == 5 then
		B738CMD_save_cfg1:once()
	elseif cmd == 6 then
		B738CMD_save_cfg2:once()
	elseif cmd == 7 then
		B738CMD_save_cfg3:once()
	elseif cmd == 8 then
		B738CMD_save_cfg4:once()
	end
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	B738DR_tab_menu_mark[cmd-1] = 1
	run_after_time(menu_mark_timer, 0.4)
end



function page_audio_presets()
	line_c[0] =   "       LOAD/SAVE AUDIO PRESETS        "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function cmd_audio_presets(cmd)
	if cmd == 1 then
		B738CMD_load_audio1:once()
	elseif cmd == 2 then
		B738CMD_load_audio2:once()
	elseif cmd == 3 then
		B738CMD_load_audio3:once()
	elseif cmd == 4 then
		B738CMD_load_audio4:once()
	elseif cmd == 5 then
		B738CMD_save_audio1:once()
	elseif cmd == 6 then
		B738CMD_save_audio2:once()
	elseif cmd == 7 then
		B738CMD_save_audio3:once()
	elseif cmd == 8 then
		B738CMD_save_audio4:once()
	end
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	B738DR_tab_menu_mark[cmd-1] = 1
	run_after_time(menu_mark_timer, 0.4)
end

function page_settings()
	line_c[0] =   "        SETTINGS AND FEATURES         "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function page_announc()
	line_c[0] =   "             ANNOUNCEMENTS            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 4 do
			B738DR_tab_menu_manip[i] = 1
		end
		for i = 5, 6 do
			B738DR_tab_menu_manip[i] = 0
		end
		B738DR_tab_menu_manip[7] = 1
		-- for i = 0, 7 do
			-- B738DR_tab_menu_manip[i] = 1
		-- end
		clr_line_manip()
		clr_perf_manip()
	end
end

function B738_failure_exit()
	if B738DR_failure_save ~= 0 then
		-- deactivate arrows, lines
		clr_line_manip()
		
		B738DR_tab_nav_manip = 0
		B738DR_tab_info_manip = 0
		B738DR_tab_nav2_manip = 0
		B738DR_tab_arrows_enable = 0
		
		-- activate button yes/no
		B738DR_tab_menu_manip[5] = 1
		B738DR_tab_menu_manip[6] = 1
	end
end

function read_failures(in_failure)
	el_failure_mem = {}
	hyd_failure_mem = {}
	sys_failure_mem = {}
	pressurisation_failure_mem = {}
	engine_failure_mem = {}
	for ii = 0, 69 do
		if in_failure == 0 then
			el_failure_mem[ii] = B738DR_el_failure[ii]
		elseif in_failure == 1 then
			hyd_failure_mem[ii] = B738DR_hyd_failure[ii]
		elseif in_failure == 2 then
			sys_failure_mem[ii] = B738DR_sys_failure[ii]
		elseif in_failure == 3 then
			pressurisation_failure_mem[ii] = B738DR_pressurisation_failure[ii]
		elseif in_failure == 4 then
			engine_failure_mem[ii] = B738DR_engine_failure[ii]
		end
		failure_changed[ii] = 0
	end
end

function write_failures(in_failure)
	for ii = 0, 69 do
		if in_failure == 0 then
			B738DR_el_failure[ii] = el_failure_mem[ii]
		elseif in_failure == 1 then
			B738DR_hyd_failure[ii] = hyd_failure_mem[ii]
		elseif in_failure == 2 then
			B738DR_sys_failure[ii] = sys_failure_mem[ii]
		elseif in_failure == 3 then
			B738DR_pressurisation_failure[ii] = pressurisation_failure_mem[ii]
		elseif in_failure == 4 then
			B738DR_engine_failure[ii] = engine_failure_mem[ii]
		end
	end
end

function page_failures()
	line_c[0] =   "               FAILURES               "
	line_s[0] = "                                " .. num_pages(page, max_page)
	-- for i = 0, 4 do
		-- B738DR_tab_menu_manip[i] = 1
	-- end
	-- B738DR_tab_menu_manip[2] = 0	-- sys fail
	-- for i = 5, 6 do
		-- B738DR_tab_menu_manip[i] = 0
	-- end
	-- B738DR_tab_menu_manip[7] = 1
	for i = 0, 7 do
		B738DR_tab_menu_manip[i] = 1
	end
	-- B738DR_tab_menu_manip[2] = 0	-- sys fail
	clr_line_manip()
	clr_perf_manip()
end

function page_fail_elec()
	line_c[0] =   "        ELECTRIC FAILURES             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	B738DR_tab_line_manip[0] = 1
	local j = (page - 1) * 9
	local k = 0
	for i = 1, 9 do
		k = j + i
		if k <= fail_elec_num then
			if fail_elec_tab2[k] >= 0 then
				line[i] = "  " .. fail_elec_tab1[k]
				if B738DR_el_failure[fail_elec_tab2[k]] == 1 and B738DR_rst_fail_available2 == 0 then
					line_a[i] = "                                 FAIL"
				elseif failure_changed[fail_elec_tab2[k]] ~= 0 then
					-- changed
					if el_failure_mem[fail_elec_tab2[k]] == 0 then
						line_s[i] = "                                   OK"
					elseif el_failure_mem[fail_elec_tab2[k]] == 1 then
						line_s[i] = "                                 FAIL"
					else
						line_s[i] = "                                 RAND"
					end
				else
					-- normal
					if el_failure_mem[fail_elec_tab2[k]] == 0 then
						line_g[i] = "                                   OK"
					elseif el_failure_mem[fail_elec_tab2[k]] == 1 then
						line_a[i] = "                                 FAIL"
					else
						line_g[i] = "                                 RAND"
					end
				end
				
				B738DR_tab_line_manip[i] = 1
			else
				line_a[i] = "  " .. fail_elec_tab1[k]
				B738DR_tab_line_manip[i] = 0
			end
		else
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_fail_elec(cmd)
	
	if cmd <= fail_elec_num then
		if fail_elec_tab2[cmd] >= 0 then
			if B738DR_el_failure[fail_elec_tab2[cmd]] ~= 1 or B738DR_rst_fail_available2 ~= 0 then
				if el_failure_mem[fail_elec_tab2[cmd]] == 0 then
					el_failure_mem[fail_elec_tab2[cmd]] = 1
				elseif el_failure_mem[fail_elec_tab2[cmd]] == 1 then
					el_failure_mem[fail_elec_tab2[cmd]] = 2
				else
					el_failure_mem[fail_elec_tab2[cmd]] = 0
				end
				failures_changed = 1
				failure_changed[fail_elec_tab2[cmd]] = 1
			end
		end
	end
end

function page_fail_hyd()
	line_c[0] =   "        HYDRAULIC FAILURES            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	B738DR_tab_line_manip[0] = 1
	local j = (page - 1) * 9
	local k = 0
	for i = 1, 9 do
		k = j + i
		if k <= fail_hyd_num then
			if fail_hyd_tab2[k] >= 0 then
				line[i] = "  " .. fail_hyd_tab1[k]
				if B738DR_hyd_failure[fail_hyd_tab2[k]] == 1 and B738DR_rst_fail_available2 == 0 then
					if fail_hyd_tab2[k] == 3 or fail_hyd_tab2[k] == 4 then
						line_a[i] = "                                 LEAK"
					else
						line_a[i] = "                                 FAIL"
					end
				elseif failure_changed[fail_hyd_tab2[k]] ~= 0 then
					-- changed
					if hyd_failure_mem[fail_hyd_tab2[k]] == 0 then
						line_s[i] = "                                   OK"
					elseif hyd_failure_mem[fail_hyd_tab2[k]] == 1 then
						if fail_hyd_tab2[k] == 3 or fail_hyd_tab2[k] == 4 then
							line_s[i] = "                                 LEAK"
						else
							line_s[i] = "                                 FAIL"
						end
					else
						line_s[i] = "                                 RAND"
					end
				else
					-- normal
					if hyd_failure_mem[fail_hyd_tab2[k]] == 0 then
						line_g[i] = "                                   OK"
					elseif hyd_failure_mem[fail_hyd_tab2[k]] == 1 then
						if fail_hyd_tab2[k] == 3 or fail_hyd_tab2[k] == 4 then
							line_a[i] = "                                 LEAK"
						else
							line_a[i] = "                                 FAIL"
						end
					else
						line_g[i] = "                                 RAND"
					end
				end
				
				B738DR_tab_line_manip[i] = 1
			else
				line_a[i] = "  " .. fail_hyd_tab1[k]
				B738DR_tab_line_manip[i] = 0
			end
		else
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_fail_hyd(cmd)
	
	if cmd <= fail_hyd_num then
		if fail_hyd_tab2[cmd] >= 0 then
			if B738DR_hyd_failure[fail_hyd_tab2[cmd]] ~= 1 or B738DR_rst_fail_available2 ~= 0 then
				if hyd_failure_mem[fail_hyd_tab2[cmd]] == 0 then
					hyd_failure_mem[fail_hyd_tab2[cmd]] = 1
				elseif hyd_failure_mem[fail_hyd_tab2[cmd]] == 1 then
					hyd_failure_mem[fail_hyd_tab2[cmd]] = 2
				else
					hyd_failure_mem[fail_hyd_tab2[cmd]] = 0
				end
				failures_changed = 1
				failure_changed[fail_hyd_tab2[cmd]] = 1
			end
		end
	end
end

function page_fail_sys()
	line_c[0] =   "         SYSTEM FAILURES              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	B738DR_tab_line_manip[0] = 1
	local j = (page - 1) * 9
	local k = 0
	for i = 1, 9 do
		k = j + i
		if k <= fail_sys_num then
			if fail_sys_tab2[k] >= 0 then
				line[i] = "  " .. fail_sys_tab1[k]
				if B738DR_sys_failure[fail_sys_tab2[k]] == 1 and B738DR_rst_fail_available2 == 0 then
					line_a[i] = "                                 FAIL"
				elseif failure_changed[fail_sys_tab2[k]] ~= 0 then
					-- changed
					if sys_failure_mem[fail_sys_tab2[k]] == 0 then
						line_s[i] = "                                   OK"
					elseif sys_failure_mem[fail_sys_tab2[k]] == 1 then
						line_s[i] = "                                 FAIL"
					else
						line_s[i] = "                                 RAND"
					end
				else
					-- normal
					if sys_failure_mem[fail_sys_tab2[k]] == 0 then
						line_g[i] = "                                   OK"
					elseif sys_failure_mem[fail_sys_tab2[k]] == 1 then
						line_a[i] = "                                 FAIL"
					else
						line_g[i] = "                                 RAND"
					end
				end
				
				B738DR_tab_line_manip[i] = 1
			else
				line_a[i] = "  " .. fail_sys_tab1[k]
				B738DR_tab_line_manip[i] = 0
			end
		else
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_fail_sys(cmd)
	
	if cmd <= fail_sys_num then
		if fail_sys_tab2[cmd] >= 0 then
			if B738DR_sys_failure[fail_sys_tab2[cmd]] ~= 1 or B738DR_rst_fail_available2 ~= 0 then
				if sys_failure_mem[fail_sys_tab2[cmd]] == 0 then
					sys_failure_mem[fail_sys_tab2[cmd]] = 1
				elseif sys_failure_mem[fail_sys_tab2[cmd]] == 1 then
					sys_failure_mem[fail_sys_tab2[cmd]] = 2
				else
					sys_failure_mem[fail_sys_tab2[cmd]] = 0
				end
				failures_changed = 1
				failure_changed[fail_sys_tab2[cmd]] = 1
			end
		end
	end
end

function page_fail_pressurisation()
	line_c[0] =   "       AIR SYSTEM FAILURES            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	B738DR_tab_line_manip[0] = 1
	local j = (page - 1) * 9
	local k = 0
	for i = 1, 9 do
		k = j + i
		if k <= fail_pressurisation_num then
			if fail_pressurisation_tab2[k] >= 0 then
				line[i] = "  " .. fail_pressurisation_tab1[k]
				if B738DR_pressurisation_failure[fail_pressurisation_tab2[k]] == 1 and B738DR_rst_fail_available2 == 0 then
					if fail_pressurisation_tab2[k] < 2 then
						line_a[i] = "                              DEPRESS"
					else
						line_a[i] = "                                 FAIL"
					end
				elseif failure_changed[fail_pressurisation_tab2[k]] ~= 0 then
					-- changed
					if pressurisation_failure_mem[fail_pressurisation_tab2[k]] == 0 then
						if fail_pressurisation_tab2[k] < 2 then
							line_s[i] = "                                 NONE"
						else
							line_s[i] = "                                   OK"
						end
					elseif pressurisation_failure_mem[fail_pressurisation_tab2[k]] == 1 then
						if fail_pressurisation_tab2[k] < 2 then
							line_s[i] = "                              DEPRESS"
						else
							line_s[i] = "                                 FAIL"
						end
					else
						line_s[i] = "                                 RAND"
					end
				else
					-- normal
					if pressurisation_failure_mem[fail_pressurisation_tab2[k]] == 0 then
						if fail_pressurisation_tab2[k] < 2 then
							line_g[i] = "                                 NONE"
						else
							line_g[i] = "                                   OK"
						end
					elseif pressurisation_failure_mem[fail_pressurisation_tab2[k]] == 1 then
						if fail_pressurisation_tab2[k] < 2 then
							line_a[i] = "                              DEPRESS"
						else
							line_a[i] = "                                 FAIL"
						end
					else
						line_g[i] = "                                 RAND"
					end
				end
				
				B738DR_tab_line_manip[i] = 1
			else
				line_a[i] = "  " .. fail_pressurisation_tab1[k]
				B738DR_tab_line_manip[i] = 0
			end
		else
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_fail_pressurisation(cmd)
	
	if cmd <= fail_pressurisation_num then
		if fail_pressurisation_tab2[cmd] >= 0 then
			if B738DR_pressurisation_failure[fail_pressurisation_tab2[cmd]] ~= 1 or B738DR_rst_fail_available2 ~= 0 then
				if pressurisation_failure_mem[fail_pressurisation_tab2[cmd]] == 0 then
					pressurisation_failure_mem[fail_pressurisation_tab2[cmd]] = 1
				elseif pressurisation_failure_mem[fail_pressurisation_tab2[cmd]] == 1 then
					pressurisation_failure_mem[fail_pressurisation_tab2[cmd]] = 2
				else
					pressurisation_failure_mem[fail_pressurisation_tab2[cmd]] = 0
				end
				failures_changed = 1
				failure_changed[fail_pressurisation_tab2[cmd]] = 1
			end
		end
	end
end

function page_fail_eng()
	line_c[0] =   "         ENGINES FAILURES             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	B738DR_tab_line_manip[0] = 1
	local j = (page - 1) * 9
	local k = 0
	for i = 1, 9 do
		k = j + i
		if k <= fail_eng_num then
			if fail_eng_tab2[k] >= 0 then
				line[i] = "  " .. fail_eng_tab1[k]
				if B738DR_engine_failure[fail_eng_tab2[k]] == 1 and B738DR_rst_fail_available2 == 0 then
					if fail_eng_tab2[k] <= 7 then
						line_a[i] = "                                  YES"
					elseif fail_eng_tab2[k] <= 11 then
						line_a[i] = "                                 FAIL"
					elseif fail_eng_tab2[k] <= 13 then
						line_a[i] = "                                 LEAK"
					elseif fail_eng_tab2[k] <= 28 then	--22
						line_a[i] = "                                 FAIL"
					end
				elseif failure_changed[fail_eng_tab2[k]] ~= 0 then
					-- changed
					if fail_eng_tab2[k] <= 7 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_s[i] = "                                   NO"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_s[i] = "                                  YES"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 2 then
							line_s[i] = "                                 RAND"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 3 then
							line_s[i] = "                             AT 65 KT"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 4 then
							line_s[i] = "                                AT V1"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 5 then
							line_s[i] = "                                AT V2"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 6 then
							line_s[i] = "                         AT 1000FT RA"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 7 then
							line_s[i] = "                           AT 10000FT"
						else
							line_s[i] = "                         AT GO-AROUND"
						end
					elseif fail_eng_tab2[k] <= 11 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_s[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_s[i] = "                                 FAIL"
						else
							line_s[i] = "                                 RAND"
						end
					elseif fail_eng_tab2[k] <= 13 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_s[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_s[i] = "                                 LEAK"
						else
							line_s[i] = "                                 RAND"
						end
					elseif fail_eng_tab2[k] <= 28 then	--22
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_s[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_s[i] = "                                 FAIL"
						else
							line_s[i] = "                                 RAND"
						end
					end
				else
					-- normal
					if fail_eng_tab2[k] <= 7 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_g[i] = "                                   NO"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_a[i] = "                                  YES"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 2 then
							line_g[i] = "                                 RAND"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 3 then
							line_g[i] = "                             AT 65 KT"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 4 then
							line_g[i] = "                                AT V1"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 5 then
							line_g[i] = "                                AT V2"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 6 then
							line_g[i] = "                         AT 1000FT RA"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 7 then
							line_g[i] = "                           AT 10000FT"
						else
							line_g[i] = "                         AT GO-AROUND"
						end
					elseif fail_eng_tab2[k] <= 11 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_g[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_a[i] = "                                 FAIL"
						else
							line_g[i] = "                                 RAND"
						end
					elseif fail_eng_tab2[k] <= 13 then
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_g[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_a[i] = "                                 LEAK"
						else
							line_g[i] = "                                 RAND"
						end
					elseif fail_eng_tab2[k] <= 28 then	--22
						if engine_failure_mem[fail_eng_tab2[k]] == 0 then
							line_g[i] = "                                   OK"
						elseif engine_failure_mem[fail_eng_tab2[k]] == 1 then
							line_a[i] = "                                 FAIL"
						else
							line_g[i] = "                                 RAND"
						end
					end
				end
				B738DR_tab_line_manip[i] = 1
			else
				line_a[i] = "  " .. fail_eng_tab1[k]
				B738DR_tab_line_manip[i] = 0
			end
		else
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_fail_eng(cmd)
	
	if cmd <= fail_eng_num then
		if fail_eng_tab2[cmd] >= 0 then
			if B738DR_engine_failure[fail_eng_tab2[cmd]] ~= 1 or B738DR_rst_fail_available2 ~= 0 then
				if fail_eng_tab2[cmd] <= 7 then
					if engine_failure_mem[fail_eng_tab2[cmd]] == 0 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 1
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 1 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 2
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 2 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 3
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 3 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 4
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 4 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 5
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 5 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 6
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 6 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 7
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 7 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 8
					else
						engine_failure_mem[fail_eng_tab2[cmd]] = 0
					end
				else
					if engine_failure_mem[fail_eng_tab2[cmd]] == 0 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 1
					elseif engine_failure_mem[fail_eng_tab2[cmd]] == 1 then
						engine_failure_mem[fail_eng_tab2[cmd]] = 2
					else
						engine_failure_mem[fail_eng_tab2[cmd]] = 0
					end
				end
				failures_changed = 1
				failure_changed[fail_eng_tab2[cmd]] = 1
			end
		end
	end
end

function page_dev_tune()
	line_c[0] =   "           DEV TUNE                   "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line_a[1] = " MAXIMUM DEFLECTION ANGLE            "
		line[2] = " AILERON 1 DOWN                   DEG"
		line_s[2] = "                            " .. string.format("%5.2f", B738DR_def_aileron1_dn)
		line[3] = " AILERON 1 UP                     DEG"
		line_s[3] = "                            " .. string.format("%5.2f", B738DR_def_aileron1_up)
		line[4] = " AILERON 2 DOWN                   DEG"
		line_s[4] = "                            " .. string.format("%5.2f", B738DR_def_aileron2_dn)
		line[5] = " AILERON 2 UP                     DEG"
		line_s[5] = "                            " .. string.format("%5.2f", B738DR_def_aileron2_up)
		line[6] = " ELEVATOR 1 DOWN                  DEG"
		line_s[6] = "                            " .. string.format("%5.2f", B738DR_def_elevator1_dn)
		line[7] = " ELEVATOR 1 UP                    DEG"
		line_s[7] = "                            " .. string.format("%5.2f", B738DR_def_elevator1_up)
		line[8] = " ELEVATOR 2 DOWN                  DEG"
		line_s[8] = "                            " .. string.format("%5.2f", B738DR_def_elevator2_dn)
		line[9] = " ELEVATOR 2 UP                    DEG"
		line_s[9] = "                            " .. string.format("%5.2f", B738DR_def_elevator2_up)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line_a[1] = " MAXIMUM DEFLECTION ANGLE            "
		line[2] = " RUDDER 1 LEFT                    DEG"
		line_s[2] = "                            " .. string.format("%5.2f", B738DR_def_rudder1_dn)
		line[3] = " RUDDER 1 RIGHT                   DEG"
		line_s[3] = "                            " .. string.format("%5.2f", B738DR_def_rudder1_up)
		line[4] = " RUDDER 2 LEFT                    DEG"
		line_s[4] = "                            " .. string.format("%5.2f", B738DR_def_rudder2_dn)
		line[5] = " RUDDER 2 RIGHT                   DEG"
		line_s[5] = "                            " .. string.format("%5.2f", B738DR_def_rudder2_up)
		line[6] = " SPOILER 1 ROLL                   DEG"
		line_s[6] = "                            " .. string.format("%5.2f", B738DR_def_spoiler1_roll)
		line[7] = " SPOILER 1 BRAKE                  DEG"
		line_s[7] = "                            " .. string.format("%5.2f", B738DR_def_spoiler1_brk)
		line[8] = " SPOILER 2 ROLL                   DEG"
		line_s[8] = "                            " .. string.format("%5.2f", B738DR_def_spoiler2_roll)
		line[9] = " SPOILER 2 BRAKE                  DEG"
		line_s[9] = "                            " .. string.format("%5.2f", B738DR_def_spoiler2_brk)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 3 then
		line_a[1] = " MAXIMUM DEFLECTION ANGLE            "
		line[2] = " GND SPOILER 1 FLIGHT             DEG"
		line_s[2] = "                            " .. string.format("%5.2f", B738DR_def_speedbrake1_flt)
		line[3] = " GND SPOILER 1 GROUND             DEG"
		line_s[3] = "                            " .. string.format("%5.2f", B738DR_def_speedbrake1_gnd)
		line[4] = " GND SPOILER 2 FLIGHT             DEG"
		line_s[4] = "                            " .. string.format("%5.2f", B738DR_def_speedbrake2_flt)
		line[5] = " GND SPOILER 2 GROUND             DEG"
		line_s[5] = "                            " .. string.format("%5.2f", B738DR_def_speedbrake2_gnd)
		line[6] = " STABILIZATOR DOWN                DEG"
		line_s[6] = "                            " .. string.format("%5.2f", B738DR_def_elevator_trim_dn)
		line[7] = " STABILIZATOR UP                  DEG"
		line_s[7] = "                            " .. string.format("%5.2f", B738DR_def_elevator_trim_up)
		line[8] = " ELEVATOR TAB DN BAL RATIO           "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_def_elevator1_tab_ratio)
		line[9] = " ELEVATOR TAB UP BAL RATIO           "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_def_elevator2_tab_ratio)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		-- for i = 8, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		
	elseif page == 4 then
		line_a[1] = " FLAPS DEFLECTION ANGLE              "
		line[2] = " FLAPS 1                          DEG"
		line_s[2] = "                            " .. string.format("%5.2f", B738DR_def_flap_1)
		line[3] = " FLAPS 2                          DEG"
		line_s[3] = "                            " .. string.format("%5.2f", B738DR_def_flap_2)
		line[4] = " FLAPS 5                          DEG"
		line_s[4] = "                            " .. string.format("%5.2f", B738DR_def_flap_5)
		line[5] = " FLAPS 10                         DEG"
		line_s[5] = "                            " .. string.format("%5.2f", B738DR_def_flap_10)
		line[6] = " FLAPS 15                         DEG"
		line_s[6] = "                            " .. string.format("%5.2f", B738DR_def_flap_15)
		line[7] = " FLAPS 25                         DEG"
		line_s[7] = "                            " .. string.format("%5.2f", B738DR_def_flap_25)
		line[8] = " FLAPS 30                         DEG"
		line_s[8] = "                            " .. string.format("%5.2f", B738DR_def_flap_30)
		line[9] = " FLAPS 40                         DEG"
		line_s[9] = "                            " .. string.format("%5.2f", B738DR_def_flap_40)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 5 then
		line[1] =    " FLAPS1 UP CL                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap_cl[0])
		line[2] =    " FLAPS1 1  CL                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap_cl[1])
		line[3] =    " FLAPS1 2  CL                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap_cl[2])
		line[4] =    " FLAPS1 5  CL                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap_cl[3])
		line[5] =    " FLAPS1 10 CL                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap_cl[4])
		line[6] =    " FLAPS1 15 CL                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap_cl[5])
		line[7] =    " FLAPS1 25 CL                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap_cl[6])
		line[8] =    " FLAPS1 30 CL                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap_cl[7])
		line[9] =    " FLAPS1 40 CL                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap_cl[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 6 then
		line[1] =    " FLAPS1 UP CD                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap_cd[0])
		line[2] =    " FLAPS1 1  CD                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap_cd[1])
		line[3] =    " FLAPS1 2  CD                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap_cd[2])
		line[4] =    " FLAPS1 5  CD                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap_cd[3])
		line[5] =    " FLAPS1 10 CD                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap_cd[4])
		line[6] =    " FLAPS1 15 CD                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap_cd[5])
		line[7] =    " FLAPS1 25 CD                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap_cd[6])
		line[8] =    " FLAPS1 30 CD                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap_cd[7])
		line[9] =    " FLAPS1 40 CD                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap_cd[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 7 then
		line[1] =    " FLAPS1 UP CM                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap_cm[0])
		line[2] =    " FLAPS1 1  CM                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap_cm[1])
		line[3] =    " FLAPS1 2  CM                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap_cm[2])
		line[4] =    " FLAPS1 5  CM                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap_cm[3])
		line[5] =    " FLAPS1 10 CM                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap_cm[4])
		line[6] =    " FLAPS1 15 CM                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap_cm[5])
		line[7] =    " FLAPS1 25 CM                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap_cm[6])
		line[8] =    " FLAPS1 30 CM                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap_cm[7])
		line[9] =    " FLAPS1 40 CM                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap_cm[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 8 then
		line[1] =    " FLAPS2 UP CL                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[0])
		line[2] =    " FLAPS2 1  CL                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[1])
		line[3] =    " FLAPS2 2  CL                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[2])
		line[4] =    " FLAPS2 5  CL                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[3])
		line[5] =    " FLAPS2 10 CL                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[4])
		line[6] =    " FLAPS2 15 CL                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[5])
		line[7] =    " FLAPS2 25 CL                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[6])
		line[8] =    " FLAPS2 30 CL                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[7])
		line[9] =    " FLAPS2 40 CL                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap2_cl[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 9 then
		line[1] =    " FLAPS2 UP CD                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[0])
		line[2] =    " FLAPS2 1  CD                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[1])
		line[3] =    " FLAPS2 2  CD                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[2])
		line[4] =    " FLAPS2 5  CD                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[3])
		line[5] =    " FLAPS2 10 CD                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[4])
		line[6] =    " FLAPS2 15 CD                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[5])
		line[7] =    " FLAPS2 25 CD                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[6])
		line[8] =    " FLAPS2 30 CD                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[7])
		line[9] =    " FLAPS2 40 CD                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap2_cd[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 10 then
		line[1] =    " FLAPS2 UP CM                        "
		line_s[1] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[0])
		line[2] =    " FLAPS2 1  CM                        "
		line_s[2] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[1])
		line[3] =    " FLAPS2 2  CM                        "
		line_s[3] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[2])
		line[4] =    " FLAPS2 5  CM                        "
		line_s[4] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[3])
		line[5] =    " FLAPS2 10 CM                        "
		line_s[5] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[4])
		line[6] =    " FLAPS2 15 CM                        "
		line_s[6] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[5])
		line[7] =    " FLAPS2 25 CM                        "
		line_s[7] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[6])
		line[8] =    " FLAPS2 30 CM                        "
		line_s[8] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[7])
		line[9] =    " FLAPS2 40 CM                        "
		line_s[9] = "                              " .. string.format("%7.4f", B738DR_flap2_cm[8])
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 11 then
		line_a[1] = " PHASE OUT                           "
		-- line[2] = " GND SPOILER 2   260/1.00 .. 280/0.35"
		-- line[2] = " AILERON 1       " .. string.format("%3d", B738DR_aileron1_spd1) .. "/" .. string.format("%4.2f", B738DR_aileron1_rat1)
		-- line[2] = line[2] .. " .. " .. string.format("%3d", B738DR_aileron1_spd2) .. "/" .. string.format("%4.2f", B738DR_aileron1_rat2)
		line[2] = " AILERON 1 LOW SPEED              KTS"
		line_s[2] = "                              " .. string.format("%3d", B738DR_aileron1_spd1)
		line[3] = " AILERON 1 HIGH SPEED             KTS"
		line_s[3] = "                              " .. string.format("%3d", B738DR_aileron1_spd2)
		line[4] = " AILERON 1 LOW RATIO                 "
		line_s[4] = "                             " .. string.format("%4.2f", B738DR_aileron1_rat1)
		line[5] = " AILERON 1 HIGH RATIO                "
		line_s[5] = "                             " .. string.format("%4.2f", B738DR_aileron1_rat2)
		line[6] = " AILERON 2 LOW SPEED              KTS"
		line_s[6] = "                              " .. string.format("%3d", B738DR_aileron2_spd1)
		line[7] = " AILERON 2 HIGH SPEED             KTS"
		line_s[7] = "                              " .. string.format("%3d", B738DR_aileron2_spd2)
		line[8] = " AILERON 2 LOW RATIO                 "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_aileron2_rat1)
		line[9] = " AILERON 2 HIGH RATIO                "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_aileron2_rat2)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 12 then
		line_a[1] = " PHASE OUT                           "
		line[2] = " ELEVATOR 1 LOW SPEED             KTS"
		line_s[2] = "                              " .. string.format("%3d", B738DR_elevator1_spd1)
		line[3] = " ELEVATOR 1 HIGH SPEED            KTS"
		line_s[3] = "                              " .. string.format("%3d", B738DR_elevator1_spd2)
		line[4] = " ELEVATOR 1 LOW RATIO                "
		line_s[4] = "                             " .. string.format("%4.2f", B738DR_elevator1_rat1)
		line[5] = " ELEVATOR 1 HIGH RATIO               "
		line_s[5] = "                             " .. string.format("%4.2f", B738DR_elevator1_rat2)
		line[6] = " ELEVATOR 2 LOW SPEED             KTS"
		line_s[6] = "                              " .. string.format("%3d", B738DR_elevator2_spd1)
		line[7] = " ELEVATOR 2 HIGH SPEED            KTS"
		line_s[7] = "                              " .. string.format("%3d", B738DR_elevator2_spd2)
		line[8] = " ELEVATOR 2 LOW RATIO                "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_elevator2_rat1)
		line[9] = " ELEVATOR 2 HIGH RATIO               "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_elevator2_rat2)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 13 then
		line_a[1] = " PHASE OUT                           "
		line[2] = " RUDDER 1 LOW SPEED               KTS"
		line_s[2] = "                              " .. string.format("%3d", B738DR_rudder1_spd1)
		line[3] = " RUDDER 1 HIGH SPEED              KTS"
		line_s[3] = "                              " .. string.format("%3d", B738DR_rudder1_spd2)
		line[4] = " RUDDER 1 LOW RATIO                  "
		line_s[4] = "                             " .. string.format("%4.2f", B738DR_rudder1_rat1)
		line[5] = " RUDDER 1 HIGH RATIO                 "
		line_s[5] = "                             " .. string.format("%4.2f", B738DR_rudder1_rat2)
		line[6] = " RUDDER 2 LOW SPEED               KTS"
		line_s[6] = "                              " .. string.format("%3d", B738DR_rudder2_spd1)
		line[7] = " RUDDER 2 HIGH SPEED              KTS"
		line_s[7] = "                              " .. string.format("%3d", B738DR_rudder2_spd2)
		line[8] = " RUDDER 2 LOW RATIO                  "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_rudder2_rat1)
		line[9] = " RUDDER 2 HIGH RATIO                 "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_rudder2_rat2)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 14 then
		line_a[1] = " PHASE OUT                           "
		line[2] = " SPOILER 1 LOW SPEED              KTS"
		line_s[2] = "                              " .. string.format("%3d", B738DR_spoiler1_spd1)
		line[3] = " SPOILER 1 HIGH SPEED             KTS"
		line_s[3] = "                              " .. string.format("%3d", B738DR_spoiler1_spd2)
		line[4] = " SPOILER 1 LOW RATIO                 "
		line_s[4] = "                             " .. string.format("%4.2f", B738DR_spoiler1_rat1)
		line[5] = " SPOILER 1 HIGH RATIO                "
		line_s[5] = "                             " .. string.format("%4.2f", B738DR_spoiler1_rat2)
		line[6] = " SPOILER 2 LOW SPEED              KTS"
		line_s[6] = "                              " .. string.format("%3d", B738DR_spoiler2_spd1)
		line[7] = " SPOILER 2 HIGH SPEED             KTS"
		line_s[7] = "                              " .. string.format("%3d", B738DR_spoiler2_spd2)
		line[8] = " SPOILER 2 LOW RATIO                 "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_spoiler2_rat1)
		line[9] = " SPOILER 2 HIGH RATIO                "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_spoiler2_rat2)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 15 then
		line_a[1] = " PHASE OUT                           "
		line[2] = " BRK SPOILER 1 LOW SPEED          KTS"
		line_s[2] = "                              " .. string.format("%3d", B738DR_brk_spoiler1_spd1)
		line[3] = " BRK SPOILER 1 HIGH SPEED         KTS"
		line_s[3] = "                              " .. string.format("%3d", B738DR_brk_spoiler1_spd2)
		line[4] = " BRK SPOILER 1 LOW RATIO             "
		line_s[4] = "                             " .. string.format("%4.2f", B738DR_brk_spoiler1_rat1)
		line[5] = " BRK SPOILER 1 HIGH RATIO            "
		line_s[5] = "                             " .. string.format("%4.2f", B738DR_brk_spoiler1_rat2)
		line[6] = " BRK SPOILER 2 LOW SPEED          KTS"
		line_s[6] = "                              " .. string.format("%3d", B738DR_brk_spoiler2_spd1)
		line[7] = " BRK SPOILER 2 HIGH SPEED         KTS"
		line_s[7] = "                              " .. string.format("%3d", B738DR_brk_spoiler2_spd2)
		line[8] = " BRK SPOILER 2 LOW RATIO             "
		line_s[8] = "                             " .. string.format("%4.2f", B738DR_brk_spoiler2_rat1)
		line[9] = " BRK SPOILER 2 HIGH RATIO            "
		line_s[9] = "                             " .. string.format("%4.2f", B738DR_brk_spoiler2_rat2)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 16 then
		-- line_a[1] = " YOKE INPUT CURVE                    "
		-- line[2] = " ROLL COEF 1                         "
		-- line_s[2] = "                               " .. string.format("%6.2f", B738DR_roll_input_coef_1)
		-- line[3] = " ROLL COEF 2                         "
		-- line_s[3] = "                               " .. string.format("%6.2f", B738DR_roll_input_coef_2)
		
		-- line[4] = " PITCH COEF 1                        "
		-- line_s[4] = "                               " .. string.format("%6.2f", B738DR_pitch_input_coef_1)
		-- line[5] = " PITCH COEF 2                        "
		-- line_s[5] = "                               " .. string.format("%6.2f", B738DR_pitch_input_coef_2)
		
		-- line[6] = " YAW COEF 1                          "
		-- line_s[6] = "                               " .. string.format("%6.2f", B738DR_yaw_input_coef_1)
		-- line[7] = " YAW COEF 2                          "
		-- line_s[7] = "                               " .. string.format("%6.2f", B738DR_yaw_input_coef_2)
		line_a[1] = " DEFLECTION TIME - RATE              "
		line[2] = " AILERONS   CTR TO FULL   SEC        "
		line_s[2] = "                               " .. string.format("%6.2f", B738DR_def_aileron_rate)
		line[3] = " ELEVATORS  CTR TO FULL   SEC        "
		line_s[3] = "                               " .. string.format("%6.2f", B738DR_def_elevator_rate)
		line[4] = " RUDDER     CTR TO FULL   SEC        "
		line_s[4] = "                               " .. string.format("%6.2f", B738DR_def_rudder_rate)
		line[5] = " SPOILERS   DN TO UP      SEC        "
		line_s[5] = "                               " .. string.format("%6.2f", B738DR_def_spoiler_rate)
		line[6] = " SPD BRAKES DN TO UP      SEC        "
		line_s[6] = "                               " .. string.format("%6.2f", B738DR_def_brakes_rate)
		line[7] = " AILERONS WITH FLAPS EXT  SEC        "
		line_s[7] = "                               " .. string.format("%6.2f", B738DR_def_aileron_flaps_rate)
		line[8] = " SPOILERS WITH FLAPS EXT  SEC        "
		line_s[8] = "                               " .. string.format("%6.2f", B738DR_def_spoiler_flaps_rate)
		-- line_a[8] = " ------------------------------------"
		line[9] = " CURRENT STABILIZATOR UNITS:         "
		line_s[9] = "                                " .. string.format("%5.2f", B738DR_stab_trim_units)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		
	elseif page == 17 then
		line_a[1] = " FLIGHT IDLE THROTTLE COEFFICIENT    "
		line[2] = "     0 FT                            "
		line_s[2] = "                               " .. string.format("%6.4f", B738DR_flt_idle_thr1)
		line[3] = " 10000 FT                            "
		line_s[3] = "                               " .. string.format("%6.4f", B738DR_flt_idle_thr2)
		line[4] = " 15000 FT                            "
		line_s[4] = "                               " .. string.format("%6.4f", B738DR_flt_idle_sigma2)
		line[5] = " 20000 FT                            "
		line_s[5] = "                               " .. string.format("%6.4f", B738DR_flt_idle_thr3)
		line[6] = " 25000 FT                            "
		line_s[6] = "                               " .. string.format("%6.4f", B738DR_flt_idle_sigma3)
		line[7] = " 30000 FT                            "
		line_s[7] = "                               " .. string.format("%6.4f", B738DR_flt_idle_thr4)
		line[8] = " 35000 FT                            "
		line_s[8] = "                               " .. string.format("%6.4f", B738DR_flt_idle_sigma4)
		line[9] = " 40000 FT                            "
		line_s[9] = "                               " .. string.format("%6.4f", B738DR_flt_idle_thr5)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		B738DR_tab_line_manip[1] = 0
		
	elseif page == 18 then
		-- line_a[1] = " APPROACH IDLE THROTTLE COEFFICIENT  "
		-- line[2] = "     0 FT                            "
		-- line_s[2] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr1)
		-- line[3] = " 10000 FT                            "
		-- line_s[3] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr2)
		-- line[4] = " 20000 FT                            "
		-- line_s[4] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr3)
		-- line[5] = " 30000 FT                            "
		-- line_s[5] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr4)
		-- line[6] = " 40000 FT                            "
		-- line_s[6] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr5)
		-- line[7] = " FUSELAGE CD                         "
		-- line_s[7] = "                               " .. string.format("%6.4f", B738DR_curve02_coef6)
		-- line[8] = " ENGINE FAN DRAG RATIO               "
		-- line_s[8] = "                               " .. string.format("%6.4f", B738DR_eng_fan_drag_ratio)
		-- line[9] = " ENGINE LOW MACH REDUCTION           "
		-- line_s[9] = "                               " .. string.format("%6.4f", B738DR_idle_mach_reduction)
		
		line_a[1] = " OTHER PARAMETERS                    "
		line[2] = " FUSELAGE CD                         "
		line_s[2] = "                               " .. string.format("%6.4f", B738DR_curve02_coef6)
		line[3] = " MACH TRIM SYSTEM RATIO              "
		line_s[3] = "                               " .. string.format("%6.4f", B738DR_mach_trim_ratio)
		line[4] = " MACH TRIM SYSTEM SPD LOW            "
		line_s[4] = "                               " .. string.format("%6.4f", B738DR_mach_trim_spd1)
		line[5] = " MACH TRIM SYSTEM SPD HIGH           "
		line_s[5] = "                               " .. string.format("%6.4f", B738DR_mach_trim_spd2)
		line[6] = " YAW STABILIZATION RATIO             "
		line_s[6] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr1)
		-- line[7] = " BOOST ELEV AT 0FT AGL RATIO         "
		-- line_s[7] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr2)
		line[7] = " FORCE DOWN ON GROUND RATIO          "
		line_s[7] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr2)
		line[8] = " MAX ANGLE ELEV AT 0.61M RATIO       "
		line_s[8] = "                               " .. string.format("%6.4f", B738DR_app_idle_thr3)
		
		-- enable/disable manip
		for i = 0, 8 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
		-- B738DR_tab_line_manip[8] = 1
		-- B738DR_tab_line_manip[9] = 1
	
	elseif page == 19 then
		line_a[1] = " ENGINE PARAMETERS                   "
		line[2] = " STATIC THRUST                       "
		line_s[2] = "                                " .. string.format("%5d", B738DR_static_thrust)
		line[3] = " BYPASS                              "
		line_s[3] = "                               " .. string.format("%6.4f", B738DR_bypass)
		line[4] = " INLET                               "
		line_s[4] = "                               " .. string.format("%6.4f", B738DR_inlet)
		line[5] = " SCHOCK MACH                         "
		line_s[5] = "                               " .. string.format("%6.4f", B738DR_shock_mach)
		line[6] = " CURVE COEF 1                        "
		line_s[6] = "                               " .. string.format("%6.4f", B738DR_curve02_coef1)
		line[7] = " CURVE COEF 2                        "
		line_s[7] = "                               " .. string.format("%6.4f", B738DR_curve02_coef2)
		line[8] = " CURVE COEF 3                        "
		line_s[8] = "                               " .. string.format("%6.4f", B738DR_curve02_coef3)
		line[9] = " CURVE COEF 4                        "
		line_s[9] = "                               " .. string.format("%6.4f", B738DR_curve02_coef4)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 20 then
		line_a[1] = " ENGINE PARAMETERS                   "
		line[2] = " GROUND IDLE SFC  KG/HRS/N           "
		line_s[2] = "                             " .. string.format("%8.6f", B738DR_idle_sfc)
		line[3] = " SFC              KG/HRS/N           "
		line_s[3] = "                             " .. string.format("%8.6f", B738DR_sfc)
		line[4] = " SFC COEF                            "
		line_s[4] = "                             " .. string.format("%8.6f", B738DR_sfc_coef)
		line[5] = " ENGINE TYPE                         "
		line_s[5] = "                                " .. string.format("%5d", B738DR_curve02_type)
		line_a[6] = " ------------------------------------"
		line[7] = " FUEL FLOW  LB/HRS                     "
		line_s[7] = "                          " .. string.format("%5d", simDR_ff[0] * 7936.64144) .. "/" .. string.format("%5d", simDR_ff[1] * 7936.64144)
		line[8] = " ALL ENGINES THRUST   LB             "
		line_s[8] = "                                " .. string.format("%5d", -simDR_engine_thr / 4.44822162)
		line[9] = " HALF ENGINES THRUST  LB             "
		line_s[9] = "                                " .. string.format("%5d", -simDR_engine_thr / 4.44822162 * 0.5)
		
		-- enable/disable manip
		for i = 0, 5 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 6, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	
	elseif page == 21 then
		line_a[1] = " DAMPING PARAMETERS                  "
		line[2] = " ROLL DAMPING IN NM                  "
		line_s[2] = "                                " .. string.format("%5d", B738DR_roll_dmp)
		line[3] = " PITCH DAMPING IN MN                 "
		line_s[3] = "                                " .. string.format("%5d", B738DR_pitch_dmp)
		line[4] = " YAW DAMPING IN NM                   "
		line_s[4] = "                                " .. string.format("%5d", B738DR_yaw_dmp)
		
		-- enable/disable manip
		for i = 0, 4 do
			B738DR_tab_line_manip[i] = 1
		end
		
		B738DR_tab_line_manip[1] = 0
		for i = 5, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	
	elseif page == 22 then
		line_s[1] = "  ELEVATION: " .. string.format("%5d", B738DR_fms_test4) .. " FT"
		line_s[2] = "  MACH: " .. string.format("%3.1f", B738DR_fms_test5) .. "M"
		line_g[7] = "                             N1:" .. string.format("%3d", B738DR_fms_test6) .. "%"
		line_g[8] = "                            THR:" .. string.format("%5d", B738DR_fms_test7)
		line_g[9] = "                        NET THR:" .. string.format("%5d", B738DR_fms_test8)
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		for i = 1, 2 do
			B738DR_tab_line_manip[i] = 1
		end
	elseif page == 23 then
		line_s[1] = "  ELEVATION: " .. string.format("%5d", B738DR_fms_test4) .. " FT"
		line_s[2] = "  N1: " .. string.format("%3d", B738DR_fms_test3) .. "%"
		line_g[7] = "                           MACH:" .. string.format("%4.2f", B738DR_fms_test6) .. "M"
		line_g[8] = "                            THR:" .. string.format("%5d", B738DR_fms_test7)
		line_g[9] = "                        NET THR:" .. string.format("%5d", B738DR_fms_test8)
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		for i = 1, 2 do
			B738DR_tab_line_manip[i] = 1
		end
	elseif page == 24 then
		line_s[1] = "  ELEVATION: " .. string.format("%5d", B738DR_fms_test4) .. " FT"
		line_s[2] = "  N1: " .. string.format("%3d", B738DR_fms_test3) .. "%"
		line_g[7] = "                           MACH:" .. string.format("%4.2f", B738DR_fms_test6) .. "M"
		line_g[8] = "                            THR:" .. string.format("%5d", B738DR_fms_test7)
		line_g[9] = "                        NET THR:" .. string.format("%5d", B738DR_fms_test8)
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		for i = 1, 2 do
			B738DR_tab_line_manip[i] = 1
		end
	elseif page == 25 then
		-- line_s[1] = "  ELEVATION: " .. string.format("%5d", B738DR_fms_test4) .. " FT"
		-- line_s[2] = "  N1: " .. string.format("%3d", B738DR_fms_test3) .. "%"
		line_s[1] = "  MAX NET THRUST VS MACH BY ELEVATION"
		line_s[2] = "  ELEVATION: " .. string.format("%5d", B738DR_fms_test4) .. " FT"
		line_g[7] = "                           MACH:" .. string.format("%4.2f", B738DR_fms_test6) .. "M"
		line_g[8] = "                            THR:" .. string.format("%5d", B738DR_fms_test7)
		line_g[9] = "                        NET THR:" .. string.format("%5d", B738DR_fms_test8)
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		-- for i = 1, 2 do
			-- B738DR_tab_line_manip[i] = 1
		-- end
		B738DR_tab_line_manip[2] = 1
	end
end

function cmd_dev_tune(cmd)
	-- if cmd >= 1 and cmd <= 180 then
	if cmd >= 1 and cmd <= 189 then
		numpad_ref = 900 + cmd
		activate_numpad()
	-- elseif cmd == 181 or cmd == 190 or cmd == 199 or cmd == 209 then
	elseif cmd == 190 or cmd == 199 or cmd == 208 or cmd == 218 then
		if B738DR_fms_test4 == 0 then
			B738DR_fms_test4 = 10000
		elseif B738DR_fms_test4 == 10000 then
			B738DR_fms_test4 = 20000
		elseif B738DR_fms_test4 == 20000 then
			B738DR_fms_test4 = 30000
		elseif B738DR_fms_test4 == 30000 then
			B738DR_fms_test4 = 40000
		else
			B738DR_fms_test4 = 0
		end
	elseif cmd == 191 then	--182
		if B738DR_fms_test5 == 0 then
			B738DR_fms_test5 = 0.1
		elseif B738DR_fms_test5 == 0.1 then
			B738DR_fms_test5 = 0.2
		elseif B738DR_fms_test5 == 0.2 then
			B738DR_fms_test5 = 0.3
		elseif B738DR_fms_test5 == 0.3 then
			B738DR_fms_test5 = 0.4
		elseif B738DR_fms_test5 == 0.4 then
			B738DR_fms_test5 = 0.5
		elseif B738DR_fms_test5 == 0.5 then
			B738DR_fms_test5 = 0.6
		elseif B738DR_fms_test5 == 0.6 then
			B738DR_fms_test5 = 0.7
		elseif B738DR_fms_test5 == 0.7 then
			B738DR_fms_test5 = 0.8
		elseif B738DR_fms_test5 == 0.8 then
			B738DR_fms_test5 = 0.9
		else
			B738DR_fms_test5 = 0
		end
	elseif cmd == 200 or cmd == 209 then	--191 200
		if B738DR_fms_test3 == 0 then
			B738DR_fms_test3 = 10
		elseif B738DR_fms_test3 == 10 then
			B738DR_fms_test3 = 20
		elseif B738DR_fms_test3 == 20 then
			B738DR_fms_test3 = 25
		elseif B738DR_fms_test3 == 25 then
			B738DR_fms_test3 = 30
		elseif B738DR_fms_test3 == 30 then
			B738DR_fms_test3 = 35
		elseif B738DR_fms_test3 == 35 then
			B738DR_fms_test3 = 40
		elseif B738DR_fms_test3 == 40 then
			B738DR_fms_test3 = 45
		elseif B738DR_fms_test3 == 45 then
			B738DR_fms_test3 = 50
		elseif B738DR_fms_test3 == 50 then
			B738DR_fms_test3 = 55
		elseif B738DR_fms_test3 == 55 then
			B738DR_fms_test3 = 60
		elseif B738DR_fms_test3 == 60 then
			B738DR_fms_test3 = 65
		elseif B738DR_fms_test3 == 65 then
			B738DR_fms_test3 = 70
		elseif B738DR_fms_test3 == 70 then
			B738DR_fms_test3 = 75
		elseif B738DR_fms_test3 == 75 then
			B738DR_fms_test3 = 80
		elseif B738DR_fms_test3 == 80 then
			B738DR_fms_test3 = 85
		elseif B738DR_fms_test3 == 85 then
			B738DR_fms_test3 = 90
		elseif B738DR_fms_test3 == 90 then
			B738DR_fms_test3 = 95
		elseif B738DR_fms_test3 == 95 then
			B738DR_fms_test3 = 100
		elseif B738DR_fms_test3 == 100 then
			B738DR_fms_test3 = 105
		else
			B738DR_fms_test3 = 0
		end
	end
end


function page_services()
	line_c[0] =   "         GROUND SERVICES              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	for i = 0, 7 do
		B738DR_tab_menu_manip[i] = 1
	end
	-- for i = 7, 7 do
		-- B738DR_tab_menu_manip[i] = 0
	-- end
	clr_line_manip()
	clr_perf_manip()
end


function cmd_services(cmd)
	if cmd == 1 then
		B738CMD_gpu_toggle:once()
	elseif cmd == 2 then
		B738CMD_chock_toggle:once()
	elseif cmd == 4 then
		B738CMD_asu_toggle:once()
	elseif cmd == 5 then
		B738CMD_deice_toggle:once()
	elseif cmd == 6 then
		if B738DR_use_ext_airstairs == 0 then
			B738CMD_airstairs_toggle:once()
		else
			B738CMD_airstairs_ext_toggle:once()
		end
	end
	
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	B738DR_tab_menu_mark[cmd-1] = 1
	run_after_time(menu_mark_timer, 0.4)
end

function page_bp()
	line_c[0] =   "         BETTER PUSHBACK              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	for i = 0, 4 do
		B738DR_tab_menu_manip[i] = 1
	end
	for i = 5, 7 do
		B738DR_tab_menu_manip[i] = 0
	end
	clr_line_manip()
	clr_perf_manip()
end

function cmd_bp(cmd)
	if bp_installed == 1 then
		if cmd == 1 then
			BP_CMD_start_planner:once()
		elseif cmd == 2 then
			BP_CMD_start:once()
		elseif cmd == 3 then
			BP_CMD_disconnect:once()
		elseif cmd == 4 then
			BP_CMD_reconnect:once()
		elseif cmd == 5 then
			BP_CMD_stop:once()
		end
		clr_menu_mark()
		if is_timer_scheduled(menu_mark_timer) == true then
			stop_timer(menu_mark_timer)
		end
		B738DR_tab_menu_mark[cmd-1] = 1
		run_after_time(menu_mark_timer, 0.4)
	end
end


function page_avitab()
	line_c[0] =   "               AVITAB                 "
	line_s[0] = "                                " .. num_pages(page, max_page)
	for i = 0, 3 do
		B738DR_tab_menu_manip[i] = 1
	end
	for i = 4, 7 do
		B738DR_tab_menu_manip[i] = 0
	end
	B738DR_tab_menu_manip[7] = 1
	clr_line_manip()
	clr_perf_manip()
end

function page_checklist()
	line_c[0] =   "               CHECKLIST              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	elseif page == 2 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	elseif page == 3 then
		for i = 0, 2 do
			B738DR_tab_menu_manip[i] = 1
		end
		for i = 3, 7 do
			B738DR_tab_menu_manip[i] = 0
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function page_optional()
	line_c[0] = "       DISPLAY AND VARIANTS           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	if page == 1 then
		for i = 0, 7 do
			B738DR_tab_menu_manip[i] = 1
		end
		clr_line_manip()
		clr_perf_manip()
	end
end

function page_option_exterier()
	
	line_c[0] = "       EXTERIOR                       "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	line[1] = "  WINGLETS             /       /  "
	if B738DR_b737_variant == 3 then
		line[1] = "  WINGLETS"
		line_g[1] = "                          NO WINGLETS"
	elseif B738DR_b737_variant == 4 then
		line[1] = "  WINGLETS                     /  "
		if B738DR_wings_variant == 0 then
			line_g[1] = "                        BLENDED      "
			line_s[1] = "                                SPLIT"
		else
			line_g[1] = "                                SPLIT"
			line_s[1] = "                        BLENDED      "
		end
	elseif B738DR_wings_variant == 0 then
		line_g[1] = "                        BLENDED      "
		line_s[1] = "                   NONE         SPLIT"
	elseif  B738DR_wings_variant == 1 then
		line_g[1] = "                                SPLIT"
		line_s[1] = "                   NONE BLENDED      "
	else
		line_g[1] = "                   NONE              "
		line_s[1] = "                        BLENDED SPLIT"
	end
	
	line[2] = "  AIRSTAIRS                      /"
	if B738DR_not_airstairs == 0 then
		line_g[2] = "                                  YES"
		line_s[2] = "                               NO    "
	else
		line_g[2] = "                               NO    "
		line_s[2] = "                                  YES"
	end
	
	if B738DR_b737_variant < 0 then
		line[3] = "  SAT COM            /     /    / "
		if B738DR_satcom_variant == 0 then
			line_g[3] = "                 NONE                "
			line_s[3] = "                      FRONT REAR BOTH"
		elseif B738DR_satcom_variant == 1 then
			line_g[3] = "                      FRONT          "
			line_s[3] = "                 NONE       REAR BOTH"
		elseif B738DR_satcom_variant == 2 then
			line_g[3] = "                            REAR     "
			line_s[3] = "                 NONE FRONT      BOTH"
		else
			line_g[3] = "                                 BOTH"
			line_s[3] = "                 NONE FRONT REAR     "
		end
	else
		if B738DR_b737_variant == 3 then
			line[3] = "  SAT COM                       /"
			if B738DR_satcom_variant == 2 then
				line_g[3] = "                                 REAR"
				line_s[3] = "                            NONE     "
			else
				line_g[3] = "                            NONE     "
				line_s[3] = "                                 REAR"
			end
		else
			line[3] = "  SAT COM           /    /     /"
			if B738DR_satcom_variant == 0 then
				line_g[3] = "                NONE                 "
				line_s[3] = "                     BOTH REAR1 REAR2"
			elseif B738DR_satcom_variant == 1 then
				line_g[3] = "                     BOTH            "
				line_s[3] = "                NONE      REAR1 REAR2"
			elseif B738DR_satcom_variant == 2 then
				line_g[3] = "                          REAR1      "
				line_s[3] = "                NONE BOTH       REAR2"
			else
				line_g[3] = "                                REAR2"
				line_s[3] = "                NONE BOTH REAR1      "
			end
		end
	end
	
	line[4] = "  LANDING LIGHTS                 /"
	if B738DR_b737_variant == 1 or B738DR_b737_variant == 3 then
		line[4] = "  LANDING LIGHTS"
		line_g[4] = "                              HALOGEN"
	elseif B738DR_led_lights == 0 then
		line_g[4] = "                          HALOGEN    "
		line_s[4] = "                                  LED"
	else
		line_g[4] = "                                  LED"
		line_s[4] = "                          HALOGEN    "
	end
	
	line[5] = "  LANDING PULSE LITE             /"
	if B738DR_pulse_lite == 0 then
		line_g[5] = "                               NO    "
		line_s[5] = "                                  YES"
	else
		line_g[5] = "                                  YES"
		line_s[5] = "                               NO    "
	end
	
	line[6] = "  LONG LED STROBES               /"
	if B738DR_long_led_strobes == 0 then
		line_g[6] = "                               NO    "
		line_s[6] = "                                  YES"
	else
		line_g[6] = "                                  YES"
		line_s[6] = "                               NO    "
	end
	
	-- enable/disable manip
	for i = 0, 6 do
		B738DR_tab_line_manip[i] = 1
	end
	for i = 7, 9 do
		B738DR_tab_line_manip[i] = 0
	end
	
	if B738DR_b737_variant >= 0 then
		
		if B738DR_b737_variant == 4 or B738DR_no_pip_kill ~= 0 then
			line[7] =   "  EYEBROWS                        "
			line_s[7] = "                        NOT AVAILABLE"
		else
			line[7] = "  EYEBROWS                       /"
			if B738DR_no_eyebrow_kill == 0 then
				line_g[7] = "                               NO    "
				line_s[7] = "                                  YES"
			else
				line_g[7] = "                                  YES"
				line_s[7] = "                               NO    "
			end
			B738DR_tab_line_manip[7] = 1
		end
		
		if B738DR_b737_variant ~= 1 and B738DR_b737_variant ~= 3 then
			if B738DR_wings_variant < 2 then
				line[8] = "  PIP                            /"
				if B738DR_no_pip_kill == 0 then
					line_g[8] = "                               NO    "
					line_s[8] = "                                  YES"
				else
					line_g[8] = "                                  YES"
					line_s[8] = "                               NO    "
				end
				B738DR_tab_line_manip[8] = 1
			else
				line[8] = "  PIP                             "
				line_s[8] = "                        NOT AVAILABLE"
			end
			
			if B738DR_b737_variant == 4 then
				line[9] = "  AFT DOOR                 /"
				if B738DR_no_aft_exit_kill == 0 then
					line_g[9] = "                   PLUGGED           "
					line_s[9] = "                            UNPLUGGED"
				else
					line_g[9] = "                            UNPLUGGED"
					line_s[9] = "                   PLUGGED           "
				end
				B738DR_tab_line_manip[9] = 1
			end
		end
	end
end

function cmd_option_exterior(cmd)
	if cmd == 1 and B738DR_b737_variant ~= 3 then
		if B738DR_wings_variant == 0 then
			B738DR_wings_variant = 1
		elseif B738DR_wings_variant == 1 then
			B738DR_wings_variant = 2
		else
			B738DR_wings_variant = 0
		end
		if B738DR_b737_variant == 4 then
			if B738DR_wings_variant > 1 then
				B738DR_wings_variant = 0
			end
		end
		if B738DR_wings_variant > 1 then
			if B738DR_no_pip_kill ~= 0 then
				B738DR_no_pip_kill = 0
				B738DR_pip_kill = 1
			end
		end
	elseif cmd == 2 then
		if B738DR_not_airstairs == 0 then
			B738DR_not_airstairs = 1
		else
			B738DR_not_airstairs = 0
		end
	elseif cmd == 3 then
		if B738DR_b737_variant == 3 then
			if B738DR_satcom_variant == 0 then
				B738DR_satcom_variant = 2
			else
				B738DR_satcom_variant = 0
			end
		else
			if B738DR_satcom_variant == 0 then
				B738DR_satcom_variant = 1
			elseif B738DR_satcom_variant == 1 then
				B738DR_satcom_variant = 2
			elseif B738DR_satcom_variant == 2 then
				B738DR_satcom_variant = 3
			else
				B738DR_satcom_variant = 0
			end
		end
	elseif cmd == 4 and B738DR_b737_variant ~= 1 and B738DR_b737_variant ~= 3 then
		if B738DR_led_lights == 0 then
			B738DR_led_lights = 1
		else
			B738DR_led_lights = 0
		end
	elseif cmd == 5 then
		if B738DR_pulse_lite == 0 then
			B738DR_pulse_lite = 1
		else
			B738DR_pulse_lite = 0
		end
	elseif cmd == 6 then
		if B738DR_long_led_strobes == 0 then
			B738DR_long_led_strobes = 1
		else
			B738DR_long_led_strobes = 0
		end
	else
		if B738DR_b737_variant >= 0 then
			if cmd == 7 then
				if B738DR_no_eyebrow_kill == 0 then
					B738DR_no_eyebrow_kill = 1
					B738DR_eyebrow_kill = 0
					B738DR_hud_disable = 1
				else
					B738DR_no_eyebrow_kill = 0
					B738DR_eyebrow_kill = 1
				end
			elseif cmd == 8 then
				if B738DR_no_pip_kill == 0 then
					B738DR_no_pip_kill = 1
					B738DR_pip_kill = 0
					B738DR_no_eyebrow_kill = 0
					B738DR_eyebrow_kill = 1
				else
					B738DR_no_pip_kill = 0
					B738DR_pip_kill = 1
				end
			elseif cmd == 9 and B738DR_b737_variant == 4 then
				if B738DR_no_aft_exit_kill == 0 then
					B738DR_no_aft_exit_kill = 1
					B738DR_aft_exit_kill = 0
				else
					B738DR_no_aft_exit_kill = 0
					B738DR_aft_exit_kill = 1
				end
			end
		end
	end
end

function page_option_systems()
	
	line_c[0] = "       SYSTEMS                        "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		if B738DR_b737_variant >= 0 and B738DR_no_eyebrow_kill ~= 0 then
			line[1] = "  HUD FOR CAPTAIN                 "
			line_s[1] = "                        NOT AVAILABLE"
		else
			line[1] = "  HUD FOR CAPTAIN                /"
			if B738DR_hud_disable == 0 then
				line_g[1] = "                                  YES"
				line_s[1] = "                               NO    "
			else
				line_g[1] = "                               NO    "
				line_s[1] = "                                  YES"
			end
		end
		
		line[2] = "  ASPIRATED TAT PROBE            /"
		if B738DR_aspirated_probe ~= 0 then
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		else
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		end
		
		line[3] = "  PROBE HEAT SWITCHES AUTO       /"
		if B738DR_probe_heat_auto == 0 then
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		else
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		end
		
		line[4] = "  ENGINE START SWITCHES AUTO     /"
		if B738DR_engine_start_auto == 0 then
			line_g[4] = "                               NO    "
			line_s[4] = "                                  YES"
		else
			line_g[4] = "                                  YES"
			line_s[4] = "                               NO    "
		end
		
		line[5] = "  RAAS                        /  /   "
		if B738DR_raas == 0 then
			line_g[5] = "                          AUTO       "
			line_s[5] = "                               ON OFF"
		elseif B738DR_raas == 1 then
			line_g[5] = "                               ON    "
			line_s[5] = "                          AUTO    OFF"
		else
			line_g[5] = "                                  OFF"
			line_s[5] = "                          AUTO ON    "
		end
		
		line[6] = "  MULTI MODE RECEIVER            /"
		if B738DR_mmr ~= 0 then
			line_g[6] = "                                  YES"
			line_s[6] = "                               NO    "
		else
			line_g[6] = "                               NO    "
			line_s[6] = "                                  YES"
		end
		
		line[7] = "  MMR BACKLIGHT                /     "
		if B738DR_mmr_colour == 0 then
			line_g[7] = "                         ORANGE      "
			line_s[7] = "                                WHITE"
		else
			line_g[7] = "                                WHITE"
			line_s[7] = "                         ORANGE      "
		end
		
		line[8] = "  COM RADIOS DECIMAL DIGITS        / "
		if B738DR_com_decimal == 0 then
			line_g[8] = "                                    3"
			line_s[8] = "                                  2  "
		else
			line_g[8] = "                                  2  "
			line_s[8] = "                                    3"
		end
		
		line[9] = "  SELCAL                          /"
		if B738DR_selcal_disable == 0 then
			line_g[9] = "                               YES   "
			line_s[9] = "                                   NO"
		else
			line_g[9] = "                                   NO"
			line_s[9] = "                               YES   "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		if B738DR_b737_variant >= 0 and B738DR_no_eyebrow_kill ~= 0 then
			B738DR_tab_line_manip[1] = 0
		end
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] = "  FLIGHTDECK CAM                  /"
		if B738DR_fd_cam_disable == 0 then
			line_g[1] = "                               YES   "
			line_s[1] = "                                   NO"
		else
			line_g[1] = "                                   NO"
			line_s[1] = "                               YES   "
		end
		
		line[2] = "  PRESSURISATION PANEL       /       "
		if B738DR_digital_press_panel == 0 then
			line_g[2] = "                       ANALOG        "
			line_s[2] = "                              DIGITAL"
		else
			line_g[2] = "                              DIGITAL"
			line_s[2] = "                       ANALOG        "
		end
		
		line[3] = "  ILS/GLS ANNUNCIATES             /"
		if B738DR_ils_gls_annun == 0 then
			line_g[3] = "                                   NO"
			line_s[3] = "                               YES   "
		else
			line_g[3] = "                               YES   "
			line_s[3] = "                                   NO"
		end
		
		line[4] = "  NO SMOKING           /          /  "
		if B738DR_no_smoking == 0 then
			line_g[4] = "                    YES              "
			line_s[4] = "                        CHIME ONLY NO"
		elseif B738DR_no_smoking == 1 then
			line_g[4] = "                        CHIME ONLY   "
			line_s[4] = "                    YES            NO"
		else
			line_g[4] = "                                   NO"
			line_s[4] = "                    YES CHIME ONLY   "
		end
		
		if B738DR_b737_variant < 0 then
			line[5] = "  VOICE RECORDER SWITCH           /"
			if B738DR_no_vcr_switch == 0 then
				line_g[5] = "                               YES   "
				line_s[5] = "                                   NO"
			else
				line_g[5] = "                                   NO"
				line_s[5] = "                               YES   "
			end
		else
			line[5] = "  VOICE RECORDER SWITCH            "
			line_s[5] = "                        NOT AVAILABLE"
		end
		
		-- if B738DR_b737_variant == 4 then
			-- line[6] = "  ANALOG STANDBY GAUGES            "
			-- line_g[6] = "                                   NO"
		-- else
			line[6] = "  ANALOG STANDBY GAUGES           /"
			if B738DR_isfd_rmi == 0 then
				line_g[6] = "                                   NO"
				line_s[6] = "                               YES   "
			else
				line_g[6] = "                               YES   "
				line_s[6] = "                                   NO"
			end
		-- end
		
		line[7] = "  YAW DAMPER GAUGE                /"
		if B738DR_yaw_damper == 0 then
			line_g[7] = "                                   NO"
			line_s[7] = "                               YES   "
		else
			line_g[7] = "                               YES   "
			line_s[7] = "                                   NO"
		end
		
		line[8] = "  MCP SPD INTV BUTTON             /"
		if B738DR_spd_intv_but == 0 then
			line_g[8] = "                                   NO"
			line_s[8] = "                               YES   "
		else
			line_g[8] = "                               YES   "
			line_s[8] = "                                   NO"
		end
		
		line[9] = "  MCP ALT INTV BUTTON             /"
		if B738DR_alt_intv_but == 0 then
			line_g[9] = "                                   NO"
			line_s[9] = "                               YES   "
		else
			line_g[9] = "                               YES   "
			line_s[9] = "                                   NO"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		if B738DR_b737_variant == 4 then
			B738DR_tab_line_manip[6] = 0
		end
		if B738DR_b737_variant >= 0 then
			B738DR_tab_line_manip[5] = 0
		end
		-- for i = 8, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 3 then
		line[1] = "  MCP PANEL                /         "
		if B738DR_old_mcp == 0 then
			line_g[1] = "                    COLLINS          "
			line_s[1] = "                            HONEYWELL"
		else
			line_g[1] = "                            HONEYWELL"
			line_s[1] = "                    COLLINS          "
		end
		
		line[2] = "  RMI                             /"
		if B738DR_rmi == 0 then
			line_g[2] = "                                   NO"
			line_s[2] = "                               YES   "
		else
			line_g[2] = "                               YES   "
			line_s[2] = "                                   NO"
		end
		
		line[3] = "  HIGH ALTITUDE LANDING           /"
		if B738DR_high_alt_ldg == 0 then
			line_g[3] = "                                   NO"
			line_s[3] = "                               YES   "
		else
			line_g[3] = "                               YES   "
			line_s[3] = "                                   NO"
		end
		
		if B738DR_b737_variant >= 0 then
			if B738DR_b737_variant == 1 or B738DR_b737_variant == 3 then
				line[4] =   "  FUEL CUTOFF                     "
				line_s[4] = "                               LEVERS"
				B738DR_tab_line_manip[4] = 0
			else
				line[4] =   "  FUEL CUTOFF               /     "
				if B738DR_fuel_cutoff_sw == 0 then
					line_g[4] = "                      LEVERS         "
					line_s[4] = "                             SWITCHES"
				else
					line_g[4] = "                             SWITCHES"
					line_s[4] = "                      LEVERS         "
				end
			end
		else
			line[4] =   "  FUEL CUTOFF               /     "
			if B738DR_fuel_cutoff_sw == 0 then
				line_g[4] = "                      LEVERS         "
				line_s[4] = "                             SWITCHES"
			else
				line_g[4] = "                             SWITCHES"
				line_s[4] = "                      LEVERS         "
			end
		end
		
		line[5] = "  CLOCK VARIANT                    /"
		if B738DR_b737_variant < 0 then
			line[5] = "  CLOCK VARIANT                      "
			line_s[5] = "                                    1"
			B738DR_tab_line_manip[5] = 0
		elseif B738DR_clock_variant == 0 then
			line_g[5] = "                                  1  "
			line_s[5] = "                                    2"
		else
			line_g[5] = "                                    2"
			line_s[5] = "                                  1  "
		end
		
		line[6] = "  HYD COMPENSATOR CARTRIDGE       /"
		if B738DR_hyd_compensator == 0 then
			line_g[6] = "                                   NO"
			line_s[6] = "                               YES   "
		else
			line_g[6] = "                               YES   "
			line_s[6] = "                                   NO"
		end
		
		line[7] = "  CTR FUEL PUMP AUTOSHUTDOWN      /"
		if B738DR_ctr_fuel_pump_auto == 0 then
			line_g[7] = "                                   NO"
			line_s[7] = "                               YES   "
		else
			line_g[7] = "                               YES   "
			line_s[7] = "                                   NO"
		end
		
		line[8] = "  A/C SWITCH COLOUR              /   "
		if B738DR_ac_switch_colour == 0 then
			line_g[8] = "                            WHITE    "
			line_s[8] = "                                  RED"
		else
			line_g[8] = "                                  RED"
			line_s[8] = "                            WHITE    "
		end
		
		line[9] = "  CABIN READY LIGHT               /"
		if B738DR_panel_cab_ready == 0 then
			line_g[9] = "                                   NO"
			line_s[9] = "                               YES   "
		else
			line_g[9] = "                               YES   "
			line_s[9] = "                                   NO"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 8, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		
		if B738DR_b737_variant < 0 then
			-- B738DR_tab_line_manip[4] = 0
			B738DR_tab_line_manip[5] = 0
		elseif B738DR_b737_variant == 1 or B738DR_b737_variant == 3 then
			B738DR_tab_line_manip[4] = 0
		end
		
	elseif page == 4 then
		line[1] = "  FLIGHTDECK CALL LIGHT           /"
		if B738DR_fd_call_light == 0 then
			line_g[1] = "                                   NO"
			line_s[1] = "                               YES   "
		else
			line_g[1] = "                               YES   "
			line_s[1] = "                                   NO"
		end
		
		line[2] = "  PA IN USE LIGHT                 /"
		if B738DR_pa_in_use_light == 0 then
			line_g[2] = "                                   NO"
			line_s[2] = "                               YES   "
		else
			line_g[2] = "                               YES   "
			line_s[2] = "                                   NO"
		end
		
		-- enable/disable manip
		for i = 0, 2 do
			B738DR_tab_line_manip[i] = 1
		end
		
		for i = 3, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		
	end
end

function cmd_option_systems(cmd)
	if cmd == 1 then
		if B738DR_hud_disable == 0 then
			B738DR_hud_disable = 1
		else
			B738DR_hud_disable = 0
		end
	elseif cmd == 2 then
		if B738DR_aspirated_probe == 0 then
			B738DR_aspirated_probe = 1
		else
			B738DR_aspirated_probe = 0
		end
	elseif cmd == 3 then
		if B738DR_probe_heat_auto == 0 then
			B738DR_probe_heat_auto = 1
		else
			B738DR_probe_heat_auto = 0
		end
	elseif cmd == 4 then
		if B738DR_engine_start_auto == 0 then
			B738DR_engine_start_auto = 1
		else
			B738DR_engine_start_auto = 0
		end
	elseif cmd == 5 then
		if B738DR_raas == 0 then
			B738DR_raas = 1
		elseif B738DR_raas == 1 then
			B738DR_raas = 2
		else
			B738DR_raas = 0
		end
	elseif cmd == 6 then
		if B738DR_mmr == 0 then
			B738DR_mmr = 1
		else
			B738DR_mmr = 0
			B738DR_lpv_install = 0
		end
	elseif cmd == 7 then
		if B738DR_mmr_colour == 0 then
			B738DR_mmr_colour = 1
		else
			B738DR_mmr_colour = 0
		end
	elseif cmd == 8 then
		if B738DR_com_decimal == 0 then
			B738DR_com_decimal = 1
		else
			B738DR_com_decimal = 0
		end
	elseif cmd == 9 then
		if B738DR_selcal_disable == 0 then
			B738DR_selcal_disable = 1
		else
			B738DR_selcal_disable = 0
		end
	elseif cmd == 10 then
		if B738DR_fd_cam_disable == 0 then
			B738DR_fd_cam_disable = 1
		else
			B738DR_fd_cam_disable = 0
		end
	elseif cmd == 11 then
		if B738DR_digital_press_panel == 0 then
			B738DR_digital_press_panel = 1
		else
			B738DR_digital_press_panel = 0
		end
	elseif cmd == 12 then
		if B738DR_ils_gls_annun == 0 then
			B738DR_ils_gls_annun = 1
		else
			B738DR_ils_gls_annun = 0
		end
	elseif cmd == 13 then
		if B738DR_no_smoking == 0 then
			B738DR_no_smoking = 1
		elseif B738DR_no_smoking == 1 then
			B738DR_no_smoking = 2
		else
			B738DR_no_smoking = 0
		end
	elseif cmd == 14 then
		if B738DR_no_vcr_switch == 0 then
			B738DR_no_vcr_switch = 1
		else
			B738DR_no_vcr_switch = 0
		end
	elseif cmd == 15 then
		if B738DR_isfd_rmi == 0 then
			B738DR_isfd_rmi = 1
		else
			B738DR_isfd_rmi = 0
		end
	elseif cmd == 16 then
		if B738DR_yaw_damper == 0 then
			B738DR_yaw_damper = 1
		else
			B738DR_yaw_damper = 0
		end
	elseif cmd == 17 then
		if B738DR_spd_intv_but == 0 then
			B738DR_spd_intv_but = 1
		else
			B738DR_spd_intv_but = 0
		end
	elseif cmd == 18 then
		if B738DR_alt_intv_but == 0 then
			B738DR_alt_intv_but = 1
		else
			B738DR_alt_intv_but = 0
		end
	elseif cmd == 19 then
		if B738DR_old_mcp == 0 then
			B738DR_old_mcp = 1
		else
			B738DR_old_mcp = 0
		end
	elseif cmd == 20 then
		if B738DR_rmi == 0 then
			B738DR_rmi = 1
		else
			B738DR_rmi = 0
		end
	elseif cmd == 21 then
		if B738DR_high_alt_ldg == 0 then
			B738DR_high_alt_ldg = 1
		else
			B738DR_high_alt_ldg = 0
		end
	elseif cmd == 22 then
		if B738DR_fuel_cutoff_sw == 0 then
			B738DR_fuel_cutoff_sw = 1
		else
			B738DR_fuel_cutoff_sw = 0
		end
	elseif cmd == 23 then
		if B738DR_clock_variant == 0 then
			B738DR_clock_variant = 1
		else
			B738DR_clock_variant = 0
		end
	elseif cmd == 24 then
		if B738DR_hyd_compensator == 0 then
			B738DR_hyd_compensator = 1
		else
			B738DR_hyd_compensator = 0
		end
	elseif cmd == 25 then
		if B738DR_ctr_fuel_pump_auto == 0 then
			B738DR_ctr_fuel_pump_auto = 1
			B738DR_fuel_pumps_off_placard = 0
		else
			B738DR_ctr_fuel_pump_auto = 0
		end
	elseif cmd == 26 then
		if B738DR_ac_switch_colour == 0 then
			B738DR_ac_switch_colour = 1
		else
			B738DR_ac_switch_colour = 0
		end
	elseif cmd == 27 then
		if B738DR_panel_cab_ready == 0 then
			B738DR_panel_cab_ready = 1
		else
			B738DR_panel_cab_ready = 0
		end
	elseif cmd == 28 then
		if B738DR_fd_call_light == 0 then
			B738DR_fd_call_light = 1
		else
			B738DR_fd_call_light = 0
		end
	elseif cmd == 29 then
		if B738DR_pa_in_use_light == 0 then
			B738DR_pa_in_use_light = 1
		else
			B738DR_pa_in_use_light = 0
		end
	end
end

function page_option_displays()
	
	line_c[0] = "       DISPLAYS                       "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  CHRONO DIGITAL SECONDS         /"
		if B738DR_chrono_variant == 0 then
			line_g[1] = "                                  YES"
			line_s[1] = "                               NO    "
		else
			line_g[1] = "                               NO    "
			line_s[1] = "                                  YES"
		end
		
		line[2] = "  NPS                            /"
		if B738DR_nps_disable == 0 then
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		else
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		end
		
		line[3] = "  PFD AOA-RA              /  /       "
		if B738DR_aoa_ra == 0 then
			line_g[3] = "                    AOA-RA           "
			line_s[3] = "                           RA CIRC RA"
		elseif B738DR_aoa_ra == 1 then
			line_g[3] = "                           RA        "
			line_s[3] = "                    AOA-RA    CIRC RA"
		else
			line_g[3] = "                              CIRC RA"
			line_s[3] = "                    AOA-RA RA        "
		end
		
		line[4] = "  PFD VREF         /           /     "
		if B738DR_pfd_fmc_flap_spd == 0 then
			line_g[4] = "               NONE                  "
			line_s[4] = "                    FLAPS-SPEED SPEED"
		elseif B738DR_pfd_fmc_flap_spd == 1 then
			line_g[4] = "                    FLAPS-SPEED      "
			line_s[4] = "               NONE             SPEED"
		else
			line_g[4] = "                                SPEED"
			line_s[4] = "               NONE FLAPS-SPEED      "
		end
		
		line[5] = "  ND DISPLAY              /"
		if B738DR_track_up == 1 then
			line_g[5] = "                  TRACK-UP           "
			line_s[5] = "                           HEADING-UP"
		else
			line_g[5] = "                           HEADING-UP"
			line_s[5] = "                  TRACK-UP           "
		end
		
		line[6] = "  ND VOR RADIAL COURSE            /"
		if B738DR_vor_radial == 0 then
			line_g[6] = "                               OFF   "
			line_s[6] = "                                   ON"
		else
			line_g[6] = "                                   ON"
			line_s[6] = "                               OFF   "
		end
		
		line[7] = "  ND DISTANCE RINGS              /"
		if B738DR_nd_rings == 0 then
			line_g[7] = "                               NO    "
			line_s[7] = "                                  YES"
		else
			line_g[7] = "                                  YES"
			line_s[7] = "                               NO    "
		end
		
		line[8] = "  TCAS DOTTED RANGE              /"
		if B738DR_nd_tcas_range == 0 then
			line_g[8] = "                               NO    "
			line_s[8] = "                                  YES"
		else
			line_g[8] = "                                  YES"
			line_s[8] = "                               NO    "
		end
		
		line[9] = "  FUEL GAUGE              /"
		if B738DR_fuelgauge == 0 then
			line_g[9] = "                SIDEBYSIDE           "
			line_s[9] = "                           OVER-UNDER"
		else
			line_g[9] = "                           OVER-UNDER"
			line_s[9] = "                SIDEBYSIDE           "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 2, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] = "  FUEL FLOW ON EICAS             /"
		if B738DR_ff_eicas == 0 then
			line_g[1] = "                               NO    "
			line_s[1] = "                                  YES"
		else
			line_g[1] = "                                  YES"
			line_s[1] = "                               NO    "
		end
		
		line[2] = "  LDU FLIGHT CONTROL             /"
		if B738DR_flight_ctrl == 0 then
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		else
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		end
		
		line[3] = "  LDU BRAKE TEMPERATURE          /"
		if B738DR_brake_temp == 0 then
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		else
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		end
		
		line[4] = "  GROUND SPEED ON PFD            /"
		if B738DR_gs_on_pfd == 0 then
			line_g[4] = "                               NO    "
			line_s[4] = "                                  YES"
		else
			line_g[4] = "                                  YES"
			line_s[4] = "                               NO    "
		end
		
		line[5] = "  VNAV SPEED BAND                /"
		if B738DR_at_wakeup == 0 then
			line_g[5] = "                               NO    "
			line_s[5] = "                                  YES"
		else
			line_g[5] = "                                  YES"
			line_s[5] = "                               NO    "
		end
		
		line[6] = "  ENGINE OIL QUANTITY            /"
		if B738DR_oil_qty_pct_qts == 0 then
			line_g[6] = "                              PCT    "
			line_s[6] = "                                  QTS"
		else
			line_g[6] = "                                  QTS"
			line_s[6] = "                              PCT    "
		end
		
		line[7] = "  ND AIRPORT FILTER MIN RW          M"
		line_g[7] = "                               " .. string.format("%4d", B738DR_nd_arpt_rw_lenght)
		
		line[8] = "  MISSED APP                 /"
		if B738DR_missed_app_colour == 0 then
			line_g[8] = "                  DASHED CYAN        "
			line_s[8] = "                              MAGENTA"
		else
			line_g[8] = "                              MAGENTA"
			line_s[8] = "                  DASHED CYAN        "
		end
		
		-- line[9] = "  EICAS N1                       /"
		-- if B738DR_eicas_full_n1 == 0 then
			-- line_g[9] = "                                  BUG"
			-- line_s[9] = "                  FULL THRUST+BUG    "
		-- else
			-- line_g[9] = "                  FULL THRUST+BUG    "
			-- line_s[9] = "                                  BUG"
		-- end
		
		line[9] = "  EICAS N1 DOUBLE DERATE         /"
		if B738DR_double_derate == 0 then
			line_g[9] = "                               NO    "
			line_s[9] = "                                  YES"
		else
			line_g[9] = "                                  YES"
			line_s[9] = "                               NO    "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 3 then
		-- line[1] = "  EICAS AUTO N1 BUG NUMBER        /"
		-- if B738DR_eicas_n1_num == 0 then
			-- line_g[1] = "                                   NO"
			-- line_s[1] = "                               YES   "
		-- else
			-- line_g[1] = "                               YES   "
			-- line_s[1] = "                                   NO"
		-- end
		
		line[1] = "  SINGLE CUE FLIGHT DIRECTOR     /"
		if B738DR_single_cue_fd == 0 then
			line_g[1] = "                               NO    "
			line_s[1] = "                                  YES"
		else
			line_g[1] = "                                  YES"
			line_s[1] = "                               NO    "
		end
		
		-- enable/disable manip
		-- for i = 0, 9 do
			-- B738DR_tab_line_manip[i] = 1
		-- end
		B738DR_tab_line_manip[0] = 1
		B738DR_tab_line_manip[1] = 1
		-- B738DR_tab_line_manip[2] = 1
		
		for i = 3, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_option_displays(cmd)
	if cmd == 1 then
		if B738DR_chrono_variant == 0 then
			B738DR_chrono_variant = 1
		else
			B738DR_chrono_variant = 0
		end
	elseif cmd == 2 then
		if B738DR_nps_disable == 0 then
			B738DR_nps_disable = 1
		else
			B738DR_nps_disable = 0
		end
	elseif cmd == 3 then
		if B738DR_aoa_ra == 0 then
			B738DR_aoa_ra = 1
		elseif B738DR_aoa_ra == 1 then
			B738DR_aoa_ra = 2
		else
			B738DR_aoa_ra = 0
		end
	elseif cmd == 4 then
		if B738DR_pfd_fmc_flap_spd == 0 then
			B738DR_pfd_fmc_flap_spd = 1
		elseif B738DR_pfd_fmc_flap_spd == 1 then
			B738DR_pfd_fmc_flap_spd = 2
		else
			B738DR_pfd_fmc_flap_spd = 0
		end
	elseif cmd == 5 then
		if B738DR_track_up == 0 then
			B738DR_track_up = 1
		else
			B738DR_track_up = 0
		end
	elseif cmd == 6 then
		if B738DR_vor_radial == 0 then
			B738DR_vor_radial = 1
		else
			B738DR_vor_radial = 0
		end
	elseif cmd == 7 then
		if B738DR_nd_rings == 0 then
			B738DR_nd_rings = 1
		else
			B738DR_nd_rings = 0
		end
	elseif cmd == 8 then
		if B738DR_nd_tcas_range == 0 then
			B738DR_nd_tcas_range = 1
		else
			B738DR_nd_tcas_range = 0
		end
	elseif cmd == 9 then
		if B738DR_fuelgauge == 0 then
			B738DR_fuelgauge = 1
		else
			B738DR_fuelgauge = 0
		end
	elseif cmd == 10 then
		if B738DR_ff_eicas == 0 then
			B738DR_ff_eicas = 1
		else
			B738DR_ff_eicas = 0
		end
	elseif cmd == 11 then
		if B738DR_flight_ctrl == 0 then
			B738DR_flight_ctrl = 1
		else
			B738DR_flight_ctrl = 0
		end
	elseif cmd == 12 then
		if B738DR_brake_temp == 0 then
			B738DR_brake_temp = 1
		else
			B738DR_brake_temp = 0
		end
	elseif cmd == 13 then
		if B738DR_gs_on_pfd == 0 then
			B738DR_gs_on_pfd = 1
		else
			B738DR_gs_on_pfd = 0
		end
	elseif cmd == 14 then
		if B738DR_at_wakeup == 0 then
			B738DR_at_wakeup = 1
		else
			B738DR_at_wakeup = 0
		end
	elseif cmd == 15 then
		if B738DR_oil_qty_pct_qts == 0 then
			B738DR_oil_qty_pct_qts = 1
		else
			B738DR_oil_qty_pct_qts = 0
		end
	elseif cmd == 16 then
		numpad_ref = 32
		activate_numpad()
	elseif cmd == 17 then
		if B738DR_missed_app_colour == 0 then
			B738DR_missed_app_colour = 1
		else
			B738DR_missed_app_colour = 0
		end
	-- elseif cmd == 18 then
		-- if B738DR_eicas_full_n1 == 0 then
			-- B738DR_eicas_full_n1 = 1
		-- else
			-- B738DR_eicas_full_n1 = 0
		-- end
	elseif cmd == 18 then
		if B738DR_double_derate == 0 then
			B738DR_double_derate = 1
		else
			B738DR_double_derate = 0
		end
	-- elseif cmd == 19 then
		-- if B738DR_eicas_n1_num == 0 then
			-- B738DR_eicas_n1_num = 1
		-- else
			-- B738DR_eicas_n1_num = 0
		-- end
	elseif cmd == 19 then
		if B738DR_single_cue_fd == 0 then
			B738DR_single_cue_fd = 1
		else
			B738DR_single_cue_fd = 0
		end
	end
end

function page_option_fms()
	
	line_c[0] = "       FMS                            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		-- if B738DR_b737_variant < 0 then
			-- line[1] = "  FMC MODEL 2584                  /"
			-- if B738DR_fmc_type == 0 then
				-- line_g[1] = "                                A1   "
				-- line_s[1] = "                                   A2"
			-- else
				-- line_g[1] = "                                   A2"
				-- line_s[1] = "                                A1   "
			-- end
		-- else
			-- line[1] =   "  FMC MODEL 2584                   "
			-- line_g[1] = "                                   A1"
		-- end
		
		if B738DR_b737_variant < 0 then
			line[1] = "  CDU                      /"
			if B738DR_fmc_type == 0 then
				line_g[1] = "                       MCDU          "
				line_s[1] = "                            FANS MCDU"
			else
				line_g[1] = "                            FANS MCDU"
				line_s[1] = "                       MCDU          "
			end
		else
			line[1] =   "  CDU                      /"
			line_g[1] = "                       MCDU ---------"
		end
		
		line[2] = "  RTE 2 INSTALLED                 /"
		if B738DR_no_rte2 == 0 then
			line_g[2] = "                               YES   "
			line_s[2] = "                                   NO"
		else
			line_g[2] = "                                   NO"
			line_s[2] = "                               YES   "
		end
		
		line[3] = "  INIT REF BUTTON - SMART        /"
		if B738DR_init_ref_smart == 0 then
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		else
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		end
		
		line[4] = "  IRS POS ENTRY MSG ALIGN        /"
		if B738DR_irs_ding == 0 then
			line_g[4] = "                               NO    "
			line_s[4] = "                                  YES"
		else
			line_g[4] = "                                  YES"
			line_s[4] = "                               NO    "
		end
		
		line[5] =   "  FACTORY CLB THRUST              AGL"
		line_g[5] = "                             " .. string.format("%4d", B738DR_def_clb_alt)
		
		line[6] =   "  FACTORY CLB RESTORE THRUST      AGL"
		line_g[6] = "                             " .. string.format("%4d", B738DR_def_clb_alt2)
		
		line[7] =   "  FACTORY CUTBACK THRUST          AGL"
		line_g[7] = "                             " .. string.format("%4d", B738DR_def_cut_alt)
		
		line[8] =   "  FACTORY ACCELERATION            AGL"
		line_g[8] = "                             " .. string.format("%4d", B738DR_def_accel_alt)
		
		line[9] =   "  FACTORY EO ACCELERATION         AGL"
		line_g[9] = "                             " .. string.format("%4d", B738DR_def_eo_accel_alt)
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] = "  GW ENTRY INHIBIT                /"
		if B738DR_gw_entry == 0 then
			line_g[1] = "                                   NO"
			line_s[1] = "                               YES   "
		else
			line_g[1] = "                               YES   "
			line_s[1] = "                                   NO"
		end
		
		line[2] = "  PLAN/FUEL INSTALLED             /"
		if B738DR_plan_fuel == 0 then
			line_g[2] = "                                   NO"
			line_s[2] = "                               YES   "
		else
			line_g[2] = "                               YES   "
			line_s[2] = "                                   NO"
		end
		
		line[3] =     "  VNAV WAKEUP IDLE SPD            KTS"
		line_s[3] =   "                       /5-15/        "
		line_g[3] =   "                               " .. string.format("%2d", B738DR_vnav_wakeup_idle)
		
		line[4] = "  FMC BEEP SOUND                  /"
		if B738DR_fmc_beep_sound == 0 then
			line_g[4] = "                                   NO"
			line_s[4] = "                               YES   "
		else
			line_g[4] = "                               YES   "
			line_s[4] = "                                   NO"
		end
		
		line[5] = "  APPROACH REF 2ND PAGE          /"
		if B738DR_app_ref_2nd_page == 0 then
			line_g[5] = "                               NO    "
			line_s[5] = "                                  YES"
		else
			line_g[5] = "                                  YES"
			line_s[5] = "                               NO    "
		end
		
		line[6] = "  VNAV BARO TEMP COMPENSATION    /"
		if B738DR_vnav_baro_comp == 0 then
			line_g[6] = "                               NO    "
			line_s[6] = "                                  YES"
		else
			line_g[6] = "                                  YES"
			line_s[6] = "                               NO    "
		end
		
		line[7] = "  ADDITIONAL FIX PAGES           /"
		if B738DR_add_fix_pgs == 0 then
			line_g[7] = "                                  YES"
			line_s[7] = "                               NO    "
		else
			line_g[7] = "                               NO    "
			line_s[7] = "                                  YES"
		end
		
		line[8] = "  FACTORY APPROACH RNP          /    "
		if B738DR_def_app_rnp == 0 then
			line_g[8] = "                            0.50     "
			line_s[8] = "                                 0.30"
		else
			line_g[8] = "                                 0.30"
			line_s[8] = "                            0.50     "
		end
		
		line[9] = "  FACTORY DME UPDATE              /  "
		if B738DR_def_dme_update == 0 then
			line_g[9] = "                               OFF   "
			line_s[9] = "                                   ON"
		else
			line_g[9] = "                                   ON"
			line_s[9] = "                               OFF   "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	else
		line[1] = "  CMU                 /       /      "
		if B738DR_cmu == 0 then
			line_g[1] = "                  NONE               "
			line_s[1] = "                       CMU-900 MK II+"
		elseif B738DR_cmu == 1 then
			line_g[1] = "                       CMU-900       "
			line_s[1] = "                  NONE         MK II+"
		else
			line_g[1] = "                               MK II+"
			line_s[1] = "                  NONE CMU-900       "
		end
		
		line[2] = "  CPDLC                  /      /    "
		if B738DR_cpdlc == 0 then
			line_g[2] = "                     NONE            "
			line_s[2] = "                          ATN B1 FANS"
		elseif B738DR_cpdlc == 1 then
			line_g[2] = "                          ATN B1     "
			line_s[2] = "                     NONE        FANS"
		else
			line_g[2] = "                                 FANS"
			line_s[2] = "                     NONE ATN B1     "
		end
		
		line[3] = "  ONLINE NETWORK                /    "
		if B738DR_online_network == 0 then
			line_g[3] = "                          VATSIM     "
			line_s[3] = "                                 IVAO"
		else
			line_g[3] = "                                 IVAO"
			line_s[3] = "                          VATSIM     "
		end
		
		line[4] = "  METAR SOURCE               /       "
		if B738DR_metar_source == 0 then
			line_g[4] = "                          SIM        "
			line_s[4] = "                              NETWORK"
		else
			line_g[4] = "                              NETWORK"
			line_s[4] = "                          SIM        "
		end
		
		-- enable/disable manip
		for i = 0, 4 do
			B738DR_tab_line_manip[i] = 1
		end
	end
end

function cmd_option_fms(cmd)
	if cmd == 1 and B738DR_b737_variant < 0 then
		if B738DR_fmc_type == 0 then
			B738DR_fmc_type = 1
		else
			B738DR_fmc_type = 0
			if B738DR_cmu ~= 0 and B738DR_cpdlc == 2 then
				B738DR_cpdlc = 1
			end
		end
	elseif cmd == 2 then
		if B738DR_no_rte2 == 0 then
			B738DR_no_rte2 = 1
		else
			B738DR_no_rte2 = 0
		end
	elseif cmd == 3 then
		if B738DR_init_ref_smart == 0 then
			B738DR_init_ref_smart = 1
		else
			B738DR_init_ref_smart = 0
		end
	elseif cmd == 4 then
		if B738DR_irs_ding == 0 then
			B738DR_irs_ding = 1
		else
			B738DR_irs_ding = 0
		end
	elseif cmd == 5 then
		-- climb thrust height
		numpad_ref = 26
		activate_numpad()
	elseif cmd == 6 then
		-- climb restore thrust height
		numpad_ref = 27
		activate_numpad()
	elseif cmd == 7 then
		-- cutback thrust height
		numpad_ref = 28
		activate_numpad()
	elseif cmd == 8 then
		-- acceleration height
		numpad_ref = 29
		activate_numpad()
	elseif cmd == 9 then
		-- EO acceleration height
		numpad_ref = 30
		activate_numpad()
	elseif cmd == 10 then
		if B738DR_gw_entry == 0 then
			B738DR_gw_entry = 1
		else
			B738DR_gw_entry = 0
		end
	elseif cmd == 11 then
		if B738DR_plan_fuel == 0 then
			B738DR_plan_fuel = 1
		else
			B738DR_plan_fuel = 0
		end
	elseif cmd == 12 then
		numpad_ref = 31
		activate_numpad()
	elseif cmd == 13 then
		if B738DR_fmc_beep_sound == 0 then
			B738DR_fmc_beep_sound = 1
		else
			B738DR_fmc_beep_sound = 0
		end
	elseif cmd == 14 then
		if B738DR_app_ref_2nd_page == 0 then
			B738DR_app_ref_2nd_page = 1
		else
			B738DR_app_ref_2nd_page = 0
		end
	elseif cmd == 15 then
		if B738DR_vnav_baro_comp == 0 then
			B738DR_vnav_baro_comp = 1
		else
			B738DR_vnav_baro_comp = 0
		end
	elseif cmd == 16 then
		if B738DR_add_fix_pgs == 0 then
			B738DR_add_fix_pgs = 1
		else
			B738DR_add_fix_pgs = 0
		end
	elseif cmd == 17 then
		if B738DR_def_app_rnp == 0 then
			B738DR_def_app_rnp = 1
		else
			B738DR_def_app_rnp = 0
		end
	elseif cmd == 18 then
		if B738DR_def_dme_update == 0 then
			B738DR_def_dme_update = 1
		else
			B738DR_def_dme_update = 0
		end
		B738CMD_update_factory:once()
	elseif cmd == 19 then
		if B738DR_cmu == 0 then
			B738DR_cmu = 1
		elseif B738DR_cmu == 1 then
			B738DR_cmu = 2
		else
			B738DR_cmu = 0
			B738DR_cpdlc = 0
		end
	elseif cmd == 20 then
		if B738DR_cmu ~= 0 then
			if B738DR_cpdlc == 0 then
				B738DR_cpdlc = 1
			elseif B738DR_cpdlc == 1 and B738DR_fmc_type ~= 0 then
				B738DR_cpdlc = 2
			else
				B738DR_cpdlc = 0
			end
		end
	elseif cmd == 21 then
		if B738DR_online_network == 0 then
			B738DR_online_network = 1
		else
			B738DR_online_network = 0
		end
	elseif cmd == 22 then
		if B738DR_metar_source == 0 then
			B738DR_metar_source = 1
		else
			B738DR_metar_source = 0
		end
	end
end

function page_option_autoflight()
	
	line_c[0] = "       AUTOFLIGHT                     "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	line[1] = "  TAKEOFF ROLL MODE          /"
	if B738DR_takeoff_hdg == 0 then
		line_g[1] = "                     WING LVL        "
		line_s[1] = "                              HDG SEL"
	else
		line_g[1] = "                              HDG SEL"
		line_s[1] = "                     WING LVL        "
	end
	
	line[2] = "  GOAROUND ROLL MODE         /"
	if B738DR_go_around_hdg == 0 then
		line_g[2] = "                     WING LVL        "
		line_s[2] = "                              HDG SEL"
	else
		line_g[2] = "                              HDG SEL"
		line_s[2] = "                     WING LVL        "
	end
	
	line[3] = "  VNAV INSTALLED              /"
	if B738DR_vnav_common == 0 then
		line_g[3] = "                         BASIC       "
		line_s[3] = "                               COMMON"
	else
		line_g[3] = "                               COMMON"
		line_s[3] = "                         BASIC       "
	end
	
	line[4] = "  VNAV ALT INSTALLED              /"
	if B738DR_vnav_alt_disable == 0 then
		line_g[4] = "                               YES   "
		line_s[4] = "                                   NO"
	else
		line_g[4] = "                                   NO"
		line_s[4] = "                               YES   "
	end
	
	line[5] = "  APPROACH LNAV ARM              /"
	if B738DR_vorloc_lnav == 0 then
		line_g[5] = "                               NO    "
		line_s[5] = "                                  YES"
	else
		line_g[5] = "                                  YES"
		line_s[5] = "                               NO    "
	end
	
	line[6] = "  IAN INSTALLED                  /"
	if B738DR_ian_not_install == 0 then
		line_g[6] = "                                  YES"
		line_s[6] = "                               NO    "
	else
		line_g[6] = "                               NO    "
		line_s[6] = "                                  YES"
	end
	
	line[7] = "  AUTOLAND FAIL          /"
	if B738DR_autoland_install == 0 then
		line_g[7] = "                          OPERATIONAL"
		line_s[7] = "                  PASSIVE            "
	else
		line_g[7] = "                  PASSIVE            "
		line_s[7] = "                          OPERATIONAL"
	end
	
	line[8] = "  LPV APPROACH CAPABILITY        /"
	if B738DR_mmr == 0 then
		line_s[8] = "                               NO YES"
	elseif B738DR_lpv_install == 0 then
		line_g[8] = "                               NO    "
		line_s[8] = "                                  YES"
	else
		line_g[8] = "                                  YES"
		line_s[8] = "                               NO    "
	end
	
	line[9] = "  CAPTURE GS BEFORE LOC          /"
	if B738DR_gs_before_loc == 0 then
		line_g[9] = "                               NO    "
		line_s[9] = "                                  YES"
	else
		line_g[9] = "                                  YES"
		line_s[9] = "                               NO    "
	end
	
	-- enable/disable manip
	for i = 0, 9 do
		B738DR_tab_line_manip[i] = 1
	end
	
	if B738DR_mmr == 0 then
		B738DR_tab_line_manip[8] = 0	-- LPV
	end
end

function cmd_option_autoflight(cmd)
	if cmd == 1 then
		if B738DR_takeoff_hdg == 0 then
			B738DR_takeoff_hdg = 1
		else
			B738DR_takeoff_hdg = 0
		end
	elseif cmd == 2 then
		if B738DR_go_around_hdg == 0 then
			B738DR_go_around_hdg = 1
		else
			B738DR_go_around_hdg = 0
		end
	elseif cmd == 3 then
		if B738DR_vnav_common == 0 then
			B738DR_vnav_common = 1
		else
			B738DR_vnav_common = 0
		end
	elseif cmd == 4 then
		if B738DR_vnav_alt_disable == 0 then
			B738DR_vnav_alt_disable = 1
		else
			B738DR_vnav_alt_disable = 0
		end
	elseif cmd == 5 then
		if B738DR_vorloc_lnav == 0 then
			B738DR_vorloc_lnav = 1
		else
			B738DR_vorloc_lnav = 0
		end
	elseif cmd == 6 then
		if B738DR_ian_not_install == 0 then
			B738DR_ian_not_install = 1
		else
			B738DR_ian_not_install = 0
		end
	elseif cmd == 7 then
		if B738DR_autoland_install == 0 then
			B738DR_autoland_install = 1
		else
			B738DR_autoland_install = 0
		end
	elseif cmd == 8 then
		if B738DR_lpv_install == 0 then
			B738DR_lpv_install = 1
		else
			B738DR_lpv_install = 0
		end
	elseif cmd == 9 then
		if B738DR_gs_before_loc == 0 then
			B738DR_gs_before_loc = 1
		else
			B738DR_gs_before_loc = 0
		end
	end
end

function page_option_callouts()
	line_c[0] = "       CALLOUTS                       "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		if B738DR_b737_variant < 0 then
			line[1] = "  FO CALLOUTS                     /"
			if B738DR_disable_fo_callout == 0 then
				line_g[1] = "                               YES   "
				line_s[1] = "                                   NO"
			else
				line_g[1] = "                                   NO"
				line_s[1] = "                               YES   "
			end
		else
			line[1] = "  FO CALLOUTS                      "
			if B738DR_disable_fo_callout ~= 0 then
				line_g[1] = "                                 NONE"
			elseif B738DR_fo_callout_var == 0 then
				line_g[1] = "                              BRITISH"
			elseif B738DR_fo_callout_var == 1 then
				line_g[1] = "                             AMERICAN"
			end
		end
		
		line[2] = "  RA CALLOUT    5 FT             /"
		if B738DR_ra_callout_disable[0] == 0 then
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		else
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		end
		
		line[3] = "  RA CALLOUT   10 FT             /"
		if B738DR_ra_callout_disable[1] == 0 then
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		else
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		end
		
		line[4] = "  RA CALLOUT   20 FT             /"
		if B738DR_ra_callout_disable[2] == 0 then
			line_g[4] = "                                  YES"
			line_s[4] = "                               NO    "
		else
			line_g[4] = "                               NO    "
			line_s[4] = "                                  YES"
		end
		
		line[5] = "  RA CALLOUT   30 FT             /"
		if B738DR_ra_callout_disable[3] == 0 then
			line_g[5] = "                                  YES"
			line_s[5] = "                               NO    "
		else
			line_g[5] = "                               NO    "
			line_s[5] = "                                  YES"
		end
		
		line[6] = "  RA CALLOUT   40 FT             /"
		if B738DR_ra_callout_disable[4] == 0 then
			line_g[6] = "                                  YES"
			line_s[6] = "                               NO    "
		else
			line_g[6] = "                               NO    "
			line_s[6] = "                                  YES"
		end
		
		line[7] = "  RA CALLOUT   50 FT             /"
		if B738DR_ra_callout_disable[5] == 0 then
			line_g[7] = "                                  YES"
			line_s[7] = "                               NO    "
		else
			line_g[7] = "                               NO    "
			line_s[7] = "                                  YES"
		end
		
		line[8] = "  RA CALLOUT   60 FT             /"
		if B738DR_ra_callout_disable[6] == 0 then
			line_g[8] = "                                  YES"
			line_s[8] = "                               NO    "
		else
			line_g[8] = "                               NO    "
			line_s[8] = "                                  YES"
		end
		
		line[9] = "  RA CALLOUT  100 FT             /"
		if B738DR_ra_callout_disable[7] == 0 then
			line_g[9] = "                                  YES"
			line_s[9] = "                               NO    "
		else
			line_g[9] = "                               NO    "
			line_s[9] = "                                  YES"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] = "  RA CALLOUT  200 FT             /"
		if B738DR_ra_callout_disable[8] == 0 then
			line_g[1] = "                                  YES"
			line_s[1] = "                               NO    "
		else
			line_g[1] = "                               NO    "
			line_s[1] = "                                  YES"
		end
		
		line[2] = "  RA CALLOUT  300 FT             /"
		if B738DR_ra_callout_disable[9] == 0 then
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		else
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		end
		
		line[3] = "  RA CALLOUT  400 FT             /"
		if B738DR_ra_callout_disable[10] == 0 then
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		else
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		end
		
		line[4] = "  RA CALLOUT  500 FT      /     /"
		if B738DR_ra_callout_disable[11] == 0 then
			line_g[4] = "                                 HARD"
			line_s[4] = "                        NO SMART     "
		elseif B738DR_ra_callout_disable[11] == 1 then
			line_g[4] = "                        NO           "
			line_s[4] = "                           SMART HARD"
		else
			line_g[4] = "                           SMART     "
			line_s[4] = "                        NO       HARD"
		end
		
		line[5] = "  RA CALLOUT 1000 FT      /     /"
		if B738DR_ra_callout_disable[12] == 0 then
			line_g[5] = "                                 HARD"
			line_s[5] = "                        NO SMART     "
		elseif B738DR_ra_callout_disable[12] == 1 then
			line_g[5] = "                        NO           "
			line_s[5] = "                           SMART HARD"
		else
			line_g[5] = "                           SMART     "
			line_s[5] = "                        NO       HARD"
		end
		
		line[6] = "  RA CALLOUT 1000 FT STABIL.     /"
		if B738DR_ra_callout_disable[13] == 0 then
			line_g[6] = "                                  YES"
			line_s[6] = "                               NO    "
		else
			line_g[6] = "                               NO    "
			line_s[6] = "                                  YES"
		end
		
		line[7] = "  RA CALLOUT 2500 FT             /"
		if B738DR_ra_callout_disable[14] == 0 then
			line_g[7] = "                                  YES"
			line_s[7] = "                               NO    "
		else
			line_g[7] = "                               NO    "
			line_s[7] = "                                  YES"
		end
		
		line[8] = "  MINIMUM CALLOUTS          /     "
		if B738DR_ra_minimums == 0 then
			line_g[8] = "                     MINIMUM         "
			line_s[8] = "                             MINIMUMS"
		else
			line_g[8] = "                             MINIMUMS"
			line_s[8] = "                     MINIMUM         "
		end
		
		line[9] = "  APP MINIMUM CALLOUT       /    /"
		if B738DR_ra_decision_height ~= 0 then
			line_g[9] = "                          DH         "
			line_s[9] = "                             +100 MIN"
		elseif B738DR_plus_hundred ~= 0 then
			line_g[9] = "                             +100    "
			line_s[9] = "                          DH      MIN"
		else
			line_g[9] = "                                  MIN"
			line_s[9] = "                          DH +100    "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		
	elseif page == 3 then
		line[1] = "  RA CALLOUT         /"
		if B738DR_ra_radio_altimeter == 0 then
			line_g[1] = "                 2500                "
			line_s[1] = "                      RADIO ALTIMETER"
		else
			line_g[1] = "                      RADIO ALTIMETER"
			line_s[1] = "                 2500                "
		end
		
		line[2] = "  500/1000FT SOURCE             /"
		if B738DR_ra_500_1000_baro == 0 then
			line_g[2] = "                           RADIO     "
			line_s[2] = "                                 BARO"
		else
			line_g[2] = "                                 BARO"
			line_s[2] = "                           RADIO     "
		end
		
		-- enable/disable manip
		for i = 0, 2 do
			B738DR_tab_line_manip[i] = 1
		end
		
		for i = 3, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_option_callouts(cmd)
	if cmd == 1 then
		if B738DR_b737_variant < 0 then
			if B738DR_disable_fo_callout == 0 then
				B738DR_disable_fo_callout = 1
			else
				B738DR_disable_fo_callout = 0
			end
		else
			if B738DR_disable_fo_callout == 0 then
				if B738DR_fo_callout_var == 0 then
					B738DR_fo_callout_var = 1
				elseif B738DR_fo_callout_var == 1 then
					B738DR_fo_callout_var = 2
				else
					B738DR_fo_callout_var = 0
					B738DR_disable_fo_callout = 1
				end
			else
				B738DR_disable_fo_callout = 0
				B738DR_fo_callout_var = 0
			end
		end
	elseif cmd >= 2 and cmd <= 16 then
		local cmd_idx = cmd-2
		if cmd_idx == 11 or cmd_idx == 12 then	--or cmd_idx == 14 then
			if B738DR_ra_callout_disable[cmd_idx] == 0 then
				B738DR_ra_callout_disable[cmd_idx] = 1
			elseif B738DR_ra_callout_disable[cmd_idx] == 1 then
				B738DR_ra_callout_disable[cmd_idx] = 2
			else
				B738DR_ra_callout_disable[cmd_idx] = 0
			end
		else
			if B738DR_ra_callout_disable[cmd_idx] == 0 then
				B738DR_ra_callout_disable[cmd_idx] = 1
			else
				B738DR_ra_callout_disable[cmd_idx] = 0
			end
		end
	elseif cmd == 17 then
		if B738DR_ra_minimums == 0 then
			B738DR_ra_minimums = 1
		else
			B738DR_ra_minimums = 0
		end
	elseif cmd == 18 then
		if B738DR_ra_decision_height ~= 0 then
			B738DR_ra_decision_height = 0
			B738DR_plus_hundred = 1
		elseif B738DR_plus_hundred ~= 0 then
			B738DR_plus_hundred = 0
			B738DR_ra_decision_height = 0
		else
			B738DR_plus_hundred = 0
			B738DR_ra_decision_height = 1
		end
	elseif cmd == 19 then
		if B738DR_ra_radio_altimeter == 0 then
			B738DR_ra_radio_altimeter = 1
		else
			B738DR_ra_radio_altimeter = 0
		end
	elseif cmd == 20 then
		if B738DR_ra_500_1000_baro == 0 then
			B738DR_ra_500_1000_baro = 1
		else
			B738DR_ra_500_1000_baro = 0
		end
	end
end

function page_option_placards()
	
	line_c[0] = "       PLACARDS                       "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	-- if B738DR_b737_variant < 0 then
		if B738DR_ctr_fuel_pump_auto == 0 then
			line[1] = "  FUEL PUMPS PLACARD             /"
			if B738DR_fuel_pumps_off_placard == 0 then
				line_g[1] = "                               NO    "
				line_s[1] = "                                  YES"
			else
				line_g[1] = "                                  YES"
				line_s[1] = "                               NO    "
			end
		else
			line[1] = "  FUEL PUMPS PLACARD              "
			line_s[1] = "                                   NO"
		end
		
		line[2] = "  CAT III PLACARD          / / / / / "
		if B738DR_cat3_placard == 0 then
			line_g[2] = "                         NO          "
			line_s[2] = "                            1 2 3 4 5"
		elseif B738DR_cat3_placard == 1 then
			line_g[2] = "                            1        "
			line_s[2] = "                         NO   2 3 4 5"
		elseif B738DR_cat3_placard == 2 then
			line_g[2] = "                              2      "
			line_s[2] = "                         NO 1   3 4 5"
		elseif B738DR_cat3_placard == 3 then
			line_g[2] = "                                3    "
			line_s[2] = "                         NO 1 2   4 5"
		elseif B738DR_cat3_placard == 4 then
			line_g[2] = "                                  4  "
			line_s[2] = "                         NO 1 2 3   5"
		else
			line_g[2] = "                                    5"
			line_s[2] = "                         NO 1 2 3 4  "
		end
		
		line[3] = "  BRAKES PLACARD                 /"
		if B738DR_brakes_placard == 0 then
			line_g[3] = "                               NO    "
			line_s[3] = "                                  YES"
		else
			line_g[3] = "                                  YES"
			line_s[3] = "                               NO    "
		end
		
		-- enable/disable manip
		for i = 0, 3 do
			B738DR_tab_line_manip[i] = 1
		end
		
		for i = 4, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	-- else
		-- for i = 0, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	-- end
end

function cmd_option_placards(cmd)
	-- if B738DR_b737_variant < 0 then
		if cmd == 1 then
			if B738DR_ctr_fuel_pump_auto == 0 then
				if B738DR_fuel_pumps_off_placard == 0 then
					B738DR_fuel_pumps_off_placard = 1
				else
					B738DR_fuel_pumps_off_placard = 0
				end
			else
				B738DR_fuel_pumps_off_placard = 0
			end
		elseif cmd == 2 then
			if B738DR_cat3_placard == 0 then
				B738DR_cat3_placard = 1
			elseif B738DR_cat3_placard == 1 then
				B738DR_cat3_placard = 2
			elseif B738DR_cat3_placard == 2 then
				B738DR_cat3_placard = 3
			elseif B738DR_cat3_placard == 3 then
				B738DR_cat3_placard = 4
			elseif B738DR_cat3_placard == 4 then
				B738DR_cat3_placard = 5
			else
				B738DR_cat3_placard = 0
			end
		elseif cmd == 3 then
			if B738DR_brakes_placard == 0 then
				B738DR_brakes_placard = 1
			else
				B738DR_brakes_placard = 0
			end
		end
	-- end
end


function page_hardware()
	
	line_c[0] =   "      HARDWARE CONFIGURATION          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  TOE BRAKES AXIS           /"
		if B738DR_toe_brakes_ovr == 0 then
			line_g[1] = "                   DIFFERENT         "
			line_s[1] = "                             SYMETRIC"
		else
			line_g[1] = "                             SYMETRIC"
			line_s[1] = "                   DIFFERENT         "
		end
		
		line[2] = "  NOSEWHEEL AXIS         /   /    /  "
		if B738DR_nosewheel == 0 then
			line_g[2] = "                       ON            "
			line_s[2] = "                          YAW ROLL VR"
		elseif B738DR_nosewheel == 1 then
			line_g[2] = "                          YAW        "
			line_s[2] = "                       ON     ROLL VR"
		elseif B738DR_nosewheel == 2 then
			line_g[2] = "                              ROLL   "
			line_s[2] = "                       ON YAW      VR"
		elseif B738DR_nosewheel == 3 then
			line_g[2] = "                                   VR"
			line_s[2] = "                       ON YAW ROLL   "
		end
		
		line[3] = "  THROTTLE NOISE LOCK                "
		if B738DR_throttle_noise == 0 then
			line_g[3] = "                                  OFF"
		else
			line_g[3] = "                                  " .. string.format("%3d", B738DR_throttle_noise)
		end
		
		line[4] = "  PARKBRAKE REMOVE CHOCKS         /  "
		if B738DR_parkbrake_remove_chock == 0 then
			line_g[4] = "                               OFF   "
			line_s[4] = "                                   ON"
		else
			line_g[4] = "                                   ON"
			line_s[4] = "                               OFF   "
		end
		
		line[5] = "  A/T ENGAGED LOCK THROTTLE       /  "
		if B738DR_lock_thrust == 0 then
			line_g[5] = "                               OFF   "
			line_s[5] = "                                   ON"
		else
			line_g[5] = "                                   ON"
			line_s[5] = "                               OFF   "
		end
		
		line[6] = "  SYNC HARDWARE THROTTLE          /  "
		if B738DR_lock_thrust == 0 then
			line_s[6] = "                               OFF ON"
		else
			if B738DR_sync_thrust == 0 then
				line_g[6] = "                               OFF   "
				line_s[6] = "                                   ON"
			else
				line_g[6] = "                                   ON"
				line_s[6] = "                               OFF   "
			end
		end
		line[7] = "  ONLY VIRTUAL YOKE              /"
		if B738DR_yoke_virtual == 0 then
			line_g[7] = "                               NO    "
			line_s[7] = "                                  YES"
		else
			line_g[7] = "                                  YES"
			line_s[7] = "                               NO    "
		end
		
		line[8] = "  YOKE AUTO CENTER                /  "
		if B738DR_yoke_virtual ~= 0 then
			line_s[8] = "                               OFF ON"
		elseif B738DR_yoke_to_center == 0 then
			line_g[8] = "                               OFF   "
			line_s[8] = "                                   ON"
		else
			line_g[8] = "                                   ON"
			line_s[8] = "                               OFF   "
		end
		
		line[9] = "  BRUNNER HARDWARE                /  "
		if B738DR_brunner_enable == 0 then
			line_g[9] = "                               OFF   "
			line_s[9] = "                                   ON"
		else
			line_g[9] = "                                   ON"
			line_s[9] = "                               OFF   "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		if B738DR_lock_thrust == 0 then
			B738DR_tab_line_manip[6] = 0
		end
		
	elseif page == 2 then
		
		line[1] = "  SMART AP MCP KNOBS              /  "
		if B738DR_smart_ap_knob == 0 then
			line_g[1] = "                               OFF   "
			line_s[1] = "                                   ON"
		else
			line_g[1] = "                                   ON"
			line_s[1] = "                               OFF   "
		end
		
		line[2] = "  XHSI                            /  "
		if B738DR_xhsi_enable == 0 then
			line_g[2] = "                               OFF   "
			line_s[2] = "                                   ON"
		else
			line_g[2] = "                                   ON"
			line_s[2] = "                               OFF   "
		end
		
		line[3] = "  CFY HARDWARE               /  /    "
		if B738DR_cfy_enable == 0 then
			line_g[3] = "                          OFF   "
			line_s[3] = "                              ON TEST"
		elseif B738DR_cfy_enable == 1 then
			line_g[3] = "                              ON"
			line_s[3] = "                          OFF    TEST"
		else
			line_g[3] = "                                 TEST"
			line_s[3] = "                          OFF ON     "
		end
		
		line[4] = "  CFY TRIM CONTROL               /   "
		if B738DR_cfy_trim_control == 0 then
			line_g[4] = "                              OFF    "
			line_s[4] = "                                  YES"
		else
			line_g[4] = "                                  YES"
			line_s[4] = "                              OFF    "
		end
		
		line[5] = "  JETWAY POWER                   /   "
		if B738DR_sam_enable == 0 then
			line_g[5] = "                               ON    "
			line_s[5] = "                                  SAM"
		else
			line_g[5] = "                                  SAM"
			line_s[5] = "                               ON    "
		end
		
		line[6] = "  GUARDED COVERS ALWAYS OPEN     /"
		if B738DR_guarded_covers == 0 then
			line_g[6] = "                               NO    "
			line_s[6] = "                                  YES"
		else
			line_g[6] = "                                  YES"
			line_s[6] = "                               NO    "
		end
		
		line[7] = "  EXTERNAL PAYLOAD            /      "
		if B738DR_ext_payload == 0 then
			line_g[7] = "                       DISABLE       "
			line_s[7] = "                               ENABLE"
		else
			line_g[7] = "                               ENABLE"
			line_s[7] = "                       DISABLE       "
		end
		
		line[8] = "  EFB USE EXT SW AIRSTAIRS       /"
		if B738DR_use_ext_airstairs == 0 then
			line_g[8] = "                               NO    "
			line_s[8] = "                                  YES"
		else
			line_g[8] = "                                  YES"
			line_s[8] = "                               NO    "
		end
		line[9] = "  YOKE INPUT ADVANCED            /   "
		if B738DR_yoke_input == 0 then
			line_g[9] = "                                  OFF"
			line_s[9] = "                               ON    "
		else
			line_g[9] = "                               ON    "
			line_s[9] = "                                  OFF"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	end
end

function cmd_hardware(cmd)
	if cmd == 1 then
		if B738DR_toe_brakes_ovr == 0 then
			B738DR_toe_brakes_ovr = 1
		else
			B738DR_toe_brakes_ovr = 0
		end
	elseif cmd == 2 then
		if B738DR_nosewheel == 0 then
			B738DR_nosewheel = 1
		elseif B738DR_nosewheel == 1 then
			B738DR_nosewheel = 2
		elseif B738DR_nosewheel == 2 then
			B738DR_nosewheel = 3
		else
			B738DR_nosewheel = 0
		end
	elseif cmd == 3 then
		if B738DR_throttle_noise == 10 then
			B738DR_throttle_noise = 0
		else
			B738DR_throttle_noise = B738DR_throttle_noise + 1
		end
	elseif cmd == 4 then
		if B738DR_parkbrake_remove_chock == 0 then
			B738DR_parkbrake_remove_chock = 1
		else
			B738DR_parkbrake_remove_chock = 0
		end
	elseif cmd == 5 then
		if B738DR_lock_thrust == 0 then
			B738DR_lock_thrust = 1
		else
			B738DR_lock_thrust = 0
		end
	elseif cmd == 6 then
		if B738DR_sync_thrust == 0 then
			B738DR_sync_thrust = 1
		else
			B738DR_sync_thrust = 0
		end
	elseif cmd == 7 then
		if B738DR_yoke_virtual == 0 then
			B738DR_yoke_virtual = 1
			B738DR_yoke_to_center = 1
		else
			B738DR_yoke_virtual = 0
		end
	elseif cmd == 8 then
		if B738DR_yoke_to_center == 0 then
			B738DR_yoke_to_center = 1
		else
			B738DR_yoke_to_center = 0
		end
	elseif cmd == 9 then
		if B738DR_brunner_enable == 0 then
			B738DR_brunner_enable = 1
		else
			B738DR_brunner_enable = 0
		end
	elseif cmd == 10 then
		if B738DR_smart_ap_knob == 0 then
			B738DR_smart_ap_knob = 1
		else
			B738DR_smart_ap_knob = 0
		end
	elseif cmd == 11 then
		if B738DR_xhsi_enable == 0 then
			B738DR_xhsi_enable = 1
		else
			B738DR_xhsi_enable = 0
		end
	elseif cmd == 12 then
		if B738DR_cfy_enable == 0 then
			B738DR_cfy_enable = 1
		elseif B738DR_cfy_enable == 1 then
			B738DR_cfy_enable = 2
		else
			B738DR_cfy_enable = 0
		end
	elseif cmd == 13 then
		if B738DR_cfy_trim_control == 0 then
			B738DR_cfy_trim_control = 1
		else
			B738DR_cfy_trim_control = 0
		end
	elseif cmd == 14 then
		if B738DR_sam_enable == 0 then
			B738DR_sam_enable = 1
		else
			B738DR_sam_enable = 0
		end
	elseif cmd == 15 then
		if B738DR_guarded_covers == 0 then
			B738DR_guarded_covers = 1
		else
			B738DR_guarded_covers = 0
		end
	elseif cmd == 16 then
		if B738DR_ext_payload == 0 then
			B738DR_ext_payload = 1
		else
			B738DR_ext_payload = 0
		end
	elseif cmd == 17 then
		if B738DR_use_ext_airstairs == 0 then
			B738DR_use_ext_airstairs = 1
		else
			B738DR_use_ext_airstairs = 0
		end
	elseif cmd == 18 then
		if B738DR_yoke_input == 0 then
			B738DR_yoke_input = 1
		else
			B738DR_yoke_input = 0
		end
	end
end

function page_realism()
	
	line_c[0] =   "       REALISM SETTINGS               "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  ALIGN TIME              /    /     "
		if B738DR_align_time == 0 then
			line_g[1] = "                      REAL           "
			line_s[1] = "                           LONG SHORT"
		elseif B738DR_align_time == 1 then
			line_g[1] = "                           LONG      "
			line_s[1] = "                      REAL      SHORT"
		else
			line_g[1] = "                                SHORT"
			line_s[1] = "                      REAL LONG      "
		end
		
		line[2] = "  REFUEL TIME             /    /     "
		if B738DR_refuel_time == 0 then
			line_g[2] = "                      REAL           "
			line_s[2] = "                           LONG SHORT"
		elseif B738DR_refuel_time == 1 then
			line_g[2] = "                           LONG      "
			line_s[2] = "                      REAL      SHORT"
		else
			line_g[2] = "                                SHORT"
			line_s[2] = "                      REAL LONG      "
		end
		
		line[3] = "  PAX BOARDING TIME       /    /     "
		if B738DR_pax_time == 0 then
			line_g[3] = "                      REAL           "
			line_s[3] = "                           LONG SHORT"
		elseif B738DR_pax_time == 1 then
			line_g[3] = "                           LONG      "
			line_s[3] = "                      REAL      SHORT"
		else
			line_g[3] = "                                SHORT"
			line_s[3] = "                      REAL LONG      "
		end
		
		line[4] = "  CARGO LOAD TIME         /    /     "
		if B738DR_cargo_time == 0 then
			line_g[4] = "                      REAL           "
			line_s[4] = "                           LONG SHORT"
		elseif B738DR_cargo_time == 1 then
			line_g[4] = "                           LONG      "
			line_s[4] = "                      REAL      SHORT"
		else
			line_g[4] = "                                SHORT"
			line_s[4] = "                      REAL LONG      "
		end
		
		line[5] = "  CATERING LOAD TIME      /    /     "
		if B738DR_catering_time == 0 then
			line_g[5] = "                      REAL           "
			line_s[5] = "                           LONG SHORT"
		elseif B738DR_catering_time == 1 then
			line_g[5] = "                           LONG      "
			line_s[5] = "                      REAL      SHORT"
		else
			line_g[5] = "                                SHORT"
			line_s[5] = "                      REAL LONG      "
		end
		
		line[6] = "  PAUSE AT T/D                    /"
		if B738DR_pause_td == 0 then
			line_g[6] = "                               OFF   "
			line_s[6] = "                                   ON"
		else
			line_g[6] = "                                   ON"
			line_s[6] = "                               OFF   "
		end
		
		line[7] = "  TIRE BLOWN ADVANCED             /"
		if B738DR_tire_blown == 0 then
			line_g[7] = "                               OFF   "
			line_s[7] = "                                   ON"
		else
			line_g[7] = "                                   ON"
			line_s[7] = "                               OFF   "
		end
		
		line[8] = "  YOKE MOVEMENT         /        /   "
		if B738DR_yoke_disco_ap == 0 then
			line_g[8] = "                     OFF             "
			line_s[8] = "                         DISCO AP CWS"
		elseif B738DR_yoke_disco_ap == 1 then
			line_g[8] = "                         DISCO AP    "
			line_s[8] = "                     OFF          CWS"
		else
			line_g[8] = "                                  CWS"
			line_s[8] = "                     OFF DISCO AP    "
		end
		
		line[9] = "  PARKING BRAKE SET           /      "
		if B738DR_parkbrake_set == 0 then
			line_g[9] = "                               SIMPLY"
			line_s[9] = "                          REAL       "
		else
			line_g[9] = "                          REAL       "
			line_s[9] = "                               SIMPLY"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end\
		-- if simDR_int_ver >= 120000 then
			-- B738DR_tab_line_manip[9] = 0
		-- end
	elseif page == 2 then
		line[1] = "  FMC INPUT LAG                   /"
		if B738DR_fmc_input_lag == 0 then
			line_g[1] = "                               OFF   "
			line_s[1] = "                                   ON"
		else
			line_g[1] = "                                   ON"
			line_s[1] = "                               OFF   "
		end
		
		line[2] = "  AP YOKE NEUTRAL TOL.        /      "
		if B738DR_ap_yoke_tolerance ~= 0 then
			line_g[2] = "                               SIMPLY"
			line_s[2] = "                          REAL       "
		else
			line_g[2] = "                          REAL       "
			line_s[2] = "                               SIMPLY"
		end
		
		line[3] = "  AUTOSAVE           /    /    /     "
		if B738DR_autosave == 0 then
			line_g[3] = "                  OFF                "
			line_s[3] = "                      1MIN 5MIN 15MIN"
		elseif B738DR_autosave == 1 then
			line_g[3] = "                      1MIN           "
			line_s[3] = "                  OFF      5MIN 15MIN"
		elseif B738DR_autosave == 2 then
			line_g[3] = "                           5MIN      "
			line_s[3] = "                  OFF 1MIN      15MIN"
		else
			line_g[3] = "                                15MIN"
			line_s[3] = "                  OFF 1MIN 5MIN      "
		end
		
		if B738DR_max_rnd_fail == 0 then
			B738DR_max_rnd_fail = 1
		end
		line[4] = "  MAX RANDOM FAILURES              "
		line_g[4] = "                                   " .. string.format("%2d", B738DR_max_rnd_fail)
		
		line[5] = "  PAUSE AFTER LOAD FLIGHT        /   "
		if B738DR_pause_load_flt == 0 then
			line_g[5] = "                               NO    "
			line_s[5] = "                                  YES"
		else
			line_g[5] = "                                  YES"
			line_s[5] = "                               NO    "
		end
		
		-- enable/disable manip
		for i = 0, 5 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 6, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		-- if simDR_int_ver >= 120000 then
			-- B738DR_tab_line_manip[3] = 0
		-- end
	end
end

function cmd_realism(cmd)
	if cmd == 1 then
		if B738DR_align_time == 0 then
			B738DR_align_time = 1
		elseif B738DR_align_time == 1 then
			B738DR_align_time = 2
		else
			B738DR_align_time = 0
		end
	elseif cmd == 2 then
		if B738DR_refuel_time == 0 then
			B738DR_refuel_time = 1
		elseif B738DR_refuel_time == 1 then
			B738DR_refuel_time = 2
		else
			B738DR_refuel_time = 0
		end
	elseif cmd == 3 then
		if B738DR_pax_time == 0 then
			B738DR_pax_time = 1
		elseif B738DR_pax_time == 1 then
			B738DR_pax_time = 2
		else
			B738DR_pax_time = 0
		end
	elseif cmd == 4 then
		if B738DR_cargo_time == 0 then
			B738DR_cargo_time = 1
		elseif B738DR_cargo_time == 1 then
			B738DR_cargo_time = 2
		else
			B738DR_cargo_time = 0
		end
	elseif cmd == 5 then
		if B738DR_catering_time == 0 then
			B738DR_catering_time = 1
		elseif B738DR_catering_time == 1 then
			B738DR_catering_time = 2
		else
			B738DR_catering_time = 0
		end
	elseif cmd == 6 then
		B738CMD_pause_td_toggle:once()
	elseif cmd == 7 then
		if B738DR_tire_blown == 0 then
			B738DR_tire_blown = 1
		else
			B738DR_tire_blown = 0
		end
	elseif cmd == 8 then
		if B738DR_yoke_disco_ap == 0 then
			B738DR_yoke_disco_ap = 1
		elseif B738DR_yoke_disco_ap == 1 then
			B738DR_yoke_disco_ap = 2
		else
			B738DR_yoke_disco_ap = 0
		end
	elseif cmd == 9 then
		if B738DR_parkbrake_set == 0 then
			B738DR_parkbrake_set = 1
		else
			B738DR_parkbrake_set = 0
		end
	elseif cmd == 10 then
		if B738DR_fmc_input_lag == 0 then
			B738DR_fmc_input_lag = 1
		else
			B738DR_fmc_input_lag = 0
		end
	elseif cmd == 11 then
		if B738DR_ap_yoke_tolerance == 0 then
			B738DR_ap_yoke_tolerance = 1
		else
			B738DR_ap_yoke_tolerance = 0
		end
	elseif cmd == 12 then
		if B738DR_autosave == 0 then
			B738DR_autosave = 1
		elseif B738DR_autosave == 1 then
			B738DR_autosave = 2
		elseif B738DR_autosave == 2 then
			B738DR_autosave = 3
		else
			B738DR_autosave = 0
		end
	elseif cmd == 13 then
		if B738DR_max_rnd_fail == 10 then
			B738DR_max_rnd_fail = 1;
		else
			B738DR_max_rnd_fail = math.floor(B738DR_max_rnd_fail + 1)
		end
	elseif cmd == 14 then
		if B738DR_pause_load_flt == 0 then
			B738DR_pause_load_flt = 1
		else
			B738DR_pause_load_flt = 0
		end
	end
end

function page_visual()
	
	line_c[0] =   "          VISUAL EFFECTS              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  WINDSHIELD EFFECTS      /  /   /   "
		if simDR_int_ver >= 120000 then
			line_s[1] = "                        ON XE SKI OFF"
		elseif B738DR_b737_variant >= 0 then
			line[1] = "  WINDSHIELD EFFECTS              /  "
			if B738DR_kill_windshield < 3 then
				line_g[1] = "                                   ON"
				line_s[1] = "                               OFF   "
			else
				line_g[1] = "                               OFF   "
				line_s[1] = "                                   ON"
			end
		elseif B738DR_kill_windshield == 0 then
			line_g[1] = "                        ON           "
			line_s[1] = "                           XE SKI OFF"
		elseif B738DR_kill_windshield == 1 then
			line_g[1] = "                           XE        "
			line_s[1] = "                        ON    SKI OFF"
		elseif B738DR_kill_windshield == 2 then
			line_g[1] = "                              SKI    "
			line_s[1] = "                        ON XE     OFF"
		else
			line_g[1] = "                                  OFF"
			line_s[1] = "                        ON XE SKI    "
		end
		
		if B738DR_b737_variant < 0 then
			line[2] = "  WINDSHIELD REFLECTION           /"
			if B738DR_hide_glass == 1 then
				line_g[2] = "                               OFF   "
				line_s[2] = "                                   ON"
			else
				line_g[2] = "                                   ON"
				line_s[2] = "                               OFF   "
			end
			
			line[3] = "  GAUGES REFLECTION               /"
			if B738DR_hide_gauges_reflection == 1 then
				line_g[3] = "                               OFF   "
				line_s[3] = "                                   ON"
			else
				line_g[3] = "                                   ON"
				line_s[3] = "                               OFF   "
			end
		else
			line[2] = "  COCKPIT GLASS                   /"
			if B738DR_hide_gauges_reflection == 1 then
				line_g[2] = "                               OFF   "
				line_s[2] = "                                   ON"
			else
				line_g[2] = "                                   ON"
				line_s[2] = "                               OFF   "
			end
			line_s[3] = "  /WINDSHIELD AND GAUGES REFLECTION/"
		end
		
		line[4] = "  HARDWARE THROTTLE ON EICAS      /"
		if B738DR_hardware_thr_lever == 0 then
			line_g[4] = "                               OFF   "
			line_s[4] = "                                   ON"
		else
			line_g[4] = "                                   ON"
			line_s[4] = "                               OFF   "
		end
		
		if B738DR_b737_variant < 0 then
			line[5] = "  PASSENGERS               /    /    "
			if B738DR_passengers == 1 then
				line_g[5] = "                            HIDE     "
				line_s[5] = "                       SHOW      AUTO"
			elseif B738DR_passengers == 2 then
				line_g[5] = "                                 AUTO"
				line_s[5] = "                       SHOW HIDE     "
			else
				line_g[5] = "                       SHOW          "
				line_s[5] = "                            HIDE AUTO"
			end
		else
			line[5] = "  PASSENGERS                         "
			line_s[5] = "                        NOT AVAILABLE"
		end
		
		line[6] = "  STROBE EFFECT IN COCKPIT        /"
		if B738DR_strobe_cockpit == 0 then
			line_g[6] = "                               OFF   "
			line_s[6] = "                                   ON"
		else
			line_g[6] = "                                   ON"
			line_s[6] = "                               OFF   "
		end
		
		if simDR_int_ver >= 120000 then
			line[7] = "  VR PARTICLE WINDSHIELD RAIN      "
			line_s[7] = "                                  OFF"
		else
			line[7] = "  VR PARTICLE WINDSHIELD RAIN     /"
			if B738DR_particle_rain == 0 then
				line_g[7] = "                               OFF   "
				line_s[7] = "                                   ON"
			else
				line_g[7] = "                                   ON"
				line_s[7] = "                               OFF   "
			end
		end
		
		line[8] = "  SHOW FPS/ERROR NO.              /"
		if B738DR_fps_enable == 0 then
			line_g[8] = "                               OFF   "
			line_s[8] = "                                   ON"
		else
			line_g[8] = "                                   ON"
			line_s[8] = "                               OFF   "
		end
		
		line[9] = "  FLIGHT DIRECTOR HELPER          /"
		if B738DR_fd_helper == 0 then
			line_g[9] = "                               OFF   "
			line_s[9] = "                                   ON"
		else
			line_g[9] = "                                   ON"
			line_s[9] = "                               OFF   "
		end
		
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		if B738DR_b737_variant >= 0 then
			-- B738DR_tab_line_manip[1] = 0
			B738DR_tab_line_manip[5] = 0
		end
		
	elseif page == 2 then
		line[1] = "  MANIP. YOKE                   /"
		if B738DR_manip_yoke == 0 then
			line_g[1] = "                            SHOW     "
			line_s[1] = "                                 HIDE"
		else
			line_g[1] = "                                 HIDE"
			line_s[1] = "                            SHOW     "
		end
		
		line[2] = "  MANIP. THROTTLE               /"
		if B738DR_manip_throttle == 0 then
			line_g[2] = "                            SHOW     "
			line_s[2] = "                                 HIDE"
		else
			line_g[2] = "                                 HIDE"
			line_s[2] = "                            SHOW     "
		end
		
		line[3] = "  MANIP. FLAPS                  /"
		if B738DR_manip_flaps == 0 then
			line_g[3] = "                            SHOW     "
			line_s[3] = "                                 HIDE"
		else
			line_g[3] = "                                 HIDE"
			line_s[3] = "                            SHOW     "
		end
		
		line[4] = "  MANIP. SPEEDBRAKE             /"
		if B738DR_manip_speedbrake == 0 then
			line_g[4] = "                            SHOW     "
			line_s[4] = "                                 HIDE"
		else
			line_g[4] = "                                 HIDE"
			line_s[4] = "                            SHOW     "
		end
		
		line[5] = "  MANIP. TRIMWHEEL              /"
		if B738DR_manip_trimwheel == 0 then
			line_g[5] = "                            SHOW     "
			line_s[5] = "                                 HIDE"
		else
			line_g[5] = "                                 HIDE"
			line_s[5] = "                            SHOW     "
		end
		
		line[6] = "  MANIP. PARKING BRAKE          /"
		if B738DR_manip_park_brake == 0 then
			line_g[6] = "                            SHOW     "
			line_s[6] = "                                 HIDE"
		else
			line_g[6] = "                                 HIDE"
			line_s[6] = "                            SHOW     "
		end
		
		line[7] = "  MANIP. STAB TRIM CUTOUT       /"
		if B738DR_manip_stab_trim == 0 then
			line_g[7] = "                            SHOW     "
			line_s[7] = "                                 HIDE"
		else
			line_g[7] = "                                 HIDE"
			line_s[7] = "                            SHOW     "
		end
		
		line[8] = "  MANIP. FUEL CUTOUT            /"
		if B738DR_manip_fuelcutout == 0 then
			line_g[8] = "                            SHOW     "
			line_s[8] = "                                 HIDE"
		else
			line_g[8] = "                                 HIDE"
			line_s[8] = "                            SHOW     "
		end
		
		line[9] = "  MANIP. HORN CUTOUT            /"
		if B738DR_manip_horn_cutout == 0 then
			line_g[9] = "                            SHOW     "
			line_s[9] = "                                 HIDE"
		else
			line_g[9] = "                                 HIDE"
			line_s[9] = "                            SHOW     "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 6, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 3 then
		line[1] = "  3D ARROW HELPER               /"
		if B738DR_arrow_3d_helper == 0 then
			line_g[1] = "                                 HIDE"
			line_s[1] = "                            SHOW     "
		else
			line_g[1] = "                            SHOW     "
			line_s[1] = "                                 HIDE"
		end
		
		line[2] = "  EFB COLORIZE                   /"
		if B738DR_efb_colorize == 0 then
			line_g[2] = "                               NO    "
			line_s[2] = "                                  YES"
		else
			line_g[2] = "                                  YES"
			line_s[2] = "                               NO    "
		end
		
		line[3] = "  EFB BRIGHTNESS           /   /     "
		if B738DR_efb_brightness == 0 then
			line_g[3] = "                       AUTO          "
			line_s[3] = "                            DAY NIGHT"
		elseif B738DR_efb_brightness == 1 then
			line_g[3] = "                            DAY      "
			line_s[3] = "                       AUTO     NIGHT"
		else
			line_g[3] = "                                NIGHT"
			line_s[3] = "                       AUTO DAY      "
		end
		
		line[4] = "  VANISH_Y VALUE /400-600/       "
		line_g[4] = "                                  " .. string.format("%3d", B738DR_vanish_y)
		line_g[4] = "                                  " .. string.format("%3d", B738DR_vanish_y)
		line_s[5] = "   NEED RELOAD PLANE FOR SEE CHANGES "
		
		-- enable/disable manip
		for i = 0, 4 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 5, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		-- if simDR_int_ver >= 120000 then
			-- B738DR_tab_line_manip[3] = 0
		-- end
	end
	
end

function cmd_visual(cmd)
	if cmd == 1 then
		if simDR_int_ver < 120000 then
			if B738DR_b737_variant < 0 then
				if B738DR_kill_windshield == 0 then
					B738DR_kill_windshield = 1
				elseif B738DR_kill_windshield == 1 then
					B738DR_kill_windshield = 2
				elseif B738DR_kill_windshield == 2 then
					B738DR_kill_windshield = 3
				else
					B738DR_kill_windshield = 0
				end
			else
				if B738DR_kill_windshield < 3 then
					B738DR_kill_windshield = 3
				else
					B738DR_kill_windshield = 2
				end
			end
		end
	elseif cmd == 2 then
		if B738DR_b737_variant < 0 then
			if B738DR_hide_glass == 0 then
				B738DR_hide_glass = 1
			else
				B738DR_hide_glass = 0
			end
		else
			if B738DR_hide_gauges_reflection == 0 then
				B738DR_hide_gauges_reflection = 1
			else
				B738DR_hide_gauges_reflection = 0
			end
		end
	elseif cmd == 3 and B738DR_b737_variant < 0 then
		if B738DR_hide_gauges_reflection == 0 then
			B738DR_hide_gauges_reflection = 1
		else
			B738DR_hide_gauges_reflection = 0
		end
	elseif cmd == 4 then
		if B738DR_hardware_thr_lever == 0 then
			B738DR_hardware_thr_lever = 1
		else
			B738DR_hardware_thr_lever = 0
		end
	elseif cmd == 5 and B738DR_b737_variant < 0 then
		if B738DR_passengers == 0 then
			B738DR_passengers = 1
		elseif B738DR_passengers == 1 then
			B738DR_passengers = 2
		else
			B738DR_passengers = 0
		end
	elseif cmd == 6 then
		if B738DR_strobe_cockpit == 0 then
			B738DR_strobe_cockpit = 1
		else
			B738DR_strobe_cockpit = 0
		end
	elseif cmd == 7 then
		if simDR_int_ver < 120000 then
			if B738DR_particle_rain == 0 then
				B738DR_particle_rain = 1
			else
				B738DR_particle_rain = 0
			end
		end
	elseif cmd == 8 then
		if B738DR_fps_enable == 0 then
			B738DR_fps_enable = 1
		else
			B738DR_fps_enable = 0
		end
	elseif cmd == 9 then
		if B738DR_fd_helper == 0 then
			B738DR_fd_helper = 1
		else
			B738DR_fd_helper = 0
		end
	elseif cmd == 10 then
		if B738DR_manip_yoke == 0 then
			B738DR_manip_yoke = 1
		else
			B738DR_manip_yoke = 0
		end
	elseif cmd == 11 then
		if B738DR_manip_throttle == 0 then
			B738DR_manip_throttle = 1
		else
			B738DR_manip_throttle = 0
		end
	elseif cmd == 12 then
		if B738DR_manip_flaps == 0 then
			B738DR_manip_flaps = 1
		else
			B738DR_manip_flaps = 0
		end
	elseif cmd == 13 then
		if B738DR_manip_speedbrake == 0 then
			B738DR_manip_speedbrake = 1
		else
			B738DR_manip_speedbrake = 0
		end
	elseif cmd == 14 then
		if B738DR_manip_trimwheel == 0 then
			B738DR_manip_trimwheel = 1
		else
			B738DR_manip_trimwheel = 0
		end
	elseif cmd == 15 then
		if B738DR_manip_park_brake == 0 then
			B738DR_manip_park_brake = 1
		else
			B738DR_manip_park_brake = 0
		end
	elseif cmd == 16 then
		if B738DR_manip_stab_trim == 0 then
			B738DR_manip_stab_trim = 1
		else
			B738DR_manip_stab_trim = 0
		end
	elseif cmd == 17 then
		if B738DR_manip_fuelcutout == 0 then
			B738DR_manip_fuelcutout = 1
		else
			B738DR_manip_fuelcutout = 0
		end
	elseif cmd == 18 then
		if B738DR_manip_horn_cutout == 0 then
			B738DR_manip_horn_cutout = 1
		else
			B738DR_manip_horn_cutout = 0
		end
	elseif cmd == 19 then
		if B738DR_arrow_3d_helper == 0 then
			B738DR_arrow_3d_helper = 1
		else
			B738DR_arrow_3d_helper = 0
		end
	elseif cmd == 20 then
		if B738DR_efb_colorize == 0 then
			B738DR_efb_colorize = 1
		else
			B738DR_efb_colorize = 0
		end
	elseif cmd == 21 then
		if B738DR_efb_brightness == 0 then
			B738DR_efb_brightness = 1
		elseif B738DR_efb_brightness == 1 then
			B738DR_efb_brightness = 2
		else
			B738DR_efb_brightness = 0
		end
	elseif cmd == 22 then
		-- if simDR_int_ver < 120000 then
			numpad_ref = 500
			activate_numpad()
		-- end
	end
end

function page_config()
	
	line_c[0] =   "     GENERAL CONFIGURATION            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  GLOBAL UNITS                   /   "
		if B738DR_fmc_units == 0 then
			line_g[1] = "                              LBS    "
			line_s[1] = "                                  KGS"
		else
			line_g[1] = "                                  KGS"
			line_s[1] = "                              LBS    "
		end
		
		line[2] = "  BARO UNITS ON STARTUP          / "
		if B738DR_baro_in_hpa == 0 then
			line_g[2] = "                               IN    "
			line_s[2] = "                                  HPA"
		else
			line_g[2] = "                                  HPA"
			line_s[2] = "                               IN    "
		end
		
		line[3] = "  MINIMUMS RADIO/BARO           /   "
		if B738DR_min_baro_radio == 0 then
			line_g[3] = "                           RADIO     "
			line_s[3] = "                                 BARO"
		else
			line_g[3] = "                                 BARO"
			line_s[3] = "                           RADIO     "
		end
		
		line[4] = "  HIDE YOKE                     /  "
		if simDR_hide_yoke == 0 then
			line_g[4] = "                            HIDE     "
			line_s[4] = "                                 SHOW"
		else
			line_g[4] = "                                 SHOW"
			line_s[4] = "                            HIDE     "
		end
		
		line[5] = "  CHOCKS ON STARTUP               /"
		if B738DR_chock_on_startup == 0 then
			line_g[5] = "                               OFF   "
			line_s[5] = "                                   ON"
		else
			line_g[5] = "                                   ON"
			line_s[5] = "                               OFF   "
		end
		
		line[6] = "  ENG NO RUN              /        "
		if B738DR_engine_no_running_state == 0 then
			line_g[6] = "                 COLD-DARK           "
			line_s[6] = "                           TURNAROUND"
		else
			line_g[6] = "                           TURNAROUND"
			line_s[6] = "                 COLD-DARK           "
		end
		
		line[7] = "  GND POWER CABLE            /   /   "
		if B738DR_auto_flight ~= 0 then
			line_s[7] = "                         AUTO BCN OFF"
		elseif B738DR_gp_cable_connect == 0 then
			line_g[7] = "                         AUTO        "
			line_s[7] = "                              BCN OFF"
		elseif B738DR_gp_cable_connect == 1 then
			line_g[7] = "                              BCN    "
			line_s[7] = "                         AUTO     OFF"
		else
			line_g[7] = "                                  OFF"
			line_s[7] = "                         AUTO BCN    "
		end
		
		line[8] = "  FLIGHT PLAN SAVE FORMAT        / "
		if B738DR_fpln_format == 0 then
			line_g[8] = "                              FMX    "
			line_s[8] = "                                  FMS"
		else
			line_g[8] = "                                  FMS"
			line_s[8] = "                              FMX    "
		end
		
		line[9] = "  CHECKLIST                   /      "
		if B738DR_detail_cl == 0 then
			line_g[9] = "                        SIMPLE       "
			line_s[9] = "                               DETAIL"
		else
			line_g[9] = "                               DETAIL"
			line_s[9] = "                        SIMPLE       "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
	
	elseif page == 2 then
		line[1] = "  SYNC PILOT QNH MINIMUM      /   /  "
		if B738DR_sync_pilot == 0 then
			line_g[1] = "                           OFF       "
			line_s[1] = "                               CPT FO"
		elseif B738DR_sync_pilot == 1 then
			line_g[1] = "                               CPT   "
			line_s[1] = "                           OFF     FO"
		else
			line_g[1] = "                                   FO"
			line_s[1] = "                           OFF CPT   "
		end
		
		line[2] = "  SYNC PILOT STDBY BARO       /   /  "
		if B738DR_sync_pilot_isdf == 0 then
			line_g[2] = "                           OFF       "
			line_s[2] = "                               CPT FO"
		elseif B738DR_sync_pilot_isdf == 1 then
			line_g[2] = "                               CPT   "
			line_s[2] = "                           OFF     FO"
		else
			line_g[2] = "                                   FO"
			line_s[2] = "                           OFF CPT   "
		end
		
		line[3] = "  HEADSET COM RADIO           /  /   "
		if B738DR_prior_tx_com == 0 then
			line_g[3] = "                           CPT       "
			line_s[3] = "                               FO OVH"
		elseif B738DR_prior_tx_com == 1 then
			line_g[3] = "                               FO    "
			line_s[3] = "                           CPT    OVH"
		else
			line_g[3] = "                                  OVH"
			line_s[3] = "                           CPT FO    "
		end
		
		line[4] = "  HIDE COCKPIT SEATS             /"
		if B738DR_hide_seats == 0 then
			line_g[4] = "                               NO    "
			line_s[4] = "                                  YES"
		else
			line_g[4] = "                                  YES"
			line_s[4] = "                               NO    "
		end
		
		line[5] = "  BUILT-IN GND SERVICES          /"
		if B738DR_auto_flight ~= 0 then
			line_s[5] = "                               NO YES"
		elseif B738DR_int_gnd_services == 0 then
			line_g[5] = "                                  YES"
			line_s[5] = "                               NO    "
		else
			line_g[5] = "                               NO    "
			line_s[5] = "                                  YES"
		end
		
		line[6] = "  CREATE CUSTOM NAVDATA           /"
		if B738DR_cust_nav_data == 0 then
			line_g[6] = "                               OFF   "
			line_s[6] = "                                   ON"
			line_s[7] =   "  - NEED RESTART XPLANE FOR CHANGES   "
		else
			line_g[6] = "                                   ON"
			line_s[6] = "                               OFF   "
			line_s[7] =   "  - USE ON OWN RISK ONLY              "
			line_s[8] =   "  - YOU LOST YOUR USER NAV DATA       "
			-- line_s[9] =   "  - DO NOT REPORT BUG TO LR           "
			line_s[9] =   "  - NEED RESTART XPLANE FOR CHANGES   "
		end
		
		-- enable/disable manip
		for i = 0, 6 do		--0, 2
			B738DR_tab_line_manip[i] = 1
		end
		for i = 7, 9 do		--3, 9
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_config(cmd)
	if cmd == 1 then
		B738CMD_change_units:once()
	elseif cmd == 2 then
		if B738DR_baro_in_hpa == 0 then
			B738DR_baro_in_hpa = 1
		else
			B738DR_baro_in_hpa = 0
		end
	elseif cmd == 3 then
		if B738DR_min_baro_radio == 0 then
			B738DR_min_baro_radio = 1
		else
			B738DR_min_baro_radio = 0
		end
	elseif cmd == 4 then
		if simDR_hide_yoke == 0 then
			simDR_hide_yoke = 1
		else
			simDR_hide_yoke = 0
		end
	elseif cmd == 5 then
		--B738CMD_chock_toggle:once()
		if B738DR_chock_on_startup == 0 then
			B738DR_chock_on_startup = 1
		else
			B738DR_chock_on_startup = 0
		end
	elseif cmd == 6 then
		if B738DR_engine_no_running_state == 0 then
			B738DR_engine_no_running_state = 1
		else
			B738DR_engine_no_running_state = 0
		end
	elseif cmd == 7 then
		if B738DR_auto_flight == 0 then
			if B738DR_gp_cable_connect == 0 then
				B738DR_gp_cable_connect = 1
			elseif B738DR_gp_cable_connect == 1 then
				B738DR_gp_cable_connect = 2
			else
				B738DR_gp_cable_connect = 0
			end
		end
	elseif cmd == 8 then
		if B738DR_fpln_format == 0 then
			B738DR_fpln_format = 1
		else
			B738DR_fpln_format = 0
		end
	elseif cmd == 9 then
		if B738DR_detail_cl == 0 then
			B738DR_detail_cl = 1
		else
			B738DR_detail_cl = 0
		end
		-- clear items checked
		for ii = 0, 511 do
			item_checked[ii] = 0
		end
	elseif cmd == 10 then
		if B738DR_sync_pilot == 0 then
			B738DR_sync_pilot = 1
		elseif B738DR_sync_pilot == 1 then
			B738DR_sync_pilot = 2
		else
			B738DR_sync_pilot = 0
		end
	elseif cmd == 11 then
		if B738DR_sync_pilot_isdf == 0 then
			B738DR_sync_pilot_isdf = 1
		elseif B738DR_sync_pilot_isdf == 1 then
			B738DR_sync_pilot_isdf = 2
		else
			B738DR_sync_pilot_isdf = 0
		end
	elseif cmd == 12 then
		if B738DR_prior_tx_com == 0 then
			B738DR_prior_tx_com = 1
		elseif B738DR_prior_tx_com == 1 then
			B738DR_prior_tx_com = 2
		else
			B738DR_prior_tx_com = 0
		end
	elseif cmd == 13 then
		if B738DR_hide_seats == 0 then
			B738DR_hide_seats = 1
		else
			B738DR_hide_seats = 0
		end
	elseif cmd == 14 then
		if B738DR_auto_flight == 0 then
			if B738DR_int_gnd_services == 0 then
				B738DR_int_gnd_services = 1
			else
				B738DR_int_gnd_services = 0
			end
		end
	elseif cmd == 15 then
		if B738DR_cust_nav_data == 0 then
			B738DR_cust_nav_data = 1
		else
			B738DR_cust_nav_data = 0
		end
	end
end

function page_calibration()
	
	local fd_raw = ""
	line_c[0] =   "       HARDWARE CALIBRATION           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  PITCH NULL ZONE                    "
		line_g[1] = "                                   " .. string.format("%2d", B738DR_pitch_nz * 100)
		if B738DR_joy_axis_pitch >= 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_joy_axis_pitch)
		else
			fd_raw = string.format("%07.5f", B738DR_joy_axis_pitch)
		end
		line_s[1] = "                  " .. fd_raw .. "  /0-30/    "
		
		line[2] =   "  ROLL NULL ZONE                     "
		line_g[2] = "                                   " .. string.format("%2d", B738DR_roll_nz * 100)
		if B738DR_joy_axis_roll >= 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_joy_axis_roll)
		else
			fd_raw = string.format("%07.5f", B738DR_joy_axis_roll)
		end
		line_s[2] = "                  " .. fd_raw .. "  /0-30/    "
		
		line[3] =   "  YAW NULL ZONE                      "
		line_g[3] = "                                   " .. string.format("%2d", B738DR_yaw_nz * 100)
		if B738DR_joy_axis_heading >= 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_joy_axis_heading)
		else
			fd_raw = string.format("%07.5f", B738DR_joy_axis_heading)
		end
		line_s[3] = "                  " .. fd_raw .. "  /0-30/    "
		
		line[4] = "  CUSTOM FLAP AXIS                   "
		if B738DR_cfy_enable ~= 0 then
			line_g[4] = "                                  CFY"
		elseif B738DR_cust_axis_flaps_mapped == -1 then
			line_g[4] = "                                 NONE"
		else
			line_g[4] = "                                  " .. string.format("%3d", B738DR_cust_axis_flaps_mapped)
		end
		
		line[5] = "  FLAPS AXIS REVERSE              /"
		if B738DR_cust_axis_flaps_reverse == 0 then
			line_g[5] = "                               OFF   "
			line_s[5] = "                                   ON"
		else
			line_g[5] = "                                   ON"
			line_s[5] = "                               OFF   "
		end
		
		line[6] =   "  FLAP DETENT                        "
		fd_raw = " " .. string.format("%07.5f", B738DR_flap_detents[flap_detents])
		line_g[6] = "                  " .. fd_raw .. "         " .. flap_detents_txt[flap_detents+1]
		line_s[6] = "                           /UP-40/   "
		if B738DR_cfy_enable ~= 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_flaps)
		elseif B738DR_cust_axis_flaps_mapped == -1 then
			fd_raw = " " .. string.format("%07.5f", B738DR_joy_axis_flap_lever)
		else
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_flaps)
		end
		line[7] =   "    FLAP POSITION               >SET<"
		line_s[7] = "                  " .. fd_raw
		
		line[8] =   "  CUSTOM SPEEDBRAKE AXIS             "
		if B738DR_cfy_enable ~= 0 then
			line_g[8] = "                                  CFY"
		elseif B738DR_cust_axis_speedbrake_mapped == -1 then
			line_g[8] = "                                 NONE"
		else
			line_g[8] = "                                  " .. string.format("%3d", B738DR_cust_axis_speedbrake_mapped)
		end
		
		line[9] = "  SPEEDBRAKE AXIS REVERSE         /"
		if B738DR_cust_axis_speedbrake_reverse == 0 then
			line_g[9] = "                               OFF   "
			line_s[9] = "                                   ON"
		else
			line_g[9] = "                                   ON"
			line_s[9] = "                               OFF   "
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 6, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] = "  SPEEDBRAKE DETENTS NOISE           "
		line_g[1] = "                                    " .. string.format("%1d", B738DR_cust_axis_speedbrake_noise)
		
		line[2] =   "  SPEEDBRAKE DETENT                  "
		if speedbrake_detents == 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_speedbrake_arm)
		else
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_speedbrake_flight)
		end
		line_g[2] = "                   " .. fd_raw .. "    " .. speedbrake_detents_txt[speedbrake_detents+1]
		
		if B738DR_cfy_enable ~= 0 then
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_speedbrake)
		elseif B738DR_cust_axis_speedbrake_mapped == -1 then
			--fd_raw = " " .. string.format("%07.5f", B738DR_joy_axis_flap_lever)
			fd_raw = "    NONE"
		else
			fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_speedbrake)
		end
		line[3] =   "    SPEEDBRAKE POS              >SET<"
		line_s[3] = "                   " .. fd_raw
		
		line[4] =   "  CUSTOM LANDINGGEAR AXIS            "
		if B738DR_cust_axis_landgear_mapped == -1 then
			line_g[4] = "                                 NONE"
		else
			line_g[4] = "                                  " .. string.format("%3d", B738DR_cust_axis_landgear_mapped)
		end
		
		line[5] = "  LANDINGGEAR AXIS REVERSE        /"
		if B738DR_cust_axis_landgear_reverse == 0 then
			line_g[5] = "                               OFF   "
			line_s[5] = "                                   ON"
		else
			line_g[5] = "                                   ON"
			line_s[5] = "                               OFF   "
		end
		
		if B738DR_cust_axis_speedbrake_mapped == -1 then
			fd_raw = "    NONE"
		else
			if B738DR_cust_axis_landgear_off == 0 then
				fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_landgear)
			else
				fd_raw = " " .. string.format("%07.5f", B738DR_cust_axis_landgear_off)
			end
		end
		line[6] =   "    LANDG OFF  POS              >SET<"
		line_s[6] = "                   " .. fd_raw
		
		line[7] =   "  CUSTOM MIXTURE1 AXIS               "
		if B738DR_cust_axis_mixture1_mapped == -1 then
			line_g[7] = "                                 NONE"
		else
			line_g[7] = "                                  " .. string.format("%3d", B738DR_cust_axis_mixture1_mapped)
		end
		
		line[8] = "  MIXTURE1 AXIS REVERSE           /"
		if B738DR_cust_axis_mixture1_reverse == 0 then
			line_g[8] = "                               OFF   "
			line_s[8] = "                                   ON"
		else
			line_g[8] = "                                   ON"
			line_s[8] = "                               OFF   "
		end
		
		line[9] =   "  CUSTOM MIXTURE2 AXIS               "
		if B738DR_cust_axis_mixture2_mapped == -1 then
			line_g[9] = "                                 NONE"
		else
			line_g[9] = "                                  " .. string.format("%3d", B738DR_cust_axis_mixture2_mapped)
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 4, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	else
		line[1] = "  MIXTURE2 AXIS REVERSE           /"
		if B738DR_cust_axis_mixture2_reverse == 0 then
			line_g[1] = "                               OFF   "
			line_s[1] = "                                   ON"
		else
			line_g[1] = "                                   ON"
			line_s[1] = "                               OFF   "
		end
		
		-- add Custom Thrust axis: Thrust all, Thrust 1, Thrust 2
		-- add Custom Reverse axis: Reverse all, Reverse 1, Reverse 2
		
		-- enable/disable manip
		for i = 0, 1 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 2, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		
	end
end


function cmd_calibration(cmd)
	if cmd == 1 then
		-- pitch null zone
		numpad_ref = 3
		activate_numpad()
	elseif cmd == 2 then
		-- roll null zone
		numpad_ref = 4
		activate_numpad()
	elseif cmd == 3 then
		-- yaw null zone
		numpad_ref = 5
		activate_numpad()
	elseif cmd == 4 then
		-- custom flap axis
		B738_mem_axis_value()
		numpad_ref = 6
		activate_numpad()
	elseif cmd == 5 then
		-- flap reverse
		if B738DR_cust_axis_flaps_reverse == 0 then
			B738DR_cust_axis_flaps_reverse = 1
		else
			B738DR_cust_axis_flaps_reverse = 0
		end
	elseif cmd == 6 then
		-- change flap
		if flap_detents < 8 then
			flap_detents = flap_detents + 1
		else
			flap_detents = 0
		end
	elseif cmd == 7 then
		-- set flap detent
		if flap_detents == 0 then
			B738CMD_set_flap_up:once()
		elseif flap_detents == 1 then
			B738CMD_set_flap_1:once()
		elseif flap_detents == 2 then
			B738CMD_set_flap_2:once()
		elseif flap_detents == 3 then
			B738CMD_set_flap_5:once()
		elseif flap_detents == 4 then
			B738CMD_set_flap_10:once()
		elseif flap_detents == 5 then
			B738CMD_set_flap_15:once()
		elseif flap_detents == 6 then
			B738CMD_set_flap_25:once()
		elseif flap_detents == 7 then
			B738CMD_set_flap_30:once()
		elseif flap_detents == 8 then
			B738CMD_set_flap_40:once()
		end
	elseif cmd == 8 then
		-- custom speedbrake axis
		B738_mem_axis_value()
		numpad_ref = 7
		activate_numpad()
	elseif cmd == 9 then
		-- speedbrake reverse
		if B738DR_cust_axis_speedbrake_reverse == 0 then
			B738DR_cust_axis_speedbrake_reverse = 1
		else
			B738DR_cust_axis_speedbrake_reverse = 0
		end
	elseif cmd == 10 then
		-- custom speedbrake detents noise
		if B738DR_cust_axis_speedbrake_noise < 9 then
			B738DR_cust_axis_speedbrake_noise = B738DR_cust_axis_speedbrake_noise + 1
		else
			B738DR_cust_axis_speedbrake_noise = 0
		end
	elseif cmd == 11 then
		-- change speedbrake detents
		if speedbrake_detents == 0 then
			speedbrake_detents = 1
		else
			speedbrake_detents = 0
		end
	elseif cmd == 12 then
		-- set speedbrake detent
		if B738DR_cfy_enable ~= 0 then
			if speedbrake_detents == 0 then
				B738DR_cust_axis_speedbrake_arm = B738DR_cust_axis_speedbrake
			else
				B738DR_cust_axis_speedbrake_flight = B738DR_cust_axis_speedbrake
			end
		elseif B738DR_cust_axis_speedbrake_mapped >= 0 then
			if speedbrake_detents == 0 then
				B738DR_cust_axis_speedbrake_arm = B738DR_cust_axis_speedbrake
			else
				B738DR_cust_axis_speedbrake_flight = B738DR_cust_axis_speedbrake
			end
		end
	elseif cmd == 13 then
		-- custom landing gear axis
		B738_mem_axis_value()
		numpad_ref = 8
		activate_numpad()
	elseif cmd == 14 then
		-- landing gear reverse
		if B738DR_cust_axis_landgear_reverse == 0 then
			B738DR_cust_axis_landgear_reverse = 1
		else
			B738DR_cust_axis_landgear_reverse = 0
		end
	elseif cmd == 15 then
		-- set landing gear OFF detent
		if B738DR_cust_axis_speedbrake_mapped >= 0 then
			B738DR_cust_axis_landgear_off = B738DR_cust_axis_landgear
		end
	elseif cmd == 16 then
		-- custom mixture1 axis
		B738_mem_axis_value()
		numpad_ref = 9
		activate_numpad()
	elseif cmd == 17 then
		-- mixture1 reverse
		if B738DR_cust_axis_mixture1_reverse == 0 then
			B738DR_cust_axis_mixture1_reverse = 1
		else
			B738DR_cust_axis_mixture1_reverse = 0
		end
	elseif cmd == 18 then
		-- custom mixture1 axis
		B738_mem_axis_value()
		numpad_ref = 10
		activate_numpad()
	elseif cmd == 19 then
		-- mixture1 reverse
		if B738DR_cust_axis_mixture2_reverse == 0 then
			B738DR_cust_axis_mixture2_reverse = 1
		else
			B738DR_cust_axis_mixture2_reverse = 0
		end
	end
end


function cmd_doors(cmd)
	if cmd == 2 then
		B738CMD_door_fwd_L_toggle:once()
	elseif cmd == 3 then
		B738CMD_door_fwd_R_toggle:once()
	elseif cmd == 4 then
		B738CMD_door_fwd_cargo_toggle:once()
	elseif cmd == 6 then
		B738CMD_door_aft_L_toggle:once()
	elseif cmd == 7 then
		B738CMD_door_aft_R_toggle:once()
	elseif cmd == 8 then
		B738CMD_door_aft_cargo_toggle:once()
	elseif cmd == 9 then
		B738CMD_door_emerg4_toggle:once()
	elseif cmd == 10 then
		B738CMD_door_emerg3_toggle:once()
	elseif cmd == 11 then
		B738CMD_door_emerg2_toggle:once()
	elseif cmd == 12 then
		B738CMD_door_emerg1_toggle:once()
	elseif cmd == 13 then
		B738CMD_door_emerg5_toggle:once()
	elseif cmd == 14 then
		B738CMD_door_emerg6_toggle:once()
	end
end

function page_cat_lights()
	line_c[0] =   "           CABIN LIGHTING             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line_a[1] = "  PASSENGER AREA                     "
		line[2] = "                ---->                "
		if set_pax_lighting == LIGHT_PAX_WB then
			line_g[2] = "                         WHITE BRIGHT"
		else
			line_s[2] = "                         WHITE BRIGHT"
		end
		line[3] = "                ---->                "
		if set_pax_lighting == LIGHT_PAX_WM then
			line_g[3] = "                         WHITE MEDIUM"
		else
			line_s[3] = "                         WHITE MEDIUM"
		end
		line[4] = "                ---->        /       "
		if set_pax_lighting == LIGHT_PAX_LAND then
			line_g[4] = "                      TAKEOFF LANDING"
		else
			line_s[4] = "                      TAKEOFF LANDING"
		end
		line[5] = "                ---->                "
		if set_pax_lighting == LIGHT_PAX_CRUISE then
			line_g[5] = "                               CRUISE"
		else
			line_s[5] = "                               CRUISE"
		end
		line[6] = "                ---->          /     "
		if set_pax_lighting == LIGHT_PAX_NIGHT then
			line_g[6] = "                          NIGHT      "
			line_s[6] = "                                SLEEP"
		elseif set_pax_lighting == LIGHT_PAX_SLEEP then
			line_g[6] = "                                SLEEP"
			line_s[6] = "                          NIGHT      "
		else
			line_s[6] = "                          NIGHT SLEEP"
		end
		line_a[7] = "  ENTRY AREA                         "
		line[8] = "                ---->                "
		if set_entry_lighting == LIGHT_ENTRY_WB then
			line_g[8] = "                         WHITE BRIGHT"
		else
			line_s[8] = "                         WHITE BRIGHT"
		end
		line[9] = "                ---->                "
		if set_entry_lighting == LIGHT_ENTRY_WM then
			line_g[9] = "                         WHITE MEDIUM"
		else
			line_s[9] = "                         WHITE MEDIUM"
		end
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[1] = 0
		B738DR_tab_line_manip[7] = 0
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	end
end

function cmd_lights(cmd)
	if cmd == 2 then
		B738CMD_pax_white_bright:once()
	elseif cmd == 3 then
		B738CMD_pax_white_medium:once()
	elseif cmd == 4 then
		B738CMD_pax_to_landing:once()
	elseif cmd == 5 then
		B738CMD_pax_cruise:once()
	elseif cmd == 6 then
		B738CMD_pax_night_sleep:once()
	elseif cmd == 8 then
		B738CMD_entry_white_bright:once()
	elseif cmd == 9 then
		B738CMD_entry_white_medium:once()
	end
end

function page_feature()
	line_c[0] =   "         AUDIO FEATURES               "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		if B738DR_b737_variant < 0 then
			line[1] = "  PAX BOARD                       /  "
			if B738DR_enable_pax_boarding == 0 then
				line_g[1] = "                               OFF   "
				line_s[1] = "                                   ON"
			else
				line_g[1] = "                                   ON"
				line_s[1] = "                               OFF   "
			end
			
			line[2] = "  PAX CHATTER                     /  "
			if B738DR_enable_chatter == 0 then
				line_g[2] = "                               OFF   "
				line_s[2] = "                                   ON"
			else
				line_g[2] = "                                   ON"
				line_s[2] = "                               OFF   "
			end
			
			line[3] = "  AIRPORT SET         /        /     "
			if B738DR_airport_set == 2 then
				line_g[3] = "                       REGIONAL      "
				line_s[3] = "                 BASIC          LARGE"
			elseif B738DR_airport_set == 3 then
				line_g[3] = "                                LARGE"
				line_s[3] = "                 BASIC REGIONAL      "
			else
				line_g[3] = "                 BASIC               "
				line_s[3] = "                       REGIONAL LARGE"
			end
		else
			line[1] =   "  PAX BOARD                          "
			line_s[1] = "                        NOT AVAILABLE"
			line[2] = "  PAX CHATTER                        "
			line_s[2] = "                        NOT AVAILABLE"
			line[3] = "  AIRPORT SET                        "
			line_s[3] = "                        NOT AVAILABLE"
		end
		
		line[4] = "  MUTE TRIMWHEEL                  /  "
		if B738DR_enable_mutetrim == 0 then
			line_g[4] = "                               OFF   "
			line_s[4] = "                                   ON"
		else
			line_g[4] = "                                   ON"
			line_s[4] = "                               OFF   "
		end
		
		line[5] = "  MUTE FMC                        /  "
		if B738DR_enable_fmc_mute_on == 0 then
			line_g[5] = "                               OFF   "
			line_s[5] = "                                   ON"
		else
			line_g[5] = "                                   ON"
			line_s[5] = "                               OFF   "
		end
		
		if B738DR_b737_variant < 0 then
			line[6] = "  PAX APPLAUSE                    /  "
			if B738DR_vol_int_pax_applause == 0 then
				line_g[6] = "                               OFF   "
				line_s[6] = "                                   ON"
			else
				line_g[6] = "                                   ON"
				line_s[6] = "                               OFF   "
			end
			
			line[7] = "  TO ANNOUNC.          /      /      "
			if B738DR_TO_trigger == 0 then
				line_g[7] = "                    OFF              "
				line_s[7] = "                        STROBE ATTEND"
			elseif B738DR_TO_trigger == 1 then
				line_g[7] = "                        STROBE       "
				line_s[7] = "                    OFF        ATTEND"
			else
				line_g[7] = "                               ATTEND"
				line_s[7] = "                    OFF STROBE       "
			end
			
			line[8] = "  CABIN READY                   /    "
			if B738DR_TO_airside == 0 then
				line_g[8] = "                          SAFETY     "
				line_s[8] = "                                 TAXI"
			else
				line_g[8] = "                                 TAXI"
				line_s[8] = "                          SAFETY     "
			end
			
			line[9] = "  CAPTAIN MESSAGES              /    "
			if B738DR_msg_airside == 0 then
				line_g[9] = "                             OFF     "
				line_s[9] = "                                 AUTO"
			else
				line_g[9] = "                                 AUTO"
				line_s[9] = "                             OFF     "
			end
			
			-- line[7] = "  TO ANNOUNC.          /      /      "
			-- if B738DR_panel_cab_ready ~= 0 then
				-- line_s[7] = "                WING LT POS LT ATTEND"
			-- elseif B738DR_TO_trigger == 0 then
				-- line_g[7] = "                WING LT              "
				-- line_s[7] = "                        POS LT ATTEND"
			-- elseif B738DR_TO_trigger == 1 then
				-- line_g[7] = "                        POS LT       "
				-- line_s[7] = "                WING LT        ATTEND"
			-- else
				-- line_g[7] = "                               ATTEND"
				-- line_s[7] = "                WING LT POS LT       "
			-- end
			
			-- line[8] = "  TO ANNOUNC. AIRSIDE           /    "
			-- if B738DR_TO_airside == 0 then
				-- line_g[8] = "                             OFF     "
				-- line_s[8] = "                                 AUTO"
			-- else
				-- line_g[8] = "                                 AUTO"
				-- line_s[8] = "                             OFF     "
			-- end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- B738DR_tab_line_manip[8] = 0
			-- B738DR_tab_line_manip[9] = 0
		else
			line[6] =   "  PAX APPLAUSE                       "
			line_s[6] = "                        NOT AVAILABLE"
			line[7] =   "  TO ANNOUNC.TRIGGER                 "
			line_s[7] = "                        NOT AVAILABLE"
			
			line[8] = "  MUTE SWITCHES                   /  "
			if B738DR_mute_switches == 0 then
				line_g[8] = "                               OFF   "
				line_s[8] = "                                   ON"
			else
				line_g[8] = "                                   ON"
				line_s[8] = "                               OFF   "
			end
			
			-- enable/disable manip
			for i = 0, 8 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[9] = 0
		end
		
	end
end

function cmd_feature(cmd)
	if cmd == 1 and B738DR_b737_variant < 0 then
		B738CMD_enable_pax_boarding:once()
	elseif cmd == 2 and B738DR_b737_variant < 0 then
		B738CMD_enable_chatter:once()
	elseif cmd == 3 and B738DR_b737_variant < 0 then
		B738CMD_airport_set:once()
	elseif cmd == 4 then
		B738CMD_enable_mutetrim:once()
	elseif cmd == 5 then
		B738CMD_enable_fmc_mute_on:once()
	elseif cmd == 6 and B738DR_b737_variant < 0 then
		B738CMD_vol_int_pax_applause:once()
	elseif cmd == 7 and B738DR_b737_variant < 0 then
		B738CMD_switch_TO_trigger:once()
	elseif cmd == 8 then
		if B738DR_b737_variant < 0 then
			if B738DR_TO_airside == 0 then
				B738DR_TO_airside = 1
			else
				B738DR_TO_airside = 0
			end
		else
			if B738DR_mute_switches == 0 then
				B738DR_mute_switches = 1
			else
				B738DR_mute_switches = 0
			end
		end
	elseif cmd == 9 then
		if B738DR_b737_variant < 0 then
			if B738DR_msg_airside == 0 then
				B738DR_msg_airside = 1
			else
				B738DR_msg_airside = 0
			end
		end
	end
end

function page_volume_eq()
	line_c[0] =   "        AUDIO CONFIGURATION           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] = "  PAX VOLUME                         "
		line_g[1] = "                                   " .. string.format("%2d", B738DR_vol_int_pax)
		line_s[1] = "                           /0-10/    "
		
		line[2] = "  PM VOLUME                          "
		line_g[2] = "                                   " .. string.format("%2d", B738DR_vol_PM)
		line_s[2] = "                           /0-10/    "
		
		line[3] = "  AIRPORT VOLUME                     "
		line_g[3] = "                                   " .. string.format("%2d", B738DR_vol_airport)
		line_s[3] = "                           /0-10/    "
		
		line[4] = "  GYRO VOLUME                        "
		line_g[4] = "                                   " .. string.format("%2d", B738DR_vol_int_gyro)
		line_s[4] = "                           /0-10/    "
		
		line[5] = "  ENGINE VOLUME                      "
		line_g[5] = "                                   " .. string.format("%2d", B738DR_vol_int_eng)
		line_s[5] = "                           /0-10/    "
		
		line[6] = "  AC VOLUME                          "
		line_g[6] = "                                   " .. string.format("%2d", B738DR_vol_int_ac)
		line_s[6] = "                           /0-10/    "
		
		line[7] = "  WIND VOLUME                        "
		line_g[7] = "                                   " .. string.format("%2d", B738DR_vol_int_wind_vol)
		line_s[7] = "                           /0-10/    "
		
		line[8] = "  ROLL/IMPACT VOLUME                 "
		line_g[8] = "                                   " .. string.format("%2d", B738DR_vol_int_roll)
		line_s[8] = "                           /0-10/    "
		
		line[9] = "  BUMPS VOLUME                       "
		line_g[9] = "                                   " .. string.format("%2d", B738DR_vol_int_bump)
		line_s[9] = "                           /0-10/    "
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
	elseif page == 2 then
		line[1] = "  GPWS TCAS VOLUME                   "
		line_g[1] = "                                   " .. string.format("%2d", B738DR_vol_computer)
		line_s[1] = "                           /0-10/    "
		
		line[2] = "  WEATHER VOLUME                     "
		line_g[2] = "                                   " .. string.format("%2d", B738DR_vol_weather)
		line_s[2] = "                           /0-10/    "
		
		line[3] = "  TRIM WHEEL VOLUME                  "
		line_g[3] = "                                   " .. string.format("%2d", B738DR_vol_int_trim)
		line_s[3] = "                           /0-10/    "
		
		line[4] = "  ADD LOW FREQ                       "
		line_g[4] = "                                   " .. string.format("%2d", eq_low)
		line_s[4] = "                           /0-10/    "
		
		line[5] = "  ADD MID FREQ                       "
		line_g[5] = "                                   " .. string.format("%2d", eq_mid)
		line_s[5] = "                           /0-10/    "
		
		line[6] = "  ADD HIGH FREQ                      "
		line_g[6] = "                                   " .. string.format("%2d", eq_high)
		line_s[6] = "                           /0-10/    "
		
		-- enable/disable manip
		for i = 0, 6 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 7, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_volume_eq(cmd)
	if cmd == 1 then
		B738CMD_vol_int_pax:once()
	elseif cmd == 2 then
		B738CMD_vol_PM:once()
	elseif cmd == 3 then
		B738CMD_vol_airport:once()
	elseif cmd == 4 then
		B738CMD_vol_int_gyro:once()
	elseif cmd == 5 then
		B738CMD_vol_int_eng:once()
	elseif cmd == 6 then
		B738CMD_vol_int_ac:once()
	elseif cmd == 7 then
		B738CMD_vol_int_wind:once()
	elseif cmd == 8 then
		B738CMD_vol_int_roll:once()
	elseif cmd == 9 then
		B738CMD_vol_int_bump:once()
	elseif cmd == 10 then
		B738CMD_vol_computer:once()
	elseif cmd == 11 then
		B738CMD_vol_weather:once()
	elseif cmd == 12 then
		B738CMD_vol_int_trim:once()
	elseif cmd == 13 then
		B738_eq_low:once()
	elseif cmd == 14 then
		B738_eq_mid:once()
	elseif cmd == 15 then
		B738_eq_high:once()
	end
end

function cmd_home(cmd)
	-- if B738DR_b737_variant < 0 then
		if B738DR_auto_flight == 0 then
			if cmd == 2 then
				-- START/END FLIGHT LEG
				if start_leg == 0 then
					B738_start_leg:once()
				else
					B738_end_leg:once()
				end
			elseif cmd == 3 then
				-- CARGO/CLEAN/CATER
				B738CMD_play_cargo:once()
			end
		end
		clr_menu_mark()
		if is_timer_scheduled(menu_mark_timer) == true then
			stop_timer(menu_mark_timer)
		end
		B738DR_tab_menu_mark[cmd-1] = 1
		run_after_time(menu_mark_timer, 0.4)
	-- end
end

function cmd_announc(cmd)
	-- if B738DR_b737_variant < 0 then
		if cmd == 1 then
			B738CMD_play_welcome:once()
		elseif cmd == 2 then
			B738CMD_play_cruise:once()
		elseif cmd == 3 then
			B738CMD_play_descent:once()
		elseif cmd == 4 then
			B738CMD_play_preland:once()
		elseif cmd == 5 then
			B738CMD_play_turbulence:once()
		end
		clr_menu_mark()
		if is_timer_scheduled(menu_mark_timer) == true then
			stop_timer(menu_mark_timer)
		end
		B738DR_tab_menu_mark[cmd-1] = 1
		run_after_time(menu_mark_timer, 0.4)
	-- end
end

function page_ann_set()
	if B738DR_b737_variant < 0 then
		line_c[0] =   "      ANNOUNCEMENTS SETTINGS          "
		line_s[0] = "                                " .. num_pages(page, max_page)
		
		line[1] = "  FA AND CAPTAIN                     "
		line_g[1] = "                                   " .. string.format("%2d", B738DR_vol_crew)
		line_s[1] = "                           /0-10/    "
		
		line[2] = "  FA IN COCKPIT                      "
		line_g[2] = "                                   " .. string.format("%2d", B738DR_vol_FAC)
		line_s[2] = "                           /0-10/    "
		
		line[3] = "  ANNOUNCEMENTS SET NR.              "
		--line_g[3] = "                                   " .. string.format("%2d", (B738DR_announcement_set+1))
		if B738DR_pa_announc_set == 0 then
			line_g[3] = "                                 AUTO"
		else
			line_g[3] = "                                   " .. string.format("%2d", (B738DR_pa_announc_set))
		end
		line_s[3] = "                                     "
	
		-- enable/disable manip
		for i = 0, 3 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 4, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	else
		line_c[0] = "      ANNOUNCEMENTS SETTINGS          "
		line_s[0] = "                                " .. num_pages(page, max_page)
		
		line_s[1] = "           NOT AVAILABLE"
	
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
end

function cmd_ann_set(cmd)
	local int, frac = math.modf(os.clock())
	local seed = math.random(1, frac*1000.0)
	math.randomseed(seed)
	
	if B738DR_b737_variant < 0 then
		if cmd == 1 then
			B738CMD_vol_crew:once()
		elseif cmd == 2 then
			B738CMD_vol_FAC:once()
		elseif cmd == 3 then
			--B738CMD_announcement_set:once()
			if B738DR_pa_announc_set < 24 then	--16
				B738DR_pa_announc_set = B738DR_pa_announc_set + 1
				B738DR_announcement_set = B738DR_pa_announc_set - 1
			else
				B738DR_pa_announc_set = 0	-- auto
				if string.len(livery) == 0 then
					B738DR_announcement_set = math.floor(math.random(BASE_LIVERY_SET1, BASE_LIVERY_SET2) + 0.5)
				else
					change_sound_set(livery)
				end
			end
		end
	end
end

function checklist_act_page(x_from, x_to)
	local result = -1
	local new_page = 0
	
	if page < max_page then
		for i = x_from, x_to do
			if item_checked[i] == 0 then
				result = i
				break
			end
		end
		
		if result >= 0 then
			new_page = math.floor((result - x_from) / 9) + 1
			if new_page >= min_page and new_page <= max_page then
				page = new_page
			end
		end
	end
end

function check_list_auto_page()
	if page < max_page then
		page = page + 1
	end
end

function check_items_auto(x_from, x_to, in_cmd)
	local result = 1
	
	local last_item = in_cmd % 9
	
	if page < max_page and last_item == 0 then
		for i = x_from, x_to do
			if item_checked[i] == 0 then
				result = 0
				break
			end
		end
		
		if result ~= 0 then
			--next page
			if is_timer_scheduled(check_list_auto_page) == true then
				stop_timer(check_list_auto_page)
			end
			run_after_time(check_list_auto_page, 0.4)
		end
	end
end

function check_items(x_from, x_to)
	local result = 1
	for i = x_from, x_to do
		if item_checked[i] == 0 then
			result = 0
			break
		end
	end
	return result
end

function check_items(x_from, x_to)
	local result = 1
	for i = x_from, x_to do
		if item_checked[i] == 0 then
			result = 0
			break
		end
	end
	return result
end

function check_items_help(x_from, x_to)
	local result = -1
	for i = x_from, x_to do
		if item_checked[i] == 0 then
			result = i
			break
		end
	end
	return result
end

--both_arrows_used, kill_1, kill_2, x_val, y_val, z_val, rot_val, x2_val, y2_val, z2_val, rot2_val = get_xyz_lever_switch(in_lever_switch)
function get_xyz_lever_switch(in_lever_switch)
	
	local res_both_arrows_used = false
	local res_kil_1 = 1
	local res_kil_2 = 1
	local res_x_val = 0
	local res_y_val = 0
	local res_z_val = 0
	local res_rot_val = 0
	local res_x2_val = 0
	local res_y2_val = 0
	local res_z2_val = 0
	local res_rot2_val = 0
	
	local kill_1 = -1
	local kill_2 = -1
	local dr_1 = 0
	local dr_2 = 0
	local x_values = 0
	raw_table('y_values')
	local y_values = {}
	raw_table('z_values')
	local z_values = {}
	local x2_values = 0
	local rot = 0
	local rot2 = 0
	
	if in_lever_switch > 500 then
		if in_lever_switch == 501 then
			-- Engine start Levers
			dr_1 = B738DR_mixture_ratio1
			dr_2 = B738DR_mixture_ratio2
			res_both_arrows_used = true
			kill_1 = 0
			kill_2 = 0
			x_values = -0.015
			x2_values = 0.015
			y_values = { -0.61, -0.605, -0.59, -0.57, -0.55}
			z_values = { -0.255, -0.22, -0.18, -0.16, -0.14}
		elseif in_lever_switch == 502 then
			-- Speedbrake Lever
			dr_1 = B738DR_speedbrake_lever
			dr_2 = 0
			kill_1 = 0
			x_values = -0.105
			y_values = { -0.31, -0.35, -0.40, -0.44, -0.49}
			z_values = { -0.07, -0.06, -0.05, -0.04, -0.05}
		elseif in_lever_switch == 503 then
			-- Flap Lever
			dr_1 = B738DR_flap_lever
			dr_2 = 0
			kill_1 = 0
			x_values = 0.105
			y_values = { -0.41, -0.475, -0.53, -0.58, -0.62}
			z_values = { -0.06, -0.065, -0.082, -0.11, -0.15}
		elseif in_lever_switch == 504 then
			-- Landing gear Lever
			dr_1 = B738DR_gear_handle_pos
			dr_2 = 0
			kill_1 = 0
			x_values = 0.162
			y_values = { -0.09, -0.11, -0.13, -0.13, -0.13}
			z_values = { 0.15, 0.12, 0.085, 0.05, 0.01}
		elseif in_lever_switch == 505 then
			-- Throttle Levers
			dr_1 = B738DR_thrust1_leveler
			dr_2 = B738DR_thrust2_leveler
			res_both_arrows_used = true
			kill_1 = 0
			kill_2 = 0
			x_values = -0.028
			x2_values = 0.028
			y_values = { -0.555, -0.50, -0.44, -0.38, -0.32}
			z_values = { -0.01, 0.01, 0.015, 0.005, -0.015}
		elseif in_lever_switch == 506 then
			-- TOGA Throttle Levers
			dr_1 = B738DR_thrust1_leveler
			dr_2 = B738DR_thrust2_leveler
			res_both_arrows_used = true
			kill_1 = 0
			kill_2 = 0
			x_values = -0.028
			x2_values = 0.028
			y_values = { -0.52, -0.46, -0.41, -0.36, -0.30}
			z_values = { -0.052, -0.035, -0.03, -0.035, -0.052}
		elseif in_lever_switch == 507 then
			-- Reverese Levers
			dr_1 = B738DR_reverse_lever1
			dr_2 = B738DR_reverse_lever2
			res_both_arrows_used = true
			kill_1 = 0
			kill_2 = 0
			x_values = -0.012
			x2_values = 0.012
			y_values = { -0.35, -0.325, -0.34, -0.38, -0.45}
			z_values = { -0.105, -0.04, 0.021, 0.07, 0.095}
			if B738DR_thrust1_leveler > 0 then
				kill_1 = 1
			else
				rot = 180
			end
			if B738DR_thrust2_leveler > 0 then
				kill_2 = 1
			else
				rot2 = 180
			end
		elseif in_lever_switch == 508 then
			-- Flight controls
			dr_1 = B738DR_yoke_pitch
			dr_2 = B738DR_yoke_pitch2
			res_both_arrows_used = true
			kill_1 = 0.5
			kill_2 = 0.5
			x_values = -0.51
			x2_values = 0.51
			y_values = { -0.28, -0.42, -0.56 }
			z_values = { 0.035, 0.04, 0.02 }
		elseif in_lever_switch == 601 then
			-- Mixture 1 Lever
			dr_1 = B738DR_mixture_ratio1
			dr_2 = 0
			kill_1 = 0
			x_values = -0.015
			y_values = { -0.61, -0.605, -0.59, -0.57, -0.55}
			z_values = { -0.255, -0.22, -0.18, -0.16, -0.14}
		elseif in_lever_switch == 602 then
			-- Mixture 2 Lever
			dr_1 = B738DR_mixture_ratio2
			dr_2 = 0
			kill_1 = 0
			x_values = 0.015
			y_values = { -0.61, -0.605, -0.59, -0.57, -0.55}
			z_values = { -0.255, -0.22, -0.18, -0.16, -0.14}
		elseif in_lever_switch == 603 then
			-- Throttle 1 Lever
			dr_1 = B738DR_thrust1_leveler
			dr_2 = 0
			kill_1 = 0
			x_values = -0.028
			y_values = { -0.555, -0.50, -0.44, -0.38, -0.32}
			z_values = { -0.01, 0.01, 0.015, 0.005, -0.015}
		elseif in_lever_switch == 604 then
			-- Throttle 2 Lever
			dr_1 = B738DR_thrust2_leveler
			dr_2 = 0
			kill_1 = 0
			x_values = 0.028
			y_values = { -0.555, -0.50, -0.44, -0.38, -0.32}
			z_values = { -0.01, 0.01, 0.015, 0.005, -0.015}
		elseif in_lever_switch == 605 then
			-- Reverese 1 Lever
			dr_1 = B738DR_reverse_lever1
			dr_2 = 0
			kill_1 = 0
			x_values = -0.012
			y_values = { -0.35, -0.325, -0.34, -0.38, -0.45}
			z_values = { -0.105, -0.04, 0.021, 0.07, 0.095}
			if B738DR_thrust1_leveler > 0 then
				kill_1 = 1
			else
				rot = 180
			end
		elseif in_lever_switch == 606 then
			-- Reverese 2 Lever
			dr_1 = B738DR_reverse_lever2
			dr_2 = 0
			kill_1 = 0
			x_values = 0.012
			y_values = { -0.35, -0.325, -0.34, -0.38, -0.45}
			z_values = { -0.105, -0.04, 0.021, 0.07, 0.095}
			if B738DR_thrust2_leveler > 0 then
				kill_1 = 1
			else
				rot = 180
			end
		elseif in_lever_switch == 607 then
			-- Flight control CPT
			dr_1 = B738DR_yoke_pitch
			dr_2 = 0
			kill_1 = 0.5
			x_values = -0.51
			y_values = { -0.28, -0.42, -0.56 }
			z_values = { 0.035, 0.04, 0.02 }
		elseif in_lever_switch == 608 then
			-- Flight control FO
			dr_1 = B738DR_yoke_pitch2
			dr_2 = 0
			kill_1 = 0.5
			x_values = 0.51
			y_values = { -0.28, -0.42, -0.56 }
			z_values = { 0.035, 0.04, 0.02 }
		end
		
		if kill_1 >= 0 then
			if kill_1 == 0 then
				res_kil_1 = 0
				res_rot_val = rot
				res_x_val = x_values
				if dr_1 < 0.25 then
					res_y_val = B738_rescale(0, y_values[1], 0.25, y_values[2], dr_1)
					res_z_val = B738_rescale(0, z_values[1], 0.25, z_values[2], dr_1)
				elseif dr_1 < 0.5 then
					res_y_val = B738_rescale(0.25, y_values[2], 0.50, y_values[3], dr_1)
					res_z_val = B738_rescale(0.25, z_values[2], 0.50, z_values[3], dr_1)
				elseif dr_1 < 0.75 then
					res_y_val = B738_rescale(0.50, y_values[3], 0.75, y_values[4], dr_1)
					res_z_val = B738_rescale(0.50, z_values[3], 0.75, z_values[4], dr_1)
				else
					res_y_val = B738_rescale(0.75, y_values[4], 1, y_values[5], dr_1)
					res_z_val = B738_rescale(0.75, z_values[4], 1, z_values[5], dr_1)
				end
			elseif kill_1 == 0.5 then
				res_kil_1 = 0
				res_rot_val = rot
				res_x_val = x_values
				if dr_1 < 0 then
					res_y_val = B738_rescale(-1, y_values[1], 0, y_values[2], dr_1)
					res_z_val = B738_rescale(-1, z_values[1], 0, z_values[2], dr_1)
				else
					res_y_val = B738_rescale(0, y_values[2], 1, y_values[3], dr_1)
					res_z_val = B738_rescale(0, z_values[2], 1, z_values[3], dr_1)
				end
			else
				res_kil_1 = 1
			end
		end
		
		if res_both_arrows_used == true then
			if kill_2 >= 0 then
				res_kil_2 = kill_2
				if kill_2 == 0 then
					res_kil_2 = 0
					res_rot2_val = rot2
					res_x2_val = x2_values
					if dr_2 < 0.25 then
						res_y2_val = B738_rescale(0, y_values[1], 0.25, y_values[2], dr_2)
						res_z2_val = B738_rescale(0, z_values[1], 0.25, z_values[2], dr_2)
					elseif dr_2 < 0.5 then
						res_y2_val = B738_rescale(0.25, y_values[2], 0.50, y_values[3], dr_2)
						res_z2_val = B738_rescale(0.25, z_values[2], 0.50, z_values[3], dr_2)
					elseif dr_2 < 0.75 then
						res_y2_val = B738_rescale(0.50, y_values[3], 0.75, y_values[4], dr_2)
						res_z2_val = B738_rescale(0.50, z_values[3], 0.75, z_values[4], dr_2)
					else
						res_y2_val = B738_rescale(0.75, y_values[4], 1, y_values[5], dr_2)
						res_z2_val = B738_rescale(0.75, z_values[4], 1, z_values[5], dr_2)
					end
				elseif kill_2 == 0.5 then
					res_kil_2 = 0
					res_rot2_val = rot2
					res_x2_val = x2_values
					if dr_2 < 0 then
						res_y2_val = B738_rescale(-1, y_values[1], 0, y_values[2], dr_2)
						res_z2_val = B738_rescale(-1, z_values[1], 0, z_values[2], dr_2)
					else
						res_y2_val = B738_rescale(0, y_values[2], 1, y_values[3], dr_2)
						res_z2_val = B738_rescale(0, z_values[2], 1, z_values[3], dr_2)
					end
				else
					res_kil_2 = 1
				end
			end
		end
	else
		if in_lever_switch == 0 then
			res_kil_1 = 1
		else
			res_kil_1 = 0
			if in_lever_switch <= 20 and B738DR_old_mcp == 0 then
				in_lever_switch = in_lever_switch + 20
			elseif in_lever_switch == 77 and B738DR_ils_gls_annun ~= 0 then
				in_lever_switch = 89
			end
			if in_lever_switch == 184 then
				rot = 180
			end
			res_rot_val = rot
			res_x_val = item_x[in_lever_switch]
			res_y_val = item_y[in_lever_switch]
			res_z_val = item_z[in_lever_switch]
		end
	end
	
	return res_both_arrows_used, res_kil_1, res_kil_2, res_x_val, res_y_val, res_z_val, res_rot_val, res_x2_val, res_y2_val, res_z2_val, res_rot2_val
end

function xyz_lever_switch(in2_lever_switch, in2_lever_switch2)
	
	local both_arrows_used = false
	local kill_1 = 0
	local kill_2 = 0
	local x_val = 0
	local y_val = 0
	local z_val = 0
	local rot_val = 0
	local x2_val = 0
	local y2_val = 0
	local z2_val = 0
	local rot2_val = 0
	
	both_arrows_used, kill_1, kill_2, x_val, y_val, z_val, rot_val, x2_val, y2_val, z2_val, rot2_val = get_xyz_lever_switch(in2_lever_switch)
	B738DR_arrow_3d_kill = kill_1
	if kill_1 == 0 then
		B738DR_arrow_3d_x = x_val
		B738DR_arrow_3d_y = y_val
		B738DR_arrow_3d_z = z_val
		B738DR_arrow_3d_rotate = rot_val
	end
	
	if both_arrows_used == false then
		both_arrows_used, kill_1, kill_2, x_val, y_val, z_val, rot_val, x2_val, y2_val, z2_val, rot2_val = get_xyz_lever_switch(in2_lever_switch2)
		if both_arrows_used == false then
			B738DR_arrow_3d_kill2 = kill_1
			if kill_1 == 0 then
				B738DR_arrow_3d_x2 = x_val
				B738DR_arrow_3d_y2 = y_val
				B738DR_arrow_3d_z2 = z_val
				B738DR_arrow_3d_rotate2 = rot_val
			end
		else
			B738DR_arrow_3d_kill2 = 1
		end
	else
		B738DR_arrow_3d_kill2 = kill_2
		if kill_2 == 0 then
			B738DR_arrow_3d_x2 = x2_val
			B738DR_arrow_3d_y2 = y2_val
			B738DR_arrow_3d_z2 = z2_val
			B738DR_arrow_3d_rotate2 = rot2_val
		end
	end
end

function page_cl_before_start()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "      BEFORE START PROCEDURE          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if B738DR_detail_cl == 0 then
		if page == 1 then
			
			line[1] =   "  FLIGHT DECK DOOR                   "
			line_s[1] = "                  ....CLOSED/LOCKED  "
			
			line[2] =   "  CDU DISPLAY                        "
			line_s[2] = "             ...................SET  "
			
			line[3] =   "  N1 BUGS                            "
			line_s[3] = "         .....................CHECK  "
			
			line[4] =   "  IAS BUGS                           "
			line_s[4] = "          ....................CHECK  "
			
			line[5] =   "  MCP                                "
			line_s[5] = "     ...........................SET  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 4)
			complete = check_items(checklist_offset, checklist_offset + CL_BEFORE_START - 1)
			
			if complete ~= 0 then
				line_a[6] = "  TAXI/TAKEOFF BRIEFINGS             "
				line_g[6] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 4 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 5 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 6, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 4)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_BEFORE_START - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	else
		if page == 1 then
			line[1] =   "  FLIGHT DECK DOOR                   "
			line_s[1] = "                  ....CLOSED/LOCKED  "
			
			line[2] =   "  CDU DISPLAY                        "
			line_s[2] = "             ...................SET  "
			
			line[3] =   "  N1 BUGS                            "
			line_s[3] = "         .....................CHECK  "
			
			line[4] =   "  IAS BUGS                           "
			line_s[4] = "          ....................CHECK  "
			
			line[5] =   "  MCP                                "
			line_s[5] = "                                     "
			
			line[6] =   "  -A/T                               "
			line_s[6] = "      ..........................ARM  "
			
			line[7] =   "  -IAS/MACH                          "
			line_s[7] = "           ..................SET V2  "
			
			line[8] =   "  -ARM LNAV                          "
			line_s[8] = "           ...............AS NEEDED  "
			
			line[9] =   "  -INITIAL HEADING                   "
			line_s[9] = "                  ..............SET  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[4] = 0
			item_checked[4+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[5] = 0
			-- for i = 7, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  -INITIAL ALTITUDE                  "
			line_s[1] = "                   .............SET  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 9)
			complete = check_items(checklist_offset, checklist_offset + CL_BEFORE_START_D - 1)
			
			if complete ~= 0 then
				line_a[2] = "  TAXI/TAKEOFF BRIEFINGS             "
				line_g[2] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 0 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 1 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 2, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 9)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_BEFORE_START_D - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
	
end

function cmd_cl_bs(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_preflight()
	local item_act = ((page - 1) * 9) + checklist_offset
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "  PRELIMINARY PREFLIGHT PROCEDURE     "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  BATTERY SWITCH                     "
			line_s[1] = "                .......GUARD CLOSED  "
			
			line[2] =   "  GPU OR APU                         "
			line_s[2] = "            .................ON BUS  "
			
			line[3] =   "  IRS MODE SELECTOR                  "
			line_s[3] = "                   ....OFF,THEN NAV  "
			
			line[4] =   "  VOICE RECORDER                     "
			line_s[4] = "                ..........AS NEEDED  "
			
			line[5] =   "  FLIGHT DECK ACCESS                 "
			line_s[5] = "                    ...GUARD CLOSED  "
			
			line[6] =   "  EMERGENCY EQUIPMENT                "
			line_s[6] = "                     .........CHECK  "
			
			line[7] =   "  ELT LIGHT/SWITCH                   "
			line_s[7] = "           ............GUARD CLOSED  "
			
			line[8] =   "  PSEU LIGHT                         "
			line_s[8] = "            ...........EXTINGUISHED  "
			
			line[9] =   "  GPS LIGHT                          "
			line_s[9] = "           ............EXTINGUISHED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 7, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  SERVICE INTERPHONE                 "
			line_s[1] = "                    ............OFF  "
			
			line[2] =   "  ENGINE PANEL                       "
			line_s[2] = "              ..................SET  "
			
			line[3] =   "  OXYGEN PANEL                       "
			line_s[3] = "              ..................SET  "
			
			line[4] =   "  LANDING GEAR LIGHT                 "
			line_s[4] = "                    ....ILLUMINATED  "
			
			line[5] =   "  FLIGHT RECORDER                    "
			line_s[5] = "                 ......GUARD CLOSED  "
			
			line[6] =   "  STALL WARNING TEST                 "
			line_s[6] = "                    ...........PASS  "
			
			line[7] =   "  MANUAL GEAR EXTENSION DOOR         "
			line_s[7] = "                            .CLOSED  "
			
			line[8] =   "  PARKING BRAKE                      "
			line_s[8] = "               ...........AS NEEDED  "
			
			clr_item()
			for i = 0, 7 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 8 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 9, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 16)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_PRELIM - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	else
		if page == 1 then
			line[1] =   "  BATTERY SWITCH                     "
			line_s[1] = "                .......GUARD CLOSED  "
			
			line[2] =   "  GPU OR APU                         "
			line_s[2] = "            .................ON BUS  "
			
			line[3] =   "  IRS MODE SELECTOR                  "
			line_s[3] = "                   ....OFF,THEN NAV  "
			
			line[4] =   "  VOICE RECORDER                     "
			line_s[4] = "                ..........AS NEEDED  "
			
			line[5] =   "  FLIGHT DECK ACCESS                 "
			line_s[5] = "                    ...GUARD CLOSED  "
			
			line[6] =   "  EMERGENCY EQUIPMENT                "
			line_s[6] = "                     .........CHECK  "
			
			line[7] =   "  ELT LIGHT/SWITCH                   "
			line_s[7] = "           ............GUARD CLOSED  "
			
			line[8] =   "  PSEU LIGHT                         "
			line_s[8] = "            ...........EXTINGUISHED  "
			
			line[9] =   "  GPS LIGHT                          "
			line_s[9] = "           ............EXTINGUISHED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 7, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  SERVICE INTERPHONE                 "
			line_s[1] = "                    ............OFF  "
			
			line[2] =   "  ENGINE PANEL                       "
			line_s[2] = "              ..................SET  "
			
			line[3] =   "  OXYGEN PANEL                       "
			line_s[3] = "                                     "
			
			line[4] =   "  -PASSENGER OXYGEN                  "
			line_s[4] = "                   ....GUARD CLOSED  "
			
			line[5] =   "  -PASS OXY ON LIGHT                 "
			line_s[5] = "                    ...EXTINGUISHED  "
			
			line[6] =   "  LANDING GEAR LIGHT                 "
			line_s[6] = "                    ....ILLUMINATED  "
			
			line[7] =   "  FLIGHT RECORDER                    "
			line_s[7] = "                 ......GUARD CLOSED  "
			
			line[8] =   "  STALL WARNING TEST                 "
			line_s[8] = "                    ...........PASS  "
			
			line[9] =   "  MANUAL GEAR EXTENSION DOOR         "
			line_s[9] = "                            .CLOSED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[3] = 0
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line[1] =   "  PARKING BRAKE                      "
			line_s[1] = "               ...........AS NEEDED  "
			
			clr_item()
			for i = 0, 0 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 1 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 2, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 18)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_PRELIM_D - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
	
end

function cmd_cl_pf(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_cdu_preflight()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "       CDU PREFLIGHT PROCEDURE        "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  INITIAL DATA                       "
			line_s[1] = "              ..................SET  "
			
			line[2] =   "  NAVIGATION DATA                    "
			line_s[2] = "                 ...............SET  "
			
			line[3] =   "  PERFORMANCE DATA                   "
			line_s[3] = "                  ..............SET  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 2)
			complete = check_items(checklist_offset, checklist_offset + CL_CDU - 1)
			
			if complete ~= 0 then
				line_a[4] = "  PREFLIGHT BRIEFING                 "
				line_g[4] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 2 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 3 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 4, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 2)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_CDU - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	else
		if page == 1 then
			line[1] =   "  INITIAL DATA                       "
			line_s[1] = "                                     "
			
			line[2] =   "  -IDENT PAGE                        "
			line_s[2] = "                                     "
			
			line[3] =   "  --VERIFY MODEL                     "
			line_s[3] = "                ............CORRECT  "
			
			line[4] =   "  --VERIFY ENG RATING                "
			line_s[4] = "                     .......CORRECT  "
			
			line[5] =   "  --VERIFY NAVDATA BASE              "
			line_s[5] = "                       .....CURRENT  "
			
			line[6] =   "  -POS INIT PAGE                     "
			line_s[6] = "                                     "
			
			line[7] =   "  --TIME                             "
			line_s[7] = "        ....................CORRECT  "
			
			line[8] =   "  --SET IRS POS                      "
			line_s[8] = "               ...ACCURATE POSITION  "
			
			line[9] =   "  NAVIGATION DATA                    "
			line_s[9] = "                                     "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[0] = 0
			item_checked[0+item_act] = 1
			B738DR_tab_item[1] = 0
			item_checked[1+item_act] = 1
			B738DR_tab_item[5] = 0
			item_checked[5+item_act] = 1
			B738DR_tab_item[8] = 0
			item_checked[8+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[1] = 0
			B738DR_tab_line_manip[2] = 0
			B738DR_tab_line_manip[6] = 0
			B738DR_tab_line_manip[9] = 0
			-- for i = 4, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  -ROUTE PAGE                        "
			line_s[1] = "                                     "
			
			line[2] =   "  --ORIGIN                           "
			line_s[2] = "          ..................ENTERED  "
			
			line[3] =   "  --ROUTE                            "
			line_s[3] = "         ...................ENTERED  "
			
			line[4] =   "  --FLIGHT NUMBER                    "
			line_s[4] = "                 ...........ENTERED  "
			
			line[5] =   "  --ROUTE                            "
			line_s[5] = "         ........ACTIVATED/EXECUTED  "
			
			line[6] =   "  -DEPARTURES PAGE                   "
			line_s[6] = "                                     "
			
			line[7] =   "  --RUNWAY/DEPARTURE                 "
			line_s[7] = "                    .......EXECUTED  "
			
			line[8] =   "  -LEGS PAGE                         "
			line_s[8] = "                                     "
			
			line[9] =   "  --RNP DEPARTURE                    "
			line_s[9] = "                 ...........CORRECT  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[0] = 0
			item_checked[0+item_act] = 1
			B738DR_tab_item[5] = 0
			item_checked[5+item_act] = 1
			B738DR_tab_item[7] = 0
			item_checked[7+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[1] = 0
			B738DR_tab_line_manip[6] = 0
			B738DR_tab_line_manip[8] = 0
			-- for i = 4, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
			
		elseif page == 3 then
			line[1] =   "  --ROUTE CHECKED                    "
			line_s[1] = "                 ...........CORRECT  "
			
			line[2] =   "  PERFORMANCE DATA                   "
			line_s[2] = "                                     "
			
			line[3] =   "  -PERF INIT PAGE                    "
			line_s[3] = "                                     "
			
			line[4] =   "  --ZFW                              "
			line_s[4] = "       .....................ENTERED  "
			
			line[5] =   "  --FUEL                             "
			line_s[5] = "        ....................CORRECT  "
			
			line[6] =   "  --PLAN FUEL                        "
			line_s[6] = "             .............AS NEEDED  "
			
			line[7] =   "  --FUEL FOR FLIGHT                  "
			line_s[7] = "                   .........CORRECT  "
			
			line[8] =   "  --GROSSWEIGHT/CG                   "
			line_s[8] = "                  ..........CORRECT  "
			
			line[9] =   "  -N1 LIMIT PAGE                     "
			line_s[9] = "                                     "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[1] = 0
			item_checked[1+item_act] = 1
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			B738DR_tab_item[8] = 0
			item_checked[8+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[2] = 0
			B738DR_tab_line_manip[3] = 0
			B738DR_tab_line_manip[9] = 0
			-- for i = 4, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 4 then
			line[1] =   "  --OAT TEMPERATURE                  "
			line_s[1] = "                   .............SET  "
			
			line[2] =   "  --ASSUMMED TEMPERATURE             "
			line_s[2] = "                        ..AS NEEDED  "
			
			line[3] =   "  --FULL/DERATED THRUST              "
			line_s[3] = "                       ...AS NEEDED  "
			
			line[4] =   "  -TAKEOFF PAGE                      "
			line_s[4] = "                                     "
			
			line[5] =   "  --CG                               "
			line_s[5] = "      ..........................SET  "
			
			line[6] =   "  --TRIM VALUE                       "
			line_s[6] = "              ..............CORRECT  "
			
			line[7] =   "  --TAKEOFF SPEED                    "
			line_s[7] = "                 ..........SELECTED  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 33)
			complete = check_items(checklist_offset, checklist_offset + CL_CDU_D - 1)
			
			if complete ~= 0 then
				line_a[8] = "  PREFLIGHT BRIEFING                 "
				line_g[8] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 6 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[3] = 0
			item_checked[3+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 7 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 8, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			B738DR_tab_line_manip[4] = 0
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 33)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_CDU_D - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
end

function cmd_cl_cdu_pf(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_fo_preflight()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "      F/O PREFLIGHT PROCEDURE         "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	--if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  FLIGHT CONTROL PANEL               "
			line_s[1] = "                      ........CHECK  "
			
			line[2] =   "  NAVIGATION PANEL                   "
			line_s[2] = "                  ............  SET  "
			
			line[3] =   "  DISPLAY PANEL                      "
			line_s[3] = "               .................SET  "
			
			line[4] =   "  FUEL PANEL                         "
			line_s[4] = "            ....................SET  "
			
			line[5] =   "  ELECTRICAL PANEL                   "
			line_s[5] = "                  ..............SET  "
			
			line[6] =   "  OVERHEAT PANEL                     "
			line_s[6] = "                ..............CHECK  "
			
			line[7] =   "  FIRE PROTECTION PANEL              "
			line_s[7] = "                       .......CHECK  "
			
			line[8] =   "  APU AS NEEDED                      "
			line_s[8] = "               ...............START  "
			
			line[9] =   "  EQUIPMENT COOLING                  "
			line_s[9] = "                   ............NORM  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  EMERGENCY EXIT LIGHT               "
			line_s[1] = "                      .GUARD CLOSED  "
			
			line[2] =   "  PASSENGER SIGNS                    "
			line_s[2] = "                 ...............SET  "
			
			line[3] =   "  WINDSHIELD WIPER                   "
			line_s[3] = "                  .............PARK  "
			
			line[4] =   "  WINDOW HEAT                        "
			line_s[4] = "             ....................ON  "
			
			line[5] =   "  PROBE HEAT                         "
			if B738DR_probe_heat_auto == 0 then
				line_s[5] = "            ....................OFF  "
			else
				line_s[5] = "            ...................AUTO  "
			end
			
			line[6] =   "  WING ANTI-ICE                      "
			line_s[6] = "               .................OFF  "
			
			line[7] =   "  ENGINE ANTI-ICE                    "
			line_s[7] = "                 ...............OFF  "
			
			line[8] =   "  HYDRAULIC PANEL                    "
			line_s[8] = "                 ...............SET  "
			
			line[9] =   "  AIR CONDITIONING PANEL             "
			line_s[9] = "                        ........SET  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line[1] =   "  CABIN PRESSURIZATION PANEL         "
			line_s[1] = "                            ....SET  "
			
			line[2] =   "  LIGHTING PANEL                     "
			line_s[2] = "                ................SET  "
			
			line[3] =   "  IGNITION SELECT                    "
			line_s[3] = "                 ........IGN L OR R  "
			
			line[4] =   "  ENGINE START                       "
			if B738DR_engine_start_auto == 0 then
				line_s[4] = "              ................. OFF  "
			else
				line_s[4] = "              .................AUTO  "
			end
			
			line[5] =   "  MODE CONTROL PANEL                 "
			line_s[5] = "                    ............SET  "
			
			line[6] =   "  EFIS CONTROL PANEL                 "
			line_s[6] = "                    ............SET  "
			
			line[7] =   "  OXYGEN                             "
			line_s[7] = "        ...............TEST AND SET  "
			
			line[8] =   "  CLOCK                              "
			line_s[8] = "       .........................SET  "
			
			line[9] =   "  DISPLAY SELECT PANEL               "
			line_s[9] = "                      ..........SET  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 4 then
			line[1] =   "  TAKEOFF CONFIG LIGHT               "
			line_s[1] = "                      .EXTINGUISHED  "
			
			line[2] =   "  CABIN ALTITUDE LIGHT               "
			line_s[2] = "                      .EXTINGUISHED  "
			
			line[3] =   "  LIGHT TEST                         "
			line_s[3] = "            ..............HOLD TO 1  "
			
			line[4] =   "  LIGHT TEST                         "
			line_s[4] = "            ..............HOLD TO 2  "
			
			line[5] =   "  FLIGHT INSTRUMENTS                 "
			line_s[5] = "                    ..........CHECK  "
			
			line[6] =   "  GROUND PROXIMITY PANEL             "
			line_s[6] = "                        ......CHECK  "
			
			line[7] =   "  LANDING GEAR PANEL                 "
			line_s[7] = "                    ............SET  "
			
			line[8] =   "  AUTO BRAKE SELECT                  "
			line_s[8] = "                   .............RTO  "
			
			line[9] =   "  ANTISKID INOP                      "
			line_s[9] = "               ........EXTINGUISHED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 5 then
			line[1] =   "  ENG DISPLAY CONTROL                "
			line_s[1] = "                     ...........SET  "
			
			line[2] =   "  ENGINE INSTRUMENTS                 "
			line_s[2] = "                    ..........CHECK  "
			
			line[3] =   "  CARGO FIRE PANEL                   "
			line_s[3] = "                  ............CHECK  "
			
			line[4] =   "  VHF NAV RADIOS                     "
			line_s[4] = "                ..SET FOR DEPARTURE  "
			
			line[5] =   "  AUDIO CONTROL PANEL                "
			line_s[5] = "                     ...........SET  "
			
			line[6] =   "  ADF RADIOS                         "
			line_s[6] = "            ....................SET  "
			
			line[7] =   "  WEATHER RADAR PANEL                "
			line_s[7] = "                     ...........SET  "
			
			line[8] =   "  TRANSPONDER PANEL                  "
			line_s[8] = "                   .............SET  "
			
			line[9] =   "  STABILIZER TRIM                    "
			line_s[9] = "                 ......GUARD CLOSED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 6 then
			line[1] =   "  SEAT                               "
			line_s[1] = "      .....................ADJUSTED  "
			
			line[2] =   "  RUDDER PEDALS                      "
			line_s[2] = "               ............ADJUSTED  "
			
			line[3] =   "  SEAT BELTS                         "
			line_s[3] = "               ............ADJUSTED  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 47)
			complete = check_items(checklist_offset, checklist_offset + CL_FO_PREFLT - 1)
			
			if complete ~= 0 then
				line_a[4] = "  F/O PREFLIGHT                      "
				line_g[4] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 2 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 3 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 4, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 47)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_FO_PREFLT - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	--else
	--end
end

function cmd_cl_fo_pf(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_cpt_preflight()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "   CAPTAIN PREFLIGHT PROCEDURE        "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	--if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  LIGHTS                             "
			line_s[1] = "        .......................TEST  "
			
			line[2] =   "  EFIS CONTROL PANEL                 "
			line_s[2] = "                    ..........  SET  "
			
			line[3] =   "  MODE CONTROL PANEL                 "
			line_s[3] = "                    ............SET  "
			
			line[4] =   "  OXYGEN                             "
			line_s[4] = "        ...............TEST AND SET  "
			
			line[5] =   "  CLOCK                              "
			line_s[5] = "       .........................SET  "
			
			line[6] =   "  NOSE WHEEL STEERING                "
			line_s[6] = "                     ..GUARD CLOSED  "
			
			line[7] =   "  DISPLAY SELECT PANEL               "
			line_s[7] = "                      ........  SET  "
			
			line[8] =   "  TAKEOFF CONFIG LIGHT               "
			line_s[8] = "                      .EXTINGUISHED  "
			
			line[9] =   "  CABIN ALTITUDE LIGHT               "
			line_s[9] = "                      .EXTINGUISHED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  LIGHT TEST                         "
			line_s[1] = "            ..............HOLD TO 1  "
			
			line[2] =   "  LIGHT TEST                         "
			line_s[2] = "            ..............HOLD TO 2  "
			
			line[3] =   "  STAB OUT OF TRIM                   "
			line_s[3] = "                  .....EXTINGUISHED  "
			
			line[4] =   "  FLIGHT INSTRUMENTS                 "
			line_s[4] = "                    ..........CHECK  "
			
			line[5] =   "  STANDBY INSTRUMENTS                "
			line_s[5] = "                     .........CHECK  "
			
			line[6] =   "  STANDBY RMI                        "
			line_s[6] = "             ...................SET  "
			
			line[7] =   "  SPEED BRAKE LEVER                  "
			line_s[7] = "                   .....DOWN DETEND  "
			
			line[8] =   "  REVERSE THRUST LEVERS              "
			line_s[8] = "                       ........DOWN  "
			
			line[9] =   "  FORWARD THRUST LEVERS              "
			line_s[9] = "                       ......CLOSED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line[1] =   "  FLAP LEVER                         "
			line_s[1] = "            ....................SET  "
			
			line[2] =   "  FLAPS INDICATOR                    "
			line_s[2] = "                 .............CHECK  "
			
			line[3] =   "  PARKING BRAKE                      "
			line_s[3] = "               .................SET  "
			
			line[4] =   "  ENGINE START LEVERS                "
			line_s[4] = "                     ........CUTOFF  "
			
			line[5] =   "  STABILIZER TRIM CUTOUT             "
			line_s[5] = "                        .....NORMAL  "
			
			line[6] =   "  VHF NAV RADIOS                     "
			line_s[6] = "                ..SET FOR DEPARTURE  "
			
			line[7] =   "  AUDIO CONTROL PANEL                "
			line_s[7] = "                     ...........SET  "
			
			line[8] =   "  SEAT                               "
			line_s[8] = "      .......................ADJUST  "
			
			line[9] =   "  RUDDER PEDALS                      "
			line_s[9] = "               ..............ADJUST  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 5, 7 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 4 then
			line[1] =   "  SEAT BELTS                         "
			line_s[1] = "               ............ADJUSTED  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 27)
			complete = check_items(checklist_offset, checklist_offset + CL_CPT_PREFLT - 1)
			
			if complete ~= 0 then
				line_a[2] = "  CAPTAIN PREFLIGHT                  "
				line_g[2] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 0 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 1 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 2, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 27)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_CPT_PREFLT - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	--else
	--end
end

function cmd_cl_cpt_pf(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_pushback()
	local item_act = ((page - 1) * 9) + checklist_offset
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "       PUSHBACK PROCEDURE             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  TRANSPONDER                        "
			line_s[1] = "             .............AS NEEDED  "
			
			line[2] =   "  PARKING BRAKE                      "
			line_s[2] = "               .....BY GROUND HANDL  "
			
			line_a[3] = "  AFTER PUSHBACK                     "
			line_s[3] = "                                     "
			
			line[4] =   "  HYDRAULIC PUMPS                    "
			line_s[4] = "                 ................ON  "
			
			clr_item()
			for i = 0, 3 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 4 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 5, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			B738DR_tab_line_manip[3] = 0
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 3)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_PUSHBACK - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	else
		if page == 1 then
			line[1] =   "  TRANSPONDER                        "
			line_s[1] = "             .............AS NEEDED  "
			
			line[2] =   "  PARKING BRAKE                      "
			line_s[2] = "               .....BY GROUND HANDL  "
			
			line_a[3] = "  AFTER PUSHBACK                     "
			line_s[3] = "                                     "
			
			line[4] =   "  HYDRAULIC PUMPS                    "
			line_s[4] = "                 ................ON  "
			
			line[5] =   "   -HYD A LOW PRESSURE               "
			line_s[5] = "                      ...EXTINGUISH  "
			
			line[6] =   "   -HYD A PRESSURE                   "
			line_s[6] = "                  .....MIN 2800 PSI  "
			
			clr_item()
			for i = 0, 5 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 6 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 7, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			B738DR_tab_line_manip[3] = 0
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 5)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_PUSHBACK_D - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
end

function cmd_cl_pushback(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_eng_start()
	local item_act = ((page - 1) * 9) + checklist_offset
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "    ENGINES START PROCEDURE           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line_a[1] = "  ENGINE 2 START                     "
		line_s[1] = "                                     "
		
		line[2] =   "  PACK SWITCHES                      "
		line_s[2] = "               .................OFF  "
		
		line[3] =   "  ENGINE 2 START SEQUENCE            "
		line_s[3] = "                         ..ANNOUNCE  "
		
		line[4] =   "  ENGINE 2 START SWITCH              "
		line_s[4] = "                       .........GRD  "
		
		line[5] =   "  ENGINE 2 N2 RPM INCREASES          "
		line_s[5] = "                           ..VERIFY  "
		
		line_a[6] = "  ENGINE 2 AT 25% N2                 "
		line_s[6] = "                                     "
		
		line[7] =   "  ENGINE 2 START LEVER               "
		line_s[7] = "                      .........IDLE  "
		
		line_a[8] = "  ENGINE 2 AT 56% N2                 "
		line_s[8] = "                                     "
		
		line[9] =   "  ENGINE 2 START SWITCH OFF          "
		line_s[9] = "                           ..VERIFY  "
		
		clr_item()
		for i = 0, 8 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		B738DR_tab_item[5] = 0
		item_checked[5+item_act] = 1
		B738DR_tab_item[7] = 0
		item_checked[7+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[6] = 0
		B738DR_tab_line_manip[8] = 0
		-- for i = 7, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] =   "  START 2 VALVE OPEN                 "
		line_s[1] = "                    ...EXTINGUISHED  "
		
		line[2] =   "  STARTER 2 CUTOUT                   "
		line_s[2] = "                  .........ANNOUNCE  "
		
		line_a[3] = "  AFTER THE ENGINE 2 IS STABLE       "
		line_s[3] = "                                     "
		
		line_a[4] = "  ENGINE 1 START                     "
		line_s[4] = "                                     "
		
		line[5] =   "  ENGINE 1 START SEQUENCE            "
		line_s[5] = "                         ..ANNOUNCE  "
		
		line[6] =   "  ENGINE 1 START SWITCH              "
		line_s[6] = "                       .........GRD  "
		
		line[7] =   "  ENGINE 1 N2 RPM INCREASES          "
		line_s[7] = "                           ..VERIFY  "
		
		line_a[8] = "  ENGINE 1 AT 25% N2                 "
		line_s[8] = "                                     "
		
		line[9] =   "  ENGINE 1 START LEVER               "
		line_s[9] = "                      .........IDLE  "
		
		clr_item()
		for i = 0, 8 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[2] = 0
		item_checked[2+item_act] = 1
		B738DR_tab_item[3] = 0
		item_checked[3+item_act] = 1
		B738DR_tab_item[7] = 0
		item_checked[7+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 4, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		B738DR_tab_line_manip[3] = 0
		B738DR_tab_line_manip[4] = 0
		B738DR_tab_line_manip[8] = 0
	elseif page == 3 then
		line_a[1] = "  ENGINE 1 AT 56% N2                 "
		line_s[1] = "                                     "
		
		line[2] =   "  ENGINE 1 START SWITCH OFF          "
		line_s[2] = "                           ..VERIFY  "
		
		line[3] =   "  START 1 VALVE OPEN                 "
		line_s[3] = "                    ...EXTINGUISHED  "
		
		line[4] =   "  STARTER 1 CUTOUT                   "
		line_s[4] = "                  .........ANNOUNCE  "
		
		
		clr_item()
		for i = 0, 3 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 4 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 5, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
	end
	
	-- item_helper = check_items_help(checklist_offset, checklist_offset + 11)
	item_helper = check_items_help(checklist_offset, checklist_offset + CL_ENG_START - 1)
	if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
		if B738DR_blink ~= 0 then
			item_page = math.floor((item_helper - checklist_offset) / 9) + 1
			item_line = ((item_helper - checklist_offset) % 9) + 1
			if page == item_page then
				line_c[item_line] = line[item_line]
				line[item_line] = ""
			end
		end
		
		B738DR_arrow_3d_item_number = item_helper
		
		B738DR_arrow_3d_kill = 0
		B738DR_arrow_3d_kill2 = 0
		
		if B738DR_detail_cl == 0 then
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
		else
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
		end
	elseif B738DR_arrow_3d_override == 0 then
		B738DR_arrow_3d_kill = 1
		B738DR_arrow_3d_kill2 = 1
	end
	
end

function cmd_cl_eng_start(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_before_taxi()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "     BEFORE TAXI PROCEDURE            "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	--if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  GENERATORS 1 AND 2                 "
			line_s[1] = "                    .............ON  "
			
			line[2] =   "  PROBE HEAT                         "
			line_s[2] = "            .....................ON  "
			
			line[3] =   "  WING ANTI-ICE                      "
			line_s[3] = "               ...........AS NEEDED  "
			
			line[4] =   "  ENGINE ANTI-ICE                    "
			line_s[4] = "                 .........AS NEEDED  "
			
			line[5] =   "  PACK SWITCHES                      "
			line_s[5] = "                 ..............AUTO  "
			
			line[6] =   "  ISOLATION VALVE                    "
			line_s[6] = "                 ..............AUTO  "
			
			line[7] =   "  APU BLEED                          "
			line_s[7] = "           .....................OFF  "
			
			line[8] =   "  APU SWITCH                         "
			line_s[8] = "            ..............AS NEEDED  "
			
			line[9] =   "  ENGINE START SWITCHES              "
			line_s[9] = "                       ........CONT  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 4, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  ENGINE START LEVERS                "
			line_s[1] = "                     ..........IDLE  "
			
			line[2] =   "  GROUND EQUIPMENT CLEAR             "
			line_s[2] = "                        .....VERIFY  "
			
			line[3] =   "  FLAP LEVER                         "
			line_s[3] = "            ......SET TAKEOFF FLAPS  "
			
			line[4] =   "  FLIGHT CONTROLS                    "
			line_s[4] = "                 .............CHECK  "
			
			line[5] =   "  LOWER DU                           "
			line_s[5] = "          ....................BLANK  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 13)
			complete = check_items(checklist_offset, checklist_offset + CL_BEFORE_TAXI - 1)
			
			if complete ~= 0 then
				line_a[6] = "  BEFORE TAXI CHECKLIST              "
				line_g[6] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 4 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 5 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 6, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 13)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_BEFORE_TAXI - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	--end
end

function cmd_cl_before_taxi(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_takeoff()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "        TAKEOFF PROCEDURE             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	--if B738DR_detail_cl == 0 then
		if page == 1 then
			line_a[1] = "  BEFORE ENTERING THE RUNWAY         "
			line_s[1] = "                                     "
			
			line[2] =   "  DEPARTURE RUNWAY CORRECT           "
			line_s[2] = "                          ...VERIFY  "
			
			line_a[3] = "  ENTERING THE RUNWAY                "
			line_s[3] = "                                     "
			
			line[4] =   "  STROBE LIGHT                       "
			line_s[4] = "              ...................ON  "
			
			line[5] =   "  OTHER LIGHTS                       "
			line_s[5] = "              ............AS NEEDED  "
			
			line[6] =   "  TRANSPONDER                        "
			line_s[6] = "             .................TA/RA  "
			
			line_a[7] = "  AFTER CLEAR FOR TAKEOFF            "
			line_s[7] = "                                     "
			
			line[8] =   "  FIXED LANDING LIGHTS               "
			line_s[8] = "                      ...........ON  "
			
			line[9] =   "  THRUST LEVERS                      "
			line_s[9] = "               .......APPROX 40% N1  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[0] = 0
			item_checked[0+item_act] = 1
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			B738DR_tab_item[6] = 0
			item_checked[6+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[1] = 0
			B738DR_tab_line_manip[3] = 0
			B738DR_tab_line_manip[7] = 0
			-- for i = 5, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line_a[1] = "  AFTER ENGINES STABILIZE            "
			line_s[1] = "                                     "
			
			line[2] =   "  TO/GA SWITCH                       "
			line_s[2] = "              .................PUSH  "
			
			line_a[3] = "  AT VR                              "
			line_s[3] = "                                     "
			
			line[4] =   "  ROTATE TOWARD                      "
			line_s[4] = "               ........PITCH 15 DEG  "
			
			line_a[5] = "  AT POSITIVE CLIMB                  "
			line_s[5] = "                                     "
			
			line[6] =   "  LANDING GEAR LEVER                 "
			line_s[6] = "                    .............UP  "
			
			line_a[7] = "  ABOVE 400 FT                       "
			line_s[7] = "                                     "
			
			line[8] =   "  ROLL MODE                          "
			line_s[8] = "           ....... SELECT OR VERIFY  "
			
			line[9] =   "  FLAPS RETRACT                      "
			line_s[9] = "               .........AS SCHEDULE  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[0] = 0
			item_checked[0+item_act] = 1
			B738DR_tab_item[2] = 0
			item_checked[2+item_act] = 1
			B738DR_tab_item[4] = 0
			item_checked[4+item_act] = 1
			B738DR_tab_item[6] = 0
			item_checked[6+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[1] = 0
			B738DR_tab_line_manip[3] = 0
			B738DR_tab_line_manip[5] = 0
			B738DR_tab_line_manip[7] = 0
			-- for i = 5, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line_a[1] = "  AFTER FLAPS AND SLATS RETRACTED    "
			line_s[1] = "                                     "
			
			line[2] =   "  VNAV MODE                          "
			line_s[2] = "           .....................SET  "
			
			line[3] =   "  AUTOPILOT                          "
			line_s[3] = "           ...............AS NEEDED  "
			
			line[4] =   "  ENGINE START SWITCHES              "
			line_s[4] = "                       ...AS NEEDED  "
			
			line[5] =   "  AUTOBRAKE                          "
			line_s[5] = "           .....................OFF  "
			
			line[6] =   "  LANDING GEAR LEVER                 "
			line_s[6] = "                    ............OFF  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 23)
			complete = check_items(checklist_offset, checklist_offset + CL_TAKEOFF - 1)
			
			if complete ~= 0 then
				line_a[7] = "  AFTER TAKEOFF CHECKLIST            "
				line_g[7] = "                           COMPLETE  "
			end
			
			clr_item()
			for i = 0, 5 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[0] = 0
			item_checked[0+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 6 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[1] = 0
			for i = 7, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 23)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_TAKEOFF - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	--else
	--end
end

function cmd_cl_takeoff(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_climb_cruise()
	local item_act = ((page - 1) * 9) + checklist_offset
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "   CLIMB AND CRUISE PROCEDURE         "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line_a[1] = "  AT OR ABOVE 10000 FT               "
		line_s[1] = "                                     "
		
		line[2] =   "  LANDING LIGHTS                     "
		line_s[2] = "                ................OFF  "
		
		line[3] =   "  PASSENGER SIGN                     "
		line_s[3] = "                ..........AS NEEDED  "
		
		line_a[4] = "  AT TRANSITION ALTITUDE             "
		line_s[4] = "                                     "
		
		line[5] =   "  ALTIMETER SET                      "
		line_s[5] = "               ............STANDARD  "
		
		line[6] =   "  ALTIMETER CROSSCHECK               "
		line_s[6] = "                      .......VERIFY  "
		
		line_a[7] = "  BEFORE TOP OF DESCENT              "
		line_s[7] = "                                     "
		
		line[8] =   "  MOD ROUTE FOR ARRIVAL              "
		line_s[8] = "                       ...AS NEEDED  "
		
		line[9] =   "  RNP FOR ARRIVAL                    "
		line_s[9] = "                 ............VERIFY  "
		
		clr_item()
		for i = 0, 9 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		B738DR_tab_item[3] = 0
		item_checked[3+item_act] = 1
		B738DR_tab_item[6] = 0
		item_checked[6+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
		B738DR_tab_line_manip[1] = 0
		B738DR_tab_line_manip[4] = 0
		B738DR_tab_line_manip[7] = 0
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 8)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_CLIMB_CRUISE - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_climb_cruise(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_descent()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "        DESCENT PROCEDURE             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  PRESSURIZATION                     "
		line_s[1] = "                                     "
		
		line[2] =   "  -LANDING ALTITUDE                  "
		line_s[2] = "                   ..........VERIFY  "
		
		line[3] =   "  SYSTEM ANNUNCIATOR                 "
		line_s[3] = "                    .........RECALL  "
		
		line[4] =   "  APPROACH REF PAGE                  "
		line_s[4] = "                                     "
		
		line[5] =   "  -VREF                              "
		line_s[5] = "      ........................ENTER  "
		
		line[6] =   "  RADIO/BARO MINIMUMS                "
		line_s[6] = "                     .....AS NEEDED  "
		
		line[7] =   "  NAVIGATION RADIO                   "
		line_s[7] = "                  .....  SET/VERIFY  "
		
		line[8] =   "  AUTOBRAKE                          "
		line_s[8] = "           ...............AS NEEDED  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 7)
		complete = check_items(checklist_offset, checklist_offset + CL_DESCENT - 1)
		
		if complete ~= 0 then
			line_a[9] = "  DESCENT CHECKLIST                  "
			line_g[9] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 7 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		B738DR_tab_item[3] = 0
		item_checked[3+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 8 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
		B738DR_tab_line_manip[4] = 0
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 7)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_DESCENT - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_descent(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_approach()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "       APPROACH PROCEDURE             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line_a[1] = "  IF FLAPS 15 LANDING NEEDED         "
		line_s[1] = "                                     "
		
		line[2] =   "  GND PROXIMITY FLAP                 "
		line_s[2] = "                    ...FLAP INHIBIT  "
		
		line_a[3] = "  AT OR ABOVE 10000 FT               "
		line_s[3] = "                                     "
		
		line[4] =   "  FIXED LANDING LIGHT                "
		line_s[4] = "                     ............ON  "
		
		line[5] =   "  PASSENGER SIGN                     "
		line_s[5] = "                ..........AS NEEDED  "
		
		line_a[6] = "  AT TRANSITION LEVEL                "
		line_s[6] = "                                     "
		
		line[7] =   "  ALTIMETER                          "
		line_s[7] = "           .....................SET  "
		
		line[8] =   "  UPDATE RNP                         "
		line_s[8] = "            ..............AS NEEDED  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 7)
		complete = check_items(checklist_offset, checklist_offset + CL_APPROACH - 1)
		
		if complete ~= 0 then
			line_a[9] = "  APPROACH CHECKLIST                 "
			line_g[9] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 7 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		B738DR_tab_item[2] = 0
		item_checked[2+item_act] = 1
		B738DR_tab_item[5] = 0
		item_checked[5+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 8 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
		B738DR_tab_line_manip[3] = 0
		B738DR_tab_line_manip[6] = 0
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 7)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_APPROACH - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_approach(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_landing_ils()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "      LANDING ILS PROCEDURE           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  APP ROLL MODE                      "
		line_s[1] = "               .................ARM  "
		
		line[2] =   "  LOCALIZER CAPTURE                  "
		line_s[2] = "                   ..........VERIFY  "
		
		line_a[3] = "  AT GLIDE SLOPE ALIVE               "
		line_s[3] = "                                     "
		
		line[4] =   "  LANDING GEAR LEVER                 "
		line_s[4] = "                    ...........DOWN  "
		
		line[5] =   "  LANDING GEAR INDICATOR             "
		line_s[5] = "                        ....3 GREEN  "
		
		line[6] =   "  FLAP LEVER                         "
		line_s[6] = "            .....................15  "
		
		line[7] =   "  ENG START SWITCHES                 "
		line_s[7] = "                    ...........CONT  "
		
		line[8] =   "  SPEEDBRAKE LEVER                   "
		line_s[8] = "                  ..............ARM  "
		
		line[9] =   "  SPEEDBRAKE ARMED                   "
		line_s[9] = "                  .......ILLUMINATE  "
		
		clr_item()
		for i = 0, 8 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[2] = 0
		item_checked[2+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[3] = 0
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line_a[1] = "  AT GLIDE SLOPE CAPTURE             "
		line_s[1] = "                                     "
		
		line[2] =   "  FLAP LEVER                         "
		line_s[2] = "            ............AS DIRECTED  "
		
		line[3] =   "  MCP MISSED APPROACH ALT            "
		line_s[3] = "                         .......SET  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 11)
		complete = check_items(checklist_offset, checklist_offset + CL_LANDING_ILS - 1)
		
		if complete ~= 0 then
			line_a[4] = "  LANDING CHECKLIST                  "
			line_g[4] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 2 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 3 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 4, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
		
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 11)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_LANDING_ILS - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_landing_ils(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_landing_ian()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "      LANDING IAN PROCEDURE           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  APP ROLL MODE                      "
		line_s[1] = "               .................ARM  "
		
		line[2] =   "  LOCALIZER CAPTURE                  "
		line_s[2] = "                   ..........VERIFY  "
		
		line_a[3] = "  AT GLIDE PATH ALIVE                "
		line_s[3] = "                                     "
		
		line[4] =   "  LANDING GEAR LEVER                 "
		line_s[4] = "                    ...........DOWN  "
		
		line[5] =   "  LANDING GEAR INDICATOR             "
		line_s[5] = "                        ....3 GREEN  "
		
		line[6] =   "  FLAP LEVER                         "
		line_s[6] = "            .....................15  "
		
		line[7] =   "  ENG START SWITCHES                 "
		line_s[7] = "                    ...........CONT  "
		
		line[8] =   "  SPEEDBRAKE LEVER                   "
		line_s[8] = "                  ..............ARM  "
		
		line[9] =   "  SPEEDBRAKE ARMED                   "
		line_s[9] = "                  .......ILLUMINATE  "
		
		clr_item()
		for i = 0, 8 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[2] = 0
		item_checked[2+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[3] = 0
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line_a[1] = "  AT GLIDE PATH CAPTURE              "
		line_s[1] = "                                     "
		
		line[2] =   "  FLAP LEVER                         "
		line_s[2] = "            ............AS DIRECTED  "
		
		line[3] =   "  MCP MISSED APPROACH ALT            "
		line_s[3] = "                         .......SET  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 11)
		complete = check_items(checklist_offset, checklist_offset + CL_LANDING_IAN - 1)
		
		if complete ~= 0 then
			line_a[4] = "  LANDING CHECKLIST                  "
			line_g[4] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 2 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[0] = 0
		item_checked[0+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 3 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 4, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 0
		
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 11)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_LANDING_IAN - 1)
		
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_landing_ian(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_landing_vnav()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "      LANDING VNAV PROCEDURE           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  ROLL MODE                          "
		line_s[1] = "           .........LNAV OR VOR/LOC  "
		
		line_a[2] = "  AT 2NM BEFORE FAF                  "
		line_s[2] = "                                     "
		
		line[3] =   "  MCP ALT DA(H) OR MDA(H)            "
		line_s[3] = "                         .......SET  "
		
		line[4] =   "  LANDING GEAR LEVER                 "
		line_s[4] = "                    ...........DOWN  "
		
		line[5] =   "  LANDING GEAR INDICATOR             "
		line_s[5] = "                        ....3 GREEN  "
		
		line[6] =   "  FLAP LEVER                         "
		line_s[6] = "            .....................15  "
		
		line[7] =   "  ENG START SWITCHES                 "
		line_s[7] = "                    ...........CONT  "
		
		line[8] =   "  SPEEDBRAKE LEVER                   "
		line_s[8] = "                  ..............ARM  "
		
		line[9] =   "  SPEEDBRAKE ARMED                   "
		line_s[9] = "                  .......ILLUMINATE  "
		
		clr_item()
		for i = 0, 8 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[1] = 0
		item_checked[1+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[2] = 0
		-- for i = 9, 9 do
			-- B738DR_tab_line_manip[i] = 0
		-- end
	elseif page == 2 then
		line[1] =   "  FLAP LEVER                         "
		line_s[1] = "            ............AS DIRECTED  "
		
		line_a[2] = "  BELOW 300 FT MISSED APPROACH ALT   "
		line_s[2] = "                                     "
		
		line[3] =   "  MCP MISSED APPROACH ALT            "
		line_s[3] = "                         .......SET  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 11)
		complete = check_items(checklist_offset, checklist_offset + CL_LANDING_VNAV - 1)
		
		if complete ~= 0 then
			line_a[4] = "  LANDING CHECKLIST                  "
			line_g[4] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 2 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[1] = 0
		item_checked[1+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 3 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 4, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[2] = 0
		
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 11)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_LANDING_VNAV - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_landing_vnav(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_go_around()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "  GO-AROUND/MISSED APP PROCEDURE      "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  TO/GA                              "
		line_s[1] = "       ........................PUSH  "
		
		line[2] =   "  FLAPS LEVER                        "
		line_s[2] = "             ....................15  "
		
		line_a[3] = "  AT POSITIVE CLIMB                  "
		line_s[3] = "                                     "
		
		line[4] =   "  LANDING GEAR LEVER                 "
		line_s[4] = "                    .............UP  "
		
		line[5] =   "  MCP MISSED APP ALT                 "
		line_s[5] = "                    .........VERIFY  "
		
		line[6] =   "  FLAP LEVER                         "
		line_s[6] = "            ............AS DIRECTED  "
		
		line_a[7] = "  AFTER FLAP RETRACTION              "
		line_s[7] = "                                     "
		
		line[8] =   "  PITCH MODE                         "
		line_s[8] = "            ................LVL CHG  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 7)
		complete = check_items(checklist_offset, checklist_offset + CL_GOAROUND - 1)
		
		if complete ~= 0 then
			line_a[9] = "  GO-AROUND CHECKLIST                "
			line_g[9] = "                           COMPLETE  "
		end
			
		clr_item()
		for i = 0, 7 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		B738DR_tab_item[2] = 0
		item_checked[2+item_act] = 1
		B738DR_tab_item[6] = 0
		item_checked[6+item_act] = 1
		
		-- enable/disable manip
		for i = 0, 8 do
			B738DR_tab_line_manip[i] = 1
		end
		B738DR_tab_line_manip[3] = 0
		B738DR_tab_line_manip[7] = 0
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 7)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_GOAROUND - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_go_around(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_after_land()
	local item_act = ((page - 1) * 9) + checklist_offset
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "     AFTER LANDING PROCEDURE          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  AUTOBRAKE                          "
		line_s[1] = "           .....................OFF  "
		
		line[2] =   "  SPEEDBRAKE LEVER                   "
		line_s[2] = "                  .............DOWN  "
		
		line[3] =   "  PROBE HEAT                         "
		if B738DR_probe_heat_auto == 0 then
			line_s[3] = "            ....................OFF  "
		else
			line_s[3] = "            ...................AUTO  "
		end
		
		line[4] =   "  EXTERIOR LIGHTS                    "
		line_s[4] = "                 .........AS NEEDED  "
		
		line[5] =   "  ENG START SWITCHES                 "
		if B738DR_engine_start_auto == 0 then
			line_s[5] = "                    ........... OFF  "
		else
			line_s[5] = "                    ...........AUTO  "
		end
		
		line[6] =   "  WEATHER RADAR                      "
		line_s[6] = "               .................OFF  "
		
		line[7] =   "  FLAP LEVER                         "
		line_s[7] = "            .....................UP  "
		
		line[8] =   "  TRANSPONDER                        "
		line_s[8] = "             .............AS NEEDED  "
		
		clr_item()
		for i = 0, 7 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		
		-- enable/disable manip
		for i = 0, 8 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 9, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 7)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_AFTER_LAND - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_after_land(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_shutdown()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "        SHUTDOWN PROCEDURE             "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if B738DR_detail_cl == 0 then
		if page == 1 then
			line[1] =   "  PARKING BRAKE                      "
			line_s[1] = "               .................SET  "
			
			line[2] =   "  ELECTRICAL POWER                   "
			line_s[2] = "                  ..............SET  "
			
			line[3] =   "  ENGINE START LEVERS                "
			line_s[3] = "                     ........CUTOFF  "
			
			line[4] =   "  FASTEN BELTS                       "
			line_s[4] = "              ..................OFF  "
			
			line[5] =   "  ANTI COLLISION LIGHT               "
			line_s[5] = "                      ..........OFF  "
			
			line[6] =   "  FUEL PUMP SWITCHES                 "
			line_s[6] = "                    ............OFF  "
			
			line[7] =   "  CAB/UTIL                           "
			line_s[7] = "          ................AS NEEDED  "
			
			line[8] =   "  IFE/PASS SEAT                      "
			line_s[8] = "               ...........AS NEEDED  "
			
			line[9] =   "  WING ANTI-ICE                      "
			line_s[9] = "               .................OFF  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  ENGINE ANTI-ICE                    "
			line_s[1] = "                 ...............OFF  "
			
			line[2] =   "  HYDRAULIC PANEL                    "
			line_s[2] = "                 ...............SET  "
			
			line[3] =   "  RECIRC FAN                         "
			line_s[3] = "            ..............AS NEEDED  "
			
			line[4] =   "  PACK SWITCHES                      "
			line_s[4] = "               ................AUTO  "
			
			line[5] =   "  ISOLATION VALVE                    "
			line_s[5] = "                 ..............OPEN  "
			
			line[6] =   "  ENGINE BLEED                       "
			line_s[6] = "              ...................ON  "
			
			line[7] =   "  APU BLEED                          "
			line_s[7] = "           ......................ON  "
			
			line[8] =   "  EXTERIOR LIGHTS                    "
			line_s[8] = "                 .........AS NEEDED  "
			
			line[9] =   "  FLIGHT DIRECTOR                    "
			line_s[9] = "                 ...............OFF  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line[1] =   "  TRANSPONDER                        "
			line_s[1] = "             ..................STBY  "
			
			line[2] =   "  APU SWITCH                         "
			line_s[2] = "            ..............AS NEEDED  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 19)
			complete = check_items(checklist_offset, checklist_offset + CL_SHUTDOWN - 1)
			
			if complete ~= 0 then
				line_a[3] = "  SHUTDOWN CHECKLIST                 "
				line_g[3] = "                           COMPLETE  "
			end
				
			clr_item()
			for i = 0, 1 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 2 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 3, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 19)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_SHUTDOWN - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	else
		if page == 1 then
			line[1] =   "  PARKING BRAKE                      "
			line_s[1] = "               .................SET  "
			
			line[2] =   "  ELECTRICAL POWER                   "
			line_s[2] = "                                     "
			
			line[3] =   "  -APU GENERATOR BUS                 "
			line_s[3] = "                    .............ON  "
			
			line[4] =   "  -SOURCE OFF LIGHTS                 "
			line_s[4] = "                    .....EXTINGUISH  "
			
			line[5] =   "  ENGINE START LEVERS                "
			line_s[5] = "                     ........CUTOFF  "
			
			line[6] =   "  FASTEN BELTS                       "
			line_s[6] = "              ..................OFF  "
			
			line[7] =   "  ANTI COLLISION LIGHT               "
			line_s[7] = "                      ..........OFF  "
			
			line[8] =   "  FUEL PUMP SWITCHES                 "
			line_s[8] = "                    ............OFF  "
			
			line[9] =   "  CAB/UTIL                           "
			line_s[9] = "          ................AS NEEDED  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[1] = 0
			item_checked[1+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[2] = 0
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 2 then
			line[1] =   "  IFE/PASS SEAT                      "
			line_s[1] = "               ...........AS NEEDED  "
			
			line[2] =   "  WING ANTI-ICE                      "
			line_s[2] = "               .................OFF  "
			
			line[3] =   "  ENGINE ANTI-ICE                    "
			line_s[3] = "                 ...............OFF  "
			
			line[4] =   "  HYDRAULIC PANEL                    "
			line_s[4] = "                                     "
			
			line[5] =   "  -ENG HYDRAULIC PUMPS               "
			line_s[5] = "                      ...........ON  "
			
			line[6] =   "  -ELECTRIC HYDRAULIC PUMPS          "
			line_s[6] = "                           .....OFF  "
			
			line[7] =   "  RECIRC FAN                         "
			line_s[7] = "            ..............AS NEEDED  "
			
			line[8] =   "  PACK SWITCHES                      "
			line_s[8] = "               ................AUTO  "
			
			line[9] =   "  ISOLATION VALVE                    "
			line_s[9] = "                 ..............OPEN  "
			
			clr_item()
			for i = 0, 8 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			B738DR_tab_item[3] = 0
			item_checked[3+item_act] = 1
			
			-- enable/disable manip
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 1
			end
			B738DR_tab_line_manip[4] = 0
			-- for i = 9, 9 do
				-- B738DR_tab_line_manip[i] = 0
			-- end
		elseif page == 3 then
			line[1] =   "  ENGINE BLEED                       "
			line_s[1] = "              ...................ON  "
			
			line[2] =   "  APU BLEED                          "
			line_s[2] = "           ......................ON  "
			
			line[3] =   "  EXTERIOR LIGHTS                    "
			line_s[3] = "                 .........AS NEEDED  "
			
			line[4] =   "  FLIGHT DIRECTOR                    "
			line_s[4] = "                 ...............OFF  "
			
			line[5] =   "  TRANSPONDER                        "
			line_s[5] = "             ..................STBY  "
			
			line[6] =   "  APU SWITCH                         "
			line_s[6] = "            ..............AS NEEDED  "
			
			-- complete = check_items(checklist_offset, checklist_offset + 23)
			complete = check_items(checklist_offset, checklist_offset + CL_SHUTDOWN_D - 1)
			
			if complete ~= 0 then
				line_a[7] = "  SHUTDOWN CHECKLIST                 "
				line_g[7] = "                           COMPLETE  "
			end
				
			clr_item()
			for i = 0, 5 do
				B738DR_tab_item[i] = 1
				B738DR_tab_item_checked[i] = item_checked[i+item_act]
			end
			
			-- enable/disable manip
			for i = 0, 6 do
				B738DR_tab_line_manip[i] = 1
			end
			for i = 7, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			
		end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 23)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_SHUTDOWN_D - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
end

function cmd_cl_shutdown(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_cl_secure()
	local item_act = ((page - 1) * 9) + checklist_offset
	local complete = 0
	local item_helper = 0
	local item_page = 0
	local item_line = 0
	
	line_c[0] =   "        SECURE PROCEDURE              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		line[1] =   "  IRS MODE SELECTOR                  "
		line_s[1] = "                   .............OFF  "
		
		line[2] =   "  EMERGENCY EXIT LIGHTS              "
		line_s[2] = "                       ........ OFF  "
		
		line[3] =   "  WINDOW HEAT                        "
		line_s[3] = "             ...................OFF  "
		
		line[4] =   "  PACK SWITCHES                      "
		line_s[4] = "               .................OFF  "
		
		-- complete = check_items(checklist_offset, checklist_offset + 3)
		complete = check_items(checklist_offset, checklist_offset + CL_SECURE - 1)
		
		if complete ~= 0 then
			line_a[5] = "  SECURE CHECKLIST                   "
			line_g[5] = "                           COMPLETE  "
		end
		
		clr_item()
		for i = 0, 3 do
			B738DR_tab_item[i] = 1
			B738DR_tab_item_checked[i] = item_checked[i+item_act]
		end
		
		-- enable/disable manip
		for i = 0, 4 do
			B738DR_tab_line_manip[i] = 1
		end
		for i = 5, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
		
		-- item_helper = check_items_help(checklist_offset, checklist_offset + 3)
		item_helper = check_items_help(checklist_offset, checklist_offset + CL_SECURE - 1)
		if item_helper >= 0 and B738DR_arrow_3d_helper ~= 0 and B738DR_arrow_3d_override == 0 then
			if B738DR_blink ~= 0 then
				item_page = math.floor((item_helper - checklist_offset) / 9) + 1
				item_line = ((item_helper - checklist_offset) % 9) + 1
				if page == item_page then
					line_c[item_line] = line[item_line]
					line[item_line] = ""
				end
			end
			
			B738DR_arrow_3d_item_number = item_helper
			
			B738DR_arrow_3d_kill = 0
			B738DR_arrow_3d_kill2 = 0
			
			if B738DR_detail_cl == 0 then
				xyz_lever_switch(item_sw[item_helper+1], item_sw2[item_helper+1])
			else
				xyz_lever_switch(item_D_sw[item_helper+1], item_D_sw2[item_helper+1])
			end
		elseif B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
end

function cmd_cl_secure(cmd)
	local item_act = cmd + checklist_offset - 1
	if item_checked[item_act] == 0 then
		item_checked[item_act] = 1
		check_items_auto(checklist_offset, item_act, cmd)
	else
		item_checked[item_act] = 0
	end
end

function page_pay_perf()
	line_c[0] =   "      FUEL, PAYLOAD, CG, OPT          "
	line_s[0] = "                                " .. num_pages(page, max_page)
	for i = 0, 4 do
		B738DR_tab_menu_manip[i] = 1
	end
	for i = 5, 6 do
		B738DR_tab_menu_manip[i] = 0
	end
	B738DR_tab_menu_manip[7] = 1
	
	--B738DR_tab_menu_manip[4] = 1
	clr_line_manip()
	clr_perf_manip()
end

function cmd_pay_perf(cmd)
	if cmd == 5 then
		B738CMD_fueltruck_toggle:once()
	end
	
	clr_menu_mark()
	if is_timer_scheduled(menu_mark_timer) == true then
		stop_timer(menu_mark_timer)
	end
	B738DR_tab_menu_mark[cmd-1] = 1
	run_after_time(menu_mark_timer, 0.4)
end


function calc_mac_DR()
	local left_fuel = simDR_fuel_tank_weight_kg[0]
	local center_fuel = simDR_fuel_tank_weight_kg[1]
	local right_fuel = simDR_fuel_tank_weight_kg[2]
	
	local total_fuel = left_fuel + center_fuel + right_fuel
	local payload_wgt = simDR_payload_weight - physical_crew_payload_weight()
	
	local empty_kg = B738DR_oew_kg
	
	local zfw_wgt = empty_kg + payload_wgt
	
	local required_fuel = 0
	local total_wgt = 0
	if B738DR_req_fuel ~= 0 then
		total_wgt = zfw_wgt + B738DR_req_fuel
		required_fuel = B738DR_req_fuel
	else
		total_wgt = zfw_wgt + total_fuel
	end
	
	local units_string = ""
	local mac, mac_pos = calc_mac(gw_tow_state)
	local mac_zfw = calc_zfw_mac()
	local mac_des = 0
	local lw = 0
	if B738DR_dest_fuel >= 0 then
		mac_des = calc_des_mac(B738DR_dest_fuel)
		lw = zfw_wgt + B738DR_dest_fuel
	end
	
	B738DR_mac = mac
	B738DR_mac_zfw = mac_zfw
	B738DR_mac_des = mac_des
	
	mac, mac_pos = calc_mac(gw_tow_state)
end



function page_fuel_cg()
	line_c[0] =   "       FUEL, PAYLOAD AND CG           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	local left_fuel = simDR_fuel_tank_weight_kg[0]
	local center_fuel = simDR_fuel_tank_weight_kg[1]
	local right_fuel = simDR_fuel_tank_weight_kg[2]
	
	local total_fuel = left_fuel + center_fuel + right_fuel
	local payload_wgt = simDR_payload_weight - physical_crew_payload_weight()
	
	local empty_kg = B738DR_oew_kg	--43000	--41.4
	-- if B738DR_73x == 1 then
		-- empty_kg = 42500
	-- elseif B738DR_73x == 2 then
		-- empty_kg = 37600
	-- end
	
	local zfw_wgt = empty_kg + payload_wgt
	
	local required_fuel = 0
	local total_wgt = 0
	if B738DR_req_fuel ~= 0 then
		total_wgt = zfw_wgt + B738DR_req_fuel
		required_fuel = B738DR_req_fuel
	else
		total_wgt = zfw_wgt + total_fuel
	end
	
	local units_string = ""
	local mac, mac_pos = calc_mac(gw_tow_state)
	local mac_zfw = calc_zfw_mac()
	local mac_des = 0
	local lw = 0
	if B738DR_dest_fuel >= 0 then
		mac_des = calc_des_mac(B738DR_dest_fuel)
		lw = zfw_wgt + B738DR_dest_fuel
	end
	
	B738DR_tab_cg_pos = mac_pos
	
	local zfw_wgt_kg = zfw_wgt
	local lw_wgt_kg = lw
	local total_wgt_kg = total_wgt
	
	if B738DR_fmc_units == 0 then
		total_fuel = total_fuel * KGS_LBS
		payload_wgt = payload_wgt * KGS_LBS
		total_wgt = total_wgt * KGS_LBS
		zfw_wgt = zfw_wgt * KGS_LBS
		units_string = "LBS"
		required_fuel = required_fuel * KGS_LBS
		lw = lw * KGS_LBS
	else
		units_string = "KGS"
	end
	
	B738DR_perf_clearway_show = 0
	B738DR_perf_stopway_show = 0
	
	if page == 1 then
		line[1] =   "  PAYLOAD "
		line_g[1] = "         " .. string.format("%6d", payload_wgt)
		line_s[1] = "                " .. units_string

		line[2] =   "  ZFW    " .. string.format("%6d", zfw_wgt)
		line_s[2] = "                " .. units_string

		line[3] =   "  FUEL    "
		if required_fuel == 0 then
			line_g[3] = "         " .. string.format("%6d", total_fuel)
			line_s[3] = "                " .. units_string
		else
			line_g[3] = "         " .. string.format("%6d", required_fuel)
			line_s[3] = "      REQ       " .. units_string
			line_s[4] = "      ACT" .. string.format("%6d", total_fuel) .. " " .. units_string
		end
		
		if gw_tow_state == 0 then
			line[5] = "  WEIGHT "
			line[5] = line[5] .. string.format("%6d", total_wgt)
		else
			line[5] = "  TOW    "
			if B738DR_fmc_units == 0 then
				line[5] = line[5] .. string.format("%6d", (total_wgt_kg - 226.8) * KGS_LBS)
			else
				line[5] = line[5] .. string.format("%6d", total_wgt - 226.8)
			end
		end
		line_s[5] = "                " .. units_string
		
		line[6] = "  -----------------"
		
		if gw_tow_state == 0 then
			line[7] =   "  GW    CG    "
			if total_wgt_kg == 0 then
				line[7] = line[7] .. "--.-%"
			else
				if mac == 0 then
					line_a[7] = "              CHECK"
				else
					if check_gw(total_wgt_kg, mac) then
						line_g[7] = "              " .. string.format("%4.1f", mac) .. "%"
					else
						line_a[7] = "              " .. string.format("%4.1f", mac) .. "%"
					end
				end
				if B738DR_dev_tune ~= 0 then
					if enable_cg == 0 then
						line_s[7] = "                    " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
					else
						if line_a[7] == "" then
							line_a[7] = "                    " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
						else
							line_a[7] = line_a[7] .. " " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
						end
					end
				end
			end
		else
			line[7] =   "  TOW   CG    "
			if total_wgt_kg == 0 then
				line[7] = line[7] .. "--.-%"
			else
				if mac == 0 then
					line_a[7] = "              CHECK"
				else
					if check_tow(total_wgt_kg - 226.8, mac) then	-- 500 lb
						line_g[7] = "              " .. string.format("%4.1f", mac) .. "%"
					else
						line_a[7] = "              " .. string.format("%4.1f", mac) .. "%"
					end
				end
				if B738DR_dev_tune ~= 0 then
					if enable_cg == 0 then
						line_s[7] = "                    " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
					else
						if line_a[7] == "" then
							line_a[7] = "                    " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
						else
							line_a[7] = line_a[7] .. " " .. string.format("%4.1f", simDR_cg_z_mac) .. "%" .. "   SH:" .. string.format("%6.2f", B738DR_shift_cg_mac) .. "%"
						end
					end
				end
			end
		end
		
		line[8] =   "  ZFW   CG    "
		if zfw_wgt_kg == 0 then
			line[8] = line[8] .. "--.-%"
		else
			if mac_zfw == 0 then
				line_a[8] = "              CHECK"
			else
				if check_zfw(zfw_wgt_kg, mac_zfw) then
					line_g[8] = "              " .. string.format("%4.1f", mac_zfw) .. "%"
				else
					line_a[8] = "              " .. string.format("%4.1f", mac_zfw) .. "%"
				end
			end
		end
		
		line[9] =   "  LW    CG    "
		if lw_wgt_kg == 0 then
			line[9] = line[9] .. "--.-%"
		else
			if mac_des == 0 then
				line_a[9] = "              CHECK"
			else
				if check_lw(lw_wgt_kg, mac_des) then
					line_g[9] = "              " .. string.format("%4.1f", mac_des) .. "%"
				else
					line_a[9] = "              " .. string.format("%4.1f", mac_des) .. "%"
				end
			end
		end
		
		if B738DR_dev_tune ~= 0 then
			line_s[9] = "                        "
			line_s[9] = line_s[9] .. string.format("%4d", simDR_gear_vert_force[0]/1000) .. " "
			line_s[9] = line_s[9] .. string.format("%4d", simDR_gear_vert_force[1]/1000) .. " "
			line_s[9] = line_s[9] .. string.format("%4d", simDR_gear_vert_force[2]/1000)
		end
		
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		B738DR_tab_line_manip[1] = 1
		B738DR_tab_line_manip[3] = 1
		B738DR_tab_line_manip[7] = 1
		B738DR_tab_line_manip[8] = 1
		
		if B738DR_dev_tune ~= 0 then
			B738DR_tab_line_manip[9] = 1
		end
		
		if B738DR_dev_tune ~= 0 then
			line_s[8] = "                        SH GND:" .. string.format("%6.2f", B738DR_shift_cg_mac_gnd) .. "%"
		else
			line_s[8] =   "                                 FUEL>"
		end
		
		for i = 0, 15 do
			B738DR_tab_perf_manip[i] = 0
		end
		if B738DR_dev_tune == 0 then
			B738DR_tab_perf_manip[15] = 1
		end
		
	elseif page == 2 then
		line_c[0] =   "             PAYLOAD                  "
		line_s[1] = "  ZONE            M  F  K"
		line[2] =   "  ZONE 1                 "
		line_g[2] = "                 " .. string.format("%2d", zone1_pax[1]) .. string.format("%3d", zone1_pax[2]) .. string.format("%3d", zone1_pax[3])
		line_s[2] = "         MAX " .. string.format("%2d", B738DR_std_pax_num[0])
		
		line[3] =   "  ZONE 2                 "
		line_g[3] = "                 " .. string.format("%2d", zone2_pax[1]) .. string.format("%3d", zone2_pax[2]) .. string.format("%3d", zone2_pax[3])
		line_s[3] = "         MAX " .. string.format("%2d", B738DR_std_pax_num[1])
		
		line[4] =   "  ZONE 3                 "
		line_g[4] = "                 " .. string.format("%2d", zone3_pax[1]) .. string.format("%3d", zone3_pax[2]) .. string.format("%3d", zone3_pax[3])
		line_s[4] = "         MAX " .. string.format("%2d", B738DR_std_pax_num[2])
		
		line[5] =   "  ZONE 4                 "
		line_g[5] = "                 " .. string.format("%2d", zone4_pax[1]) .. string.format("%3d", zone4_pax[2]) .. string.format("%3d", zone4_pax[3])
		line_s[5] = "         MAX " .. string.format("%2d", B738DR_std_pax_num[3])
		
		line[6] =   "  ZONE 5                 "
		line_g[6] = "                 " .. string.format("%2d", zone5_pax[1]) .. string.format("%3d", zone5_pax[2]) .. string.format("%3d", zone5_pax[3])
		line_s[6] = "         MAX " .. string.format("%2d", B738DR_std_pax_num[4])
		if B738DR_fmc_units == 0 then
			line[7] =   "  CARGO 1 FWD        "
			-- line_s[7] = "                        LBS"
			line_g[7] = "                 " .. string.format("%6d", zone_cargo1 * KGS_LBS)
			line[8] =   "  CARGO 2 AFT        "
			-- line_s[8] = "                        LBS"
			line_g[8] = "                 " .. string.format("%6d", zone_cargo2 * KGS_LBS)
		else
			line[7] =   "  CARGO 1 FWD        "
			-- line_s[7] = "                        KGS"
			line_g[7] = "                 " .. string.format("%6d", zone_cargo1)
			line[8] =   "  CARGO 2 AFT        "
			-- line_s[8] = "                        KGS"
			line_g[8] = "                 " .. string.format("%6d", zone_cargo2)
		end
		line_s[7] = "                        " .. units_string
		line_s[8] = "                        " .. units_string
		
		local total_payload = 0
		local std_pax_weight = 0
		for zxp = 1, 3 do
			std_pax_weight = B738DR_std_pax_weight[zxp-1]
			total_payload = total_payload + zone1_pax[zxp] * std_pax_weight
			total_payload = total_payload + zone2_pax[zxp] * std_pax_weight
			total_payload = total_payload + zone3_pax[zxp] * std_pax_weight
			total_payload = total_payload + zone4_pax[zxp] * std_pax_weight
			total_payload = total_payload + zone5_pax[zxp] * std_pax_weight
		end
		total_payload = total_payload + zone_cargo1 + zone_cargo2
		total_payload = total_payload
		if B738DR_fmc_units == 0 then
			total_payload = total_payload * KGS_LBS
			line[9] =   "  PAYLOAD TOTAL  "
			line_g[9] = "                 " .. string.format("%6d", total_payload)
			-- line_s[9] = "                        LBS"
		else
			line[9] =   "  PAYLOAD TOTAL  "
			line_g[9] = "                 " .. string.format("%6d", total_payload)
			-- line_s[9] = "                        KGS"
		end
		line_s[9] = "                        " .. units_string
		
		for i = 0, 1 do
			B738DR_tab_line_manip[i] = 0
		end
		for i = 2, 9 do
			B738DR_tab_line_manip[i] = 1
		end
	elseif page == 3 then
		line_c[0] =   "               CG ENVELOPE            "
		line[1] =     "  WEIGHTS"
		if B738DR_fmc_units == 0 then
			if B738DR_b737_variant == 3 then
				--600
				line_s[2] =     "  BEW  80200"
			elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
				--700
				line_s[2] =     "  BEW  83000"
			elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
				--800
				line_s[2] =     "  BEW  91300"
			elseif B738DR_b737_variant == 1 then	--or B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
				--900
				line_s[2] =     "  BEW  91300"
			elseif B738DR_b737_variant == 4 then
				--900ER
				line_s[2] =     "  BEW  98495"
			elseif B738DR_73x == 2 then
				--700
				line_s[2] =     "  BEW  83000"
			else
				line_s[2] =     "  BEW  91300"
			end
			-- if B738DR_73x == 2 then
				-- line_s[2] =     "  BEW  83000"
			-- else
				-- line_s[2] =     "  BEW  91300"
			-- end
			line_s[3] =     "  OEW " .. string.format("%6d", B738DR_oew_kg * KGS_LBS)
			line_s[4] =     "  ZFW " .. string.format("%6d", zfw_wgt_kg * KGS_LBS)
			if lw_wgt_kg == 0 then
				line_s[5] =     "  LW  ------"
			else
				line_s[5] =     "  LW  " .. string.format("%6d", lw_wgt_kg * KGS_LBS)
			end
			if gw_tow_state == 0 then
				line_s[6] =     "  GW  " .. string.format("%6d", total_wgt_kg * KGS_LBS)
			else
				line_s[6] =     "  TOW " .. string.format("%6d", (total_wgt_kg - 226.8) * KGS_LBS)
			end
		else
			if B738DR_b737_variant == 3 then
				--600
				line_s[2] =     "  BEW  36378"
			elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
				--700
				line_s[2] =     "  BEW  37648"
			elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
				--800
				line_s[2] =     "  BEW  41413"
			elseif B738DR_b737_variant == 1 then	--or B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
				--900
				line_s[2] =     "  BEW  41418"
			elseif B738DR_b737_variant == 4 then
				--900ER
				line_s[2] =     "  BEW  44677"
			elseif B738DR_73x == 2 then
				--700
				line_s[2] =     "  BEW  37648"
			else
				line_s[2] =     "  BEW  41413"
			end
			-- if B738DR_73x == 2 then
				-- line_s[2] =     "  BEW  37648"
			-- else
				-- line_s[2] =     "  BEW  41413"
			-- end
			line_s[3] =     "  OEW " .. string.format("%6d", B738DR_oew_kg)
			line_s[4] =     "  ZFW " .. string.format("%6d", zfw_wgt_kg)
			if lw_wgt_kg == 0 then
				line_s[5] =     "  LW  ------"
			else
				line_s[5] =     "  LW  " .. string.format("%6d", lw_wgt_kg)
			end
			if gw_tow_state == 0 then
				line_s[6] =     "  GW  " .. string.format("%6d", total_wgt_kg)
			else
				line_s[6] =     "  TOW " .. string.format("%6d", total_wgt_kg - 226.8)
			end
		end
		
		line_s[2] = line_s[2] .. " " .. units_string
		line_s[3] = line_s[3] .. " " .. units_string
		line_s[4] = line_s[4] .. " " .. units_string
		line_s[5] = line_s[5] .. " " .. units_string
		line_s[6] = line_s[6] .. " " .. units_string
		
		if zfw_wgt_kg == B738DR_oew_kg then
			B738DR_oew_cg = 0
			-- ZFW
			B738DR_zfw_cg = math.min(mac_zfw, 40)
			B738DR_zfw_cg = math.max(B738DR_zfw_cg, 0)
			B738DR_zfw_weight = math.min(zfw_wgt_kg/1000, 80)
			B738DR_zfw_weight = math.max(B738DR_zfw_weight, 40)
			B738DR_zfw_str = "OEW/ZFW (" .. string.format("%4.1f", B738DR_zfw_cg) .. "%MAC)"
		else
			-- OEW
			B738DR_oew_cg = calc_oew_mac()	--18.5
			B738DR_oew_weight = B738DR_oew_kg / 1000
			B738DR_oew_str = "OEW (" .. string.format("%4.1f", B738DR_oew_cg) .. "%MAC)"
			-- ZFW
			B738DR_zfw_cg = math.min(mac_zfw, 40)
			B738DR_zfw_cg = math.max(B738DR_zfw_cg, 0)
			B738DR_zfw_weight = math.min(zfw_wgt_kg/1000, 80)
			B738DR_zfw_weight = math.max(B738DR_zfw_weight, 40)
			B738DR_zfw_str = "ZFW (" .. string.format("%4.1f", B738DR_zfw_cg) .. "%MAC)"
		end
		-- TOW
		if gw_tow_state == 0 then
			B738DR_tow_cg = math.min(mac, 40)
			B738DR_tow_cg = math.max(B738DR_tow_cg, 0)
			B738DR_tow_weight = math.min(total_wgt_kg/1000, 80)
			B738DR_tow_weight = math.max(B738DR_tow_weight, 40)
			B738DR_tow_str = "GW (" .. string.format("%4.1f", B738DR_tow_cg) .. "%MAC)"
		else
			B738DR_tow_cg = math.min(mac, 40)
			B738DR_tow_cg = math.max(B738DR_tow_cg, 0)
			B738DR_tow_weight = math.min(total_wgt_kg/1000, 80)
			B738DR_tow_weight = math.max(B738DR_tow_weight, 40)
			B738DR_tow_str = "TOW (" .. string.format("%4.1f", B738DR_tow_cg) .. "%MAC)"
		end
		-- LW
		if mac_des == 0 then
			B738DR_lw_cg = 0
		else
			B738DR_lw_cg = math.min(mac_des, 40)
			B738DR_lw_cg = math.max(B738DR_lw_cg, 0)
			B738DR_lw_weight = math.min(lw_wgt_kg/1000, 80)
			B738DR_lw_weight = math.max(B738DR_lw_weight, 40)
			B738DR_lw_str = "LW (" .. string.format("%4.1f", B738DR_lw_cg) .. "%MAC)"
		end
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	elseif page == 4 then
		line_c[0] =   "    LAYOUT/STD WEIGHT SETTINGS        "
		if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
			--600 & 700
			line[1] =       "  LAYOUT PAX                         "
			line_g[1] = "                                  138"
			line_s[1] = "                                     "
		elseif B738DR_b737_variant == 4 then
			--900ER
			-- line[1] =       "  LAYOUT PAX                         "
			-- line_g[1] = "                                  215"
			-- line_s[1] = "                                     "
			line[1] =       "  LAYOUT PAX         /   /   /   /   "
			if B738DR_pax_layout == 5 then
				line_g[1] = "                                  215"
				line_s[1] = "                  174 179 180 214    "
			elseif B738DR_pax_layout == 6 then
				line_g[1] = "                              214    "
				line_s[1] = "                  174 179 180     215"
			elseif B738DR_pax_layout == 7 then
				line_g[1] = "                          180        "
				line_s[1] = "                  174 179     214 215"
			elseif B738DR_pax_layout == 8 then
				line_g[1] = "                      179            "
				line_s[1] = "                  174     180 214 215"
			else
				line_g[1] = "                  174                "
				line_s[1] = "                      179 180 214 215"
			end
		elseif B738DR_73x == 2 then
			line[1] =       "  LAYOUT PAX                         "
			-- if B738DR_pax_layout == 4 then
				line_g[1] = "                                  138"
				line_s[1] = "                                     "
			-- end
		else
			line[1] =       "  LAYOUT PAX             /   /   /   "
			if B738DR_pax_layout == 0 then
				line_g[1] = "                      160            "
				line_s[1] = "                          180 187 189"
			elseif B738DR_pax_layout == 1 then
				line_g[1] = "                          180        "
				line_s[1] = "                      160     187 189"
			elseif B738DR_pax_layout == 2 then
				line_g[1] = "                              187    "
				line_s[1] = "                      160 180     189"
			else
				line_g[1] = "                                  189"
				line_s[1] = "                      160 180 187    "
			end
		end
		line_s[2] = "   PAX ZONES           "
		line_s[2] = line_s[2] .. string.format("%2d", B738DR_std_pax_num[0])
		line_s[2] = line_s[2] .. "/" .. string.format("%2d", B738DR_std_pax_num[1])
		line_s[2] = line_s[2] .. "/" .. string.format("%2d", B738DR_std_pax_num[2])
		line_s[2] = line_s[2] .. "/" .. string.format("%2d", B738DR_std_pax_num[3])
		line_s[2] = line_s[2] .. "/" .. string.format("%2d", B738DR_std_pax_num[4])
		line[3] =   "  MALE STD WEIGHT           "
		line[4] =   "  FEMALE STD WEIGHT         "
		line[5] =   "  KIDS STD WEIGHT           "
		line[6] =   "  FA FWD                    "
		line[7] =   "  FA AFT                    "
		line[8] =   "  GALLEYS F                 "
		line[9] =   "  GALLEYS R                 "
		if B738DR_fmc_units == 0 then
			line_g[3] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[0] * KGS_LBS)
			line_s[3] = "                    /210.0/       LBS"
			line_g[4] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[1] * KGS_LBS)
			line_s[4] = "                    /210.0/       LBS"
			line_g[5] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[2] * KGS_LBS)
			line_s[5] = "                    /210.0/       LBS"
			line_g[6] = "                            " .. string.format("%5.1f", B738DR_fa_fwd_kg * KGS_LBS)
			line_s[6] = "                    /460.0/       LBS"
			line_g[7] = "                            " .. string.format("%5.1f", B738DR_fa_aft_kg * KGS_LBS)
			line_s[7] = "                    /460.0/       LBS"
			if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg * KGS_LBS)
				line_s[8] = "                     /2145/       LBS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg * KGS_LBS)
				line_s[9] = "                     /2600/       LBS"
			elseif B738DR_73x == 2 then
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg * KGS_LBS)
				line_s[8] = "                     /2145/       LBS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg * KGS_LBS)
				line_s[9] = "                     /2600/       LBS"
			else
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg * KGS_LBS)
				line_s[8] = "                     /2595/       LBS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg * KGS_LBS)
				line_s[9] = "                     /2700/       LBS"
			end
		else
			line_g[3] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[0])
			line_s[3] = "                     /95.2/       KGS"
			line_g[4] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[1])
			line_s[4] = "                     /95.2/       KGS"
			line_g[5] = "                            " .. string.format("%5.1f", B738DR_std_pax_weight[2])
			line_s[5] = "                     /95.2/       KGS"
			line_g[6] = "                            " .. string.format("%5.1f", B738DR_fa_fwd_kg)
			line_s[6] = "                    /208.6/       KGS"
			line_g[7] = "                            " .. string.format("%5.1f", B738DR_fa_aft_kg)
			line_s[7] = "                    /208.6/       KGS"
			if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg)
				line_s[8] = "                      /972/       KGS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg)
				line_s[9] = "                     /1179/       KGS"
			elseif B738DR_73x == 2 then
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg)
				line_s[8] = "                      /972/       KGS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg)
				line_s[9] = "                     /1179/       KGS"
			else
				line_g[8] = "                            " .. string.format("%5.1f", B738DR_galley_fwd_kg)
				line_s[8] = "                     /1177/       KGS"
				line_g[9] = "                            " .. string.format("%5.1f", B738DR_galley_aft_kg)
				line_s[9] = "                     /1225/       KGS"
			end
		end
		
		if B738DR_auto_flight == 0 then
			for i = 1, 9 do
				B738DR_tab_line_manip[i] = 1
			end
		else
			for i = 1, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		B738DR_tab_line_manip[2] = 0
		
	end
	
end

function cmd_fuel_cg(cmd)
	if B738DR_dev_tune ~= 0 and cmd >= 7 and cmd <= 9 then
		if cmd == 7 then
			numpad_ref = 600
			activate_numpad()
		elseif cmd == 8 then
			numpad_ref = 601
			activate_numpad()
		else
			if enable_cg == 0 then
				B738DR_debug = 2000
				enable_cg = 1
			else
				B738DR_debug = 2001
				enable_cg = 0
			end
		end
	elseif cmd == 1 then
		-- payload
		page = 2
		display_update = 1
	elseif cmd == 3 then
		-- fuel
		numpad_ref = 1
		activate_numpad()
	elseif cmd >= 7 and cmd <= 8 then
		page = 3
		display_update = 1
	elseif cmd == 11 then
		-- zone 1 pax
		numpad_ref = 11
		activate_numpad()
		B738DR_tab_numpad_spec2 = 2
	elseif cmd == 12 then
		-- zone 2 pax
		numpad_ref = 12
		activate_numpad()
		B738DR_tab_numpad_spec2 = 2
	elseif cmd == 13 then
		-- zone 3 pax
		numpad_ref = 13
		activate_numpad()
		B738DR_tab_numpad_spec2 = 2
	elseif cmd == 14 then
		-- zone 4 pax
		numpad_ref = 14
		activate_numpad()
		B738DR_tab_numpad_spec2 = 2
	elseif cmd == 15 then
		-- zone 5 pax
		numpad_ref = 15
		activate_numpad()
		B738DR_tab_numpad_spec2 = 2
	elseif cmd == 16 then
		-- zone cargo 1
		numpad_ref = 16
		activate_numpad()
	elseif cmd == 17 then
		-- zone cargo 2
		numpad_ref = 17
		activate_numpad()
	elseif cmd == 18 then
		-- total payload
		numpad_ref = 18
		activate_numpad()
		B738DR_tab_numpad_spec1 = 1
	elseif cmd == 28 then
		-- layout pax
		if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
			--600 & 700
			-- Layout 4
			B738DR_pax_layout = 4
			B738DR_std_pax_num[0] = 24
			B738DR_std_pax_num[1] = 30
			B738DR_std_pax_num[2] = 24
			B738DR_std_pax_num[3] = 30
			B738DR_std_pax_num[4] = 30
			B738DR_zone_arm[0] = 9.3218	-- 367 in
			B738DR_zone_arm[1] = 12.827	-- 505 in
			B738DR_zone_arm[2] = 16.4592	-- 648 in
			B738DR_zone_arm[3] = 19.939	-- 785 in
			B738DR_zone_arm[4] = 24.003	-- 945 in
		elseif B738DR_b737_variant == 4 then
			--900ER
			if B738DR_pax_layout == 5 then
				-- Layout 9
				B738DR_pax_layout = 9
				B738DR_std_pax_num[0] = 30
				B738DR_std_pax_num[1] = 36
				B738DR_std_pax_num[2] = 36
				B738DR_std_pax_num[3] = 36
				B738DR_std_pax_num[4] = 36
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			elseif B738DR_pax_layout == 6 then
				-- Layout 5
				B738DR_pax_layout = 5
				B738DR_std_pax_num[0] = 31
				B738DR_std_pax_num[1] = 46
				B738DR_std_pax_num[2] = 46
				B738DR_std_pax_num[3] = 46
				B738DR_std_pax_num[4] = 46
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			elseif B738DR_pax_layout == 7 then
				-- Layout 6
				B738DR_pax_layout = 6
				B738DR_std_pax_num[0] = 42
				B738DR_std_pax_num[1] = 43
				B738DR_std_pax_num[2] = 43
				B738DR_std_pax_num[3] = 43
				B738DR_std_pax_num[4] = 43
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			elseif B738DR_pax_layout == 8 then
				-- Layout 7
				B738DR_pax_layout = 7
				B738DR_std_pax_num[0] = 40
				B738DR_std_pax_num[1] = 35
				B738DR_std_pax_num[2] = 35
				B738DR_std_pax_num[3] = 35
				B738DR_std_pax_num[4] = 35
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			else
				-- Layout 8
				B738DR_pax_layout = 8
				B738DR_std_pax_num[0] = 20
				B738DR_std_pax_num[1] = 33
				B738DR_std_pax_num[2] = 42
				B738DR_std_pax_num[3] = 42
				B738DR_std_pax_num[4] = 42
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			end
		elseif B738DR_73x == 2 then
			-- Layout 4
			B738DR_pax_layout = 4
			B738DR_std_pax_num[0] = 24
			B738DR_std_pax_num[1] = 30
			B738DR_std_pax_num[2] = 24
			B738DR_std_pax_num[3] = 30
			B738DR_std_pax_num[4] = 30
			B738DR_zone_arm[0] = 9.3218	-- 367 in
			B738DR_zone_arm[1] = 12.827	-- 505 in
			B738DR_zone_arm[2] = 16.4592	-- 648 in
			B738DR_zone_arm[3] = 19.939	-- 785 in
			B738DR_zone_arm[4] = 24.003	-- 945 in
		else
			if B738DR_pax_layout == 0 then
				-- Layout 1
				B738DR_pax_layout = 1
				B738DR_std_pax_num[0] = 36
				B738DR_std_pax_num[1] = 36
				B738DR_std_pax_num[2] = 36
				B738DR_std_pax_num[3] = 36
				B738DR_std_pax_num[4] = 36
				B738DR_zone_arm[0] = 6.6548	-- 262 in
				B738DR_zone_arm[1] = 11.43	-- 450 in
				B738DR_zone_arm[2] = 16.764	-- 660 in
				B738DR_zone_arm[3] = 21.463	-- 845 in
				B738DR_zone_arm[4] = 26.289	-- 1035 in
			elseif B738DR_pax_layout == 1 then
				-- Layout 2
				B738DR_pax_layout = 2
				B738DR_std_pax_num[0] = 27
				B738DR_std_pax_num[1] = 42
				B738DR_std_pax_num[2] = 34
				B738DR_std_pax_num[3] = 42
				B738DR_std_pax_num[4] = 42
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			elseif B738DR_pax_layout == 2 then
				-- Layout 3
				B738DR_pax_layout = 3
				B738DR_std_pax_num[0] = 27
				B738DR_std_pax_num[1] = 42
				B738DR_std_pax_num[2] = 36
				B738DR_std_pax_num[3] = 42
				B738DR_std_pax_num[4] = 42
				B738DR_zone_arm[0] = 5.842	-- 230 in
				B738DR_zone_arm[1] = 10.16	-- 400 in
				B738DR_zone_arm[2] = 15.748	-- 620 in
				B738DR_zone_arm[3] = 20.828	-- 820 in
				B738DR_zone_arm[4] = 26.035	-- 1025 in
			else
				-- Layout 0
				B738DR_pax_layout = 0
				B738DR_std_pax_num[0] = 16
				B738DR_std_pax_num[1] = 36
				B738DR_std_pax_num[2] = 36
				B738DR_std_pax_num[3] = 36
				B738DR_std_pax_num[4] = 36
				B738DR_zone_arm[0] = 6.6548	-- 262 in
				B738DR_zone_arm[1] = 11.43	-- 450 in
				B738DR_zone_arm[2] = 16.764	-- 660 in
				B738DR_zone_arm[3] = 21.463	-- 845 in
				B738DR_zone_arm[4] = 26.289	-- 1035 in
			end
		end
	elseif cmd == 30 then
		-- male std weight
		numpad_ref = 19
		activate_numpad()
	elseif cmd == 31 then
		-- female std weight
		numpad_ref = 20
		activate_numpad()
	elseif cmd == 32 then
		-- male std weight
		numpad_ref = 21
		activate_numpad()
	elseif cmd == 33 then
		-- FA fwd weight
		numpad_ref = 22
		activate_numpad()
	elseif cmd == 34 then
		-- FA aft weight
		numpad_ref = 23
		activate_numpad()
	elseif cmd == 35 then
		-- galleys F weight
		numpad_ref = 24
		activate_numpad()
	elseif cmd == 36 then
		-- galleys R weight
		numpad_ref = 25
		activate_numpad()
	end
end

function cmd_perf_fuel_cg(cmd)
	if cmd == 16 then
		cat = CAT_PAY_PERF
		page = 1
		min_page = 1
		max_page = 1
		display_update = 1
		B738DR_tab_nav2_manip = 0
	end
end

function page_auto_flight()
	
	line_c[0] =   "        AIRSIDE SERVICES              "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	local units_string = ""
	if B738DR_fmc_units == 0 then
		units_string = "LBS"
	else
		units_string = "KGS"
	end
	
	local num_temp = 0
	
	if page == 1 then
		line[1] = "STATUS:"
		if B738DR_auto_flight == 0 then
			line_s[1] = "        NOT ACTIVE"
		else
			line_g[1] = "        ACTIVE"
		end
		
		local ai_refuel = false
		if auto_fuel_status  >= 1 and auto_fuel_status  <= 2 and B738DR_req_fuel ~= 0 then
			ai_refuel = true
		end
		
		local ai_clean = false
		if auto_catter_status >= 1 and auto_catter_status <= 2 then
			ai_clean = true
		end
		
		local ai_cargo_load = false
		if auto_cargo_status  >= 1 and auto_cargo_status  <= 2 then
			ai_cargo_load = true
		end
		
		local ai_pax_board = false
		if auto_pax_status == 2 then
			ai_pax_board = true
		end
		
		local ai_pax_unboard = false
		local ai_cargo_unload = false
		if B738DR_auto_flight == 7 then
			if zone1_pax[1] ~= 0 or zone2_pax[1] ~= 0 or zone3_pax[1] ~= 0 or zone4_pax[1] ~= 0 or zone5_pax[1] ~= 0 then
				ai_pax_unboard = true
			end
			if zone_cargo1 ~= 0 or zone_cargo2 ~= 0 then
				ai_cargo_unload = true
			end
		end
		
		line[2] = "--------------------------------------"
		local iii = 3
		
		if ai_refuel == true then
			line[iii] = " REFUELING..."
			iii = iii + 1
		end
		
		if ai_clean == true then
			line[iii] = " CLEANING / CATERING LOADING..."
			iii = iii + 1
		end
		
		if ai_cargo_load == true then
			line[iii] = " CARGO LOADING..."
			iii = iii + 1
		end
		
		if ai_pax_board == true then
			line[iii] = " PAX BOARDING..."
			iii = iii + 1
		end
		
		if ai_pax_unboard == true then
			line[iii] = " PAX UNBOARDING..."
			iii = iii + 1
		end
		
		if ai_cargo_unload == true then
			line[iii] = " CARGO UNLOADING..."
			iii = iii + 1
		end
		
		if B738DR_auto_flight == 2  then
			-- if B738DR_req_fuel == 0 and auto_catter_status > 3 then
			if auto_catter_status > 3 then
				if auto_pax_status == 0 and auto_pax_timer <= 0 then
					line[7]   = " HINT:                               "
					if B738DR_no_smoking == 0 then
						if no_smoke_cycle == true then
							line_s[7] = "      FOR PAX BOARDING SET NO SMOKING"
							line_s[8] = "      SWITCH TO ON/AUTO.             "
						else
							line_s[7] = "      FOR PAX BOARDING SET NO SMOKING"
							line_s[8] = "      SWITCH TO OFF AND THEN ON/AUTO."
						end
					elseif B738DR_no_smoking == 1 then
						if no_smoke_cycle == true then
							line_s[7] = "      FOR PAX BOARDING SET CHIME     "
							line_s[8] = "      SWITCH TO ON.                  "
						else
							line_s[7] = "      FOR PAX BOARDING SET CHIME     "
							line_s[8] = "      SWITCH TO OFF AND THEN ON.     "
						end
					end
				end
			end
		elseif B738DR_auto_flight == 3 then
			if auto_after_land == true then
				if simDR_on_ground[0] == 1 and simDR_on_ground[1] == 1 and simDR_on_ground[2] == 1 then
					if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 then
						if B738DR_parking_brake_pos ~= 0 or B738DR_chock_status ~= 0 then
							if simDR_beacon_lights_on ~= 0 then
								line[7]   = " HINT:                               "
								line_s[7] = "      FOR PAX UNBOARDING SET ANTI-   "
								line_s[8] = "      COLLISION SWITCH TO OFF.       "
							end
						end
					end
				end
			end
		end
		
		-- " PAX: 100%   CARGO: 100%   FUEL: 100%"
		line[9] = " PAX:        CARGO:        FUEL:     "
		line_s[9] = "         %             %            %"
		line[9] = " PAX: "
		if auto_pax_tot == 0 then
			line[9] = line[9] .. "---"
			line_g[9] = "         "
		else
			line[9] = line[9] .. "   "
			num_temp = 0
			for zxp = 1, 3 do
				num_temp = num_temp + zone1_pax[zxp] + zone2_pax[zxp] + zone3_pax[zxp] + zone4_pax[zxp] + zone5_pax[zxp]
			end
			line_g[9] = "      " .. string.format("%3d", math.floor((num_temp / auto_pax_tot) * 100))
		end
		
		line[9] = line[9] .. "    CARGO: "
		if auto_cargo_tot == 0 then
			line[9] = line[9] .. "---"
			line_g[9] = line_g[9] .. "              "
		else
			line[9] = line[9] .. "   "
			num_temp = zone_cargo1 + zone_cargo2
			line_g[9] = line_g[9] .. "           " .. string.format("%3d", math.floor((num_temp / auto_cargo_tot) * 100))
		end
		
		line[9] = line[9] .. "    FUEL: "
		if auto_req_fuel == 0 then
			line[9] = line[9] .. "---"
			line_g[9] = line_g[9] .. "          "
		else
			line[9] = line[9] .. "   "
			num_temp = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2]
			line_g[9] = line_g[9] .. "          " .. string.format("%3d", math.floor((num_temp / auto_req_fuel) * 100))
		end
		
		for i = 1, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	elseif page == 2 then
		line[1] = "STATUS:                            "
		line[2] = "--------------------------------------"
		line[3] = " FLIGHT PLAN REQUIREMENTS"
		line[4] = " - PASSENGERS:"
		line[5] = " - CARGO     :"
		line[6] = " - ZFW       :"
		line[7] = " - FUEL      :"
		
		if B738DR_auto_flight == 0 then
			line_s[1] = "        NOT ACTIVE"
			if auto_flight_enable == true then
				line_g[1] = "                          ACTIVATE"
				line[1] = line[1] .. ">>>"
			else
				line_s[1] = line_s[1] .. "        ACTIVATE"
			end
			if auto_pax_tot == 0 then
				line[4] = line[4] .. "                     ---"
			else
				line_g[4] = "                                   " .. string.format("%3d", auto_pax_tot)
			end
			if auto_cargo_tot == 0 then
				line[5] = line[5] .. "              ------"
			else
				if B738DR_fmc_units == 0 then
					line_g[5] = "                            " .. string.format("%6d", auto_cargo_tot * KGS_LBS)
				else
					line_g[5] = "                            " .. string.format("%6d", auto_cargo_tot)
				end
			end
			line_s[5] = "                                   " .. units_string
			if auto_zfw_tot ~= 0 then
				if B738DR_fmc_units == 0 then
					line_s[6] = "                            " .. string.format("%6d", auto_zfw_tot * KGS_LBS) .. " " .. units_string
				else
					line_s[6] = "                            " .. string.format("%6d", auto_zfw_tot) .. " " .. units_string
				end
			end
			if auto_req_fuel == 0 then
				line[7] = line[7] .. "              ------"
			else
				if B738DR_fmc_units == 0 then
					line_g[7] = "                            " .. string.format("%6d", auto_req_fuel * KGS_LBS)
				else
					line_g[7] = "                            " .. string.format("%6d", auto_req_fuel)
				end
			end
			line_s[7] = "                                   " .. units_string
			line[8] = "--------------------------------------"
			line[9] = " <<<                                  "
			line_g[9] = "     LOAD OFP                         "
			
		else
			line[1] = line[1] .. ">>>"
			line_g[1] = "        ACTIVE              CANCEL"
			if auto_pax_tot ~= 0 then
				line_s[4] = "                                   " .. string.format("%3d", auto_pax_tot)
			end
			if auto_cargo_tot ~= 0 then
				if B738DR_fmc_units == 0 then
					line_s[5] = "                            " .. string.format("%6d", auto_cargo_tot * KGS_LBS) .. " " .. units_string
				else
					line_s[5] = "                            " .. string.format("%6d", auto_cargo_tot) .. " " .. units_string
				end
			end
			if auto_zfw_tot ~= 0 then
				if B738DR_fmc_units == 0 then
					line_s[6] = "                            " .. string.format("%6d", auto_zfw_tot * KGS_LBS) .. " " .. units_string
				else
					line_s[6] = "                            " .. string.format("%6d", auto_zfw_tot) .. " " .. units_string
				end
			end
			if auto_req_fuel ~= 0 then
				if B738DR_fmc_units == 0 then
					line_s[7] = "                            " .. string.format("%6d", auto_req_fuel * KGS_LBS) .. " " .. units_string
				else
					line_s[7] = "                            " .. string.format("%6d", auto_req_fuel) .. " " .. units_string
				end
			end
		end
		
		for i = 1, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		if auto_flight_enable == true then
			B738DR_tab_line_manip[1] = 1
		end
		if B738DR_auto_flight == 0 then
			B738DR_tab_line_manip[4] = 1
			B738DR_tab_line_manip[5] = 1
			-- B738DR_tab_line_manip[6] = 1
			B738DR_tab_line_manip[7] = 1
			B738DR_tab_line_manip[9] = 1
		end
	end
	
end

function cmd_auto_flight(cmd)
	local num_tmp = 0
	local num_tmp2 = 0
	local num_tmp3 = 0
	local zxp = 0
	
	if cmd == 10 then
		if B738DR_auto_flight == 0 then
			B738DR_auto_flight = 1
			
			-- if B738DR_pax_layout == 0 then
				-- num_tmp = 160
			-- elseif B738DR_pax_layout == 1 then
				-- num_tmp = 180
			-- else
				-- num_tmp = 189
			-- end
			
			if B738DR_pax_layout < 0 or B738DR_pax_layout > 9 then
				num_tmp = 189
			else
				num_tmp = max_pax_layout[B738DR_pax_layout + 1]
			end
			
			if auto_pax_tot > num_tmp then
				auto_pax_tot = num_tmp
			end
			
			num_tmp2 = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0]
			num_tmp3 = num_tmp2 + 8410
			
			if num_tmp2 > auto_zfw_tot then
				while num_tmp2 > auto_zfw_tot do
					if auto_pax_tot <= 0 then
						auto_pax_tot = 0
						break
					else
						auto_pax_tot = auto_pax_tot - 1
						num_tmp2 = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0]
					end
				end
			elseif num_tmp3 < auto_zfw_tot then
				while num_tmp3 < auto_zfw_tot do
					if auto_pax_tot >= num_tmp then
						auto_pax_tot = num_tmp
						break
					else
						auto_pax_tot = auto_pax_tot + 1
						num_tmp2 = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0]
						num_tmp3 = num_tmp2 + 8410
					end
				end
			end
			
			auto_cargo_tot = auto_zfw_tot - num_tmp2
			if auto_cargo_tot > 8410 then
				auto_cargo_tot = 8410
			elseif auto_cargo_tot < 0 then
				auto_cargo_tot = 0
			end
			
			if auto_cargo_tot <= 300 then
				cargo1_tgt = auto_cargo_tot
			elseif auto_cargo_tot <= 1000 then
				cargo1_tgt = 300
			else
				if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 or B738DR_73x == 2 then
					cargo1_tgt = math.floor((auto_cargo_tot * B738_rescale(1000, 0.3, 5099, 0.378, auto_cargo_tot)) + 0.5)
					-- cargo1_tgt = math.floor((auto_cargo_tot * 0.377) + 0.5)
					-- cargo1_tgt = math.floor((auto_cargo_tot * 0.226) + 0.5) + 1000
					if cargo1_tgt > 1927 then
						cargo1_tgt = 1927
					end
				else
					cargo1_tgt = math.floor((auto_cargo_tot * B738_rescale(1000, 0.3, 8410, 0.423, auto_cargo_tot)) + 0.5)
					-- cargo1_tgt = math.floor((auto_cargo_tot * 0.423) + 0.5)
					-- cargo1_tgt = math.floor((auto_cargo_tot * 0.345) + 0.5) + 1000
					if cargo1_tgt > 3560 then
						cargo1_tgt = 3560
					end
				end
			end
			
			cargo2_tgt = auto_cargo_tot - cargo1_tgt
			if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 or B738DR_73x == 2 then
				if cargo2_tgt > 3172 then
					cargo2_tgt = 3172
				elseif cargo2_tgt < 0 then
					cargo2_tgt = 0
				end
			else
				if cargo2_tgt > 4850 then
					cargo2_tgt = 4850
				elseif cargo2_tgt < 0 then
					cargo2_tgt = 0
				end
			end
			auto_cargo_tot = cargo1_tgt + cargo2_tgt
			
			for zxp = 1, 3 do
				zone1_pax[zxp] = 0
				zone2_pax[zxp] = 0
				zone3_pax[zxp] = 0
				zone4_pax[zxp] = 0
				zone5_pax[zxp] = 0
			end
			
			zone1_pax_tgt = math.floor((B738DR_std_pax_num[0] / num_tmp) * auto_pax_tot)
			zone2_pax_tgt = math.floor((B738DR_std_pax_num[1] / num_tmp) * auto_pax_tot)
			zone3_pax_tgt = math.floor((B738DR_std_pax_num[2] / num_tmp) * auto_pax_tot)
			zone4_pax_tgt = math.floor((B738DR_std_pax_num[3] / num_tmp) * auto_pax_tot)
			zone5_pax_tgt = math.floor((B738DR_std_pax_num[4] / num_tmp) * auto_pax_tot)
			
			num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			while num_tmp < auto_pax_tot do
				if zone1_pax_tgt >= B738DR_std_pax_num[0] then
					break
				end
				zone1_pax_tgt = zone1_pax_tgt + 1
				num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			end
			
			while num_tmp < auto_pax_tot do
				if zone2_pax_tgt >= B738DR_std_pax_num[1] then
					break
				end
				zone2_pax_tgt = zone2_pax_tgt + 1
				num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			end
			
			while num_tmp < auto_pax_tot do
				if zone3_pax_tgt >= B738DR_std_pax_num[2] then
					break
				end
				zone3_pax_tgt = zone3_pax_tgt + 1
				num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			end
			
			while num_tmp < auto_pax_tot do
				if zone4_pax_tgt >= B738DR_std_pax_num[3] then
					break
				end
				zone4_pax_tgt = zone4_pax_tgt + 1
				num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			end
			
			while num_tmp < auto_pax_tot do
				if zone5_pax_tgt >= B738DR_std_pax_num[4] then
					break
				end
				zone5_pax_tgt = zone5_pax_tgt + 1
				num_tmp = zone1_pax_tgt + zone2_pax_tgt + zone3_pax_tgt + zone4_pax_tgt + zone5_pax_tgt
			end
			
			auto_after_land = false
			gp_cable_connect = B738DR_gp_cable_connect
			B738DR_gp_cable_connect = 0
		else
			B738DR_auto_flight = 0
			B738DR_req_fuel = 0
			B738DR_hide_fueltruck = 1
			hide_fueltruck = 1
			B738DR_hide_fwd_stairs = 1
			B738DR_hide_aft_stairs = 1
			B738DR_hide_pax_bus = 1
			B738DR_hide_pax_bus2 = 1
			auto_after_land = false
			B738DR_gp_cable_connect = gp_cable_connect
		end
	elseif cmd == 13 then
		--pax
		numpad_ref = 301
		activate_numpad()
	elseif cmd == 14 then
		--cargo
		numpad_ref = 302
		activate_numpad()
	elseif cmd == 16 then
		-- fuel
		numpad_ref = 300
		activate_numpad()
	elseif cmd == 18 then
		load_ofp()
	end
end

function load_ofp()
	local apt_line = ""
	local iii = 0
	local jjj = 0
	local kkk = 0
	local lll = 0
	local xml_data_txt = ""
	local xml_data_num = 0
	
	local flt_num1_txt = ""
	local flt_num2_txt = ""
	
	local toc_act = 0
	local fix_act = 0
	local valid_toc = 0
	local valid_id = 0
	local id_str = ""
	
	auto_pax_tot = 0
	auto_cargo_tot = 0
	auto_req_fuel = 0
	auto_payload_tot = 0
	auto_zfw_tot = 0
	zone1_pax_tgt = 0
	zone2_pax_tgt = 0
	zone3_pax_tgt = 0
	zone4_pax_tgt = 0
	zone5_pax_tgt = 0
	cargo1_tgt = 0
	cargo2_tgt = 0
	
	local file_name_imp = "Output/FMS plans/" .. "b738x.xml"
	local file_navdata2 = io.open(file_name_imp, "r")
	if file_navdata2 ~= nil then
		--parse xml data
		apt_line = file_navdata2:read()
		while apt_line do
			if auto_pax_tot == 0 then
				iii,jjj = string.find(apt_line, "<pax_count>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_num = tonumber(string.sub(apt_line, iii+11, kkk-1))
						if xml_data_num ~= nil then
							auto_pax_tot = xml_data_num
							if B738DR_pax_layout < 0 or B738DR_pax_layout > 9 then
								if auto_pax_tot > 189 then
									auto_pax_tot = 189
								end
							elseif auto_pax_tot > max_pax_layout[B738DR_pax_layout + 1] then
								auto_pax_tot = max_pax_layout[B738DR_pax_layout + 1]
							end
						end
					end
				end
			end
			if auto_cargo_tot == 0 then
				iii,jjj = string.find(apt_line, "<cargo>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_num = tonumber(string.sub(apt_line, iii+7, kkk-1))
						if xml_data_num ~= nil then
							auto_cargo_tot = xml_data_num
						end
					end
				end
			end
			if auto_payload_tot == 0 then
				iii,jjj = string.find(apt_line, "<payload>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_num = tonumber(string.sub(apt_line, iii+9, kkk-1))
						if xml_data_num ~= nil then
							auto_payload_tot = xml_data_num
						end
					end
				end
			end
			if auto_zfw_tot == 0 then
				iii,jjj = string.find(apt_line, "<est_zfw>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_num = tonumber(string.sub(apt_line, iii+9, kkk-1))
						if xml_data_num ~= nil then
							auto_zfw_tot = xml_data_num
						end
					end
				end
			end
			
			if auto_req_fuel == 0 then
				iii,jjj = string.find(apt_line, "<plan_ramp>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_num = tonumber(string.sub(apt_line, iii+11, kkk-1))
						if xml_data_num ~= nil then
							auto_req_fuel = xml_data_num
						end
					end
				end
			end
			if xml_data_txt == "" then
				iii,jjj = string.find(apt_line, "<units>")
				if iii ~= nil then
					kkk,lll = string.find(apt_line, "</")
					if kkk ~= nil then
						xml_data_txt = string.sub(apt_line, iii+7, kkk-1)
					end
				end
			end
			
			apt_line = file_navdata2:read()
		end
		file_navdata2:close()
	end
	
	if xml_data_txt ~= "kgs" then
		auto_cargo_tot = auto_cargo_tot / KGS_LBS
		auto_req_fuel = auto_req_fuel / KGS_LBS
		auto_payload_tot = auto_payload_tot / KGS_LBS
		auto_zfw_tot = auto_zfw_tot / KGS_LBS
	end
end

function jbr_opt()
	local rwy_list = ""
	local rwy_list_len = 0
	local rwy_temp = ""
	local rwy_idx_temp = 0
	
	if B738DR_jbr_opt737 == 0 then
		perf_ref_rwy_num = 0
		ref_icao_old = ""
		jbr_find_rwy_timer = 0
		perf_rwy = 0
		perf_intx = 0
		perf_takeoff_rating = 0
	else
		if jbr_find_rwy_timer ~= 0 then
			if perf_ref_rwy_num == 0 then
				if JBRDR_737opt_status == "OK" then
					jbr_find_rwy_timer = 0
					--parse runways
					rwy_list = JBRDR_737opt_runway_list
					rwy_list_len = string.len(rwy_list)
					if rwy_list_len > 0 then
						rwy_temp = ""
						for aaa = 1, rwy_list_len do
							if string.sub(rwy_list, aaa, aaa) == "," then
								if rwy_temp ~= "" then
									perf_ref_rwy_num = perf_ref_rwy_num + 1
									perf_ref_rwy_list[perf_ref_rwy_num] = rwy_temp
									rwy_temp = ""
								end
							else
								rwy_temp = rwy_temp .. string.sub(rwy_list, aaa, aaa)
							end
						end
						if rwy_temp ~= "" then
							perf_ref_rwy_num = perf_ref_rwy_num + 1
							perf_ref_rwy_list[perf_ref_rwy_num] = rwy_temp
						end
						
						--parse rwy and intx
						local rwy_correct = ""
						local rwy_correct_len = 0
						local rwy_correct_intx = 0
						if perf_ref_rwy_num > 0 then
							for aaa = 1, perf_ref_rwy_num do
								rwy_correct = perf_ref_rwy_list[aaa]
								rwy_correct_len = string.len(rwy_correct)
								rwy_correct_intx = 0
								for bbb = 1, rwy_correct_len do
									if string.sub(rwy_correct, bbb, bbb) == "_" then
										rwy_correct_intx = bbb + 1
									end
								end
								if rwy_correct_intx == 0 then
									perf_ref_rwy_lst_num = perf_ref_rwy_lst_num + 1
									perf_ref_rwy_lst[perf_ref_rwy_lst_num] = rwy_correct
									perf_ref_rwy_intx_num[perf_ref_rwy_lst_num] = 1
									perf_ref_rwy_intx[perf_ref_rwy_lst_num] = {}
									perf_ref_rwy_intx[perf_ref_rwy_lst_num][perf_ref_rwy_intx_num[perf_ref_rwy_lst_num]] = "FULL"
								elseif rwy_correct_intx <= rwy_correct_len then
									perf_ref_rwy_intx_num[perf_ref_rwy_lst_num] = perf_ref_rwy_intx_num[perf_ref_rwy_lst_num] + 1
									perf_ref_rwy_intx[perf_ref_rwy_lst_num][perf_ref_rwy_intx_num[perf_ref_rwy_lst_num]] = string.sub(rwy_correct, rwy_correct_intx, -1)
								end
							end
							perf_rwy = 1
							perf_intx = 1
						end
						
					end
				elseif string.sub(JBRDR_737opt_status, 1, 3) == "ERR" then
					jbr_find_rwy_timer = 0
				end
			else
				if JBRDR_737opt_status == "OK" then
					jbr_find_rwy_timer = 0
					perf_takeoff_err = 0
					
					--parse result
					rwy_list = JBRDR_737opt_result
					rwy_list_len = string.len(rwy_list)
					if rwy_list_len > 0 then
						rwy_temp = ""
						rwy_idx_temp = 0
						
						for aaa = 1, rwy_list_len do
							if string.sub(rwy_list, aaa, aaa) == "," then
								if rwy_temp ~= "" then
									if rwy_idx_temp == 0 then
										perf_takeoff_windshear = tonumber(rwy_temp)
									elseif rwy_idx_temp == 1 then
										perf_takeoff_full_valid = tonumber(rwy_temp)
									elseif rwy_idx_temp == 2 then
										perf_takeoff_full_rating = tonumber(rwy_temp)
									elseif rwy_idx_temp == 3 then
										perf_takeoff_full_n1 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 4 then
										perf_takeoff_full_v1 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 5 then
										perf_takeoff_full_vr = tonumber(rwy_temp)
									elseif rwy_idx_temp == 6 then
										perf_takeoff_full_v2 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 7 then
										perf_takeoff_atm_valid = tonumber(rwy_temp)
									elseif rwy_idx_temp == 8 then
										perf_takeoff_atm_rating = tonumber(rwy_temp)
									elseif rwy_idx_temp == 9 then
										perf_takeoff_atm_seltemp = tonumber(rwy_temp)
									elseif rwy_idx_temp == 10 then
										perf_takeoff_atm_n1 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 11 then
										perf_takeoff_atm_v1 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 12 then
										perf_takeoff_atm_vr = tonumber(rwy_temp)
									elseif rwy_idx_temp == 13 then
										perf_takeoff_atm_v2 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 14 then
										perf_takeoff_max_wt = tonumber(rwy_temp)
									elseif rwy_idx_temp == 15 then
										perf_takeoff_vref40 = tonumber(rwy_temp)
									elseif rwy_idx_temp == 16 then
										perf_takeoff_flaps = tonumber(rwy_temp)
										perf_takeoff_flaps = tonumber(rwy_temp)
									elseif rwy_idx_temp == 17 then
										perf_takeoff_trim = tonumber(rwy_temp)
									end
									
									rwy_temp = ""
									rwy_idx_temp = rwy_idx_temp + 1
								end
							else
								rwy_temp = rwy_temp .. string.sub(rwy_list, aaa, aaa)
							end
						end
						
						if rwy_temp ~= "" then
							if rwy_idx_temp == 0 then
								perf_takeoff_windshear = tonumber(rwy_temp)
							elseif rwy_idx_temp == 1 then
								perf_takeoff_full_valid = tonumber(rwy_temp)
							elseif rwy_idx_temp == 2 then
								perf_takeoff_full_rating = tonumber(rwy_temp)
							elseif rwy_idx_temp == 3 then
								perf_takeoff_full_n1 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 4 then
								perf_takeoff_full_v1 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 5 then
								perf_takeoff_full_vr = tonumber(rwy_temp)
							elseif rwy_idx_temp == 6 then
								perf_takeoff_full_v2 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 7 then
								perf_takeoff_atm_valid = tonumber(rwy_temp)
							elseif rwy_idx_temp == 8 then
								perf_takeoff_atm_rating = tonumber(rwy_temp)
							elseif rwy_idx_temp == 9 then
								perf_takeoff_atm_seltemp = tonumber(rwy_temp)
							elseif rwy_idx_temp == 10 then
								perf_takeoff_atm_n1 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 11 then
								perf_takeoff_atm_v1 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 12 then
								perf_takeoff_atm_vr = tonumber(rwy_temp)
							elseif rwy_idx_temp == 13 then
								perf_takeoff_atm_v2 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 14 then
								perf_takeoff_max_wt = tonumber(rwy_temp)
							elseif rwy_idx_temp == 15 then
								perf_takeoff_vref40 = tonumber(rwy_temp)
							elseif rwy_idx_temp == 16 then
								perf_takeoff_flaps = tonumber(rwy_temp)
							elseif rwy_idx_temp == 17 then
								perf_takeoff_trim = tonumber(rwy_temp)
							end
						end
					end
					
					if rwy_idx_temp >= 16 then
						perf_takeoff_rating = 1
						
						if perf_takeoff_atm_valid ~= 0 and perf_takeoff_full_valid ~= 0 then
							perf_takeoff_full = 0
						elseif perf_takeoff_full_valid ~= 0 then
							perf_takeoff_full = 1
						else
							perf_takeoff_full = 0
						end
					end
					
				elseif string.sub(JBRDR_737opt_status, 1, 3) == "ERR" then
					jbr_find_rwy_timer = 0
					perf_takeoff_err = 1
					perf_takeoff_rating = 1
				end
			end
			
			if jbr_find_rwy_timer ~= 0 then
				jbr_find_rwy_timer = jbr_find_rwy_timer - SIM_PERIOD
				if jbr_find_rwy_timer < 0 then
					jbr_find_rwy_timer = 0
					if perf_ref_rwy_num ~= 0 then
						perf_takeoff_err = 1
					end
				end
			end
		else
			if B738DR_ref_list_rwy_icao ~= ref_icao_old then
				JBRDR_737opt_icao = B738DR_ref_list_rwy_icao
				JBRCMD_737opt_fetch_rwy:once()
				perf_ref_rwy_num = 0
				perf_ref_rwy_list = {}
				perf_ref_rwy_list_len = {}
				perf_ref_rwy_list_hdg = {}
				perf_ref_rwy_lst_num = 0
				perf_ref_rwy_lst = {}
				perf_ref_rwy_intx_num = {}
				perf_ref_rwy_intx = {}
				jbr_find_rwy_timer = 30
				perf_rwy = 0
				perf_intx = 0
				perf_takeoff_rating = 0
			end
			ref_icao_old = B738DR_ref_list_rwy_icao
		end
	end
end

function jbr_opt_calculate()
	local jbr_entry = ""
	
	if perf_ref_rwy_lst_num > 0 and perf_rwy > 0 and perf_rwy <= perf_ref_rwy_lst_num and perf_intx > 0 and perf_intx <= perf_ref_rwy_intx_num[perf_rwy] then
		
		jbr_entry = perf_ref_rwy_lst[perf_rwy]
		if perf_ref_rwy_intx[perf_rwy][perf_intx] ~= "FULL" then
			jbr_entry = jbr_entry .. "_" .. perf_ref_rwy_intx[perf_rwy][perf_intx]
		end
		
		if perf_flap == "OPTIMUM" then
			jbr_entry = jbr_entry .. ",0"
		else
			jbr_entry = jbr_entry .. "," .. perf_flap
		end
		
		jbr_entry = jbr_entry .. "," .. tostring(perf_oat)
		
		if perf_qnh <= 40 then
			jbr_entry = jbr_entry .. "," .. tostring(math.floor(perf_qnh * 33.8639))
		else
			jbr_entry = jbr_entry .. "," .. tostring(perf_qnh)
		end
		
		if perf_cond == "DRY" then
			jbr_entry = jbr_entry .. ",1"
		else
			jbr_entry = jbr_entry .. ",0"
		end
		
		jbr_entry = jbr_entry .. "," .. tostring(math.floor(perf_weight / 100) / 10)
		
		if perf_ac == "OFF" then
			jbr_entry = jbr_entry .. ",0"
		else
			jbr_entry = jbr_entry .. ",1"
		end
		
		if perf_ai == "OFF" then
			jbr_entry = jbr_entry .. ",0,0"
		elseif perf_ai == "ENG" then
			jbr_entry = jbr_entry .. ",1,0"
		elseif perf_ai == "WING" then
			jbr_entry = jbr_entry .. ",0,1"
		else
			jbr_entry = jbr_entry .. ",1,1"
		end
		
		if perf_wind_spd ~= 0 then
			if perf_wind_dir < 0 then
				jbr_entry = jbr_entry .. "," .. tostring(perf_wind_spd)
			else
				jbr_entry = jbr_entry .. "," .. tostring(perf_wind_dir) .. "/" .. tostring(perf_wind_spd)
			end
		else
			jbr_entry = jbr_entry .. ",0"
		end
		
		jbr_entry = jbr_entry .. "," .. perf_rtg
		
		jbr_entry = jbr_entry .. ",0, " .. perf_cg .. ",0"
		
		perf_takeoff_rating = 0
		
		--send command
		jbr_find_rwy_timer = 300
		JBRDR_737opt_query_input = jbr_entry
		JBRCMD_737opt_calculate:once()
	end
end


function page_perf_takeof()
	
	if perf_takeoff_rating ~= 0 then
		max_page = 2
	else
		max_page = 1
	end
	
	line_c[0] =   "        PERFORMANCE TAKEOFF           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	local units_string = ""
	if B738DR_fmc_units == 0 then
		units_string = "LBS"
	else
		units_string = "KGS"
	end
	
	if page == 1 then
		
		perf_arpt = B738DR_ref_list_rwy_icao
		
		local p_arpt = spaces_after(perf_arpt, 14)
		local p_rwy = ""
		local p_intx = ""
		
		if perf_ref_rwy_lst_num > 0 and perf_rwy > 0 and perf_rwy <= perf_ref_rwy_lst_num and perf_intx > 0 and perf_intx <= perf_ref_rwy_intx_num[perf_rwy] then
			p_rwy = perf_ref_rwy_lst[perf_rwy]
			p_intx = perf_ref_rwy_intx[perf_rwy][perf_intx]
		end
		
		p_rwy = spaces_after(p_rwy, 14)
		p_intx = spaces_after(p_intx, 14)
		
		local p_cond = spaces_after(perf_cond, 14)
		local p_wind = ""
		if perf_wind_spd ~= 0 then
			if perf_wind_dir < 0 then
				p_wind = tostring(perf_wind_spd) .. " KT"
			else
				p_wind = string.format("%03d", perf_wind_dir) .. "/" .. tostring(perf_wind_spd) .. " KT"
			end
		else
			p_wind = "0 KT"
		end
		p_wind = spaces_after(p_wind, 14)
		local p_oat = tostring(perf_oat) .. "`C"
		p_oat = spaces_after(p_oat, 14)
		local p_qnh = ""
		if perf_qnh <= 40 then
			p_qnh = string.format("%5.2f", perf_qnh) .. " IN HG"
		else
			p_qnh = string.format("%6.1f", perf_qnh) .. " HPA"
		end
		p_qnh = spaces_after(p_qnh, 14)
		
		local p_rtg = perf_rtg
		local p_atm = perf_atm
		local p_flap = perf_flap
		local p_ac = perf_ac
		local p_ai = perf_ai
		local p_weight = perf_weight
		local p_cg = perf_cg
		
		line_s[1] =   "  ARPT                            RTG "
		line_g[1] =   "       " .. p_arpt .. p_rtg
		line_s[2] =   "   RWY                            ATM "
		line_g[2] =   "       " .. p_rwy .. p_atm
		line_s[3] =   "  INTX                            FLAP"
		line_g[3] =   "       " .. p_intx .. p_flap
		line_s[4] =   "  COND                            A/C "
		line_g[4] =   "       " .. p_cond .. p_ac
		line_s[5] =   "  WIND                            A/I "
		line[5] =     "       " .. p_wind
		line_g[5] =   "                     " .. p_ai
		line_s[6] =   "   OAT"
		line[6] =     "       " .. p_oat
		line_s[7] =   "   QNH"
		line[7] =     "       " .. p_qnh
		line_s[8] =   "  TAKEOFF WT:                CG%:     "
		
		if B738DR_fmc_units == 0 then
			line[8] =     "              " .. string.format("%6d", p_weight * KGS_LBS)
		else
			line[8] =     "              " .. string.format("%6d", p_weight)
		end
		line[8] = line[8] .. " " .. string.sub(units_string, 1, 2) ..   "           " .. string.format("%4.1f", p_cg)
		-- if perf_wind_spd > 0 then
			-- if perf_head_wind == 0 then
				-- line_s[9] = "  0 HW / "
			-- elseif perf_head_wind < 0 then
				-- line_s[9] = "  " ..tostring(-perf_head_wind) .. " HW / "
			-- else
				-- line_s[9] = "  " .. tostring(perf_head_wind) .. " TW / "
			-- end
			-- if perf_cross_wind == 0 then
				-- line_s[9] = line_s[9] .. "0 XW KT"
			-- elseif perf_cross_wind > 0 then
				-- line_s[9] = line_s[9] .. "L" .. tostring(perf_cross_wind) .. " XW KT"
			-- else
				-- line_s[9] = line_s[9] .. "R" .. tostring(-perf_cross_wind) .. " XW KT"
			-- end
		-- end
		
		for i = 1, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		for i = 0, 15 do
			B738DR_tab_perf_manip[i] = 1
		end
		-- B738DR_tab_perf_manip[2] = 0
		B738DR_tab_perf_manip[13] = 0
		B738DR_tab_perf_manip[14] = 0
		
		if jbr_find_rwy_timer == 0 and B738DR_jbr_opt737 ~= 0 and perf_weight ~= 0 then
			if perf_ref_rwy_lst_num > 0 and perf_rwy > 0 and perf_rwy <= perf_ref_rwy_lst_num and perf_intx > 0 and perf_intx <= perf_ref_rwy_intx_num[perf_rwy] then
				line[9] = "               < CALCULATE >"
				B738DR_tab_line_manip[9] = 1
			end
		end
		
	elseif page == 2 then
		B738DR_atm_valid = 0
		if perf_takeoff_err == 0 and (perf_takeoff_atm_valid ~= 0 or perf_takeoff_full_valid ~= 0) then
			
			if perf_takeoff_full == 0 then
				perf_takeoff_rating = perf_takeoff_atm_rating
				perf_takeoff_seltemp = perf_takeoff_atm_seltemp
				perf_takeoff_n1 = perf_takeoff_atm_n1
				perf_takeoff_v1 = perf_takeoff_atm_v1
				perf_takeoff_vr = perf_takeoff_atm_vr
				perf_takeoff_v2 = perf_takeoff_atm_v2
				B738DR_atm_valid = 1
				line_g[1] = "      ATM"
				if perf_takeoff_full_valid ~= 0 then
					line[1] =   " FULL/"
				else
					line[1] =   "     /"
					line_s[1] = " FULL    "
				end
			else
				perf_takeoff_rating = perf_takeoff_full_rating
				perf_takeoff_seltemp = 0
				perf_takeoff_n1 = perf_takeoff_full_n1
				perf_takeoff_v1 = perf_takeoff_full_v1
				perf_takeoff_vr = perf_takeoff_full_vr
				perf_takeoff_v2 = perf_takeoff_full_v2
				line_g[1] = " FULL    "
				if perf_takeoff_atm_valid ~= 0 then
					line[1] =   "     /ATM"
				else
					line[1] =   "     /"
					line_s[1] = "      ATM"
				end
			end
			
			line_s[2] =   " FLAP               TRIM              "
			line_s[3] =   "                             V1       "
			if perf_takeoff_flaps < 10 then
				line[3] = " " .. perf_takeoff_flaps .. " "
			else
				line[3] = " " .. perf_takeoff_flaps
			end
			
			if perf_takeoff_trim <= 0 or perf_cg < 6 or perf_cg > 36 then
				line[3] = line[3] .. "                 N/A         "
			else
				line[3] = line[3] .. "                 " .. string.format("%4.2f", perf_takeoff_trim) .. "        "
			end
			
			line[3] = line[3] .. string.format("%3d", perf_takeoff_v1) .. " KT"
			
			line_s[5] =   " RWY/INTX                    VR       "
			line[5] =     "                                " .. string.format("%3d", perf_takeoff_vr) .. " KT"
			if perf_ref_rwy_lst_num > 0 and perf_rwy > 0 and perf_rwy <= perf_ref_rwy_lst_num and perf_intx > 0 and perf_intx <= perf_ref_rwy_intx_num[perf_rwy] then
				local rwy_result = perf_ref_rwy_lst[perf_rwy]
				if perf_ref_rwy_intx[perf_rwy][perf_intx] ~= "FULL" then
					rwy_result = rwy_result .. "/" .. perf_ref_rwy_intx[perf_rwy][perf_intx]
				end
				line[6] =     " " .. rwy_result
			end
			
			line_s[7] =   "                             V2       "
			line[7] =     "                                " .. string.format("%3d", perf_takeoff_v2) .. " KT"
			
			line_s[8] =   " TOGW     "
			if perf_takeoff_seltemp > perf_oat and perf_takeoff_seltemp ~= 0 then
				line_s[8] = line_s[8] .. "R-" .. tostring(perf_takeoff_rating)
			else
				line_s[8] = line_s[8] .. " " .. tostring(perf_takeoff_rating) .. " "
			end
			line_s[8] = line_s[8] .. "K  SEL TMP"
			
			line[9] =     " " .. string.format("%5d", perf_weight) .. "    " .. string.format("%5.1f", perf_takeoff_n1)  .. "    "
			if perf_takeoff_seltemp > perf_oat and perf_takeoff_seltemp ~= 0 then
				line[9] = line[9] .. string.format("%2d", perf_takeoff_seltemp)
			else
				line[9] = line[9] .. "--"
			end
			
			line[9] = line[9] .. "           " .. string.format("%3d", perf_takeoff_vref40) .. " KT"
			
			line_s[9] =   "      KG             C   VREF40"
			
			B738DR_tab_line_manip[1] = 1
			for i = 2, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		else
			line[1] =   " CALCULATION ERROR"
			
			for i = 1, 9 do
				B738DR_tab_line_manip[i] = 0
			end
		end
		for i = 0, 15 do
			B738DR_tab_perf_manip[i] = 0
		end
	end
end

function cmd_perf_takeoff(cmd)
	
	-- if cmd == 1 then
		-- numpad_ref = 100
		-- activate_numpad()
	-- elseif cmd == 2 then
		-- numpad_ref = 101
		-- activate_numpad()
	-- elseif cmd == 3 then
		-- numpad_ref = 102
		-- activate_numpad()
	-- end
	if cmd == 9 then
		jbr_opt_calculate()
	elseif cmd == 10 then
		if perf_takeoff_err == 0 and (perf_takeoff_atm_valid ~= 0 or perf_takeoff_full_valid ~= 0) then
			if perf_takeoff_atm_valid ~= 0 and perf_takeoff_full_valid ~= 0 then
				if perf_takeoff_full == 0 then
					perf_takeoff_full = 1
				else
					perf_takeoff_full = 0
				end
			elseif perf_takeoff_full_valid ~= 0 then
				perf_takeoff_full = 1
			else
				perf_takeoff_full = 0
			end
		end
	end
end

function cmd_perf_takeoff2(cmd)
	-- ** Takeoff ** --
	if cmd == 1 then
		-- APT
	elseif cmd == 2 then
		-- RWY
		if perf_ref_rwy_lst_num > 0 then
			perf_rwy = perf_rwy + 1
			if perf_rwy > perf_ref_rwy_lst_num then
				perf_rwy = 1
			end
			perf_intx = 1
			-- calc_perf_wind()
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 3 then
		--INTX
		if perf_ref_rwy_lst_num > 0 and perf_rwy > 0 then
			if perf_ref_rwy_intx_num[perf_rwy] > 0 then
				perf_intx = perf_intx + 1
				if perf_intx > perf_ref_rwy_intx_num[perf_rwy] then
					perf_intx = 1
				end
			end
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 4 then
		-- COND
		if perf_cond == "DRY" then
			perf_cond = "WET"
		elseif perf_cond == "WET" then
			perf_cond = "SK-R"
		else
			perf_cond = "DRY"
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 5 then
		-- WIND
		numpad_ref = 202
		activate_numpad()
		B738DR_tab_numpad_spec2 = 1
		perf_takeoff_rating = 0
	elseif cmd == 6 then
		-- OAT
		numpad_ref = 203
		activate_numpad()
		perf_takeoff_rating = 0
	elseif cmd == 7 then
		-- QNH
		numpad_ref = 204
		activate_numpad()
		perf_takeoff_rating = 0
	elseif cmd == 8 then
		-- TOW
		numpad_ref = 205
		activate_numpad()
		perf_takeoff_rating = 0
	elseif cmd == 9 then
		-- RTG
		if perf_rtg == "OPTIMUM" then
			perf_rtg = "R26K"
		elseif perf_rtg == "R26K" then
			perf_rtg = "R24K"
		elseif perf_rtg == "R24K" then
			perf_rtg = "R22K"
		elseif perf_rtg == "R22K" then
			perf_rtg = "WINDSHEAR"
		else
			perf_rtg = "OPTIMUM"
		end
		perf_takeoff_rating = 0
	elseif cmd == 10 then
		-- ATM
	elseif cmd == 11 then
		-- FLAP
		if perf_flap == "1" then
			perf_flap = "5"
		elseif perf_flap == "5" then
			perf_flap = "10"
		elseif perf_flap == "10" then
			perf_flap = "15"
		elseif perf_flap == "15" then
			perf_flap = "OPTIMUM"
		else
			perf_flap = "1"
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 12 then
		-- A/C
		if perf_ac == "ON" then
			perf_ac = "AUTO"
		elseif perf_ac == "AUTO" then
			perf_ac = "OFF"
		else
			perf_ac = "ON"
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 13 then
		-- A/I
		if perf_ai == "OFF" then
			perf_ai = "ENG"
		elseif perf_ai == "ENG" then
			perf_ai = "WING"
		elseif perf_ai == "WING" then
			perf_ai = "ENG/WING"
		else
			perf_ai = "OFF"
		end
		display_update = 1
		perf_takeoff_rating = 0
	elseif cmd == 16 then
		-- CG
		numpad_ref = 206
		activate_numpad()
		perf_takeoff_rating = 0
	end
end


-- function calc_perf_wind()
	-- if perf_wind_spd > 0 and perf_ref_rwy_num > 0 and perf_rwy <= perf_ref_rwy_num and perf_rwy > 0 then
		-- perf_head_wind = perf_wind_spd * math.cos(math.rad(Angle180(perf_wind_dir))-math.rad(perf_ref_rwy_list_hdg[perf_rwy]))
		-- perf_cross_wind = perf_wind_spd * math.sin(math.rad(Angle180(perf_wind_dir))-math.rad(perf_ref_rwy_list_hdg[perf_rwy]))
		-- if perf_head_wind > 0 then
			-- perf_head_wind = math.floor (perf_head_wind + 0.5)
		-- else
			-- perf_head_wind = -perf_head_wind
			-- perf_head_wind = math.floor (perf_head_wind + 0.5)
			-- perf_head_wind = -perf_head_wind
		-- end
		-- if perf_cross_wind > 0 then
			-- perf_cross_wind = math.floor (perf_cross_wind + 0.5)
		-- else
			-- perf_cross_wind = -perf_cross_wind
			-- perf_cross_wind = math.floor (perf_cross_wind + 0.5)
			-- perf_cross_wind = -perf_cross_wind
		-- end
	-- else
		-- perf_head_wind = 0
		-- perf_cross_wind = 0
	-- end
-- end

function page_perf_land()
	
	local units_string = ""
	if B738DR_fmc_units == 0 then
		units_string = "LBS"
	else
		units_string = "KGS"
	end
	
	if perf_lnd_arpt == "" or perf_lnd_rwy == 0 or perf_lnd_weight < 40000 then
		max_page = 1
	else
		max_page = 2
	end
	
	line_c[0] =   "        PERFORMANCE LANDING           "
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	if page == 1 then
		
		perf_lnd_arpt = B738DR_des_list_rwy_icao
		perf_des_rwy_num = 0
		perf_des_rwy_list = {}
		perf_des_rwy_list_len = {}
		perf_des_rwy_list_hdg = {}
		
		if perf_lnd_arpt ~= "" then
			local rwy_list = B738DR_des_list_rwy
			local pos = 0
			if string.len(rwy_list) > 0 then
				perf_des_rwy_num = string.len(rwy_list) / 3
				for aaa = 1, perf_des_rwy_num do
					pos = ((aaa-1) * 3) + 1
					perf_des_rwy_list[aaa] = string.sub(rwy_list, pos, pos + 2)
					perf_des_rwy_list_len[aaa] = B738DR_des_list_rwy_len[aaa - 1]
					perf_des_rwy_list_hdg[aaa] = B738DR_des_list_rwy_hdg[aaa - 1]
				end
			end
		end
		
		if perf_lnd_arpt ~= perf_lnd_arpt_old then
			perf_lnd_rwy = 0
		end
		perf_lnd_arpt_old = perf_lnd_arpt
		
		local p_arpt = spaces_after(perf_lnd_arpt, 14)
		local p_rwy = ""
		if perf_lnd_rwy <= perf_des_rwy_num and perf_lnd_rwy > 0 then
			p_rwy = perf_des_rwy_list[perf_lnd_rwy]
		end
		p_rwy = spaces_after(p_rwy, 14)
		local p_macg = spaces_after("2.50% MINGR", 14)
		
		local p_cond = spaces_after(perf_lnd_cond, 14)
		
		local p_wind = ""
		if perf_lnd_wind_spd > 0 then
			p_wind = string.format("%03d", perf_lnd_wind_dir) .. "/" .. tostring(perf_lnd_wind_spd) .. " KT"
		else
			p_wind = "0 KT"
		end
		p_wind = spaces_after(p_wind, 14)
		local p_oat = tostring(perf_lnd_oat) .. "`C"
		p_oat = spaces_after(p_oat, 14)
		local p_qnh = ""
		if perf_lnd_qnh <= 40 then
			p_qnh = string.format("%5.2f", perf_lnd_qnh) .. " IN HG"
		else
			p_qnh = string.format("%6.1f", perf_lnd_qnh) .. " HPA"
		end
		p_qnh = spaces_after(p_qnh, 14)
		
		local p_flap = perf_lnd_flap
		local p_ac = perf_lnd_ac
		local p_ai = perf_lnd_ai
		local p_brks = perf_lnd_brks
		local p_nnc = "NONE"
		local p_sbrk = "AUTO"
		local p_rev = perf_lnd_reverse
		local p_weight = perf_lnd_weight
		local p_vref_add = perf_lnd_vref_add
		
		line_s[1] =   "  ARPT                            FLAP"
		line_g[1] =   "       " .. p_arpt .. p_flap
		line_s[2] =   "   RWY                            A/C "
		line_g[2] =   "       " .. p_rwy .. p_ac
		line_s[3] =   "  MACG                            A/I "
		line_g[3] =   "       " .. p_macg .. p_ai
		line_s[4] =   "  COND                            BRKS"
		line_g[4] =   "       " .. p_cond .. p_brks
		line_s[5] =   "  WIND                            NNC "
		line[5] =     "       " .. p_wind
		line_g[5] =   "                     " .. p_nnc
		line_s[6] =   "   OAT                            SBRK"
		line[6] =     "       " .. p_oat
		line_g[6] =   "                     " .. p_sbrk
		line_s[7] =   "   QNH                            REV "
		line[7] =     "       " .. p_qnh
		line_g[7] =   "                     " .. p_rev
		line_s[8] =   "  LANDING WT:           VREF ADD:     "
		if B738DR_fmc_units == 0 then
			line[8] =     "              " .. string.format("%6d", p_weight * KGS_LBS)
		else
			line[8] =     "              " .. string.format("%6d", p_weight)
		end
		line[8] = line[8] .. " " .. string.sub(units_string, 1, 2) ..   "           " .. string.format("%4d", p_vref_add)
		if perf_lnd_wind_spd > 0 then
			if perf_lnd_head_wind == 0 then
				line_s[9] = "  0 HW / "
			elseif perf_lnd_head_wind < 0 then
				line_s[9] = "  " ..tostring(-perf_lnd_head_wind) .. " HW / "
			else
				line_s[9] = "  " .. tostring(perf_lnd_head_wind) .. " TW / "
			end
			if perf_lnd_cross_wind == 0 then
				line_s[9] = line_s[9] .. "0 XW KT"
			elseif perf_lnd_cross_wind > 0 then
				line_s[9] = line_s[9] .. "L" .. tostring(perf_lnd_cross_wind) .. " XW KT"
			else
				line_s[9] = line_s[9] .. "R" .. tostring(-perf_lnd_cross_wind) .. " XW KT"
			end
		end
		
		for i = 1, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		
		for i = 0, 15 do
			B738DR_tab_perf_manip[i] = 1
		end
		
	elseif page == 2 then
		
		local scale = 0
		local ad = 0
		local mm = 0
		local ma = 0
		local ab3 = 0
		local ab2 = 0
		local ab1 = 0
		
		if perf_lnd_arpt ~= "" and perf_lnd_weight >= 40000 then
			if perf_lnd_rwy <= perf_des_rwy_num and perf_lnd_rwy > 0 then
				if perf_des_rwy_list_len[perf_lnd_rwy] > 500 then
					
					local gw_to = perf_lnd_weight / 1000 	-- / KGS_LBS
					local weight_min = 0
					local weight_max = 0
					raw_table('perf_vref_calc')
					local perf_vref_calc = 
						{
						[15] = { [40] = 121, [45] = 128, [50] = 136, [55] = 143, [60] = 149, [65] = 156, [70] = 161, [75] = 167, [80] = 172, [85] = 177 },
						[30] = { [40] = 115, [45] = 122, [50] = 129, [55] = 136, [60] = 142, [65] = 148, [70] = 153, [75] = 158, [80] = 163, [85] = 168 },
						[40] = { [40] = 108, [45] = 115, [50] = 122, [55] = 128, [60] = 135, [65] = 141, [70] = 146, [75] = 151, [80] = 155, [85] = 160 }
						}
						
					-- Weight: 40 to 85  x1000 kg
					weight_max = math.min ( 85, roundUpToIncrement(gw_to, 5 ))
					weight_max = math.max ( 40, weight_max)
					weight_min = math.max ( 40, weight_max - 5)
					
					local perf_vref = 0
					if perf_lnd_flap == "15" then
						-- 15
						perf_vref = B738_rescale(weight_min, perf_vref_calc[40][weight_min], weight_max, perf_vref_calc[40][weight_max], gw_to)
						perf_vref = perf_vref + 20
					elseif perf_lnd_flap == "30" then
						-- 30
						perf_vref = B738_rescale(weight_min, perf_vref_calc[30][weight_min], weight_max, perf_vref_calc[30][weight_max], gw_to)
					else
						perf_vref = B738_rescale(weight_min, perf_vref_calc[40][weight_min], weight_max, perf_vref_calc[40][weight_max], gw_to)
					end
					
					
					-- local vref_40 = 140
					local vref_app = perf_vref + perf_lnd_vref_add
					
					local vref_add_txt = "VREF" .. perf_lnd_flap .. "+" .. tostring(perf_lnd_vref_add)
					vref_add_txt = spaces_after(vref_add_txt, 9)
					
					local lda = perf_des_rwy_list_len[perf_lnd_rwy] - 120	--100
					scale = 594 / lda
					
					local vref_2 = vref_app * 0.51444444
					vref_2 = vref_2 * vref_2
					
					local mm_k1 = 0
					local mm_k2 = 0
					local ma_k1 = 0
					local ma_k2 = 0
					local ab1_k1 = 0
					local ab1_k2 = 0
					local ab2_k1 = 0
					local ab2_k2 = 0
					local ab3_k1 = 0
					local ab3_k2 = 0
					
					if perf_lnd_cond == "DRY" then
						mm_k1 = 235
						mm_k2 = 4.43
						ma_k1 = 328
						ma_k2 = 3.41
						ab3_k1 = 475
						ab3_k2 = 2.149
						ab2_k1 = 635
						ab2_k2 = 1.551
						ab1_k1 = 837
						ab1_k2 = 1.358
					elseif perf_lnd_cond == "WET" then
						if perf_lnd_reverse == "NOT AVAIL" then
							mm_k1 = 575
							mm_k2 = 2.468
							ma_k1 = 610
							ma_k2 = 2.209
							ab3_k1 = 599
							ab3_k2 = 1.828
							ab2_k1 = 757
							ab2_k2 = 1.332
							ab1_k1 = 985
							ab1_k2 = 1.1627
						elseif perf_lnd_reverse == "ONE" then
							mm_k1 = 514
							mm_k2 = 2.594
							ma_k1 = 545
							ma_k2 = 2.327
							ab3_k1 = 587
							ab3_k2 = 1.828
							ab2_k1 = 791
							ab2_k2 = 1.397
							ab1_k1 = 993
							ab1_k2 = 1.2922
						else
							mm_k1 = 470
							mm_k2 = 2.726
							ma_k1 = 498
							ma_k2 = 2.445
							ab3_k1 = 581
							ab3_k2 = 1.825
							ab2_k1 = 767
							ab2_k2 = 1.495
							ab1_k1 = 837
							ab1_k2 = 1.358
						end
					end
					
					
					ad = 4.548 * vref_app * 0.51444444
					
					mm = mm_k1 + (vref_2 - 1693.77985) / mm_k2 * 0.5
					ma = ma_k1 + (vref_2 - 1693.77985) / ma_k2 * 0.5
					ab1 = ab1_k1 + (vref_2 - 1693.77985) / ab1_k2 * 0.5
					ab2 = ab2_k1 + (vref_2 - 1693.77985) / ab2_k2 * 0.5
					ab3 = ab3_k1 + (vref_2 - 1693.77985) / ab3_k2 * 0.5
					
					mm = mm + ad
					ma = ma + ad
					ab3 = ab3 + ad
					ab2 = ab2 + ad
					ab1 = ab1 + ad
					
					local on_rwy = 0
					local out_rwy = 0
					
					if perf_lnd_brks == "MAX MANUAL" then
						if mm > lda then
							out_rwy = mm - lda
						end
						on_rwy = mm - ad
					elseif perf_lnd_brks == "AB2" then
						if ab2 > lda then
							out_rwy = ab2 - lda
						end
						on_rwy = ab2 - ad
					elseif perf_lnd_brks == "AB3" then
						if ab3 > lda then
							out_rwy = ab3 - lda
						end
						on_rwy = ab3 - ad
					elseif perf_lnd_brks == "MAX AUTO" then
						if ma > lda then
							out_rwy = ma - lda
						end
						on_rwy = ma - ad
					else
						if ab1 > lda then
							out_rwy = ab1 - lda
						end
						on_rwy = ab1 - ad
					end
					
					if ab1 > lda then
						-- out_rwy = ab1 - lda
						B738DR_perf_ab1_state = 2
					else
						B738DR_perf_ab1_state = 1
					end
					if ab2 > lda then
						B738DR_perf_ab2_state = 2
					else
						B738DR_perf_ab2_state = 1
					end
					if ab3 > lda then
						B738DR_perf_ab3_state = 2
					else
						B738DR_perf_ab3_state = 1
					end
					if ma > lda then
						B738DR_perf_ma_state = 2
					else
						B738DR_perf_ma_state = 1
					end
					if mm > lda then
						B738DR_perf_mm_state = 2
					else
						B738DR_perf_mm_state = 1
					end
					
					line_s[1] =   " LAND WEIGHT       MAX MANUAL: "
					if perf_lnd_brks == "MAX MANUAL" then
						B738DR_perf_ab1_state = 0
						B738DR_perf_ab2_state = 0
						B738DR_perf_ab3_state = 0
						B738DR_perf_ma_state = 0
						if B738DR_perf_mm_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_g[1] = "                               " .. string.format("%5d", mm * 3.28) .. "FT"
							else
								line_g[1] = "                               " .. string.format("%4d", mm) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[1] = "                               " .. string.format("%5d", mm * 3.28) .. "FT"
							else
								line_a[1] = "                               " .. string.format("%4d", mm) .. "M"
							end
						end
					else
						if B738DR_perf_mm_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_s[1] = line_s[1] .. string.format("%5d", mm * 3.28) .. "FT"
							else
								line_s[1] = line_s[1] .. string.format("%4d", mm) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[1] = "                               " .. string.format("%5d", mm * 3.28) .. "FT"
							else
								line_a[1] = "                               " .. string.format("%4d", mm) .. "M"
							end
						end
					end
					line_s[2] =   "                   AUTO BRK 1: "
					if perf_lnd_brks == "AB1" then
						B738DR_perf_ab2_state = 0
						B738DR_perf_ab3_state = 0
						B738DR_perf_ma_state = 0
						B738DR_perf_mm_state = 0
						if B738DR_perf_ab1_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_g[2] = "                               " .. string.format("%5d", ab1 * 3.28) .. "FT"
							else
								line_g[2] = "                               " .. string.format("%4d", ab1) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[2] = "                               " .. string.format("%5d", ab1 * 3.28) .. "FT"
							else
								line_a[2] = "                               " .. string.format("%4d", ab1) .. "M"
							end
						end
					else
						if B738DR_perf_ab1_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_s[2] = line_s[2] .. string.format("%5d", ab1 * 3.28) .. "FT"
							else
								line_s[2] = line_s[2] .. string.format("%4d", ab1) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[2] = "                               " .. string.format("%5d", ab1 * 3.28) .. "FT"
							else
								line_a[2] = "                               " .. string.format("%4d", ab1) .. "M"
							end
						end
					end
					if B738DR_fmc_units == 0 then
						line[2] =   "  " .. string.format("%6d", perf_lnd_weight * KGS_LBS) .. " " .. string.sub(units_string, 1, 2)
					else
						line[2] =   "  " .. string.format("%6d", perf_lnd_weight) .. " " .. string.sub(units_string, 1, 2)
					end
					line_s[3] =   "  " .. vref_add_txt .. "        AUTO BRK 2: "
					if perf_lnd_brks == "AB2" then
						B738DR_perf_ab1_state = 0
						B738DR_perf_ab3_state = 0
						B738DR_perf_ma_state = 0
						B738DR_perf_mm_state = 0
						if B738DR_perf_ab2_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_g[3] = "                               " .. string.format("%5d", ab2 * 3.28) .. "FT"
							else
								line_g[3] = "                               " .. string.format("%4d", ab2) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[3] = "                               " .. string.format("%5d", ab2 * 3.28) .. "FT"
							else
								line_a[3] = "                               " .. string.format("%4d", ab2) .. "M"
							end
						end
					else
						if B738DR_perf_ab2_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_s[3] = line_s[3] .. string.format("%5d", ab2 * 3.28) .. "FT"
							else
								line_s[3] = line_s[3] .. string.format("%4d", ab2) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[3] = "                               " .. string.format("%5d", ab2 * 3.28) .. "FT"
							else
								line_a[3] = "                               " .. string.format("%4d", ab2) .. "M"
							end
						end
					end
					line_s[4] =   "                   AUTO BRK 3: "
					if perf_lnd_brks == "AB3" then
						B738DR_perf_ab1_state = 0
						B738DR_perf_ab2_state = 0
						B738DR_perf_ma_state = 0
						B738DR_perf_mm_state = 0
						if B738DR_perf_ab3_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_g[4] = "                               " .. string.format("%5d", ab3 * 3.28) .. "FT"
							else
								line_g[4] = "                               " .. string.format("%4d", ab3) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[4] = "                               " .. string.format("%5d", ab3 * 3.28) .. "FT"
							else
								line_a[4] = "                               " .. string.format("%4d", ab3) .. "M"
							end
						end
					else
						if B738DR_perf_ab3_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_s[4] = line_s[4] .. string.format("%5d", ab3 * 3.28) .. "FT"
							else
								line_s[4] = line_s[4] .. string.format("%4d", ab3) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[4] = "                               " .. string.format("%5d", ab3 * 3.28) .. "FT"
							else
								line_a[4] = "                               " .. string.format("%4d", ab3) .. "M"
							end
						end
					end
					line[4] =     "   " .. string.format("%3d", vref_app) .. " KT"
					line_s[5] =   " LDA:                MAX AUTO: "
					if perf_lnd_brks == "MAX AUTO" then
						B738DR_perf_ab1_state = 0
						B738DR_perf_ab2_state = 0
						B738DR_perf_ab3_state = 0
						B738DR_perf_mm_state = 0
						if B738DR_perf_ma_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_g[5] = "                               " .. string.format("%5d", ma * 3.28) .. "FT"
							else
								line_g[5] = "                               " .. string.format("%4d", ma) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[5] = "                               " .. string.format("%5d", ma * 3.28) .. "FT"
							else
								line_a[5] = "                               " .. string.format("%4d", ma) .. "M"
							end
						end
					else
						if B738DR_perf_ma_state <= 1 then
							if B738DR_fmc_units == 0 then
								line_s[5] = line_s[5] .. string.format("%5d", ma * 3.28) .. "FT"
							else
								line_s[5] = line_s[5] .. string.format("%4d", ma) .. "M"
							end
						else
							if B738DR_fmc_units == 0 then
								line_a[5] = "                               " .. string.format("%5d", ma * 3.28) .. "FT"
							else
								line_a[5] = "                               " .. string.format("%4d", ma) .. "M"
							end
						end
					end
					if B738DR_fmc_units == 0 then
						line[5] =     "      " .. string.format("%5d", lda * 3.28) .. "FT"
						line_s[6] =   " AD:  " .. string.format("%5d", ad * 3.28) .. "FT"
					else
						line[5] =     "      " .. string.format("%4d", lda) .. "M"
						line_s[6] =   " AD:  " .. string.format("%4d", ad) .. "M"
					end
					
					B738DR_perf_ab1 = ab1 * scale
					B738DR_perf_ab2 = ab2 * scale
					B738DR_perf_ab3 = ab3 * scale
					B738DR_perf_ma = ma * scale
					B738DR_perf_mm = mm * scale
					B738DR_perf_ad = ad * scale
					
					B738DR_perf_on_rwy = on_rwy * scale
					B738DR_perf_out_rwy = out_rwy * scale
					
				end
			end
		end
		
		for i = 1, 9 do
			B738DR_tab_line_manip[i] = 0
		end
	end
	
end

function cmd_perf_land(cmd)
end

function cmd_perf_land2(cmd)
	-- ** Landing ** --
	if cmd == 2 then
		-- RWY
		if perf_des_rwy_num > 0 then
			perf_lnd_rwy = perf_lnd_rwy + 1
			if perf_lnd_rwy > perf_des_rwy_num then
				perf_lnd_rwy = 1
			end
			calc_perf_lnd_wind()
		end
		display_update = 1
	elseif cmd == 4 then
		-- condition
		if perf_lnd_cond == "DRY" then
			perf_lnd_cond = "WET"
			perf_lnd_reverse = "BOTH"
		else
			perf_lnd_cond = "DRY"
			perf_lnd_reverse = "NO CREDIT"
		end
		display_update = 1
	elseif cmd == 5 then
		-- WIND
		numpad_ref = 209
		activate_numpad()
		B738DR_tab_numpad_spec2 = 1
	elseif cmd == 6 then
		-- OAT
		numpad_ref = 210
		activate_numpad()
	elseif cmd == 7 then
		-- QNH
		numpad_ref = 211
		activate_numpad()
	elseif cmd == 8 then
		-- TOW
		numpad_ref = 212
		activate_numpad()
	elseif cmd == 9 then
		-- Flap
		if perf_lnd_flap == "15" then
			perf_lnd_flap = "30"
		elseif perf_lnd_flap == "30" then
			perf_lnd_flap = "40"
		else
			perf_lnd_flap = "15"
		end
		display_update = 1
	elseif cmd == 10 then
		-- A/C
		if perf_lnd_ac == "ON" then
			perf_lnd_ac = "AUTO"
		elseif perf_lnd_ac == "AUTO" then
			perf_lnd_ac = "OFF"
		else
			perf_lnd_ac = "ON"
		end
		display_update = 1
	elseif cmd == 11 then
		-- A/I
		if perf_lnd_ai == "ON" then
			perf_lnd_ai = "OFF"
		else
			perf_lnd_ai = "ON"
		end
		display_update = 1
	elseif cmd == 12 then
		-- BRKS
		if perf_lnd_brks == "ALL" then
			perf_lnd_brks = "MAX MANUAL"
		elseif perf_lnd_brks == "MAX MANUAL" then
			perf_lnd_brks = "AB1"
		elseif perf_lnd_brks == "AB1" then
			perf_lnd_brks = "AB2"
		elseif perf_lnd_brks == "AB2" then
			perf_lnd_brks = "AB3"
		elseif perf_lnd_brks == "AB3" then
			perf_lnd_brks = "MAX AUTO"
		else
			perf_lnd_brks = "ALL"
		end
		display_update = 1
	elseif cmd == 15 then
		-- reverse
		if perf_lnd_cond ~= "DRY" then
			if perf_lnd_reverse == "NOT AVAIL" then
				perf_lnd_reverse = "BOTH"
			elseif perf_lnd_reverse == "BOTH" then
				perf_lnd_reverse = "ONE"
			else
				perf_lnd_reverse = "NOT AVAIL"
			end
		end
		display_update = 1
	elseif cmd == 16 then
		-- VREF ADD
		numpad_ref = 213
		activate_numpad()
	end
end

function calc_perf_lnd_wind()
	if perf_lnd_wind_spd > 0 and perf_des_rwy_num > 0 and perf_lnd_rwy <= perf_des_rwy_num and perf_lnd_rwy > 0 then
		perf_lnd_head_wind = perf_lnd_wind_spd * math.cos(math.rad(Angle180(perf_lnd_wind_dir))-math.rad(perf_des_rwy_list_hdg[perf_lnd_rwy]))
		perf_lnd_cross_wind = perf_lnd_wind_spd * math.sin(math.rad(Angle180(perf_lnd_wind_dir))-math.rad(perf_des_rwy_list_hdg[perf_lnd_rwy]))
		if perf_lnd_head_wind > 0 then
			perf_lnd_head_wind = math.floor (perf_lnd_head_wind + 0.5)
		else
			perf_lnd_head_wind = -perf_lnd_head_wind
			perf_lnd_head_wind = math.floor (perf_lnd_head_wind + 0.5)
			perf_lnd_head_wind = -perf_lnd_head_wind
		end
		if perf_lnd_cross_wind > 0 then
			perf_lnd_cross_wind = math.floor (perf_lnd_cross_wind + 0.5)
		else
			perf_lnd_cross_wind = -perf_lnd_cross_wind
			perf_lnd_cross_wind = math.floor (perf_lnd_cross_wind + 0.5)
			perf_lnd_cross_wind = -perf_lnd_cross_wind
		end
	else
		perf_lnd_head_wind = 0
		perf_lnd_cross_wind = 0
	end
	if perf_lnd_wind_spd > 0 and perf_lnd_head_wind < 0 then
		perf_lnd_vref_add = math.floor(-perf_lnd_head_wind / 2)
		if perf_lnd_vref_add < 5 then
			perf_lnd_vref_add = 5
		elseif perf_lnd_vref_add > 20 then
			perf_lnd_vref_add = 20
		end
	else
		perf_lnd_vref_add = 5
	end
end

function page_app_rating()
	if B738DR_approach_rating ~= 0 then
		line_c[0] = "APPROACH RATING " .. string.format("%1d", 6 - B738DR_approach_rating) .. " - PENALTIES LIST    "
	else
		line_c[0] =   "APPROACH RATING - PENALTIES LIST      "
	end
	line_s[0] = "                                " .. num_pages(page, max_page)
	
	raw_table('app_rating_txt')
	local app_rating_txt = {}
	app_rating_txt[0] = "exceed Flap speed limit"
	app_rating_txt[1] = "Speedbrake with flaps 15-40"
	app_rating_txt[2] = "Flaps above FL190"
	app_rating_txt[3] = "Spd 250kts below 6000ft"
	app_rating_txt[4] = "Gear not down below 1000ft AGL"
	app_rating_txt[5] = "High ROD below 500ft AGL"
	app_rating_txt[6] = "High ROD below 1000ft AGL"
	app_rating_txt[7] = "High ROD below 2000ft AGL"
	app_rating_txt[8] = "Tyre speed above 185 kts"
	app_rating_txt[9] = "Overload landing"
	app_rating_txt[10] = "High GS deviation 200-500ft AGL"
	app_rating_txt[11] = "High GS deviation 500-1000ft AGL"
	app_rating_txt[12] = "Land flaps with Speedbrake"
	app_rating_txt[13] = "Land flaps - app speed below 400ft"
	app_rating_txt[14] = "Land flaps - app speed below 400ft"
	app_rating_txt[15] = "not set landing flaps below 500ft AGL"
	app_rating_txt[16] = "app spd at 500ft AGL"
	app_rating_txt[17] = "exceed Vmo speed"
	app_rating_txt[18] = "exceed Mmo speed"
	app_rating_txt[19] = "Damaged flaps"
	app_rating_txt[20] = "app flaps/speed in FMC below 2000ft"
	
	raw_table('app_penalties')
	local app_penalties = {}
	
	local num_penalties = 0
	if B738DR_approach_rating ~= 0 and simDR_aircraft_groundspeed < 30 then
		for ii = 0, 21 do
			if B738DR_app_rating_param[ii] ~= 0 then
				if ii == 14 then
					if B738DR_app_rating_param[13] == 0 then
						num_penalties = num_penalties + 1
						app_penalties[num_penalties] = app_rating_txt[ii]
					end
				else
					num_penalties = num_penalties + 1
					app_penalties[num_penalties] = app_rating_txt[ii]
				end
			end
		end
		
		max_page = math.floor(num_penalties / 9) + 1
		
		if page > max_page then
			page = max_page
		end
		
		local act_line = 1
		local act_penal = 0
		if page == 1 then
			if B738DR_approach_rating == 1 then
				line_s[1] = "  NONE                               "
			else
				act_penal = 1
				if act_penal <= num_penalties then
					while act_line <= 9 do
						line_s[act_line] = " " .. app_penalties[act_penal]
						act_line = act_line + 1
						act_penal = act_penal +1
						if act_penal > num_penalties then
							break
						end
					end
				end
			end
		elseif page == 2 then
			act_penal = 10
			if act_penal <= num_penalties then
				while act_line <= 9 do
					line_s[act_line] = " " .. app_penalties[act_penal]
					act_line = act_line + 1
					act_penal = act_penal +1
					if act_penal > num_penalties then
						break
					end
				end
			end
		elseif page == 3 then
			act_penal = 19
			if act_penal <= num_penalties then
				while act_line <= 9 do
					line_s[act_line] = " " .. app_penalties[act_penal]
					act_line = act_line + 1
					act_penal = act_penal +1
					if act_penal > num_penalties then
						break
					end
				end
			end
		end
	end
	
	-- enable/disable manip
	for i = 0, 9 do
		B738DR_tab_line_manip[i] = 0
	end
end


function activate_numpad()
	B738DR_tab_numpad_act = 1
	B738DR_tab_numpad_val = ""
	-- disable manip
	for i = 0, 7 do
		B738DR_tab_line_manip[i] = 0
	end
end

function reset_autoupdate()
	if is_timer_scheduled(autoupdate_timer) == true then
		stop_timer(autoupdate_timer)
	end
	if B738DR_b737_variant < 0 then
		B738DR_tab_credits = 0
	else
		B738DR_tab_credits = 1
	end
	run_at_interval(autoupdate_timer, 1)
end

function prepare_page()
	if cat == CAT_HOME then
		page_home()
		B738DR_tab_menu_page = 1
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_CREDITS then
		B738DR_tab_menu_page = 8
		clr_menu_manip()
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_SETTINGS then
		page_settings()
		B738DR_tab_menu_page = 2
		clr_line_manip()
		clr_perf_manip()
	--**--
	elseif cat == CAT_OPTIONAL_ACCESS then
		page_optional()
		B738DR_tab_menu_page = 16	--NEW PAGE FOR OPTIONAL ACCES
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_EXTERIOR then
		page_option_exterier()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_SYSTEMS then
		page_option_systems()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_DISPLAYS then
		page_option_displays()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_FMS then
		page_option_fms()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_AUTOFLIGHT then
		page_option_autoflight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_CALLOUTS then
		page_option_callouts()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_OPTION_PLACARDS then
		page_option_placards()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_ANNOUNC then
		page_announc()
		B738DR_tab_menu_page = 3
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_FAILURES then
		page_failures()
		B738DR_tab_menu_page = 13
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_FAIL_ELEC then
		page_fail_elec()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FAIL_HYD then
		page_fail_hyd()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FAIL_SYS then
		page_fail_sys()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FAIL_PRESSURIS then
		page_fail_pressurisation()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FAIL_ENG then
		page_fail_eng()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_DEV_TUNE then
		page_dev_tune()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_SERVICES then
		page_services()
		B738DR_tab_menu_page = 9
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_BP_MENU then
		page_bp()
		B738DR_tab_menu_page = 10
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_AVITAB then
		page_avitab()
		B738DR_tab_menu_page = 11
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_CHECKLIST then
		page_checklist()
		B738DR_tab_menu_page = 4
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_LOAD_SAVE then
		page_load_save()
		B738DR_tab_menu_page = 5
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_CFG_PRESETS then
		page_cfg_presets()
		B738DR_tab_menu_page = 6
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_AUDIO_PRESETS then
		page_audio_presets()
		B738DR_tab_menu_page = 7
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_STATE_PRESETS then
		page_state_preset()
		B738DR_tab_menu_page = 12
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_LOAD_SAVE_FLIGHT then
		page_load_save_flight()
		B738DR_tab_menu_page = 15
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_ANN_SET then
		page_ann_set()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_HARDWARE then
		page_hardware()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_REALISM then
		page_realism()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_VISUAL_EFFECTS then
		page_visual()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CONFIG then
		page_config()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CALIBRATE then
		page_calibration()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FEATURES then
		page_feature()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_VOLUME_EQ then
		page_volume_eq()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_FUEL_CG then
		clr_perf_manip()
		page_fuel_cg()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
	elseif cat == CAT_AUTO_FLIGHT then
		clr_perf_manip()
		page_auto_flight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
	elseif cat == CAT_PERF_LAND then
		clr_perf_manip()
		page_perf_land()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
	elseif cat == CAT_PERF_TAKEOFF then
		clr_perf_manip()
		page_perf_takeof()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
	elseif cat == CAT_APP_RATING then
		clr_perf_manip()
		page_app_rating()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		
	elseif cat == CAT_PAY_PERF then
		page_pay_perf()
		B738DR_tab_menu_page = 14
		clr_line_manip()
		clr_perf_manip()
	elseif cat == CAT_DOORS then
		page_door()
		B738DR_tab_menu_page = 17
		clr_line_manip()
		clr_perf_manip()
	-- elseif cat == CAT_DOORS then
		-- page_cat_doors()
		-- B738DR_tab_menu_page = 0
		-- clr_menu_manip()
		-- clr_perf_manip()
	elseif cat == CAT_LIGHTS then
		page_cat_lights()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_PR_PREFLIGHT then
		page_cl_preflight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_CDU_PREFLIGHT then
		page_cl_cdu_preflight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_CPT_PREFLIGHT then
		page_cl_cpt_preflight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_FO_PREFLIGHT then
		page_cl_fo_preflight()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_BEFORE_START then
		page_cl_before_start()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_PUSHBACK then
		page_cl_pushback()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_ENG_START then
		page_cl_eng_start()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_BEFORE_TAXI then
		page_cl_before_taxi()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_TAKEOFF then
		page_cl_takeoff()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_CLIMB_CRUISE then
		page_cl_climb_cruise()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_DESCENT then
		page_cl_descent()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_APPROACH then
		page_cl_approach()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_LANDING_ILS then
		page_cl_landing_ils()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_LANDING_IAN then
		page_cl_landing_ian()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_LANDING_VNAV then
		page_cl_landing_vnav()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_GOAROUND then
		page_cl_go_around()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_AFTER_LAND then
		page_cl_after_land()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_SHUTDOWN then
		page_cl_shutdown()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	elseif cat == CAT_CL_SECURE then
		page_cl_secure()
		B738DR_tab_menu_page = 0
		clr_menu_manip()
		clr_perf_manip()
	end
	if cat == CAT_FUEL_CG then
		B738DR_bgnd_fuel = 1
		B738DR_bgnd_perf_to = 0
		B738DR_bgnd_perf_lnd = 0
	elseif cat == CAT_PERF_TAKEOFF then
		B738DR_bgnd_fuel = 0
		B738DR_bgnd_perf_to = 1
		B738DR_bgnd_perf_lnd = 0
	elseif cat == CAT_PERF_LAND then
		B738DR_bgnd_fuel = 0
		B738DR_bgnd_perf_to = 0
		B738DR_bgnd_perf_lnd = 1
	else
		B738DR_bgnd_fuel = 0
		B738DR_bgnd_perf_to = 0
		B738DR_bgnd_perf_lnd = 0
	end
	
	if B738DR_tab_numpad_act == 1 or info_act == 1 then
		-- disable manip
		for i = 0, 9 do
			B738DR_tab_line_manip[i] = 0
		end
		clr_menu_manip()
		clr_perf_manip()
	end
end

function display_page()
	
	if B738DR_efb_colorize == 0 then
		line_g[0] = line_c[0]
		line_c[0] = ""
	else
		line_cs[0] = line_s[0]
		line_s[0] = ""
		for i = 1, 9 do
			line_bs[i] = line_s[i]
			line_s[i] = ""
		end
	end
	
	
	B738DR_tab_line00 = txt_trunc(line[0], 38)
	B738DR_tab_line01 = txt_trunc(line[1], 38)
	B738DR_tab_line02 = txt_trunc(line[2], 38)
	B738DR_tab_line03 = txt_trunc(line[3], 38)
	B738DR_tab_line04 = txt_trunc(line[4], 38)
	B738DR_tab_line05 = txt_trunc(line[5], 38)
	B738DR_tab_line06 = txt_trunc(line[6], 38)
	B738DR_tab_line07 = txt_trunc(line[7], 38)
	B738DR_tab_line08 = txt_trunc(line[8], 38)
	B738DR_tab_line09 = txt_trunc(line[9], 38)

	B738DR_tab_line00s = txt_trunc(line_s[0], 38)
	B738DR_tab_line01s = txt_trunc(line_s[1], 38)
	B738DR_tab_line02s = txt_trunc(line_s[2], 38)
	B738DR_tab_line03s = txt_trunc(line_s[3], 38)
	B738DR_tab_line04s = txt_trunc(line_s[4], 38)
	B738DR_tab_line05s = txt_trunc(line_s[5], 38)
	B738DR_tab_line06s = txt_trunc(line_s[6], 38)
	B738DR_tab_line07s = txt_trunc(line_s[7], 38)
	B738DR_tab_line08s = txt_trunc(line_s[8], 38)
	B738DR_tab_line09s = txt_trunc(line_s[9], 38)

	B738DR_tab_line00g = txt_trunc(line_g[0], 38)
	B738DR_tab_line01g = txt_trunc(line_g[1], 38)
	B738DR_tab_line02g = txt_trunc(line_g[2], 38)
	B738DR_tab_line03g = txt_trunc(line_g[3], 38)
	B738DR_tab_line04g = txt_trunc(line_g[4], 38)
	B738DR_tab_line05g = txt_trunc(line_g[5], 38)
	B738DR_tab_line06g = txt_trunc(line_g[6], 38)
	B738DR_tab_line07g = txt_trunc(line_g[7], 38)
	B738DR_tab_line08g = txt_trunc(line_g[8], 38)
	B738DR_tab_line09g = txt_trunc(line_g[9], 38)
	
	B738DR_tab_line01a = txt_trunc(line_a[1], 38)
	B738DR_tab_line02a = txt_trunc(line_a[2], 38)
	B738DR_tab_line03a = txt_trunc(line_a[3], 38)
	B738DR_tab_line04a = txt_trunc(line_a[4], 38)
	B738DR_tab_line05a = txt_trunc(line_a[5], 38)
	B738DR_tab_line06a = txt_trunc(line_a[6], 38)
	B738DR_tab_line07a = txt_trunc(line_a[7], 38)
	B738DR_tab_line08a = txt_trunc(line_a[8], 38)
	B738DR_tab_line09a = txt_trunc(line_a[9], 38)
	
	B738DR_tab_line00c = txt_trunc(line_c[0], 38)
	B738DR_tab_line01c = txt_trunc(line_c[1], 38)
	B738DR_tab_line02c = txt_trunc(line_c[2], 38)
	B738DR_tab_line03c = txt_trunc(line_c[3], 38)
	B738DR_tab_line04c = txt_trunc(line_c[4], 38)
	B738DR_tab_line05c = txt_trunc(line_c[5], 38)
	B738DR_tab_line06c = txt_trunc(line_c[6], 38)
	B738DR_tab_line07c = txt_trunc(line_c[7], 38)
	B738DR_tab_line08c = txt_trunc(line_c[8], 38)
	B738DR_tab_line09c = txt_trunc(line_c[9], 38)
	
	B738DR_tab_line00cs = txt_trunc(line_cs[0], 38)
	B738DR_tab_line01cs = txt_trunc(line_cs[1], 38)
	B738DR_tab_line02cs = txt_trunc(line_cs[2], 38)
	B738DR_tab_line03cs = txt_trunc(line_cs[3], 38)
	B738DR_tab_line04cs = txt_trunc(line_cs[4], 38)
	B738DR_tab_line05cs = txt_trunc(line_cs[5], 38)
	B738DR_tab_line06cs = txt_trunc(line_cs[6], 38)
	B738DR_tab_line07cs = txt_trunc(line_cs[7], 38)
	B738DR_tab_line08cs = txt_trunc(line_cs[8], 38)
	B738DR_tab_line09cs = txt_trunc(line_cs[9], 38)
	
	B738DR_tab_line00bs = txt_trunc(line_bs[0], 38)
	B738DR_tab_line01bs = txt_trunc(line_bs[1], 38)
	B738DR_tab_line02bs = txt_trunc(line_bs[2], 38)
	B738DR_tab_line03bs = txt_trunc(line_bs[3], 38)
	B738DR_tab_line04bs = txt_trunc(line_bs[4], 38)
	B738DR_tab_line05bs = txt_trunc(line_bs[5], 38)
	B738DR_tab_line06bs = txt_trunc(line_bs[6], 38)
	B738DR_tab_line07bs = txt_trunc(line_bs[7], 38)
	B738DR_tab_line08bs = txt_trunc(line_bs[8], 38)
	B738DR_tab_line09bs = txt_trunc(line_bs[9], 38)

	clear_lines()
	
end

function clear_lines()
	for i = 0, 9 do
		line[i] = ""
		line_s[i] = ""
		line_g[i] = ""
		line_a[i] = ""
		line_c[i] = ""
		line_cs[i] = ""
		line_bs[i] = ""
	end
end

function anim_info()
	if info_act == 0 then
		info_pos_tgt = 0
		if info_act ~= info_act_old then
			display_update = 1
		end
	else
		info_pos_tgt = 160
		if info_act ~= info_act_old then
			for i = 0, 9 do
				B738DR_tab_line_manip[i] = 0
			end
			clr_menu_manip()
		end
	end
	info_act_old = info_act
	
	B738DR_tab_page_info_pos = B738_set_anim_value (B738DR_tab_page_info_pos, info_pos_tgt, 0, 160, 10)
end

function bar_time()
	local loc_time_sec = simDR_local_time
	local loc_time_hod = math.floor(loc_time_sec / 3600)
	local loc_time_min = math.floor((loc_time_sec - loc_time_hod * 3600) / 60)
	B738DR_tab_page_info_time = string.format("%02d:%02d", loc_time_hod, loc_time_min)
end

function clr_menu_manip()
	for i = 0, 7 do
		B738DR_tab_menu_manip[i] = 0
	end
end

function clr_line_manip()
	for i = 0, 9 do
		B738DR_tab_line_manip[i] = 0
	end
end

function clr_item()
	for i = 0, 8 do
		B738DR_tab_item[i] = 0
	end
end

function clr_menu_mark()
	for i = 0, 7 do
		B738DR_tab_menu_mark[i] = 0
	end
end

function clr_perf_manip()
	for i = 0, 15 do
		B738DR_tab_perf_manip[i] = 0
	end
end

function menu_mark_timer()
	clr_menu_mark()
end

function boot_timer()
	boot_cnt = boot_cnt + 1
end

function boot()
	if boot_cnt < 1 then
		B738DR_tab_boot_show[boot_cnt] = 1
		if is_timer_scheduled(boot_timer) == false then
			run_after_time(boot_timer, 4)
		end
		min_page = 1
		max_page = 1
	elseif boot_cnt == 1 then
		min_page = 1
		max_page = 2
		B738DR_tab_boot_active = 0
		B738DR_tab_boot_show[0] = 0
		B738DR_tab_boot_show[1] = 0
		B738DR_tab_boot_show[2] = 0
		B738DR_tab_boot_show[3] = 0
		B738DR_tab_boot_show[4] = 0
		B738DR_tab_menu_page = 1
		B738DR_tab_nav_manip = 1
		B738DR_tab_info_manip = 1
		if B738DR_b737_variant < 0 then
			B738DR_tab_credits = 0
		else
			B738DR_tab_credits = 1
		end
		B738DR_tab_nav2_manip = 1
		--B738DR_tab_arrows_enable = 1
		for i = 0, 9 do
			B738DR_tab_menu_manip[i] = 1
		end
		if is_timer_scheduled(autoupdate_timer) == false then
			run_at_interval(autoupdate_timer, 1)
		end
		display_update = 1
		boot_cnt = boot_cnt + 1
	end
end

function calc_mac(in_gw_tow)
	
	local std_pax_weight = 0
	local payload_cg = B738DR_oew_kg
	local moment_payload = 0
	local bew_kgs = 0
	if B738DR_b737_variant == 3 then
		--600
		bew_kgs = 36902
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		bew_kgs = 38172
	elseif B738DR_b737_variant == 1 then
		--900
		bew_kgs = 42042
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		bew_kgs = 45201
	elseif B738DR_pax_layout > 3 then
		--700
		bew_kgs = 38172
	else
		--800
		bew_kgs = 42034
	end
	if B738DR_pax_layout <= 1 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout <= 3 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	elseif B738DR_pax_layout == 5 or B738DR_pax_layout == 6 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout >= 7 and B738DR_pax_layout <= 9 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	else
		-- 138PAX 737-700
		moment_payload = bew_kgs * 16.687292	-- 656.98 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 5.842	-- 230 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 27.1018	-- 1067 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 6.4262	-- 253 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 28.194	-- 1110 inch
	end
	
	for zxp = 1, 3 do
		std_pax_weight = B738DR_std_pax_weight[zxp-1]
		moment_payload = moment_payload + zone1_pax[zxp] * std_pax_weight * B738DR_zone_arm[0]
		moment_payload = moment_payload + zone2_pax[zxp] * std_pax_weight * B738DR_zone_arm[1]
		moment_payload = moment_payload + zone3_pax[zxp] * std_pax_weight * B738DR_zone_arm[2]
		moment_payload = moment_payload + zone4_pax[zxp] * std_pax_weight * B738DR_zone_arm[3]
		moment_payload = moment_payload + zone5_pax[zxp] * std_pax_weight * B738DR_zone_arm[4]
		payload_cg = payload_cg + zone1_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone2_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone3_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone4_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone5_pax[zxp] * std_pax_weight
	end
	
	if B738DR_b737_variant == 3 then
		--600
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 or B738DR_b737_variant == 1 then
		--800
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_73x == 2 then
		--737-700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	else
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	end
	payload_cg = payload_cg + zone_cargo1 + zone_cargo2
	
	local main_tank_kg = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[2]
	local center_tank_kg = simDR_fuel_tank_weight_kg[1]
	
	if in_gw_tow ~= 0 then
		if center_tank_kg >= 226.8 then
			center_tank_kg = center_tank_kg - 226.8
		elseif center_tank_kg > 0 then
			main_tank_kg = main_tank_kg - (226.8 - center_tank_kg)
			center_tank_kg = 0
		else
			main_tank_kg = main_tank_kg - 226.8
		end
		if main_tank_kg < 0 then
			main_tank_kg = 0
		end
	end
	
	local main_tank_arm = 0	--17.78508 -- 700.2 in
	local center_tank_arm = 0	--15.40764		-- 606.6 in
	main_tank_arm, center_tank_arm = fueltank_arms(main_tank_kg, center_tank_kg, B738DR_73x)
	local moment_main_tank = main_tank_kg * main_tank_arm -- *** kgm
	local moment_center_tank = center_tank_kg * center_tank_arm -- *** kgm
	moment_payload = moment_payload + moment_main_tank + moment_center_tank
	payload_cg = payload_cg + main_tank_kg + center_tank_kg
	
	local n = (moment_payload / payload_cg) - 15.92834	-- 627.1 in LEMAC
	n = n / 3.95732	-- 155.8 in MAC
	n = n * 100
	
	local n2 = math.min(n, 100)
	n2 = math.max(n, 0)
	if n < 0 or n > 40 then
		n = 0
	end
	
	return n, n2
	
end

function calc_zfw_mac()
	
	local std_pax_weight = 0
	local payload_cg = B738DR_oew_kg
	local moment_payload = 0
	local bew_kgs = 0
	if B738DR_b737_variant == 3 then
		--600
		bew_kgs = 36902
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		bew_kgs = 38172
	elseif B738DR_b737_variant == 1 then
		--900
		bew_kgs = 42042
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		bew_kgs = 45201
	elseif B738DR_pax_layout > 3 then
		--700
		bew_kgs = 38172
	else
		--800
		bew_kgs = 42034
	end
	if B738DR_pax_layout <= 1 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout <= 3 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	elseif B738DR_pax_layout == 5 or B738DR_pax_layout == 6 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout >= 7 and B738DR_pax_layout <= 9 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	else
		-- 138PAX 737-700
		moment_payload = bew_kgs * 16.687292	-- 656.98 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 5.842	-- 230 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 27.1018	-- 1067 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 6.4262	-- 253 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 28.194	-- 1110 inch
	end
	
	for zxp = 1, 3 do
		std_pax_weight = B738DR_std_pax_weight[zxp-1]
		moment_payload = moment_payload + zone1_pax[zxp] * std_pax_weight * B738DR_zone_arm[0]
		moment_payload = moment_payload + zone2_pax[zxp] * std_pax_weight * B738DR_zone_arm[1]
		moment_payload = moment_payload + zone3_pax[zxp] * std_pax_weight * B738DR_zone_arm[2]
		moment_payload = moment_payload + zone4_pax[zxp] * std_pax_weight * B738DR_zone_arm[3]
		moment_payload = moment_payload + zone5_pax[zxp] * std_pax_weight * B738DR_zone_arm[4]
		payload_cg = payload_cg + zone1_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone2_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone3_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone4_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone5_pax[zxp] * std_pax_weight
	end
	if B738DR_b737_variant == 3 then
		--600
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 or B738DR_b737_variant == 1 then
		--800
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_73x == 2 then
		--737-700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	else
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	end
	payload_cg = payload_cg + zone_cargo1 + zone_cargo2
	
	-- ZFW CG
	local n = (moment_payload / payload_cg) - 15.92834	-- 627.1 in LEMAC
	n = n / 3.95732	-- 155.8 in MAC
	n = n * 100
	if n < 0 or n > 40 then
		n = 0
	end
	
	return n
end

function calc_oew_mac()
	
	local std_pax_weight = 0
	local payload_cg = B738DR_oew_kg
	local moment_payload = 0
	local bew_kgs = 0
	if B738DR_b737_variant == 3 then
		--600
		bew_kgs = 36902
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		bew_kgs = 38172
	elseif B738DR_b737_variant == 1 then
		--900
		bew_kgs = 42042
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		bew_kgs = 45201
	elseif B738DR_pax_layout > 3 then
		--700
		bew_kgs = 38172
	else
		--800
		bew_kgs = 42034
	end
	if B738DR_pax_layout <= 1 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout <= 3 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	elseif B738DR_pax_layout == 5 or B738DR_pax_layout == 6 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout >= 7 and B738DR_pax_layout <= 9 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	else
		-- 138PAX 737-700
		moment_payload = bew_kgs * 16.687292	-- 656.98 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 5.842	-- 230 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 27.1018	-- 1067 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 6.4262	-- 253 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 28.194	-- 1110 inch
	end
	
	-- ZFW CG
	local n = (moment_payload / payload_cg) - 15.92834	-- 627.1 in LEMAC
	n = n / 3.95732	-- 155.8 in MAC
	n = n * 100
	if n < 0 or n > 40 then
		n = 0
	end
	
	return n
end

function calc_des_mac(fuel_input)
	
	local std_pax_weight = 0
	local payload_cg = B738DR_oew_kg
	local moment_payload = 0
	local bew_kgs = 0
	if B738DR_b737_variant == 3 then
		--600
		bew_kgs = 36902
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		bew_kgs = 38172
	elseif B738DR_b737_variant == 1 then
		--900
		bew_kgs = 42042
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		bew_kgs = 45201
	elseif B738DR_pax_layout > 3 then
		--700
		bew_kgs = 38172
	else
		--800
		bew_kgs = 42034
	end
	if B738DR_pax_layout <= 1 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout <= 3 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	elseif B738DR_pax_layout == 5 or B738DR_pax_layout == 6 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout >= 7 and B738DR_pax_layout <= 9 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	else
		-- 138PAX 737-700
		moment_payload = bew_kgs * 16.687292	-- 656.98 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 5.842	-- 230 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 27.1018	-- 1067 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 6.4262	-- 253 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 28.194	-- 1110 inch
	end
	
	for zxp = 1, 3 do
		std_pax_weight = B738DR_std_pax_weight[zxp-1]
		moment_payload = moment_payload + zone1_pax[zxp] * std_pax_weight * B738DR_zone_arm[0]
		moment_payload = moment_payload + zone2_pax[zxp] * std_pax_weight * B738DR_zone_arm[1]
		moment_payload = moment_payload + zone3_pax[zxp] * std_pax_weight * B738DR_zone_arm[2]
		moment_payload = moment_payload + zone4_pax[zxp] * std_pax_weight * B738DR_zone_arm[3]
		moment_payload = moment_payload + zone5_pax[zxp] * std_pax_weight * B738DR_zone_arm[4]
		payload_cg = payload_cg + zone1_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone2_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone3_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone4_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone5_pax[zxp] * std_pax_weight
	end
	if B738DR_b737_variant == 3 then
		--600
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 or B738DR_b737_variant == 1 then
		--800
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_73x == 2 then
		--737-700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	else
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	end
	payload_cg = payload_cg + zone_cargo1 + zone_cargo2
	
	local main_tank = 0
	local center_tank = 0
	if fuel_input >= 7800 then
		main_tank = 7800
		center_tank = fuel_input - 7800
	else
		main_tank = fuel_input --/ 2
	end
	
	local main_tank_kg = main_tank
	local center_tank_kg = center_tank
	local main_tank_arm = 0
	local center_tank_arm = 0
	main_tank_arm, center_tank_arm = fueltank_arms(main_tank_kg, center_tank_kg, B738DR_73x)
	local moment_main_tank = main_tank_kg * main_tank_arm -- *** kgm
	local moment_center_tank = center_tank_kg * center_tank_arm -- *** kgm
	moment_payload = moment_payload + moment_main_tank + moment_center_tank
	payload_cg = payload_cg + main_tank_kg + center_tank_kg
	
	local n = (moment_payload / payload_cg) - 15.92834	-- 627.1 in LEMAC
	n = n / 3.95732	-- 155.8 in MAC
	n = n * 100
	if n < 0 or n > 40 then	--6/36
		n = 0
	end
	return n
	
end

function calc_gw_cg_shift()
	
	-- Real calc
	local std_pax_weight = 0
	local payload_cg = B738DR_oew_kg
	local moment_payload = 0
	
	local bew_kgs = 0
	if B738DR_b737_variant == 3 then
		--600
		bew_kgs = 36902
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		bew_kgs = 38172
	elseif B738DR_b737_variant == 1 or B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900
		bew_kgs = 45201
	elseif B738DR_pax_layout > 3 then
		--700
		bew_kgs = 38172
	else
		--800
		bew_kgs = 42034
	end
	if B738DR_pax_layout <= 1 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 3.048	-- 120 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.718	-- 1170 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 3.0988	-- 122 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 31.115	-- 1225 inch
	elseif B738DR_pax_layout <= 3 then
		moment_payload = bew_kgs * cg_loc_800	-- 655.8 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 2.794	-- 110 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 29.591	-- 1165 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 2.032	-- 80 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 30.988	-- 1220 inch
	else
		-- 138PAX 737-700
		moment_payload = bew_kgs * 16.687292	-- 656.98 inch
		moment_payload = moment_payload + B738DR_fa_fwd_kg * 5.842	-- 230 inch
		moment_payload = moment_payload + B738DR_fa_aft_kg * 27.1018	-- 1067 inch
		moment_payload = moment_payload + B738DR_galley_fwd_kg * 6.4262	-- 253 inch
		moment_payload = moment_payload + B738DR_galley_aft_kg * 28.194	-- 1110 inch
	end
	
	for zxp = 1, 3 do
		std_pax_weight = B738DR_std_pax_weight[zxp-1]
		moment_payload = moment_payload + zone1_pax[zxp] * std_pax_weight * B738DR_zone_arm[0]
		moment_payload = moment_payload + zone2_pax[zxp] * std_pax_weight * B738DR_zone_arm[1]
		moment_payload = moment_payload + zone3_pax[zxp] * std_pax_weight * B738DR_zone_arm[2]
		moment_payload = moment_payload + zone4_pax[zxp] * std_pax_weight * B738DR_zone_arm[3]
		moment_payload = moment_payload + zone5_pax[zxp] * std_pax_weight * B738DR_zone_arm[4]
		payload_cg = payload_cg + zone1_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone2_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone3_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone4_pax[zxp] * std_pax_weight
		payload_cg = payload_cg + zone5_pax[zxp] * std_pax_weight
	end
	if B738DR_b737_variant == 3 then
		--600
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 or B738DR_b737_variant == 1 then
		--800
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	elseif B738DR_73x == 2 then
		--737-700
		moment_payload = moment_payload + zone_cargo1 * 10.6426	-- 419 in
		moment_payload = moment_payload + zone_cargo2 * 21.6408	-- 852 in
	else
		moment_payload = moment_payload + zone_cargo1 * 8.636	-- 340 in
		moment_payload = moment_payload + zone_cargo2 * 22.86	-- 900 in
	end
	payload_cg = payload_cg + zone_cargo1 + zone_cargo2
	local payload_cg_only = payload_cg
	
	local main_tank_kg = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[2]
	local center_tank_kg = simDR_fuel_tank_weight_kg[1]
	local main_tank_arm = 0
	local center_tank_arm = 0
	main_tank_arm, center_tank_arm = fueltank_arms(main_tank_kg, center_tank_kg, B738DR_73x)
	local moment_main_tank = main_tank_kg * main_tank_arm -- *** kgm
	local moment_center_tank = center_tank_kg * center_tank_arm -- *** kgm
	
	moment_payload = moment_payload + moment_main_tank + moment_center_tank
	payload_cg = payload_cg + main_tank_kg + center_tank_kg
	
	local n_out = 16.67
	if payload_cg ~= 0 then
		n_out = moment_payload / payload_cg
	end
	
	local n_mac_out = (moment_payload / payload_cg) - 15.92834	-- 627.1 in LEMAC
	n_mac_out = n_mac_out / 3.95732	-- 155.8 in MAC
	n_mac_out = n_mac_out * 100
	
	return n_mac_out, n_out
end

function fueltank_arms(fuel_main, fuel_center, in_plane)
	local main_tank_arm = 16.68272
	local center_tank_arm = 15.49654
	local fuel_main_k = (fuel_main * 0.5) / 4103	--3907
	if fuel_main_k > 1 then
		fuel_main_k = 1
	end
	fuel_main_k = fuel_main_k * 100
	if fuel_main_k > 3.88 then
		if fuel_main_k < 7.76 then	-- 200
			main_tank_arm = B738_rescale(3.88, 16.68272, 7.76, 16.67764, fuel_main_k)
		elseif fuel_main_k < 11.65 then	-- 300
			main_tank_arm = B738_rescale(7.76, 16.67764, 11.65, 16.68526, fuel_main_k)
		elseif fuel_main_k < 15.53 then	-- 400
			main_tank_arm = B738_rescale(11.65, 16.68526, 15.53, 16.70558, fuel_main_k)
		elseif fuel_main_k < 19.41 then	-- 500
			main_tank_arm = B738_rescale(15.53, 16.70558, 19.41, 16.7259, fuel_main_k)
		elseif fuel_main_k < 23.29 then	-- 600
			main_tank_arm = B738_rescale(19.41, 16.7259, 23.29, 16.74876, fuel_main_k)
		elseif fuel_main_k < 27.17 then	-- 700
			main_tank_arm = B738_rescale(23.29, 16.74876, 27.17, 16.76908, fuel_main_k)
		elseif fuel_main_k < 31.06 then	-- 800
			main_tank_arm = B738_rescale(27.17, 16.76908, 31.06, 16.79194, fuel_main_k)
		elseif fuel_main_k < 34.94 then	-- 900
			main_tank_arm = B738_rescale(31.06, 16.79194, 34.94, 16.8148, fuel_main_k)
		elseif fuel_main_k < 38.82 then	-- 1000
			main_tank_arm = B738_rescale(34.94, 16.8148, 38.82, 16.8402, fuel_main_k)
		elseif fuel_main_k < 42.70 then	-- 1100
			main_tank_arm = B738_rescale(38.82, 16.8402, 42.70, 16.86306, fuel_main_k)
		elseif fuel_main_k < 46.58 then	-- 1200
			main_tank_arm = B738_rescale(42.70, 16.86306, 46.58, 16.89608, fuel_main_k)
		elseif fuel_main_k < 50.47 then	-- 1300
			main_tank_arm = B738_rescale(46.58, 16.89608, 50.47, 16.93926, fuel_main_k)
		elseif fuel_main_k < 54.35 then	-- 1400
			main_tank_arm = B738_rescale(50.47, 16.93926, 54.35, 16.9799, fuel_main_k)
		elseif fuel_main_k < 58.23 then	-- 1500
			main_tank_arm = B738_rescale(54.35, 16.9799, 58.23, 17.02816, fuel_main_k)
		elseif fuel_main_k < 62.11 then	-- 1600
			main_tank_arm = B738_rescale(58.23, 17.02816, 62.11, 17.07642, fuel_main_k)
		elseif fuel_main_k < 65.99 then	-- 1700
			main_tank_arm = B738_rescale(62.11, 17.07642, 65.99, 17.1323, fuel_main_k)
		elseif fuel_main_k < 69.88 then	-- 1800
			main_tank_arm = B738_rescale(65.99, 17.1323, 69.88, 17.19072, fuel_main_k)
		elseif fuel_main_k < 73.76 then	-- 1900
			main_tank_arm = B738_rescale(69.88, 17.19072, 73.76, 17.25422, fuel_main_k)
		elseif fuel_main_k < 77.64 then	-- 2000
			main_tank_arm = B738_rescale(73.76, 17.25422, 77.64, 17.31772, fuel_main_k)
		elseif fuel_main_k < 81.52 then	-- 2100
			main_tank_arm = B738_rescale(77.64, 17.31772, 81.52, 17.38884, fuel_main_k)
		elseif fuel_main_k < 85.40 then	-- 2200
			main_tank_arm = B738_rescale(81.52, 17.38884, 85.40, 17.4625, fuel_main_k)
		elseif fuel_main_k < 89.29 then	-- 2300
			main_tank_arm = B738_rescale(85.40, 17.4625, 89.29, 17.54124, fuel_main_k)
		elseif fuel_main_k < 93.17 then	-- 2400
			main_tank_arm = B738_rescale(89.29, 17.54124, 93.17, 17.62252, fuel_main_k)
		elseif fuel_main_k < 97.05 then	-- 2500
			main_tank_arm = B738_rescale(93.17, 17.62252, 97.05, 17.71142, fuel_main_k)
		else	--2576
			main_tank_arm = B738_rescale(97.05, 17.71142, 100, 17.78508, fuel_main_k)
		end
	end
	local fuel_center_k = fuel_center / 13673	--13062
	if fuel_center_k > 1 then
		fuel_center_k = 1
	end
	fuel_center_k = fuel_center_k * 100
	if fuel_center_k > 2.33 then
		if fuel_center_k < 4.65 then	-- 200
			center_tank_arm = B738_rescale(2.33, 15.49654, 4.65, 15.48638, fuel_center_k)
		elseif fuel_center_k < 6.98 then	-- 300
			center_tank_arm = B738_rescale(4.65, 15.48638, 6.98, 15.46098, fuel_center_k)
		elseif fuel_center_k < 9.30 then	-- 400
			center_tank_arm = B738_rescale(6.98, 15.46098, 9.30, 15.42542, fuel_center_k)
		elseif fuel_center_k < 11.63 then	-- 500
			center_tank_arm = B738_rescale(9.30, 15.42542, 11.63, 15.40002, fuel_center_k)
		elseif fuel_center_k < 13.96 then	-- 600
			center_tank_arm = B738_rescale(11.63, 15.40002, 13.96, 15.38478, fuel_center_k)
		elseif fuel_center_k < 16.28 then	-- 700
			center_tank_arm = B738_rescale(13.96, 15.38478, 16.28, 15.37208, fuel_center_k)
		elseif fuel_center_k < 18.61 then	-- 800
			center_tank_arm = B738_rescale(16.28, 15.37208, 18.61, 15.367, fuel_center_k)
		elseif fuel_center_k < 20.94 then	-- 900
			center_tank_arm = B738_rescale(18.61, 15.367, 20.94, 15.36192, fuel_center_k)
		elseif fuel_center_k < 23.26 then	-- 1000
			center_tank_arm = B738_rescale(20.94, 15.36192, 23.26, 15.36192, fuel_center_k)
		elseif fuel_center_k < 25.59 then	-- 1100
			center_tank_arm = B738_rescale(23.26, 15.36192, 25.59, 15.35938, fuel_center_k)
		elseif fuel_center_k < 27.91 then	-- 1200
			center_tank_arm = B738_rescale(25.59, 15.35938, 27.91, 15.35938, fuel_center_k)
		elseif fuel_center_k < 30.24 then	-- 1300
			center_tank_arm = B738_rescale(27.91, 15.35938, 30.24, 15.36192, fuel_center_k)
		elseif fuel_center_k < 32.57 then	-- 1400
			center_tank_arm = B738_rescale(30.24, 15.36192, 32.57, 15.36192, fuel_center_k)
		elseif fuel_center_k < 34.89 then	-- 1500
			center_tank_arm = B738_rescale(32.57, 15.36192, 34.89, 15.36446, fuel_center_k)
		elseif fuel_center_k < 37.22 then	-- 1600
			center_tank_arm = B738_rescale(34.89, 15.36446, 37.22, 15.367, fuel_center_k)
		elseif fuel_center_k < 39.54 then	-- 1700
			center_tank_arm = B738_rescale(37.22, 15.367, 39.54, 15.37208, fuel_center_k)
		elseif fuel_center_k < 41.87 then	-- 1800
			center_tank_arm = B738_rescale(39.54, 15.37208, 41.87, 15.37462, fuel_center_k)
		elseif fuel_center_k < 44.20 then	-- 1900
			center_tank_arm = B738_rescale(41.87, 15.37462, 44.20, 15.37716, fuel_center_k)
		elseif fuel_center_k < 46.52 then	-- 2000
			center_tank_arm = B738_rescale(44.20, 15.37716, 46.52, 15.38224, fuel_center_k)
		elseif fuel_center_k < 48.85 then	-- 2100
			center_tank_arm = B738_rescale(46.52, 15.38224, 48.85, 15.38478, fuel_center_k)
		elseif fuel_center_k < 51.17 then	-- 2200
			center_tank_arm = B738_rescale(48.85, 15.38478, 51.17, 15.38732, fuel_center_k)
		elseif fuel_center_k < 53.50 then	-- 2300
			center_tank_arm = B738_rescale(51.17, 15.38732, 53.50, 15.38986, fuel_center_k)
		elseif fuel_center_k < 55.83 then	-- 2400
			center_tank_arm = B738_rescale(53.50, 15.38986, 55.83, 15.39494, fuel_center_k)
		elseif fuel_center_k < 58.15 then	-- 2500
			center_tank_arm = B738_rescale(55.83, 15.39494, 58.15, 15.39748, fuel_center_k)
		elseif fuel_center_k < 60.48 then	-- 2600
			center_tank_arm = B738_rescale(58.15, 15.39748, 60.48, 15.40002, fuel_center_k)
		elseif fuel_center_k < 62.81 then	-- 2700
			center_tank_arm = B738_rescale(60.48, 15.40002, 62.81, 15.40256, fuel_center_k)
		elseif fuel_center_k < 65.13 then	-- 2800
			center_tank_arm = B738_rescale(62.81, 15.40256, 65.13, 15.40256, fuel_center_k)
		elseif fuel_center_k < 67.46 then	-- 2900
			center_tank_arm = B738_rescale(65.13, 15.40256, 67.46, 15.4051, fuel_center_k)
		elseif fuel_center_k < 69.78 then	-- 3000
			center_tank_arm = B738_rescale(67.46, 15.4051, 69.78, 15.40764, fuel_center_k)
		elseif fuel_center_k < 72.11 then	-- 3100
			center_tank_arm = B738_rescale(69.78, 15.40764, 72.11, 15.41018, fuel_center_k)
		elseif fuel_center_k < 74.44 then	-- 3200
			center_tank_arm = B738_rescale(72.11, 15.41018, 74.44, 15.41018, fuel_center_k)
		elseif fuel_center_k < 76.76 then	-- 3300
			center_tank_arm = B738_rescale(74.44, 15.41018, 76.76, 15.41272, fuel_center_k)
		elseif fuel_center_k < 79.09 then	-- 3400
			center_tank_arm = B738_rescale(76.76, 15.41272, 79.09, 15.41272, fuel_center_k)
		elseif fuel_center_k < 81.41 then	-- 3500
			center_tank_arm = B738_rescale(79.09, 15.41272, 81.41, 15.41272, fuel_center_k)
		elseif fuel_center_k < 83.74 then	-- 3600
			center_tank_arm = B738_rescale(81.41, 15.41272, 83.74, 15.41018, fuel_center_k)
		elseif fuel_center_k < 86.07 then	-- 3700
			center_tank_arm = B738_rescale(83.74, 15.41018, 86.07, 15.40764, fuel_center_k)
		elseif fuel_center_k < 88.39 then	-- 3800
			center_tank_arm = B738_rescale(86.07, 15.40764, 88.39, 15.4051, fuel_center_k)
		elseif fuel_center_k < 90.72 then	-- 3900
			center_tank_arm = B738_rescale(88.39, 15.4051, 90.72, 15.40002, fuel_center_k)
		elseif fuel_center_k < 93.04 then	-- 4000
			center_tank_arm = B738_rescale(90.72, 15.40002, 93.04, 15.39748, fuel_center_k)
		elseif fuel_center_k < 95.37 then	-- 4100
			center_tank_arm = B738_rescale(93.04, 15.39748, 95.37, 15.38986, fuel_center_k)
		elseif fuel_center_k < 97.7 then	-- 4200
			center_tank_arm = B738_rescale(95.37, 15.38986, 97.7, 15.38478, fuel_center_k)
		else -- 4299
			center_tank_arm = B738_rescale(97.7, 15.38478, 100, 15.37716, fuel_center_k)
		end
	end
	return main_tank_arm, center_tank_arm
end

function check_tow(in_wght, in_mac)
	local result = false
	local mac_lim = 0
	local mac_lim2 = 0
	
	local plane_tp = 0
	if B738DR_b737_variant == 3 then
		--600
		plane_tp = 3
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		plane_tp = 2
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
		--800
		plane_tp = 0
	elseif B738DR_b737_variant == 1 then
		--900
		plane_tp = 4
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		plane_tp = 1
	elseif B738DR_73x == 2 then
		--737-700
		plane_tp = 2
	else
		plane_tp = 0
	end
	
	if plane_tp == 4 then
		--900
		if in_wght <= 79015 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 78471 then
				mac_lim = B738_rescale(65317, 6.2, 78471, 12, in_wght)
			elseif in_wght < 79015 then
				mac_lim = B738_rescale(62731, 12, 79015, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 71105 then
				mac_lim2 = B738_rescale(36651, 26.2, 71105, 35.7, in_wght)
			elseif in_wght < 78471 then
				mac_lim2 = B738_rescale(71105, 35.7, 78471, 31, in_wght)
			elseif in_wght < 79015 then
				mac_lim2 = B738_rescale(78471, 31, 79015, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp == 1 then
		--900ER
		if in_wght <= 83627 then
			-- fwd limit
			if in_wght < 69668 then
				mac_lim = 6
			elseif in_wght < 69929 then
				mac_lim = B738_rescale(69668, 6, 69929, 6.2, in_wght)
			elseif in_wght < 83353 then
				mac_lim = B738_rescale(69929, 6.2, 83353, 12, in_wght)
			elseif in_wght < 83627 then
				mac_lim = B738_rescale(67343, 12, 83627, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 75717 then
				mac_lim2 = B738_rescale(41263, 26.2, 75717, 35.7, in_wght)
			elseif in_wght < 83083 then
				mac_lim2 = B738_rescale(75717, 35.7, 83083, 31, in_wght)
			elseif in_wght < 83627 then
				mac_lim2 = B738_rescale(83083, 31, 83627, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp ~= 0 then
	--if B738DR_73x == 2 then
		if in_wght <= 70080 then
			-- fwd limit
			if in_wght < 65226 then
				mac_lim = 9
			elseif in_wght < 69626 then
				mac_lim = B738_rescale(65226, 9, 69626, 12, in_wght)
			elseif in_wght < 70080 then
				mac_lim = B738_rescale(69626, 12, 70080, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 47174 then
				mac_lim2 = B738_rescale(34000, 26.9, 47174, 33, in_wght)
			elseif in_wght < 63502 then
				mac_lim2 = 33
			elseif in_wght < 69626 then
				mac_lim2 = B738_rescale(63502, 33, 69626, 29, in_wght)
			elseif in_wght < 70080 then
				mac_lim2 = B738_rescale(69626, 29, 70080, 25.5, in_wght)
			else
				mac_lim2 = 25.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	else
		if in_wght <= 79015 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 78471 then
				mac_lim = B738_rescale(65317, 6.2, 78471, 12, in_wght)
			elseif in_wght < 79015 then
				mac_lim = B738_rescale(62731, 12, 79015, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 71105 then
				mac_lim2 = B738_rescale(36651, 26.2, 71105, 35.7, in_wght)
			elseif in_wght < 78471 then
				mac_lim2 = B738_rescale(71105, 35.7, 78471, 31, in_wght)
			elseif in_wght < 79015 then
				mac_lim2 = B738_rescale(78471, 31, 79015, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	end
	
	return result
end

function check_gw(in_wght, in_mac)
	local result = false
	local mac_lim = 0
	local mac_lim2 = 0
	
	local plane_tp = 0
	if B738DR_b737_variant == 3 then
		--600
		plane_tp = 3
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		plane_tp = 2
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
		--800
		plane_tp = 0
	elseif B738DR_b737_variant == 1 then
		--900
		plane_tp = 4
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		plane_tp = 1
	elseif B738DR_73x == 2 then
		--737-700
		plane_tp = 2
	else
		plane_tp = 0
	end
	
	if plane_tp == 4 then
		if in_wght <= 79015 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 78471 then
				mac_lim = B738_rescale(65317, 6.2, 78741, 12, in_wght)
			elseif in_wght < 79015 then
				mac_lim = B738_rescale(62731, 12, 79015, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			elseif in_wght < 70760 then
				mac_lim2 = 36
			elseif in_wght < 78471 then
				mac_lim2 = B738_rescale(70760, 36, 78471, 31, in_wght)
			elseif in_wght < 79015 then
				mac_lim2 = B738_rescale(78471, 31, 79015, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp == 1 then
		if in_wght <= 83627 then
			-- fwd limit
			if in_wght < 69668 then
				mac_lim = 6
			elseif in_wght < 67929 then
				mac_lim = B738_rescale(69668, 6, 67929, 6.2, in_wght)
			elseif in_wght < 83353 then
				mac_lim = B738_rescale(67929, 6.2, 83353, 12, in_wght)
			elseif in_wght < 83627 then
				mac_lim = B738_rescale(83353, 12, 83627, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 52239 then
				mac_lim2 = B738_rescale(34000, 31.5, 52239, 36, in_wght)
			elseif in_wght < 75372 then
				mac_lim2 = 36
			elseif in_wght < 83353 then
				mac_lim2 = B738_rescale(70760, 36, 83353, 31, in_wght)
			elseif in_wght < 83627 then
				mac_lim2 = B738_rescale(83353, 31, 83627, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp ~= 0 then
	-- if B738DR_73x == 2 then
		if in_wght <= 70080 then
			-- fwd limit
			if in_wght < 63729 then
				mac_lim = 8
			elseif in_wght < 69626 then
				mac_lim = B738_rescale(63729, 8, 69626, 12, in_wght)
			elseif in_wght < 70080 then
				mac_lim = B738_rescale(69626, 12, 70080, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 47174 then
				mac_lim2 = B738_rescale(34000, 26.9, 47174, 33, in_wght)
			elseif in_wght < 63502 then
				mac_lim2 = 33
			elseif in_wght < 69626 then
				mac_lim2 = B738_rescale(63502, 33, 69626, 29, in_wght)
			elseif in_wght < 70080 then
				mac_lim2 = B738_rescale(69626, 29, 70080, 25.5, in_wght)
			else
				mac_lim2 = 25.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	else
		if in_wght <= 79015 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 78471 then
				mac_lim = B738_rescale(65317, 6.2, 78741, 12, in_wght)
			elseif in_wght < 79015 then
				mac_lim = B738_rescale(62731, 12, 79015, 15, in_wght)
			else
				mac_lim = 15
			end
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			elseif in_wght < 70760 then
				mac_lim2 = 36
			elseif in_wght < 78471 then
				mac_lim2 = B738_rescale(70760, 36, 78471, 31, in_wght)
			elseif in_wght < 79015 then
				mac_lim2 = B738_rescale(78471, 31, 79015, 26.5, in_wght)
			else
				mac_lim2 = 26.5
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	end
	
	return result
end

function check_zfw(in_wght, in_mac)
	local result = false
	local mac_lim = 0
	local mac_lim2 = 0
	
	local plane_tp = 0
	if B738DR_b737_variant == 3 then
		--600
		plane_tp = 3
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		plane_tp = 2
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
		--800
		plane_tp = 0
	elseif B738DR_b737_variant == 1 then
		--900
		plane_tp = 4
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		plane_tp = 1
	elseif B738DR_73x == 2 then
		--737-700
		plane_tp = 2
	else
		plane_tp = 0
	end
	
	if plane_tp == 4 then
		if in_wght <= 62731 then
			-- fwd limit
			mac_lim = 6
			
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp == 1 then
		if in_wght <= 67343 then
			-- fwd limit
			mac_lim = 6
			
			-- aft limit
			if in_wght < 52239 then
				mac_lim2 = B738_rescale(34000, 31.5, 52239, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp ~= 0 then
	-- if B738DR_73x == 2 then
		if in_wght <= 54657 then
			-- fwd limit
			mac_lim = 9
			-- aft limit
			if in_wght < 47174 then
				mac_lim2 = B738_rescale(34000, 26.9, 47174, 33, in_wght)
			else
				mac_lim2 = 33
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	else
		if in_wght <= 62731 then
			-- fwd limit
			mac_lim = 6
			
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	end
	return result
end

function check_lw(in_wght, in_mac)
	local result = false
	local mac_lim = 0
	local mac_lim2 = 0
	
	local plane_tp = 0
	if B738DR_b737_variant == 3 then
		--600
		plane_tp = 3
	elseif B738DR_b737_variant == 2 or B738DR_b737_variant == 5 then
		--700
		plane_tp = 2
	elseif B738DR_b737_variant == 0 or B738DR_b737_variant == 7 then
		--800
		plane_tp = 0
	elseif B738DR_b737_variant == 1 then
		--900
		plane_tp = 4
	elseif B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
		--900ER
		plane_tp = 1
	elseif B738DR_73x == 2 then
		--737-700
		plane_tp = 2
	else
		plane_tp = 0
	end
	
	if plane_tp == 4 then
		if in_wght <= 66360 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 66360 then
				mac_lim = B738_rescale(65317, 6.2, 66360, 14.1, in_wght)
			else
				mac_lim = 14.1
			end
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp == 4 then
		if in_wght <= 70972 then
			-- fwd limit
			if in_wght < 69668 then
				mac_lim = 6
			elseif in_wght < 69929 then
				mac_lim = B738_rescale(69668, 6, 69929, 6.2, in_wght)
			elseif in_wght < 70972 then
				mac_lim = B738_rescale(69929, 6.2, 70972, 14.1, in_wght)
			else
				mac_lim = 14.1
			end
			-- aft limit
			if in_wght < 52239 then
				mac_lim2 = B738_rescale(34000, 31.5, 52239, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	elseif plane_tp ~= 0 then
	-- if B738DR_73x == 2 then
		if in_wght <= 58059 then
			-- fwd limit
			mac_lim = 9
			-- aft limit
			if in_wght < 47174 then
				mac_lim2 = B738_rescale(34000, 26.9, 47174, 33, in_wght)
			else
				mac_lim2 = 33
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	else
		if in_wght <= 66360 then
			-- fwd limit
			if in_wght < 65056 then
				mac_lim = 6
			elseif in_wght < 65317 then
				mac_lim = B738_rescale(65056, 6, 65317, 6.2, in_wght)
			elseif in_wght < 66360 then
				mac_lim = B738_rescale(65317, 6.2, 66360, 14.1, in_wght)
			else
				mac_lim = 14.1
			end
			-- aft limit
			if in_wght < 47627 then
				mac_lim2 = B738_rescale(34000, 31.5, 47627, 36, in_wght)
			else
				mac_lim2 = 36
			end
			
			if in_mac > mac_lim and in_mac < mac_lim2 then
				result = true
			end
		end
	end
	
	return result
end

function anim_checklist()
	
	local cl_manip_enable = 0
	
	if cl_pos_tgt == 0 then
		if cl_active == 2 then
			B738DR_cl_pos_y = B738_set_anim_value(B738DR_cl_pos_y * 100, -32, -100, 100, 5) / 100
			B738DR_cl_pos_z = B738_set_anim_value(B738DR_cl_pos_z * 100, 0, -100, 100, 5) / 100
			B738DR_cl_pos_x = B738_set_anim_value(B738DR_cl_pos_x * 100, 0, -100, 100, 5) / 100
			B738DR_cl_rot_x = B738_set_anim_value(B738DR_cl_rot_x, 90, -180, 180, 5)
			if cl_cpt_fo == 0 then
				B738DR_cl_rot_y = B738_set_anim_value(B738DR_cl_rot_y, 25, -180, 180, 5)
				if B738DR_cl_pos_y > -0.33 and B738DR_cl_pos_y < -0.31 
				and B738DR_cl_pos_z > -0.01 and B738DR_cl_pos_z < 0.01 
				and B738DR_cl_pos_x > -0.01 and B738DR_cl_pos_x < 0.01 
				and B738DR_cl_rot_x > 88 and B738DR_cl_rot_x < 92 
				and B738DR_cl_rot_y > 23 and B738DR_cl_rot_y < 27 then
					cl_active = 1
				end
			else
				B738DR_cl_rot_y = B738_set_anim_value(B738DR_cl_rot_y, -25, -180, 180, 5)
				if B738DR_cl_pos_y > -0.33 and B738DR_cl_pos_y < -0.31 
				and B738DR_cl_pos_z > -0.01 and B738DR_cl_pos_z < 0.01 
				and B738DR_cl_pos_x > -0.01 and B738DR_cl_pos_x < 0.01 
				and B738DR_cl_rot_x > 88 and B738DR_cl_rot_x < 92 
				and B738DR_cl_rot_y < -23 and B738DR_cl_rot_y > -27 then
					cl_active = 1
				end
			end
		elseif cl_active == 1 then
				cl_pos = B738_set_anim_value(cl_pos, cl_pos_tgt, 0, 100, 5)
				if cl_pos < 50 then
					B738DR_cl_pos_x = 0
					B738DR_cl_pos_y = B738_rescale(0, 0, 50, -0.32, cl_pos)
					B738DR_cl_pos_z = B738_rescale(0, 0, 50, 0.052, cl_pos)
					B738DR_cl_rot_x = 0
					B738DR_cl_rot_y = 0
				elseif cl_pos < 80 then
					B738DR_cl_pos_x = 0
					B738DR_cl_pos_y = -0.32
					B738DR_cl_pos_z = 0.052
					B738DR_cl_rot_x = B738_rescale(50, 0, 100, 90, cl_pos)
					B738DR_cl_rot_y = 0
				else
					B738DR_cl_rot_x = B738_rescale(50, 0, 100, 90, cl_pos)
					if cl_cpt_fo == 0 then
						B738DR_cl_rot_y = B738_rescale(80, 0, 100, 25, cl_pos)
					else
						B738DR_cl_rot_y = B738_rescale(80, 0, 100, -25, cl_pos)
					end
					B738DR_cl_pos_x = 0
					B738DR_cl_pos_y = -0.32
					B738DR_cl_pos_z = B738_rescale(80, 0.052, 100, 0, cl_pos)
				end
				if cl_pos == 0 then
					cl_active = 0
				end
		end
	else
		if cl_active == 1 then
			cl_pos = B738_set_anim_value(cl_pos, cl_pos_tgt, 0, 100, 5)
			if cl_pos > 99 then
				cl_pos = 100
			end
			if cl_pos < 50 then
				B738DR_cl_pos_x = 0
				B738DR_cl_pos_y = B738_rescale(0, 0, 50, -0.32, cl_pos)
				B738DR_cl_pos_z = B738_rescale(0, 0, 50, 0.052, cl_pos)
				B738DR_cl_rot_x = 0
				B738DR_cl_rot_y = 0
			elseif cl_pos < 80 then
				B738DR_cl_pos_x = 0
				B738DR_cl_pos_y = -0.32
				B738DR_cl_pos_z = 0.052
				B738DR_cl_rot_x = B738_rescale(50, 0, 100, 90, cl_pos)
				B738DR_cl_rot_y = 0
			else
				B738DR_cl_rot_x = B738_rescale(50, 0, 100, 90, cl_pos)
				if cl_cpt_fo == 0 then
					B738DR_cl_rot_y = B738_rescale(80, 0, 100, 25, cl_pos)
				else
					B738DR_cl_rot_y = B738_rescale(80, 0, 100, -25, cl_pos)
				end
				B738DR_cl_pos_x = 0
				B738DR_cl_pos_y = -0.32
				B738DR_cl_pos_z = B738_rescale(80, 0.052, 100, 0, cl_pos)
			end
			if cl_pos == 100 then
				cl_active = 2
			end
		else
			cl_manip_enable = 1
		end
	end
	
	B738DR_cl_manip_enable = cl_manip_enable
	
end

function autoupdate_timer()
	if B738DR_tab_menu_page ~= 8 then
		display_update = 1
	end
	
	if B738DR_b737_variant < 0 then
		if display_update_cnt < 6 then
			display_update_cnt = display_update_cnt + 1
		else
			display_update_cnt = 0
			
			if B738DR_tab_credits == 0 then
				B738DR_tab_credits = 1
			elseif B738DR_tab_credits == 1 then
				B738DR_tab_credits = 2
			elseif B738DR_tab_credits == 2 then
				B738DR_tab_credits = 3
			elseif B738DR_tab_credits == 3 then
				B738DR_tab_credits = 4
			else
				B738DR_tab_credits = 0
			end
		end
	else
		B738DR_tab_credits = 1
	end
end

function reset_efb()
	cat = CAT_HOME
	page = 1
	min_page = 1
	max_page = 2
	display_update = 0
	B738DR_tab_page_info_time = "--:--"
	info_pos_tgt = 160
	B738DR_tab_page_info_pos = 160
	info_act = 0
	info_act_old = 0
	B738DR_tab_credits = 0
	clr_menu_manip()
	clr_line_manip()
	clr_item()
	clr_perf_manip()
	B738DR_tab_menu_page = 0
	boot_cnt = 0
	B738DR_tab_power = 1
	B738DR_tab_boot_active = 1
	B738DR_tab_nav_manip = 0
	B738DR_tab_nav2_manip = 0
	B738DR_tab_info_manip = 0
	B738DR_tab_arrows_enable = 0
	checklist_offset = 0
	B738DR_detail_cl = 0
	B738DR_tab_numpad_act = 0
	B738DR_tab_numpad_val = ""
	B738DR_tab_numpad_spec1 = 0
	B738DR_tab_numpad_spec2 = 0
	numpad_ref = 0
	numpad_point = 0
	tab_numpad_val = ""
	cl_active = 0
	cl_pos = 0
	cl_pos_tgt = 0
	cl_cpt_fo = 0
	checklist_page = 1
	B738DR_bgnd_fuel = 0
	B738DR_bgnd_perf_lnd = 0
	B738DR_bgnd_perf_to = 0
	avitab_ctrl_override = 0
	if avitab_installed == 1 and avitab_ctrl_override == 0 then
		avitab_powered = 1
		avitab_enabled = 0
		avitab_brightness = 1.0
	end
	
end

function anim_door()
	if was_replay == 0 then
		door_ratio_fwd_L = B738_set_animation_rate (door_ratio_fwd_L, door_ratio_fwd_L_trg, 0, 1, 7)
		door_ratio_fwd_R = B738_set_animation_rate (door_ratio_fwd_R, door_ratio_fwd_R_trg, 0, 1, 7)
		door_ratio_aft_L = B738_set_animation_rate (door_ratio_aft_L, door_ratio_aft_L_trg, 0, 1, 7)
		door_ratio_aft_R = B738_set_animation_rate (door_ratio_aft_R, door_ratio_aft_R_trg, 0, 1, 7)
		door_ratio_fwd_cargo = B738_set_animation_rate (door_ratio_fwd_cargo, door_ratio_fwd_cargo_trg, 0, 1, 7)
		door_ratio_aft_cargo = B738_set_animation_rate (door_ratio_aft_cargo, door_ratio_aft_cargo_trg, 0, 1, 7)
		
		door_ratio_emerg1 = B738_set_animation_rate (door_ratio_emerg1, door_ratio_emerg1_trg, 0, 1, 2)
		door_ratio_emerg2 = B738_set_animation_rate (door_ratio_emerg2, door_ratio_emerg2_trg, 0, 1, 2)
		door_ratio_emerg3 = B738_set_animation_rate (door_ratio_emerg3, door_ratio_emerg3_trg, 0, 1, 2)
		door_ratio_emerg4 = B738_set_animation_rate (door_ratio_emerg4, door_ratio_emerg4_trg, 0, 1, 2)
		
		door_ratio_emerg5 = B738_set_animation_rate (door_ratio_emerg5, door_ratio_emerg5_trg, 0, 1, 2)
		door_ratio_emerg6 = B738_set_animation_rate (door_ratio_emerg6, door_ratio_emerg6_trg, 0, 1, 2)
		
		door_ratio_emerg5_lu = door_ratio_emerg5
		door_ratio_emerg6_lu = door_ratio_emerg6
		
		if B738DR_b737_variant == 1 or B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
			door_ratio_aft1 = B738_set_animation_rate (door_ratio_aft1, door_ratio_aft1_trg, 0, 1, 2)
			door_ratio_aft2 = B738_set_animation_rate (door_ratio_aft2, door_ratio_aft2_trg, 0, 1, 2)
		else
			door_ratio_aft1 = 0
			door_ratio_aft2 = 0
			door_ratio_aft1_trg = 0
			door_ratio_aft2_trg = 0
		end
	else
		door_ratio_fwd_L = door_ratio_fwd_L_trg
		door_ratio_fwd_R = door_ratio_fwd_R_trg
		door_ratio_aft_L = door_ratio_aft_L_trg
		door_ratio_aft_R = door_ratio_aft_R_trg
		door_ratio_fwd_cargo = door_ratio_fwd_cargo_trg
		door_ratio_aft_cargo = door_ratio_aft_cargo_trg
		
		door_ratio_emerg1 = door_ratio_emerg1_trg
		door_ratio_emerg2 = door_ratio_emerg2_trg
		door_ratio_emerg3 = door_ratio_emerg3_trg
		door_ratio_emerg4 = door_ratio_emerg4_trg
		
		door_ratio_emerg5 = door_ratio_emerg5_trg
		door_ratio_emerg6 = door_ratio_emerg6_trg
		
		door_ratio_emerg5_lu = door_ratio_emerg5
		door_ratio_emerg6_lu = door_ratio_emerg6
		
		if B738DR_b737_variant == 1 or B738DR_b737_variant == 4 or B738DR_b737_variant == 8 then
			door_ratio_aft1 = door_ratio_aft1_trg
			door_ratio_aft2 = door_ratio_aft2_trg
		else
			door_ratio_aft1 = 0
			door_ratio_aft2 = 0
			door_ratio_aft1_trg = 0
			door_ratio_aft2_trg = 0
		end
	end
	
	if B738DR_not_airstairs == 0 then
		if B738DR_b737_variant >= 0 then
			local airstair_anim_time = 32
			-- if simDR_bus_battery_on[1] == 0 then
			if B738DR_batbus_status == 0 then
				airstair_anim_time = 55
			end
			if B738DR_hot_batbus_status ~= 0 then
				B738DR_airstair_ratio = B738_set_animation_rate (B738DR_airstair_ratio, airstair_ratio_tgt, 0, 1, airstair_anim_time)
			end
			if B738DR_airstair_ratio == 0 then
				B738DR_hide_airstairs = 1
			else
				B738DR_hide_airstairs = 0
			end
		end
	else
		B738DR_airstair_ratio = 0
		airstair_ratio_tgt = 0
		B738DR_hide_airstairs = 1
	end
	
end

function door_state(in_door_trg, in_door_ratio, in_lock, in_idx, in_airstair)
	if in_door_trg == 0 then
		if in_door_ratio == 0 then
			door_status[in_idx] = 2		-- closed
		else
			if B738DR_blink == 0 then
				door_status[in_idx] = 1		-- closing
			else
				door_status[in_idx] = 2		-- closed
			end
		end
		if in_door_ratio == 0 then
			door_lock[in_idx] = in_lock
		else
			door_lock[in_idx] = 0
		end
	else
		if in_airstair == -1 then
			door_lock[in_idx] = 0
			if in_door_ratio == 1 then
				door_status[in_idx] = 0		-- open
			else
				if B738DR_blink == 0 then
					door_status[in_idx] = 1		-- opening
				else
					door_status[in_idx] = 0		-- open
				end
			end
		elseif in_airstair == 0 then
			door_lock[in_idx] = 1
		else
			door_lock[in_idx] = 0
			if in_door_ratio == 1 then
				door_status[in_idx] = 0		-- open
			else
				if B738DR_blink == 0 then
					door_status[in_idx] = 1		-- opening
				else
					door_status[in_idx] = 0		-- open
				end
			end
		end
	end
end

function B738_door_status()
	door_state(door_ratio_fwd_L_trg, door_ratio_fwd_L, door_locked, 0, B738DR_hide_airstairs)
	door_state(door_ratio_fwd_R_trg, door_ratio_fwd_R, door_locked, 1, -1)
	door_state(door_ratio_fwd_cargo_trg, door_ratio_fwd_cargo, door_locked, 2, -1)
	door_state(door_ratio_aft_L_trg, door_ratio_aft_L, door_locked, 3, -1)
	door_state(door_ratio_aft_R_trg, door_ratio_aft_R, door_locked, 4, -1)
	door_state(door_ratio_aft_cargo_trg, door_ratio_aft_cargo, door_locked, 5, -1)
	
	door_state(door_ratio_emerg4_trg, door_ratio_emerg4, emerg_door_locked, 6, -1)
	door_state(door_ratio_emerg3_trg, door_ratio_emerg3, emerg_door_locked, 7, -1)
	door_state(door_ratio_emerg2_trg, door_ratio_emerg2, emerg_door_locked, 8, -1)
	door_state(door_ratio_emerg1_trg, door_ratio_emerg1, emerg_door_locked, 9, -1)
	
	door_state(door_ratio_emerg5_trg, door_ratio_emerg5, emerg_door_locked, 10, -1)
	door_state(door_ratio_emerg6_trg, door_ratio_emerg6, emerg_door_locked, 11, -1)
end

function B738_fps()
	if B738DR_fps_enable ~= 0 then
		local actual_fps = 999
		if actual_fps ~= 0 then
			actual_fps = math.floor((1 / simDR_fps_period) + 0.5)
			actual_fps = math.min(actual_fps, 999)
			actual_fps = math.max(actual_fps, 0)
		end
		B738DR_fps = string.format("%3d", actual_fps) .. " FPS"
		if B738DR_fms_test1 ~= 44 then
			B738DR_fps = B738DR_fps .. "     ERROR " .. B738DR_fms_test1
		end
	else
		if B738DR_fms_test1 ~= 44 then
			B738DR_fps = "ERROR " .. B738DR_fms_test1
		else
			B738DR_fps = ""
		end
	end
	
end

function nocase (s)
	s = string.gsub(s, "%a", function (c)
	return string.format("%s", string.lower(c)) end) 
	return s
end

function change_sound_set(liv)
	local ii = 0
	local jj = 0
	local kk = 0
	local announcement_set1 = 0
	local announcement_set2 = 0
	local finded_livery = 0
	
	local int, frac = math.modf(os.clock())
	local seed = math.random(1, frac*1000.0)
	math.randomseed(seed)
	
	for ii = 1, LIVERY_NUM do
		jj,kk = string.find(liv, livery_txt[ii])
		if jj ~= nil then
			announcement_set1 = livery_set1[ii]
			announcement_set2 = livery_set2[ii]
			if announcement_set1 ~= announcement_set2 then
				announcement_set1 = math.floor(math.random(announcement_set1, announcement_set2) + 0.5)
			end
			finded_livery = 1
			break
		end
	end
	
	if simDR_livery_idx == 0 then
		announcement_set1 = math.floor(math.random(BASE_LIVERY_SET1, BASE_LIVERY_SET2) + 0.5)
	elseif finded_livery == 0 then
		announcement_set1 = math.floor(math.random(UNKNOWN_LIVERY_SET1, UNKNOWN_LIVERY_SET2) + 0.5)
	end
	B738DR_announcement_set = announcement_set1
end

function check_livery()
	livery_path = simDR_livery
	livery = nocase(livery_path)
	local int, frac = math.modf(os.clock())
	local seed = math.random(1, frac*1000.0)
	math.randomseed(seed)
	if B738DR_pa_announc_set == 0 then	-- auto
		--if string.len(livery) == 0 then
		if simDR_livery_idx == 0 then
			B738DR_announcement_set = math.floor(math.random(BASE_LIVERY_SET1, BASE_LIVERY_SET2) + 0.5)
		else
			change_sound_set(livery)
		end
	else
		B738DR_announcement_set = B738DR_pa_announc_set - 1
	end
	
	if B738DR_JAR_copilot ~= 0 then
		B738DR_disable_fo_callout = 1
	end
end

function B738_de_ice_truck()
	
	local de_ice_temp = 0
	local de_ice_temp2 = 0
	
	if de_ice_apply_time > 0 then
		de_ice_apply_time = de_ice_apply_time - SIM_PERIOD
		if de_ice_apply_time < 0 then
			de_ice_apply_time = 0
		end
		if de_ice_apply_time > 10 and de_ice_apply_time < 170 then
			B738DR_de_ice_truck_act = 1
		else
			B738DR_de_ice_truck_act = 0
		end
		if de_ice_apply_time > 175 then
			B738DR_de_ice_truck_pos[0] = 0
			B738DR_de_ice_truck_pos[1] = B738_rescale(175, 0.83, 180, 0, de_ice_apply_time)
			B738DR_de_ice_truck_pos[2] = B738_rescale(175, 0.6, 180, 0, de_ice_apply_time)
		elseif de_ice_apply_time < 5 then
			B738DR_de_ice_truck_pos[0] = 0
			B738DR_de_ice_truck_pos[1] = B738_rescale(0, 0, 5, 0.83, de_ice_apply_time)
			B738DR_de_ice_truck_pos[2] = B738_rescale(0, 0, 5, 0.6, de_ice_apply_time)
		elseif de_ice_apply_time > 170 then
			B738DR_de_ice_truck_pos[0] = B738_rescale(170, -0.8, 175, 0, de_ice_apply_time)
			B738DR_de_ice_truck_pos[1] = B738_rescale(-0.8, 0.6, 0.6, 1.0, B738DR_de_ice_truck_pos[0])
			B738DR_de_ice_truck_pos[2] = 0.6
		elseif de_ice_apply_time < 10 then
			B738DR_de_ice_truck_pos[0] = B738_rescale(5, 0, 10, -0.8, de_ice_apply_time)
			B738DR_de_ice_truck_pos[1] = B738_rescale(-0.8, 0.6, 0.6, 1.0, B738DR_de_ice_truck_pos[0])
			B738DR_de_ice_truck_pos[2] = 0.6
		else
			de_ice_temp = (de_ice_apply_time - 10) % 32
			de_ice_temp2 = 0
			if de_ice_temp < 1 then
				de_ice_temp2 = 1
			elseif de_ice_temp > 15 and de_ice_temp < 17 then
				de_ice_temp2 = 1
			elseif de_ice_temp > 31 then
				de_ice_temp2 = 1
			end
			if de_ice_temp2 == 0 then
				if de_ice_temp < 16 then
					B738DR_de_ice_truck_pos[0] = B738_rescale(1, -0.8, 15, 0.6, de_ice_temp)
					B738DR_de_ice_truck_pos[1] = B738_rescale(-0.8, 0.6, 0.6, 1.0, B738DR_de_ice_truck_pos[0])
					B738DR_de_ice_truck_pos[2] = 0.6
				else
					B738DR_de_ice_truck_pos[0] = B738_rescale(17, 0.6, 31, -0.8, de_ice_temp)
					B738DR_de_ice_truck_pos[1] = B738_rescale(-0.8, 0.6, 0.6, 1.0, B738DR_de_ice_truck_pos[0])
					B738DR_de_ice_truck_pos[2] = 0.6
				end
			end
		end
		B738DR_de_ice_truck_pos[3] = B738DR_de_ice_truck_pos[0]
		B738DR_de_ice_truck_pos[4] = B738DR_de_ice_truck_pos[1]
		B738DR_de_ice_truck_pos[5] = B738DR_de_ice_truck_pos[2]
	else
		B738DR_de_ice_truck_hide = 1
		B738DR_de_ice_truck_act = 0
	end
end

function B738_pax()
	if B738DR_passengers == 1 then
		B738DR_passengers_hide = 1
	elseif B738DR_auto_flight ~= 0 then
		local pax_empty = 1
		for zxp = 1, 3 do
			if zone1_pax[zxp] ~= 0 then
				pax_empty = 0
				break
			elseif zone2_pax[zxp] ~= 0 then
				pax_empty = 0
				break
			elseif zone3_pax[zxp] ~= 0 then
				pax_empty = 0
				break
			elseif zone4_pax[zxp] ~= 0 then
				pax_empty = 0
				break
			elseif zone5_pax[zxp] ~= 0 then
				pax_empty = 0
				break
			end
		end
		if pax_empty == 0 then
			B738DR_passengers_hide = 0
		else
			B738DR_passengers_hide = 1
		end
	elseif B738DR_passengers == 2 then
		if start_leg == 0 then
			B738DR_passengers_hide = 1
		else
			B738DR_passengers_hide = 0
		end
	else
		B738DR_passengers_hide = 0
	end
end

function B738_ext_air()
	if gpu_test_enable == 0 then
		local ground_ok = 0
		-- if (simDR_on_ground[0] == 0 and simDR_on_ground[1] == 0 and simDR_on_ground[2] == 0) or simDR_aircraft_groundspeed > 0.08 then
		if simDR_on_ground[0] == 0 and simDR_on_ground[1] == 0 and simDR_on_ground[2] == 0 then
			ground_ok = 1
		end
		
		if B738DR_asu_test == 0 then
			if B738DR_engine_air_start == 1 then
				-- if (simDR_on_ground[0] == 0 and simDR_on_ground[1] == 0 and simDR_on_ground[2] == 0) or simDR_aircraft_groundspeed > 0.08 then
				if ground_ok == 1 then
					B738DR_engine_air_start = 0
					B738DR_hide_asu = 1
				else
					B738DR_hide_asu = 0
				end
			else
				B738DR_hide_asu = 1
			end
		else
			B738DR_asu_test = 0
			B738DR_engine_air_start = 0
			B738DR_hide_asu = 1
		end
		
		
		if B738DR_deicetruck_test == 0 then
			if ground_ok == 1 then
				if B738DR_de_ice_truck_hide == 0 then
					B738DR_de_ice_truck_hide = 1
					B738DR_de_ice_truck_act = 0
					de_ice_apply_time = 0
				end
			end
		else
			B738DR_deicetruck_test = 0
			B738DR_de_ice_truck_hide = 1
			B738DR_de_ice_truck_act = 0
			de_ice_apply_time = 0
		end
		
		if B738DR_fueltruck_test == 0 then
			if ground_ok == 1 then
				-- if B738DR_hide_fueltruck == 0 then
				if hide_fueltruck == 0 then
					hide_fueltruck = 1
					B738DR_hide_fueltruck = 1
				end
			end
		else
			B738DR_fueltruck_test = 0
			hide_fueltruck = 0
			if B738DR_int_gnd_services == 0 then
				B738DR_hide_fueltruck = 0
			end
		end
		
		if ground_ok == 1 then
			if B738DR_hide_airstairs == 0 then
				B738DR_hide_airstairs = 1
				airstair_ratio_tgt = 0
				B738DR_airstair_ratio = 0
			end
		end
	end
	local vert_deflect = 0
	if B738DR_hide_airstairs == 0 then
		--B738DR_73x
		vert_deflect = math.max(simDR_vert_deflect[0], 0.2036)
		vert_deflect = math.min(vert_deflect, 0.27344)
		B738DR_airstairs_angle1 = B738_rescale(0.2036, 44.8, 0.27344, 43, vert_deflect)
	end
	if B738DR_hide_fueltruck == 0 or B738DR_cones_hide == 0 then
		vert_deflect = math.max(simDR_vert_deflect[2], 0.219)
		vert_deflect = math.min(vert_deflect, 0.290)
		B738DR_fueltruck_shift_z = B738_rescale(0.219, -2.67, 0.290, -2.63, vert_deflect)
		if B738DR_73x == 0 then
			B738DR_fueltruck_shift_y = 0
		elseif B738DR_73x == 1 then
			B738DR_fueltruck_shift_y = -0.1
		elseif B738DR_73x == 2 then
			B738DR_fueltruck_shift_y = 0.14
		end
	end
	
	if B738DR_mmr == 0 then
		if B738DR_ils_gls_annun == 0 then
			B738DR_ils_gls_inop = 0
		else
			B738DR_ils_gls_inop = 1
		end
		B738DR_lpv_install = 0
	else
		B738DR_ils_gls_inop = 0
	end
	
end

function B738_fuel_tanking()
	
	if fuel_start_tmr > 0 then
		fuel_start_tmr = fuel_start_tmr - SIM_PERIOD
		if fuel_start_tmr < 0 then
			fuel_start_tmr = 0
			fuel_start = 1
		end
	end
	
	if fuel_end_tmr > 0 then
		fuel_end_tmr = fuel_end_tmr - SIM_PERIOD
		if fuel_end_tmr < 0 then
			fuel_end_tmr = 0
			fuel_end = 1
			fuel_tank_finish_arm = 0
		end
	end
	
	if fuel_term_tmr > 0 then
		fuel_term_tmr = fuel_term_tmr - SIM_PERIOD
		if fuel_term_tmr < 0 then
			fuel_term_tmr = 0
		end
	end
	
	-- if B738DR_hide_fueltruck == 0 then
	if hide_fueltruck == 0 then
		if simDR_engine_on[0] == 1 or simDR_engine_on[1] == 1 then
			B738DR_fuel_terminated = 0
			if fuel_tank_finish_arm ~= 0 then
				if fuel_start_tmr == 0 and fuel_end_tmr == 0 then
					fuel_term_tmr = 4
					B738DR_fuel_terminated = 1
				end
			end
			B738DR_hide_fueltruck = 1
			hide_fueltruck = 1
			B738DR_fuel_start = 0
			B738DR_fuel_start2 = 0
			B738DR_fuel_end = 0
			fuel_start = 0
			fuel_end = 0
			fuel_start_tmr = 0
			fuel_end_tmr = 0
			fuel_tank_finish_arm = 0
			fuel_tank_finish = 0
		else
			local left_fuel = simDR_fuel_tank_weight_kg[0]
			local center_fuel = simDR_fuel_tank_weight_kg[1]
			local right_fuel = simDR_fuel_tank_weight_kg[2]
			local wing_fuel = left_fuel + right_fuel
			local total_fuel = left_fuel + center_fuel + right_fuel
			
			if (B738DR_fueltruck_operate == 1.5 and B738DR_int_gnd_services == 0) or (hide_fueltruck == 0 and B738DR_int_gnd_services ~= 0) then
				if fuel_tank_finish ~= 0 then
					if fuel_start_tmr == 0 then
						fuel_start = 0
						B738DR_fuel_start = 0
						B738DR_fuel_start2 = 0
						if fuel_end_tmr == 0 and fuel_end == 0 then
							fuel_end_tmr = 5
							B738DR_fuel_end = 1
						end
					end
				elseif B738DR_req_fuel ~= total_fuel then
					if fuel_end_tmr == 0 and fuel_term_tmr == 0 then
						fuel_end = 0
						B738DR_fuel_end = 0
						if fuel_start_tmr == 0 and fuel_start == 0 then
							fuel_start_tmr = 4
							B738DR_fuel_start = 1
							fuel_tank_finish_arm = 1
						end
					end
				end
				
				if fuel_start ~= 0 then
				
					local wing_tank_kg = temp_wing_tank_kg		--3907
					-- local wing_tank_kg = 3907	--3913.6
					if B738DR_73x == 1 then
						-- 900
						wing_tank_kg = 3907	--3913.6
					elseif B738DR_73x == 2 then
						-- 700
						wing_tank_kg = 3907	--3913.6
					end
					
					local tank1 = math.max(13.65 * SIM_PERIOD, 0.02)
					-- local tank2 = math.max(tank1 * 0.4, 0.02)
					
					if B738DR_refuel_time > 0 then
						tank1 = tank1 * 3
						-- tank2 = tank2 * 3
					end
					
					if B738DR_req_fuel > total_fuel then
						-- add fuel
						if left_fuel < wing_tank_kg or right_fuel < wing_tank_kg then
							total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2] + tank1
							if total_fuel > B738DR_req_fuel then
								tank1 = total_fuel - B738DR_req_fuel
							end
							if left_fuel < right_fuel then
								simDR_fuel_tank_weight_kg[0] = simDR_fuel_tank_weight_kg[0] + tank1
							else
								simDR_fuel_tank_weight_kg[2] = simDR_fuel_tank_weight_kg[2] + tank1
							end
						else
							total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2] + tank1
							if total_fuel > B738DR_req_fuel then
								tank1 = total_fuel - B738DR_req_fuel
							end
							simDR_fuel_tank_weight_kg[1] = simDR_fuel_tank_weight_kg[1] + tank1
						end
						total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2]
						if total_fuel >= B738DR_req_fuel then
							B738DR_req_fuel = 0
							fuel_tank_finish = 1
						end
					elseif B738DR_req_fuel < total_fuel then
						-- sub fuel
						if center_fuel > 0 then
							total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2] - tank1
							if total_fuel < B738DR_req_fuel then
								tank1 = B738DR_req_fuel - total_fuel
							end
							simDR_fuel_tank_weight_kg[1] = math.max(simDR_fuel_tank_weight_kg[1] - tank1, 0)
						elseif left_fuel > 0 or right_fuel > 0 then
							if left_fuel > right_fuel then
								total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2] - tank1
								if total_fuel < B738DR_req_fuel then
									tank1 = B738DR_req_fuel - total_fuel
								end
								simDR_fuel_tank_weight_kg[0] = math.max(simDR_fuel_tank_weight_kg[0] - tank1, 0)
							else
								total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2] - tank1
								if total_fuel < B738DR_req_fuel then
									tank1 = B738DR_req_fuel - total_fuel
								end
								simDR_fuel_tank_weight_kg[2] = math.max(simDR_fuel_tank_weight_kg[2] - tank1, 0)
							end
						end
						total_fuel = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2]
						if total_fuel <= B738DR_req_fuel then
							B738DR_req_fuel = 0
							fuel_tank_finish = 1
						end
					end
					if B738DR_req_fuel == total_fuel then
						B738DR_req_fuel = 0
						fuel_tank_finish = 1
					end
				elseif fuel_end ~= 0 then
					B738DR_hide_fueltruck = 1
					hide_fueltruck = 1
					fuel_tank_finish = 0
					fuel_tank_finish_arm = 0
				end
			end
		end
	else
		B738DR_fuel_terminated = 0
		if fuel_tank_finish_arm ~= 0 then
			if fuel_start_tmr == 0 and fuel_end_tmr == 0 then
				fuel_term_tmr = 4
				B738DR_fuel_terminated = 1
			end
		end
		B738DR_fuel_start = 0
		B738DR_fuel_start2 = 0
		B738DR_fuel_end = 0
		fuel_start = 0
		fuel_end = 0
		fuel_start_tmr = 0
		fuel_end_tmr = 0
		fuel_tank_finish_arm = 0
		fuel_tank_finish = 0
	end
	
	if simDR_radio_height_pilot_ft > 50 then
		if efb_first_time == 0 then
			refuel_enable = 60
		end
		if refuel_enable > 0 then
			refuel_enable = refuel_enable - SIM_PERIOD
			if refuel_enable < 0 then
				refuel_enable = 0
			end
		else
			refuel_enable = 0
		end
	else
		refuel_enable = 1
	end
end

function B738_layout()
	if B738DR_pax_layout == 0 or B738DR_pax_layout == 4 then
		B738DR_layout_0_hide = 0
		B738DR_layout_1_hide = 1
		if B738DR_passengers_hide == 0 then
			B738DR_passengers_0_hide = 0
		else
			B738DR_passengers_0_hide = 1
		end
		B738DR_passengers_1_hide = 1
	elseif B738DR_pax_layout == 5 then
		B738DR_layout_0_hide = 0
		B738DR_layout_1_hide = 1
		B738DR_layout_2_hide = 1
		B738DR_layout_3_hide = 1
		B738DR_layout_4_hide = 1
	elseif B738DR_pax_layout == 6 then
		B738DR_layout_0_hide = 1
		B738DR_layout_1_hide = 0
		B738DR_layout_2_hide = 1
		B738DR_layout_3_hide = 1
		B738DR_layout_4_hide = 1
	elseif B738DR_pax_layout == 7 then
		B738DR_layout_0_hide = 1
		B738DR_layout_1_hide = 1
		B738DR_layout_2_hide = 0
		B738DR_layout_3_hide = 1
		B738DR_layout_4_hide = 1
	elseif B738DR_pax_layout == 8 then
		B738DR_layout_0_hide = 1
		B738DR_layout_1_hide = 1
		B738DR_layout_2_hide = 1
		B738DR_layout_3_hide = 0
		B738DR_layout_4_hide = 1
	elseif B738DR_pax_layout == 9 then
		B738DR_layout_0_hide = 1
		B738DR_layout_1_hide = 1
		B738DR_layout_2_hide = 1
		B738DR_layout_3_hide = 1
		B738DR_layout_4_hide = 0
	else
		B738DR_layout_0_hide = 1
		B738DR_layout_1_hide = 0
		if B738DR_passengers_hide == 0 then
			B738DR_passengers_1_hide = 0
		else
			B738DR_passengers_1_hide = 1
		end
		B738DR_passengers_0_hide = 1
	end
end

function B738_decals()
	B738DR_fuel_pumps_off_show = B738DR_fuel_pumps_off_placard
	-- if B738DR_autoland_install == 0 then
		B738DR_cat3_show = B738DR_cat3_placard
	-- else
		-- B738DR_cat3_show = 0
	-- end
	B738DR_brakes_show = B738DR_brakes_placard
end

function B738_landing_rate()
	local land_rate_show = 0
	local app_rate_show = 0
	
	if B738DR_landing_rating ~= 0 then
		if simDR_aircraft_groundspeed < 30 then	--20
			if land_app_rating_tmr < 5 then
				land_app_rating_tmr = land_app_rating_tmr + SIM_PERIOD
			else
				land_app_rating_tmr = 0
				if land_app_rating == 0 then
					land_app_rating = 1
				else
					land_app_rating = 0
				end
			end
			
			if landing_rating == 0 then
				landing_rating = math.floor(B738DR_landing_rating + 0.5)
			end
			if app_rating == 0 then
				app_rating = math.floor(B738DR_approach_rating + 0.5)
			end
			if B738DR_tab_menu_page == 14 then
				if land_app_rating == 0 then
					land_rate_show = landing_rating
				else
					app_rate_show = app_rating
				end
			end
		end
	else
		landing_rating = 0
		app_rating = 0
	end
	B738DR_landing_rating_show = land_rate_show
	B738DR_approach_rating_show = app_rate_show
	
end

function B738_door_locked()
	
	local door_lock = 0
	local emerg_door_lock = 0
	
	if B738DR_cabin_pressure_diff > 0.2 or B738DR_air_ground_sensor == 0 then
		door_lock = 1
	elseif B738DR_air_ground_sensor == 1 and (simDR_engine_on[0] == 1 or simDR_engine_on[1] == 1) then
		door_lock = 1
	end
	if B738DR_air_ground_sensor == 0 or B738DR_thrust1_leveler > 0.5 or B738DR_thrust2_leveler > 0.5 then
		if simDR_engine_on[0] == 1 or simDR_engine_on[1] == 1 then
			emerg_door_lock = 1
		elseif door_ratio_fwd_L ~= 0 or door_ratio_fwd_R ~= 0 or door_ratio_aft_L ~= 0 or door_ratio_aft_R ~= 0 then
			emerg_door_lock = 1
		end
	end
	door_locked = door_lock
	emerg_door_locked = emerg_door_lock
end


-- --*************************************************************************************--
-- --** 				               XLUA EVENT CALLBACKS       	        			 **--
-- --*************************************************************************************--

-- --function aircraft_load() end

-- --function aircraft_unload() end

function flight_start()
	
	reset_efb()
	B738DR_cl_pos_x = 0
	B738DR_cl_pos_y = 0
	B738DR_cl_pos_z = 0
	B738DR_cl_rot_x = 0
	B738DR_cl_rot_y = 0
	B738DR_tab_adjust_x = 0
	B738DR_tab_adjust_y = 0
	adjust_z2()
	
	B738DR_fo_tab_adjust_x = -21.87
	B738DR_fo_tab_adjust_y = -3.2
	adjust_fo_z2()
	
	B738DR_hud_stow = 1
	
	if simDR_startup_running == 0 then
		if B738DR_engine_no_running_state == 0 then
			B738DR_hide_gpu = 1
			turn_around = 0
		else
			B738DR_hide_gpu = 0
			turn_around = 1
		end
	else
		B738DR_hide_gpu = 1
		turn_around = 1
	end
	if B738DR_hide_gpu == 0 then
		gpu_deployed = 1
	else
		gpu_deployed = 0
	end
	
	B738DR_de_ice_truck_hide = 1
	B738DR_de_ice_truck_act = 0
	de_ice_apply_time = 0
	B738DR_hide_airstairs = 1
	airstair_ratio_tgt = 0
	B738DR_airstair_ratio = 0
	B738DR_hide_fueltruck = 1
	hide_fueltruck = 1
	
	livery_path = simDR_livery
	livery_idx = -1	--simDR_livery_idx
	livery = nocase(livery_path)
	check_livery()
	B738DR_engine_air_n2_rise1 = 1.38
	B738DR_engine_air_n2_rise2 = 1.80
	B738DR_req_fuel = 0	--simDR_total_weight
	zone1_pax = {}
	zone2_pax = {}
	zone3_pax = {}
	zone4_pax = {}
	zone5_pax = {}
	for zxp = 1, 3 do
		zone1_pax[zxp] = 0
		zone2_pax[zxp] = 0
		zone3_pax[zxp] = 0
		zone4_pax[zxp] = 0
		zone5_pax[zxp] = 0
	end
	zone_cargo1 = 0
	zone_cargo2 = 0
	cor_time = 0
	gw_tow_state = 0
	
	perf_arpt = ""
	perf_arpt_old = ""
	perf_rwy = 0
	perf_intx = 0
	perf_cond = "DRY"
	perf_wind_dir = 0
	perf_wind_spd = 0
	perf_oat = 15
	perf_qnh = 1013
	perf_rtg = "OPTIMUM"
	perf_atm = "MAX"
	perf_flap = "5"
	perf_ac = "AUTO"
	perf_ai = "OFF"
	perf_weight = 0
	perf_cg = 0

	perf_head_wind = 0
	perf_cross_wind = 0

	perf_lnd_arpt = ""
	perf_lnd_arpt_old = ""
	perf_lnd_rwy = 0
	perf_lnd_flap = "40"
	perf_lnd_ac = "AUTO"
	perf_lnd_ai = "OFF"
	perf_lnd_brks = "ALL"
	perf_lnd_wind_dir = 0
	perf_lnd_wind_spd = 0
	perf_lnd_oat = 15
	perf_lnd_qnh = 1013
	perf_lnd_weight = 0
	perf_lnd_vref_add = 5
	perf_lnd_cond = "DRY"
	perf_lnd_reverse = "NO CREDIT"

	perf_lnd_head_wind = 0
	perf_lnd_cross_wind = 0

	perf_ref_rwy_num = 0
	perf_ref_rwy_list = {}
	perf_ref_rwy_list_len = {}
	perf_ref_rwy_list_hdg = {}
	perf_ref_rwy_lst_num = 0
	perf_ref_rwy_lst = {}
	perf_ref_rwy_intx_num = {}
	perf_ref_rwy_intx = {}
	perf_des_rwy_num = 0
	perf_des_rwy_list = {}
	perf_des_rwy_list_len = {}
	perf_des_rwy_list_hdg = {}
	
	landing_rating = 0
	app_rating = 0
	land_app_rating_tmr = 0
	
	efb_first_time = 0
	refuel_enable = 0
	
	B738DR_real_cg = 16.67
	--avitab_installed = 1
	door_locked = 0
	emerg_door_locked = 0
	f_time = 0
	fuel_start = 0
	fuel_start_tmr = 0
	fuel_end = 0
	fuel_end_tmr = 0
	fuel_tank_finish_arm = 0
	fuel_tank_finish = 0
	fuel_term_tmr = 0
	B738DR_fuel_start = 0
	B738DR_fuel_start2 = 0
	B738DR_fuel_end = 0
	B738DR_fuel_terminated = 0
	failures_changed = 0
	B738DR_failure_save = 0
	el_failure_mem = {}
	hyd_failure_mem = {}
	sys_failure_mem = {}
	pressurisation_failure_mem = {}
	engine_failure_mem = {}

	failures_changed = 0
	failure_changed = {}

	for ii = 0, 69 do
		el_failure_mem[ii] = 0
		hyd_failure_mem[ii] = 0
		sys_failure_mem[ii] = 0
		pressurisation_failure_mem[ii] = 0
		engine_failure_mem[ii] = 0
		failure_changed[ii] = 0
	end
	
	sam_tick = 0
	was_replay = 0
	
	if loaded_flight == true then
		cat = mem_cat
		page = mem_page
		min_page = mem_min_page
		max_page = mem_max_page
		boot_cnt = 3
		if is_timer_scheduled(boot_timer) == true then
			stop_timer(boot_timer)
		end
		B738DR_autoload_on = 0
		B738DR_tab_boot_active = 0
		B738DR_tab_boot_show[0] = 0
		B738DR_tab_boot_show[1] = 0
		B738DR_tab_boot_show[2] = 0
		B738DR_tab_boot_show[3] = 0
		B738DR_tab_boot_show[4] = 0
		B738DR_tab_menu_page = 0
		B738DR_tab_nav_manip = 1
		B738DR_tab_info_manip = 1
		if B738DR_b737_variant < 0 then
			B738DR_tab_credits = 0
		else
			B738DR_tab_credits = 1
		end
		B738DR_tab_nav2_manip = 1
		for i = 0, 9 do
			B738DR_tab_menu_manip[i] = 1
		end
		if is_timer_scheduled(autoupdate_timer) == false then
			run_at_interval(autoupdate_timer, 1)
		end
		display_update = 1
	end
	loaded_flight = false
	
	auto_flight_enable = false
	auto_after_land = false
	auto_pax_status = 0
	auto_cargo_status = 0
	auto_fuel_status = 0
	auto_pax_tot = 0
	auto_cargo_tot = 0
	auto_req_fuel = 0
	auto_payload_tot = 0
	auto_zfw_tot = 0
	auto_fuel_timer = 0
	auto_pax_timer = 0
	auto_cargo_timer = 0
	auto_catter_status = 0
	auto_catter_timer = 0
	zone1_pax_tgt = 0
	zone2_pax_tgt = 0
	zone3_pax_tgt = 0
	zone4_pax_tgt = 0
	zone5_pax_tgt = 0
	cargo1_tgt = 0
	cargo2_tgt = 0
	B738DR_auto_flight = 0
	B738DR_hide_fwd_stairs = 1
	B738DR_hide_aft_stairs = 1
	B738DR_hide_catering = 1
	B738DR_hide_catering2 = 1
	B738DR_hide_belt = 1
	B738DR_hide_belt2 = 1
	B738DR_hide_pax_bus = 1
	B738DR_hide_pax_bus2 = 1
	B738DR_hide_ambulance = 1
	B738DR_hide_firestriker = 1
	B738DR_hide_firestriker2 = 1
	fireservice_state1 = 0
	fireservice_tmr1 = 0
	fireservice_state2 = 0
	fireservice_tmr2 = 0
	
	ref_icao_old = ""
	jbr_find_rwy_timer = 0
	perf_takeoff_err = 0
	
	perf_takeoff_windshear = 0
	perf_takeoff_full_valid = 0
	perf_takeoff_full_rating = 0
	perf_takeoff_full_n1 = 0
	perf_takeoff_full_v1 = 0
	perf_takeoff_full_vr = 0
	perf_takeoff_full_v2 = 0

	perf_takeoff_atm_valid = 0
	perf_takeoff_atm_rating = 0
	perf_takeoff_atm_seltemp = 0
	perf_takeoff_atm_n1 = 0
	perf_takeoff_atm_v1 = 0
	perf_takeoff_atm_vr = 0
	perf_takeoff_atm_v2 = 0

	perf_takeoff_max_wt = 0
	perf_takeoff_vref40 = 0
	perf_takeoff_flaps = 0
	perf_takeoff_trim = 0
	
	perf_takeoff_rating = 0
	perf_takeoff_seltemp = 0
	perf_takeoff_n1 = 0
	perf_takeoff_v1 = 0
	perf_takeoff_vr = 0
	perf_takeoff_v2 = 0
	
	perf_takeoff_full = 0
end

function load_view()
	local aa = 0
	local bb = 0
	local file_ext = io.open(file_path .. "b738.acf", "r")
	local file_line = ""
	if file_ext ~= nil then
		file_line = file_ext:read()
		while file_line do
			aa = string.len(file_line)
			if aa > 33 then
				if string.sub(file_line, 1, 33) == "P acf/_cockpit_planned_vanish_y/0" then
					bb = tonumber(string.sub(file_line, 34, -1))
					break
				end
			end
			file_line = file_ext:read()
		end
		file_ext:close()
		if bb ~= nil then
			if bb ~= 0 then
				if bb ~= B738DR_vanish_y then
					if B738DR_vanish_y == 0 then
						B738DR_vanish_y = bb
					else
						view()
					end
				end
			end
		end
	end
end

function view()
	
	local aa = 0
	local bb = 0
	local cc = 0
	local file_ext = io.open(file_path .. "b738.acf", "r")
	raw_table('file_in')
	local file_in = {}
	local file_in_num = 0
	local file_line = ""
	if file_ext ~= nil then
		file_line = file_ext:read()
		while file_line do
			aa = string.len(file_line)
			bb = 0
			if aa > 33 then
				if string.sub(file_line, 1, 33) == "P acf/_cockpit_planned_vanish_y/0" then
					bb = tonumber(string.sub(file_line, 34, -1))
					if bb == nil then
						bb = 0
					elseif bb ~= B738DR_vanish_y then
						cc = 1
						bb = 1
					end
				end
			end
			file_in_num = file_in_num + 1
			if bb == 0 then
				file_in[file_in_num] = file_line
			else
				file_in[file_in_num] = "P acf/_cockpit_planned_vanish_y/0 " .. string.format("%5.1f", B738DR_vanish_y)
			end
			file_line = file_ext:read()
		end
		file_ext:close()
		if file_in_num > 0 and cc ~= 0 then
			file_ext = io.open(file_path .. "b738.acf", "w")
			if file_ext ~= nil then
				for aa = 1, file_in_num do
					file_ext:write(file_in[aa] .. "\n")
				end
				file_ext:write("\n")
				file_ext:close()
			end
			file_ext = io.open(file_path .. "b738_4k.acf", "w")
			if file_ext ~= nil then
				for aa = 1, file_in_num do
					file_ext:write(file_in[aa] .. "\n")
				end
				file_ext:write("\n")
				file_ext:close()
			end
			vanish_y_status = 1
		end
	end
end

function B738_max_fuel()
	local temp_coef = 0
	local delta_temp = 0
	
	if B738DR_fuel_temp_real < 15 then
		delta_temp = 15 - B738DR_fuel_temp_real
		temp_coef = 1 + (delta_temp * 0.00092)
	else
		delta_temp = B738DR_fuel_temp_real - 15
		temp_coef = 1 - (delta_temp * 0.00092)
	end
	temp_wing_tank_kg = 3905 * temp_coef
	temp_max_fuel_kg = 20828 * temp_coef
	
	B738DR_temp_left_tank = (simDR_fuel_tank_weight_kg[0] / temp_wing_tank_kg) * 100
	B738DR_temp_right_tank = (simDR_fuel_tank_weight_kg[2] / temp_wing_tank_kg) * 100
	B738DR_temp_center_tank = (simDR_fuel_tank_weight_kg[1] / (temp_max_fuel_kg - (2 * temp_wing_tank_kg))) * 100
end

function B738_auto_flight()
	local num_tmp = 0
	local num_tmp2 = 0
	local num_tmp3 = 0
	
	local int, frac = math.modf(os.clock())
	local seed = math.random(1, frac*1000.0)
	math.randomseed(seed)
	
	local gen_rand = false
	local cargo_load_const = 0
	local pax_load_const = 0
	local pax_load_time = 0
	local pax_start_time = 0
	
	if simDR_radio_height_pilot_ft > 100 then
		auto_after_land = true
	end
	
	if B738DR_auto_flight == 1 then
		if B738DR_no_smoking_pos == 0 then
			no_smoke_cycle = true
		else
			no_smoke_cycle = false
		end
	elseif B738DR_auto_flight > 1 then
		if B738DR_no_smoking_pos == 0 then
			no_smoke_cycle = true
		end
	end
	
	if B738DR_auto_flight == 0 then
		auto_flight_enable = false
		if simDR_on_ground[0] == 1 and simDR_on_ground[1] == 1 and simDR_on_ground[2] == 1 then
			if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 then
				if auto_req_fuel ~= 0 then
					auto_flight_enable = true
					auto_pax_status = 0
					auto_cargo_status = 0
					auto_fuel_status = 0
					auto_catter_status = 0
				end
			end
		end
	else
		
		if B738DR_pax_time == 0 then
			pax_load_const = 3
			pax_start_time = 40
		elseif B738DR_pax_time == 1 then
			pax_load_const = 1.5
			pax_start_time = 20
		else
			pax_load_const = 0.1
			pax_start_time = 20
		end
		
		if B738DR_cargo_time == 0 then
			cargo_load_const = 10
		elseif B738DR_cargo_time == 1 then
			cargo_load_const = 60
		else
			cargo_load_const = 300
		end
		
		if door_ratio_fwd_R_trg == 1 or door_ratio_fwd_R ~= 0 or call_catering == true then
			catering_operate_tmr = 4
		end
		
		if door_ratio_aft_R_trg == 1 or door_ratio_aft_R ~= 0  or call_catering2 == true then
			catering2_operate_tmr = 4
		end
		
		if catering_operate_tmr == 0 then
			B738DR_hide_catering = 1
		end
		
		if catering2_operate_tmr == 0 then
			B738DR_hide_catering2 = 1
		end
		
		if door_ratio_fwd_cargo_trg == 1 or door_ratio_fwd_cargo ~= 0 then
			belt_operate_tmr = 4
		end
		
		if door_ratio_aft_cargo_trg == 1 or door_ratio_aft_cargo ~= 0 then
			belt2_operate_tmr = 4
		end
		
		if belt_operate_tmr == 0 then
			B738DR_hide_belt = 1
		end
		
		if belt2_operate_tmr == 0 then
			B738DR_hide_belt2 = 1
		end
		
		auto_flight_enable = true
		if B738DR_auto_flight == 1 then
			B738DR_req_fuel = auto_req_fuel
			
			if B738DR_cargo_time == 0 then
				auto_fuel_timer = 35
				auto_cargo_timer = 55
			elseif B738DR_cargo_time == 1 then
				auto_fuel_timer = 15
				auto_cargo_timer = 35
			else
				auto_fuel_timer = 5
				auto_cargo_timer = 10
			end
			
			if turn_around ~= 0 then
				auto_catter_timer = 0
				auto_catter_status = 4
				door_ratio_fwd_R_trg = 0
				door_ratio_aft_R_trg = 0
				call_catering = false
				call_catering2 = false
			elseif B738DR_catering_time == 0 then
				auto_catter_timer = 35
			elseif B738DR_catering_time == 0 then
				auto_catter_timer = 25
			else
				auto_catter_timer = 10
			end
			
			auto_pax_timer = pax_start_time
			
			if start_leg ~= 0 then
				B738_end_leg:once()
			end
			if play_cargo ~= 0 then
				B738CMD_play_cargo:once()
			end
			B738CMD_open_fdd:once()
			if B738DR_jetway_nearest <= 0.05 then
				B738CMD_jetways_toggle:once()
			elseif B738DR_not_airstairs == 0 then
				B738DR_hide_airstairs = 0
			elseif B738DR_int_gnd_services == 0 then
				B738DR_hide_fwd_stairs = 0
			end
			B738DR_auto_flight = 2
		elseif B738DR_auto_flight == 2 then
			if auto_cargo_timer <= 0 then
				if auto_cargo_status == 0 then
					if cargo1_tgt ~= zone_cargo1 then
						door_ratio_fwd_cargo_trg = 1
					end
					if cargo2_tgt ~= zone_cargo2 then
						door_ratio_aft_cargo_trg = 1
					end
					door_ratio_fwd_L_trg = 1
					if door_ratio_fwd_L == 1 or door_ratio_aft_L == 1 then
						if play_cargo == 0 then
							B738CMD_play_cargo:once()
						end
						auto_cargo_status = 1
						auto_cargo_timer = 10	--5
					end
					if door_ratio_fwd_cargo_trg ~= 0 then
						if B738DR_int_gnd_services == 0 then
							B738DR_hide_belt = 0
						end
					end
					if door_ratio_aft_cargo_trg ~= 0 then
						if B738DR_int_gnd_services == 0 then
							B738DR_hide_belt2 = 0
						end
					end
				elseif auto_cargo_status == 1 then
					auto_cargo_status = 2
				end
			else
				auto_cargo_timer = auto_cargo_timer - SIM_PERIOD
			end
			
			if auto_cargo_status == 2 then
				-- loading cargo
				if zone_cargo1 ~= cargo1_tgt or zone_cargo2 ~= cargo2_tgt then
					if zone_cargo1 < cargo1_tgt then
						num_tmp = zone_cargo1 + cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
						if num_tmp > cargo1_tgt then
							zone_cargo1 = cargo1_tgt
						else
							zone_cargo1 = num_tmp
						end
						update_payload()
					elseif zone_cargo1 > cargo1_tgt then
						num_tmp = zone_cargo1 - cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
						if num_tmp < cargo1_tgt then
							zone_cargo1 = cargo1_tgt
						else
							zone_cargo1 = num_tmp
						end
						update_payload()
					end
					if zone_cargo2 < cargo2_tgt then
						num_tmp = zone_cargo2 + cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
						if num_tmp > cargo2_tgt then
							zone_cargo2 = cargo2_tgt
						else
							zone_cargo2 = num_tmp
						end
						update_payload()
					elseif zone_cargo2 > cargo2_tgt then
						num_tmp = zone_cargo2 - cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
						if num_tmp < cargo2_tgt then
							zone_cargo2 = cargo2_tgt
						else
							zone_cargo2 = num_tmp
						end
						update_payload()
					end
					if zone_cargo1 == cargo1_tgt and zone_cargo2 == cargo2_tgt then
						-- after finish
						auto_cargo_status = 4
						-- door_ratio_fwd_cargo_trg = 0
						-- door_ratio_aft_cargo_trg = 0
					end
					if zone_cargo1 == cargo1_tgt then
						door_ratio_fwd_cargo_trg = 0
					end
					if zone_cargo2 == cargo2_tgt then
						door_ratio_aft_cargo_trg = 0
					end
				else
					-- after finish
					auto_cargo_status = 3
					door_ratio_fwd_cargo_trg = 0
					door_ratio_aft_cargo_trg = 0
				end
			end
			
			if auto_fuel_timer <= 0 then
				if auto_fuel_status == 0 then
					num_tmp = simDR_fuel_tank_weight_kg[0] + simDR_fuel_tank_weight_kg[1] + simDR_fuel_tank_weight_kg[2]
					if B738DR_req_fuel ~= num_tmp then
						-- if B738DR_hide_fueltruck ~= 0 then
						if hide_fueltruck ~= 0 then
							cmd_pay_perf(5)
						end
						auto_fuel_status = 1
					else
						B738DR_req_fuel = 0
						B738DR_hide_fueltruck = 1
						hide_fueltruck = 1
						auto_fuel_status = 3
					end
				end
			else
				auto_fuel_timer = auto_fuel_timer - SIM_PERIOD
			end
			
			if auto_catter_status < 4 then
				if auto_catter_timer <= 0 then
					if auto_catter_status == 0 then
						if B738DR_int_gnd_services == 0 then
							call_catering = true
							call_catering2 = true
							 B738DR_hide_catering = 0
							 B738DR_hide_catering2 = 0
							if B738DR_catering_operate > 1.6 then
								door_ratio_fwd_R_trg = 1
							end
							if B738DR_catering2_operate > 1.6 then
								door_ratio_aft_R_trg = 1
							end
						else
							door_ratio_fwd_R_trg = 1
							door_ratio_aft_R_trg = 1
						end
						if door_ratio_fwd_R == 1 or door_ratio_aft_R == 1 then
							if play_cargo == 0 then
								B738CMD_play_cargo:once()
							end
							auto_catter_status = 1
							auto_catter_timer = 5
						end
					elseif auto_catter_status == 1 then
						auto_catter_status = 2
						if turn_around ~= 0 then
							auto_catter_timer = 15
						elseif B738DR_catering_time == 0 then
							auto_catter_timer = 120
						elseif B738DR_catering_time == 0 then
							auto_catter_timer = 60
						else
							auto_catter_timer = 15
						end
					elseif auto_catter_status == 2 then
						door_ratio_fwd_R_trg = 0
						door_ratio_aft_R_trg = 0
						call_catering = false
						call_catering2 = false
						if door_ratio_fwd_R == 0 and door_ratio_aft_R == 0 then
							auto_catter_timer = 10
							auto_catter_status = 3
						end
					elseif auto_catter_status == 3 then
						auto_catter_status = 4
					end
				else
					auto_catter_timer = auto_catter_timer - SIM_PERIOD
				end
			end
			
			if auto_catter_status > 3 then
				
				if auto_pax_timer > pax_start_time then
					auto_pax_timer = pax_start_time
				end
				if auto_pax_timer <= 0 then
					if auto_pax_status == 0 then
						if play_cargo ~= 0 then
							B738CMD_play_cargo:once()
						end
						if (B738DR_no_smoking_pos ~= 0 and no_smoke_cycle == true) or B738DR_no_smoking > 1 then
							auto_pax_status = 1
							auto_pax_timer = 10
						end
					elseif auto_pax_status == 1 then
						if start_leg == 0 then
							B738_start_leg:once()
						end
						door_ratio_fwd_L_trg = 1
						if B738DR_jetway_nearest > 0.05 then
							door_ratio_aft_L_trg = 1
							-- if B738DR_int_gnd_services == 0 then
								-- B738DR_hide_aft_stairs = 0
							-- end
						end
						if B738DR_int_gnd_services == 0 then
							B738DR_hide_aft_stairs = 0
						end
						auto_pax_status = 2
					elseif auto_pax_status == 2 then
						if door_ratio_fwd_L == 1 or door_ratio_aft_L == 1 then
							if zone1_pax_tgt == zone1_pax[1] and zone2_pax_tgt == zone2_pax[1] and zone3_pax_tgt == zone3_pax[1] and zone4_pax_tgt == zone4_pax[1] and zone5_pax_tgt == zone5_pax[1] then
								auto_pax_status = 3
								auto_pax_timer = 5
							else
								if B738DR_int_gnd_services == 0 and B738DR_jetway_nearest > 0.05 then
									if door_ratio_fwd_L == 1 then
										B738DR_hide_pax_bus = 0
									end
									if door_ratio_aft_L == 1 then
										B738DR_hide_pax_bus2 = 0
									end
								end
								if B738DR_pax_bus_operate >= 4.49 or B738DR_pax_bus2_operate >= 1.67 or (B738DR_hide_pax_bus ~= 0 and B738DR_hide_pax_bus2 ~= 0) then
									gen_rand = true
									while gen_rand == true do
										num_tmp = math.floor(math.random(0, 4) + 0.5)
										if num_tmp == 0 then
											if zone1_pax_tgt ~= zone1_pax[1] then
												pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
												break
											end
										elseif num_tmp == 1 then
											if zone2_pax_tgt ~= zone2_pax[1] then
												pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
												break
											end
										elseif num_tmp == 2 then
											if zone3_pax_tgt ~= zone3_pax[1] then
												pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
												break
											end
										elseif num_tmp == 3 then
											if zone4_pax_tgt ~= zone4_pax[1] then
												pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
												break
											end
										elseif num_tmp == 4 then
											if zone5_pax_tgt ~= zone5_pax[1] then
												pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
												break
											end
										end
									end
									
									if num_tmp == 0 then
										if zone1_pax_tgt < zone1_pax[1] then
											zone1_pax[1] = zone1_pax[1] - 1
										elseif zone1_pax_tgt > zone1_pax[1] then
											zone1_pax[1] = zone1_pax[1] + 1
										end
									elseif num_tmp == 1 then
										if zone2_pax_tgt < zone2_pax[1] then
											zone2_pax[1] = zone2_pax[1] - 1
										elseif zone2_pax_tgt > zone2_pax[1] then
											zone2_pax[1] = zone2_pax[1] + 1
										end
									elseif num_tmp == 2 then
										if zone3_pax_tgt < zone3_pax[1] then
											zone3_pax[1] = zone3_pax[1] - 1
										elseif zone3_pax_tgt > zone3_pax[1] then
											zone3_pax[1] = zone3_pax[1] + 1
										end
									elseif num_tmp == 3 then
										if zone4_pax_tgt < zone4_pax[1] then
											zone4_pax[1] = zone4_pax[1] - 1
										elseif zone4_pax_tgt > zone4_pax[1] then
											zone4_pax[1] = zone4_pax[1] + 1
										end
									elseif num_tmp == 4 then
										if zone5_pax_tgt < zone5_pax[1] then
											zone5_pax[1] = zone5_pax[1] - 1
										elseif zone5_pax_tgt > zone5_pax[1] then
											zone5_pax[1] = zone5_pax[1] + 1
										end
									end
									auto_pax_timer = pax_load_time
									update_payload()
								end
							end
						end
					elseif auto_pax_status == 3 then
						if auto_cargo_status > 2 then
							door_ratio_fwd_L_trg = 0
							door_ratio_aft_L_trg = 0
							auto_pax_status = 4
						end
					elseif auto_pax_status == 4 then
						if door_ratio_fwd_L == 0 and door_ratio_aft_L == 0 then
							if B738DR_jetway_nearest <= 0.05 then
								B738CMD_jetways_toggle:once()
							elseif B738DR_not_airstairs == 0 then
								B738DR_hide_airstairs = 1
							end
							B738DR_hide_fwd_stairs = 1
							B738DR_hide_aft_stairs = 1
							B738DR_hide_pax_bus = 1
							B738DR_hide_pax_bus2 = 1
							auto_pax_status = 5
						end
					end
				else
					auto_pax_timer = auto_pax_timer - SIM_PERIOD
				end
			end
			
			if B738DR_req_fuel == 0 and auto_cargo_status > 2 and auto_pax_status > 4 then
				auto_fuel_status = 3
				B738DR_auto_flight = 3
			end
		elseif B738DR_auto_flight == 3 then
			if auto_after_land == true then
				if simDR_on_ground[0] == 1 and simDR_on_ground[1] == 1 and simDR_on_ground[2] == 1 then
					if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 then
						if B738DR_parking_brake_pos ~= 0 or B738DR_chock_status ~= 0 then
							if simDR_beacon_lights_on == 0 then
								B738DR_auto_flight = 4
								auto_pax_timer = 10
							end
						end
					end
				end
			end
		elseif B738DR_auto_flight == 4 then
			if auto_pax_timer <= 0 then
				if B738DR_jetway_nearest <= 0.05 then
					B738CMD_jetways_toggle:once()
				elseif B738DR_not_airstairs == 0 then
					B738DR_hide_airstairs = 0
				else
					B738DR_hide_fwd_stairs = 0
				end
				auto_pax_timer = 20
				if zone_cargo1 ~= 0 then
					door_ratio_fwd_cargo_trg = 1
					if B738DR_int_gnd_services == 0 then
						B738DR_hide_belt = 0
					end
				end
				if zone_cargo2 ~= 0 then
					door_ratio_aft_cargo_trg = 1
					if B738DR_int_gnd_services == 0 then
						B738DR_hide_belt2 = 0
					end
				end
				B738DR_auto_flight = 5
			else
				auto_pax_timer = auto_pax_timer - SIM_PERIOD
			end
		elseif B738DR_auto_flight == 5 then
			if auto_pax_timer <= 0 then
				door_ratio_fwd_L_trg = 1
				if B738DR_jetway_nearest > 0.05 then
					door_ratio_aft_L_trg = 1
					if B738DR_int_gnd_services == 0 then
						B738DR_hide_aft_stairs = 0
						B738DR_hide_pax_bus = 0
						B738DR_hide_pax_bus2 = 0
					end
				end
				B738DR_auto_flight = 6
			else
				auto_pax_timer = auto_pax_timer - SIM_PERIOD
			end
		elseif B738DR_auto_flight == 6 then
			if door_ratio_fwd_L == 1 or door_ratio_aft_L == 1 then
				-- if start_leg ~= 0 then
					-- B738_end_leg:once()
				-- end
				auto_pax_timer = 2
				B738DR_auto_flight = 7
			end
		elseif B738DR_auto_flight == 7 then
			if zone_cargo1 ~= 0 or zone_cargo2 ~= 0 then
				if zone_cargo1 > 0 then
					num_tmp = zone_cargo1 - cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
					if num_tmp < 0 then
						zone_cargo1 = 0
					else
						zone_cargo1 = num_tmp
					end
					update_payload()
				end
				if zone_cargo2 > 0 then
					num_tmp = zone_cargo2 - cargo_load_const * (1 + (math.random(0, 4) / 10)) * SIM_PERIOD
					if num_tmp < 0 then
						zone_cargo2 = 0
					else
						zone_cargo2 = num_tmp
					end
					update_payload()
				end
			end
			if B738DR_pax_bus_operate >= 4.49 or B738DR_pax_bus2_operate >= 1.67 or (B738DR_hide_pax_bus ~= 0 and B738DR_hide_pax_bus2 ~= 0) then
				if auto_pax_timer <= 0 then
					if zone1_pax[1] > 0 or zone2_pax[1] > 0 or zone3_pax[1] > 0 or zone4_pax[1] > 0 or zone5_pax[1] > 0 then
						gen_rand = true
						while gen_rand == true do
							num_tmp = math.floor(math.random(0, 4) + 0.5)
							if num_tmp == 0 then
								if zone1_pax[1] > 0 then
									pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
									break
								end
							elseif num_tmp == 1 then
								if zone2_pax[1] > 0 then
									pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
									break
								end
							elseif num_tmp == 2 then
								if zone3_pax[1] > 0 then
									pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
									break
								end
							elseif num_tmp == 3 then
								if zone4_pax[1] > 0 then
									pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
									break
								end
							elseif num_tmp == 4 then
								if zone5_pax[1] > 0 then
									pax_load_time = pax_load_const * (1 + (math.random(0, 4) / 10))
									break
								end
							end
						end
						
						if num_tmp == 0 then
							if zone1_pax[1] > 0 then
								zone1_pax[1] = zone1_pax[1] - 1
							end
						elseif num_tmp == 1 then
							if zone2_pax[1] > 0 then
								zone2_pax[1] = zone2_pax[1] - 1
							end
						elseif num_tmp == 2 then
							if zone3_pax[1] > 0 then
								zone3_pax[1] = zone3_pax[1] - 1
							end
						elseif num_tmp == 3 then
							if zone4_pax[1] > 0 then
								zone4_pax[1] = zone4_pax[1] - 1
							end
						elseif num_tmp == 4 then
							if zone5_pax[1] > 0 then
								zone5_pax[1] = zone5_pax[1] - 1
							end
						end
						auto_pax_timer = pax_load_time
						update_payload()
					end
				else
					auto_pax_timer = auto_pax_timer - SIM_PERIOD
				end
			end
			
			if zone_cargo1 == 0 then
				door_ratio_fwd_cargo_trg = 0
			end
			
			if zone_cargo2 == 0 then
				door_ratio_aft_cargo_trg = 0
			end
			
			if zone_cargo1 == 0 and zone_cargo2 == 0 then
				if zone1_pax[1] == 0 and zone2_pax[1] == 0 and zone3_pax[1] == 0 and zone4_pax[1] == 0 and zone5_pax[1] == 0 then
					B738DR_auto_flight = 0
					B738DR_gp_cable_connect = gp_cable_connect
					
					if start_leg ~= 0 then
						B738_end_leg:once()
					end
					if play_cargo ~= 0 then
						B738CMD_play_cargo:once()
					end
					
					door_ratio_aft_L_trg = 0
				end
			end
		end
	end
	
	if B738DR_int_gnd_services ~= 0 then
		B738DR_hide_fwd_stairs = 1
		B738DR_hide_aft_stairs = 1
		B738DR_hide_catering = 1
		B738DR_hide_catering2 = 1
		catering_operate_tmr = 0
		catering2_operate_tmr = 0
		B738DR_hide_belt = 1
		B738DR_hide_belt2 = 1
		belt_operate_tmr = 0
		belt2_operate_tmr = 0
		B738DR_hide_pax_bus = 1
		B738DR_hide_pax_bus2 = 1
		call_catering = false
		call_catering2 = false
		B738DR_hide_fueltruck = 1
	elseif B738DR_auto_flight == 0 then
		if B738DR_hide_airstairs ~= 0 and B738DR_jetway_nearest > 0.05 then
			if door_ratio_fwd_L == 0 then
				B738DR_hide_fwd_stairs = 1
			elseif door_ratio_fwd_L_trg == 1 or door_ratio_fwd_L ~= 0 then
				B738DR_hide_fwd_stairs = 0
			end
		else
			B738DR_hide_fwd_stairs = 1
		end
		if door_ratio_aft_L == 0 then
			B738DR_hide_aft_stairs = 1
		elseif door_ratio_aft_L_trg == 1 or door_ratio_aft_L ~= 0 then
			B738DR_hide_aft_stairs = 0
		end
		
		if B738DR_jetway_nearest > 0.05 then
			if (door_ratio_fwd_L ~= 0 or door_ratio_fwd_L_trg == 1) and (door_ratio_aft_L ~= 0 or door_ratio_aft_L_trg == 1) then
				B738DR_hide_pax_bus = 0
				B738DR_hide_pax_bus2 = 0
			else
				B738DR_hide_pax_bus = 1
				B738DR_hide_pax_bus2 = 1
			end
		else
			B738DR_hide_pax_bus = 1
			B738DR_hide_pax_bus2 = 1
		end
		
		if door_ratio_fwd_R == 0 then
			if catering_operate_tmr == 0 then
				B738DR_hide_catering = 1
			end
		elseif door_ratio_fwd_R_trg == 1 or door_ratio_fwd_R ~= 0 then
			if B738DR_int_gnd_services == 0 then
				B738DR_hide_catering = 0
			end
		end
		if door_ratio_aft_R == 0 then
			if catering2_operate_tmr == 0 then
				B738DR_hide_catering2 = 1
			end
		elseif door_ratio_aft_R_trg == 1 or door_ratio_aft_R ~= 0 then
			if B738DR_int_gnd_services == 0 then
				B738DR_hide_catering2 = 0
			end
		end
		
		if door_ratio_fwd_R_trg == 1 or door_ratio_fwd_R ~= 0 then
			catering_operate_tmr = 4
		end
		
		if door_ratio_aft_R_trg == 1 or door_ratio_aft_R ~= 0 then
			catering2_operate_tmr = 4
		end
		
		
		if door_ratio_fwd_cargo == 0 then
			if belt_operate_tmr == 0 then
				B738DR_hide_belt = 1
			end
		elseif door_ratio_fwd_cargo_trg == 1 or door_ratio_fwd_cargo ~= 0 then
			B738DR_hide_belt = 0
		end
		if door_ratio_aft_cargo == 0 then
			if belt2_operate_tmr == 0 then
				B738DR_hide_belt2 = 1
			end
		elseif door_ratio_aft_cargo_trg == 1 or door_ratio_aft_cargo ~= 0 then
			B738DR_hide_belt2 = 0
		end
		
		if door_ratio_fwd_cargo_trg == 1 or door_ratio_fwd_cargo ~= 0 then
			belt_operate_tmr = 4
		end
		
		if door_ratio_aft_cargo_trg == 1 or door_ratio_aft_cargo ~= 0 then
			belt2_operate_tmr = 4
		end
		call_catering = false
		call_catering2 = false
	end
	
	if catering_operate_tmr ~= 0 then
		catering_operate_tmr = catering_operate_tmr - SIM_PERIOD
		if catering_operate_tmr < 0 then
			catering_operate_tmr = 0
		end
	end
	
	if belt_operate_tmr ~= 0 then
		belt_operate_tmr = belt_operate_tmr - SIM_PERIOD
		if belt_operate_tmr < 0 then
			belt_operate_tmr = 0
		end
	end
	
	if catering2_operate_tmr ~= 0 then
		catering2_operate_tmr = catering2_operate_tmr - SIM_PERIOD
		if catering2_operate_tmr < 0 then
			catering2_operate_tmr = 0
		end
	end
	
	if belt2_operate_tmr ~= 0 then
		belt2_operate_tmr = belt2_operate_tmr - SIM_PERIOD
		if belt2_operate_tmr < 0 then
			belt2_operate_tmr = 0
		end
	end
end


-- --function flight_crash() end

function before_physics()
	if avitab_installed == 1 and avitab_ctrl_override == 0 then
		if avitab_menu == 1 then
			avitab_enabled = 0
			if cat == CAT_AVITAB_ACT then
				cat = CAT_AVITAB
				display_update = 1
			end
		end
	end
	if B738DR_ui_manip ~= 0 then
		B738DR_tab_arrows_enable = 0
	else
		if B738DR_failure_save == 0 then
			if min_page == max_page then
				B738DR_tab_arrows_enable = 0
			else
				B738DR_tab_arrows_enable = 1
			end
		else
			B738DR_tab_arrows_enable = 0
		end
	end
	if B738DR_led_lights == 0 then
		B738DR_kill_led_lights = 1
	else
		B738DR_kill_led_lights = 0
	end
	
end

function load_save(in_mode)
	raw_table('glare')
	local glare = {}
	local ggg = 0
	-- local zxp = 0
	
	if B738DR_load_save == 3 or B738DR_load_save == 4 then
		if in_mode == 0 then
			for ggg = 1, 100 do
				glare[ggg] = B738DR_efb[ggg-1]
			end
			ggg = 1
			for zxp = 1, 3 do
				zone1_pax[zxp] = glare[ggg]
				ggg = ggg + 1
				zone2_pax[zxp] = glare[ggg]
				ggg = ggg + 1
				zone3_pax[zxp] = glare[ggg]
				ggg = ggg + 1
				zone4_pax[zxp] = glare[ggg]
				ggg = ggg + 1
				zone5_pax[zxp] = glare[ggg]
				ggg = ggg + 1
			end
			zone_cargo1 = glare[16]
			zone_cargo2 = glare[17]
			
			for zxp = 1, 3 do
				B738DR_zone1_payload[zxp-1] = zone1_pax[zxp]
				B738DR_zone2_payload[zxp-1] = zone2_pax[zxp]
				B738DR_zone3_payload[zxp-1] = zone3_pax[zxp]
				B738DR_zone4_payload[zxp-1] = zone4_pax[zxp]
				B738DR_zone5_payload[zxp-1] = zone5_pax[zxp]
			end
			fill_zone_weight()
			
			B738DR_zone_cargo1_payload = zone_cargo1
			B738DR_zone_cargo2_payload = zone_cargo2
			
			-- B738DR_hide_fueltruck = glare[18]
			hide_fueltruck = glare[18]
			if B738DR_int_gnd_services == 0 and hide_fueltruck == 0 then
				B738DR_hide_fueltruck = 0
			else
				B738DR_hide_fueltruck = 1
			end
			B738DR_req_fuel = glare[19]
			B738DR_de_ice_truck_hide = glare[20]
			B738DR_de_ice_truck_act = glare[21]
			de_ice_apply_time = glare[22]
			door_ratio_fwd_L = glare[23]
			door_ratio_fwd_R = glare[24]
			door_ratio_aft_L = glare[25]
			door_ratio_aft_L = glare[26]
			door_ratio_fwd_cargo = glare[27]
			door_ratio_aft_cargo = glare[28]
			door_ratio_emerg1 = glare[29]
			door_ratio_emerg2 = glare[30]
			door_ratio_emerg3 = glare[31]
			door_ratio_emerg4 = glare[32]
			door_ratio_fwd_L_trg = glare[33]
			door_ratio_fwd_R_trg = glare[34]
			door_ratio_aft_L_trg = glare[35]
			door_ratio_aft_R_trg = glare[36]
			door_ratio_fwd_cargo_trg = glare[37]
			door_ratio_aft_cargo_trg = glare[38]
			door_ratio_emerg1_trg = glare[39]
			door_ratio_emerg2_trg = glare[40]
			door_ratio_emerg3_trg = glare[41]
			door_ratio_emerg4_trg = glare[42]
			refuel_enable = glare[43]
			door_ratio_aft1 = glare[44]
			door_ratio_aft2 = glare[45]
			req_payload_weight = glare[46]
			
			B738DR_auto_flight = glare[47]
			auto_pax_tot = glare[48]
			auto_cargo_tot = glare[49]
			auto_zfw_tot = glare[50]
			auto_payload_tot = glare[51]
			auto_req_fuel = glare[52]
			
			auto_fuel_status = glare[53]
			auto_catter_status = glare[54]
			auto_cargo_status = glare[55]
			auto_pax_status = glare[56]
			
			auto_fuel_timer = glare[57]
			auto_pax_timer = glare[58]
			auto_cargo_timer = glare[59]
			auto_catter_timer = glare[60]
			zone1_pax_tgt = glare[61]
			zone2_pax_tgt = glare[62]
			zone3_pax_tgt = glare[63]
			zone4_pax_tgt = glare[64]
			zone5_pax_tgt = glare[65]
			cargo1_tgt = glare[66]
			cargo2_tgt = glare[67]
			
			B738DR_hide_fwd_stairs = glare[68]
			B738DR_hide_aft_stairs = glare[69]
			B738DR_hide_catering = glare[70]
			B738DR_hide_catering2 = glare[71]
			B738DR_hide_belt = glare[72]
			B738DR_hide_belt2 = glare[73]
			B738DR_hide_pax_bus = glare[74]
			B738DR_hide_pax_bus2 = glare[75]
			
			if glare[76] == 0 then
				no_smoke_cycle = false
			else
				no_smoke_cycle = true
			end
			if glare[77] == 0 then
				auto_flight_enable = false
			else
				auto_flight_enable = true
			end
			if glare[78] == 0 then
				auto_after_land = false
			else
				auto_after_land = true
			end
			
			catering_operate_tmr = glare[79]
			belt_operate_tmr = glare[80]
			catering2_operate_tmr = glare[81]
			belt2_operate_tmr = glare[82]
			
			if glare[83] == 0 then
				call_catering = false
			else
				call_catering = true
			end
			if glare[84] == 0 then
				call_catering2 = false
			else
				call_catering2 = true
			end
			
			if glare[85] ~= 0 and start_leg == 0 then
				B738_start_leg:once()
			elseif glare[85] == 0 and start_leg ~= 0 then
				B738_end_leg:once()
			end
			
			if glare[86] ~= 0 and play_cargo == 0 then
				B738CMD_play_cargo:once()
			elseif glare[86] == 0 and play_cargo ~= 0 then
				B738CMD_play_cargo:once()
			end
			
			landing_rating = 0
			app_rating = 0
			land_app_rating_tmr = 0
			display_update = 1
			efb_first_time = 0
			
			cargo1_weight_req = glare[87]
			cargo2_weight_req = glare[88]
			zone_weight_req[1] = glare[89]
			zone_weight_req[2] = glare[90]
			zone_weight_req[3] = glare[91]
			zone_weight_req[4] = glare[92]
			zone_weight_req[5] = glare[93]
			crew_weight_f_req = glare[94]
			crew_weight_r_req = glare[95]
		end
	elseif in_mode ~= 0 then
		for ggg = 1, 100 do
			glare[ggg] = 0
		end
		ggg = 1
		for zxp = 1, 3 do
			glare[ggg] = zone1_pax[zxp]
			ggg = ggg + 1
			glare[ggg] = zone2_pax[zxp]
			ggg = ggg + 1
			glare[ggg] = zone3_pax[zxp]
			ggg = ggg + 1
			glare[ggg] = zone4_pax[zxp]
			ggg = ggg + 1
			glare[ggg] = zone5_pax[zxp]
			ggg = ggg + 1
		end
		glare[16] = zone_cargo1
		glare[17] = zone_cargo2
		glare[18] = B738DR_hide_fueltruck	--B738DR_hide_fueltruck
		glare[19] = B738DR_req_fuel
		glare[20] = B738DR_de_ice_truck_hide
		glare[21] = B738DR_de_ice_truck_act
		glare[22] = de_ice_apply_time
		glare[23] = door_ratio_fwd_L
		glare[24] = door_ratio_fwd_R
		glare[25] = door_ratio_aft_L
		glare[26] = door_ratio_aft_L
		glare[27] = door_ratio_fwd_cargo
		glare[28] = door_ratio_aft_cargo
		glare[29] = door_ratio_emerg1
		glare[30] = door_ratio_emerg2
		glare[31] = door_ratio_emerg3
		glare[32] = door_ratio_emerg4
		glare[33] = door_ratio_fwd_L_trg
		glare[34] = door_ratio_fwd_R_trg
		glare[35] = door_ratio_aft_L_trg
		glare[36] = door_ratio_aft_R_trg
		glare[37] = door_ratio_fwd_cargo_trg
		glare[38] = door_ratio_aft_cargo_trg
		glare[39] = door_ratio_emerg1_trg
		glare[40] = door_ratio_emerg2_trg
		glare[41] = door_ratio_emerg3_trg
		glare[42] = door_ratio_emerg4_trg
		glare[43] = refuel_enable
		glare[44] = door_ratio_aft1
		glare[45] = door_ratio_aft2
		glare[46] = req_payload_weight
		
		glare[47] = B738DR_auto_flight
		glare[48] = auto_pax_tot
		glare[49] = auto_cargo_tot
		glare[50] = auto_zfw_tot
		glare[51] = auto_payload_tot
		glare[52] = auto_req_fuel
		
		glare[53] = auto_fuel_status
		glare[54] = auto_catter_status
		glare[55] = auto_cargo_status
		glare[56] = auto_pax_status
		
		glare[57] = auto_fuel_timer
		glare[58] = auto_pax_timer
		glare[59] = auto_cargo_timer
		glare[60] = auto_catter_timer
		glare[61] = zone1_pax_tgt
		glare[62] = zone2_pax_tgt
		glare[63] = zone3_pax_tgt
		glare[64] = zone4_pax_tgt
		glare[65] = zone5_pax_tgt
		glare[66] = cargo1_tgt
		glare[67] = cargo2_tgt
		
		glare[68] = B738DR_hide_fwd_stairs
		glare[69] = B738DR_hide_aft_stairs
		glare[70] = B738DR_hide_catering
		glare[71] = B738DR_hide_catering2
		glare[72] = B738DR_hide_belt
		glare[73] = B738DR_hide_belt2
		glare[74] = B738DR_hide_pax_bus
		glare[75] = B738DR_hide_pax_bus2
		
		if no_smoke_cycle == false then
			glare[76] = 0
		else
			glare[76] = 1
		end
		if auto_flight_enable == false then
			glare[77] = 0
		else
			glare[77] = 1
		end
		if auto_after_land == false then
			glare[78] = 0
		else
			glare[78] = 1
		end
		
		glare[79] = catering_operate_tmr
		glare[80] = belt_operate_tmr
		glare[81] = catering2_operate_tmr
		glare[82] = belt2_operate_tmr
		
		if call_catering == false then
			glare[83] = 0
		else
			glare[83] = 1
		end
		if call_catering2 == false then
			glare[84] = 0
		else
			glare[84] = 1
		end
		
		glare[85] = start_leg
		glare[86] = play_cargo
		
		glare[87] = cargo1_weight_req
		glare[88] = cargo2_weight_req
		glare[89] = zone_weight_req[1]
		glare[90] = zone_weight_req[2]
		glare[91] = zone_weight_req[3]
		glare[92] = zone_weight_req[4]
		glare[93] = zone_weight_req[5]
		glare[94] = crew_weight_f_req
		glare[95] = crew_weight_r_req
		
		for ggg = 1, 100 do
			B738DR_efb[ggg-1] = glare[ggg]
		end
	end
	
end

function dump_leg_append(data_str)
	local fms_line = ""
	
	local file_name2 = "legs.txt"
	local file_navdata2 = io.open(file_name2, "a")
	
	if file_navdata2 ~= nil then
		fms_line = data_str
		file_navdata2:write(fms_line)
		file_navdata2:close()
	end
end



function fire_service()
	if simDR_crashed == 0 then
		--firetruck 1
		if fireservice_state1 == 0 then
			if B738DR_nearest_apt_dist[0] < 6 then
				if ((simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1) and simDR_aircraft_groundspeed <= 0.001)
				or simDR_aircraft_groundspeed <= 0.001 then
					if simDR_eng2_fire == 6 then
						fireservice_state1 = 1
						-- fireservice_tmr1 = 30		--60 ???
						fireservice_tmr1 = B738_rescale(2, 30, 6, 80, B738DR_nearest_apt_dist[0])
					end
				end
			end
		elseif fireservice_state1 == 1 then
			if fireservice_tmr1 ~= 0 then
				fireservice_tmr1 = fireservice_tmr1 - SIM_PERIOD
				if fireservice_tmr1 <= 0 then
					fireservice_tmr1 = 0
				end
			else
				if simDR_eng_running[1] == 0 and simDR_aircraft_groundspeed <= 0.001 then
					if B738DR_parking_brake_pos == 1 or simDR_gear_deploy[1] == 0 or simDR_gear_deploy[2] == 0 then
						B738DR_hide_firestriker = 0
						fireservice_state1 = 2
						fireservice_tmr1 = 2
					end
				end
			end
		elseif fireservice_state1 == 2 then
			if B738DR_firestriker_operate >= 16 then
				if fireservice_tmr1 ~= 0 then
					fireservice_tmr1 = fireservice_tmr1 - SIM_PERIOD
					if fireservice_tmr1 <= 0 then
						fireservice_state1 = 3
						fireservice_tmr1 = 10
						fireservice_tmr1x = 30		--60 ???
					end
				end
			end
		elseif fireservice_state1 == 3 then
			if simDR_eng2_fire == 6 then
				B738DR_water_stream1 = 1
				if fireservice_tmr1x ~= 0 then
					fireservice_tmr1x = fireservice_tmr1x - SIM_PERIOD
					if fireservice_tmr1x <= 0 then
						B738DR_engine_failure[1] = 0
						simDR_eng2_fire = 0
						fireservice_tmr1x = 10
					end
				end
			else
				if fireservice_tmr1x ~= 0 then
					fireservice_tmr1x = fireservice_tmr1x - SIM_PERIOD
					if fireservice_tmr1x <= 0 then
						B738DR_water_stream1 = 0
						if fireservice_tmr1 ~= 0 then
							fireservice_tmr1 = fireservice_tmr1 - SIM_PERIOD
							if fireservice_tmr1 <= 0 then
								fireservice_state1 = 4
								fireservice_tmr1 = 30
								B738DR_hide_firestriker = 1
							end
						end
					end
				end
			end
		elseif fireservice_state1 == 4 then
			if fireservice_tmr1 ~= 0 then
				fireservice_tmr1 = fireservice_tmr1 - SIM_PERIOD
				if fireservice_tmr1 <= 0 then
					fireservice_state1 = 0
				end
			end
		end
		
		--firetruck 1
		if fireservice_state2 == 0 then
			if B738DR_nearest_apt_dist[0] < 6 then
				if ((simDR_on_ground[0] == 1 or simDR_on_ground[1] == 1 or simDR_on_ground[2] == 1) and simDR_aircraft_groundspeed <= 0.001)
				or simDR_aircraft_groundspeed <= 0.001 then
					if simDR_eng1_fire == 6 then
						fireservice_state2 = 1
						-- fireservice_tmr2 = 30		--60 ???
						fireservice_tmr2 = B738_rescale(2, 30, 6, 80, B738DR_nearest_apt_dist[0])
					end
				end
			end
		elseif fireservice_state2 == 1 then
			if fireservice_tmr2 ~= 0 then
				fireservice_tmr2 = fireservice_tmr2 - SIM_PERIOD
				if fireservice_tmr2 <= 0 then
					fireservice_tmr2 = 0
				end
			else
				if simDR_eng_running[0] == 0 and simDR_aircraft_groundspeed <= 0.001 then
					if B738DR_parking_brake_pos == 1 or simDR_gear_deploy[1] == 0 or simDR_gear_deploy[2] == 0 then
						B738DR_hide_firestriker2 = 0
						fireservice_state2 = 2
						fireservice_tmr2 = 2
					end
				end
			end
		elseif fireservice_state2 == 2 then
			if B738DR_firestriker2_operate >= 16 then
				if fireservice_tmr2 ~= 0 then
					fireservice_tmr2 = fireservice_tmr2 - SIM_PERIOD
					if fireservice_tmr2 <= 0 then
						fireservice_state2 = 3
						fireservice_tmr2 = 10
						fireservice_tmr2x = 30		--60 ???
					end
				end
			end
		elseif fireservice_state2 == 3 then
			if simDR_eng1_fire == 6 then
				B738DR_water_stream2 = 1
				if fireservice_tmr2x ~= 0 then
					fireservice_tmr2x = fireservice_tmr2x - SIM_PERIOD
					if fireservice_tmr2x <= 0 then
						B738DR_engine_failure[0] = 0
						simDR_eng1_fire = 0
						fireservice_tmr2x = 10
					end
				end
			else
				if fireservice_tmr2x ~= 0 then
					fireservice_tmr2x = fireservice_tmr2x - SIM_PERIOD
					if fireservice_tmr2x <= 0 then
						B738DR_water_stream2 = 0
						if fireservice_tmr2 ~= 0 then
							fireservice_tmr2 = fireservice_tmr2 - SIM_PERIOD
							if fireservice_tmr2 <= 0 then
								fireservice_state2 = 4
								fireservice_tmr2 = 30
								B738DR_hide_firestriker2 = 1
							end
						end
					end
				end
			end
		elseif fireservice_state2 == 4 then
			if fireservice_tmr2 ~= 0 then
				fireservice_tmr2 = fireservice_tmr2 - SIM_PERIOD
				if fireservice_tmr2 <= 0 then
					fireservice_state2 = 0
				end
			end
		end
	end
end

function aircraft_load()
	enable_cg = 1
end

function after_physics()
	if B738DR_load_save == 4 or B738DR_load_save == 3 then
		livery_idx = -1
	end
	if livery_idx ~= simDR_livery_idx then
		check_livery()
	end
	livery_idx = simDR_livery_idx
	boot()
	
	if cat < CAT_CL_PR_PREFLIGHT or cat > CAT_CL_SECURE then
		if B738DR_arrow_3d_override == 0 then
			B738DR_arrow_3d_kill = 1
			B738DR_arrow_3d_kill2 = 1
		end
	end
	
	B738_max_fuel()
	
	if B738DR_ext_payload == 0 then
		sam_tick = 0
	else
		local sam_payload_enable = false
		if simDR_on_ground[0] == 1 and simDR_on_ground[1] == 1 and simDR_on_ground[2] == 1 then
			if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 then
				sam_payload_enable = true
			end
		end
		if sam_payload_enable == true then
			if sam_tick < 5 then
				sam_tick = sam_tick + 1
			end
			sam_payload()
		else
			sam_tick = 0
			simDR_payload_weight = req_payload_weight
		end
		payload_weight_old = simDR_payload_weight
	end
	
	if B738DR_arrow_3d_override == 2 then
		xyz_lever_switch(B738DR_arrow_3d_item, B738DR_arrow_3d_item2)
	end
	
	if B738DR_efb_brightness == 0 then
		if simDR_sun_pitch < 3 then
			B738DR_efb_night_mode = 1
		else
			B738DR_efb_night_mode = 0
		end
	else
		if B738DR_efb_brightness == 1 then
			B738DR_efb_night_mode = 0
		else
			B738DR_efb_night_mode = 1
		end
	end
	
	if display_update ~= 0 then
		prepare_page()
		display_page()
		if cat ~= CAT_CALIBRATE and (cat < CAT_CL_PR_PREFLIGHT or cat > CAT_CL_SECURE) and cat ~= CAT_DEV_TUNE then
			display_update = 0
		end
		B738DR_tab_page = page
		if B738DR_autoload_on ~= 0 then
			-- Autoload
			B738DR_tab_autoload = 1
			clr_menu_manip()
			clr_line_manip()
			clr_perf_manip()
			B738DR_tab_menu_manip[5] = 1
			B738DR_tab_menu_manip[6] = 1
			B738DR_failure_save = 0
		elseif B738DR_failure_save ~= 0 then
			B738_failure_exit()
		else
			B738DR_tab_autoload = 0
		end
	end
	load_save(0)
	
	if cor_time == 0 then
		update_payload()
	end
	
	if f_time == 0 then
		f_time = 1
	elseif f_time == 1 then
		load_view()
		f_time = 2
	end
	
	bar_time()
	anim_info()
	anim_checklist()
	if avitab_installed == 1 and avitab_ctrl_override == 0 then
		if B738DR_tab_power == 0 then
			avitab_powered = 0
			avitab_enabled = 0
		end
	end
	anim_door()
	B738_door_status()
	B738_fps()
	B738_ext_air()
	B738_de_ice_truck()
	B738_pax()
	B738_fuel_tanking()
	B738_landing_rate()
	B738_layout()
	B738_decals()
	B738_door_locked()
	if B738DR_hide_gpu == 0 then
		gpu_deployed = 1
	else
		gpu_deployed = 0
	end
	
	if B738DR_isfd_rmi ~= 0 and B738DR_enable_gyro == 0 and B738DR_cb_d9 == 0 then
		B738CMD_enable_gyro:once()
	elseif (B738DR_isfd_rmi == 0 or B738DR_cb_d9 ~= 0) and B738DR_enable_gyro ~= 0 then
		B738CMD_enable_gyro:once()
	end
	
	if B738DR_aspirated_probe == 0 then
		if B738DR_probe_heat_auto == 0 then
			B738DR_probe_heat_tat = 2
		else
			B738DR_probe_heat_tat = 3
		end
	else
		if B738DR_probe_heat_auto == 0 then
			B738DR_probe_heat_tat = 0
		else
			B738DR_probe_heat_tat = 1
		end
	end
	
	if B738DR_old_mcp == 0 then
		B738DR_kill_old_mcp = 1
	else
		B738DR_kill_old_mcp = 0
	end
	if B738DR_raas == 0 then
		if B738DR_xraas_installed == 0 then
			B738DR_raas_not_installed = 1
		else
			B738DR_raas_not_installed = 0
		end
	elseif B738DR_raas == 1 then
		B738DR_raas_not_installed = 0
	else
		B738DR_raas_not_installed = 1
	end
	
	B738_find_axis()
	
	if cor_time > 3 then
		cor_time = 0
	end
	if cor_time == 0 then
		if B738DR_autogate_nearest < 0.018 then
			gw_tow_state = 1
		else
			gw_tow_state = 0
		end
		B738DR_real_cg_mac, B738DR_real_cg = calc_gw_cg_shift()
		if gw_tow_state == 0 then
			B738DR_calc_to_cg = 0
		else
			local mac_to = 0
			local mac_to_pos = 0
			mac_to, mac_to_pos = calc_mac(1)
			if mac_to < 6 or mac_to > 36 then
				B738DR_calc_to_cg = 0
			else
				B738DR_calc_to_cg = mac_to
			end
		end
	end
	cor_time = cor_time + 1
	
	-- if B738DR_load_save ~= 3 then
		-- load_save(1)
	-- end
	
	if efb_first_time == 0 then
		for iii = 0, 15 do
			door_item_hide[iii] = 0
		end
		door_item_hide[0] = 1
		door_item_hide[4] = 1
		door_item_hide[14] = 1
		door_item_hide[15] = 1
		if B738DR_b737_variant == 2 or B738DR_b737_variant == 3 then
			door_item_hide[8] = 1
			door_item_hide[10] = 1
		end
		if B738DR_b737_variant == 4 then
			door_item_hide[12] = 0
			door_item_hide[13] = 0
		else
			door_item_hide[12] = 1
			door_item_hide[13] = 1
		end
		efb_first_time = 1
	elseif efb_first_time == 1 then
		auto_zfw_tot = B738DR_oew_kg + auto_pax_tot * B738DR_std_pax_weight[0] + auto_cargo_tot
		efb_first_time = 2
	end
	
	--avitab_enabled = 1
	if B738DR_b737_variant == 3 then	--or B738DR_b737_variant == 1 then
		B738DR_wings_variant = 2
	end
	calc_mac_DR()
	
	local disable_fo_pilot = 0
	if simDR_view_is_external == 0 then
		disable_fo_pilot = 1
	elseif B738DR_disable_fo_callout ~= 0 then
		disable_fo_pilot = 1
	end
	B738DR_disable_fo_pilot = disable_fo_pilot
	
	if B738DR_ui_manip ~= 0 then
		clr_menu_manip()
		clr_line_manip()
		clr_perf_manip()
		B738DR_tab_nav_manip = 0
		B738DR_tab_info_manip = 0
		B738DR_tab_nav2_manip = 0
		B738DR_tab_arrows_enable = 0
	end
	
	if B738DR_tab_arrows_enable ~= 0 then
		if page == min_page then
			B738DR_tab_arrows_left = 0
		else
			B738DR_tab_arrows_left = 1
		end
		if page == max_page then
			B738DR_tab_arrows_right = 0
		else
			B738DR_tab_arrows_right = 1
		end
	end
	
	if B738DR_ext_payload == 0 then
		local add_weight = 0
		
		if simDR_payload_weight < req_payload_weight then
			
			-- if B738DR_b737_variant < 0 then
				-- add_weight = simDR_payload_stations[0] + (SIM_PERIOD * 222)
				-- if add_weight > cargo1_weight_req then
					-- add_weight = cargo1_weight_req
				-- end
				-- simDR_payload_stations[0] = add_weight
				
				-- add_weight = simDR_payload_stations[1] + (SIM_PERIOD * 222)
				-- if add_weight > cargo2_weight_req then
					-- add_weight = cargo2_weight_req
				-- end
				-- simDR_payload_stations[1] = add_weight
				
				-- add_weight = simDR_payload_stations[2] + (SIM_PERIOD * 222)
				-- if add_weight > zone_weight_req[1] then
					-- add_weight = zone_weight_req[1]
				-- end
				-- simDR_payload_stations[2] = add_weight
				
				-- add_weight = simDR_payload_stations[3] + (SIM_PERIOD * 222)
				-- if add_weight > zone_weight_req[2] then
					-- add_weight = zone_weight_req[2]
				-- end
				-- simDR_payload_stations[3] = add_weight
				
				-- add_weight = simDR_payload_stations[4] + (SIM_PERIOD * 222)
				-- if add_weight > zone_weight_req[3] then
					-- add_weight = zone_weight_req[3]
				-- end
				-- simDR_payload_stations[4] = add_weight
				
				-- add_weight = simDR_payload_stations[5] + (SIM_PERIOD * 222)
				-- if add_weight > zone_weight_req[4] then
					-- add_weight = zone_weight_req[4]
				-- end
				-- simDR_payload_stations[5] = add_weight
				
				-- add_weight = simDR_payload_stations[6] + (SIM_PERIOD * 222)
				-- if add_weight > zone_weight_req[5] then
					-- add_weight = zone_weight_req[5]
				-- end
				-- simDR_payload_stations[6] = add_weight
				
				-- add_weight = simDR_payload_stations[7] + (SIM_PERIOD * 222)
				-- if add_weight > crew_weight_f_req then
					-- add_weight = crew_weight_f_req
				-- end
				-- simDR_payload_stations[7] = add_weight
				
				-- add_weight = simDR_payload_stations[8] + (SIM_PERIOD * 222)
				-- if add_weight > crew_weight_r_req then
					-- add_weight = crew_weight_r_req
				-- end
				-- simDR_payload_stations[8] = add_weight
			-- else
				add_weight = simDR_payload_weight + (SIM_PERIOD * 2000)
				if add_weight > req_payload_weight then
					add_weight = req_payload_weight
				end
				simDR_payload_weight = add_weight
			-- end
			
		elseif simDR_payload_weight > req_payload_weight then
			
			-- if B738DR_b737_variant < 0 then
				-- add_weight = simDR_payload_stations[0] - (SIM_PERIOD * 222)
				-- if add_weight < cargo1_weight_req then
					-- add_weight = cargo1_weight_req
				-- end
				-- simDR_payload_stations[0] = add_weight
				
				-- add_weight = simDR_payload_stations[1] - (SIM_PERIOD * 222)
				-- if add_weight < cargo2_weight_req then
					-- add_weight = cargo2_weight_req
				-- end
				-- simDR_payload_stations[1] = add_weight
				
				-- add_weight = simDR_payload_stations[2] - (SIM_PERIOD * 222)
				-- if add_weight < zone_weight_req[1] then
					-- add_weight = zone_weight_req[1]
				-- end
				-- simDR_payload_stations[2] = add_weight
				
				-- add_weight = simDR_payload_stations[3] - (SIM_PERIOD * 222)
				-- if add_weight < zone_weight_req[2] then
					-- add_weight = zone_weight_req[2]
				-- end
				-- simDR_payload_stations[3] = add_weight
				
				-- add_weight = simDR_payload_stations[4] - (SIM_PERIOD * 222)
				-- if add_weight < zone_weight_req[3] then
					-- add_weight = zone_weight_req[3]
				-- end
				-- simDR_payload_stations[4] = add_weight
				
				-- add_weight = simDR_payload_stations[5] - (SIM_PERIOD * 222)
				-- if add_weight < zone_weight_req[4] then
					-- add_weight = zone_weight_req[4]
				-- end
				-- simDR_payload_stations[5] = add_weight
				
				-- add_weight = simDR_payload_stations[6] - (SIM_PERIOD * 222)
				-- if add_weight < zone_weight_req[5] then
					-- add_weight = zone_weight_req[5]
				-- end
				-- simDR_payload_stations[6] = add_weight
				
				-- add_weight = simDR_payload_stations[7] - (SIM_PERIOD * 222)
				-- if add_weight < crew_weight_f_req then
					-- add_weight = crew_weight_f_req
				-- end
				-- simDR_payload_stations[7] = add_weight
				
				-- add_weight = simDR_payload_stations[8] - (SIM_PERIOD * 222)
				-- if add_weight < crew_weight_r_req then
					-- add_weight = crew_weight_r_req
				-- end
				-- simDR_payload_stations[8] = add_weight
			-- else
				add_weight = simDR_payload_weight - (SIM_PERIOD * 2000)
				if add_weight < req_payload_weight then
					add_weight = req_payload_weight
				end
				simDR_payload_weight = add_weight
			-- end
			
		end
	end

	for zxp = 1, 3 do
		B738DR_zone1_payload[zxp-1] = zone1_pax[zxp]
		B738DR_zone2_payload[zxp-1] = zone2_pax[zxp]
		B738DR_zone3_payload[zxp-1] = zone3_pax[zxp]
		B738DR_zone4_payload[zxp-1] = zone4_pax[zxp]
		B738DR_zone5_payload[zxp-1] = zone5_pax[zxp]
	end

	B738DR_zone_cargo1_payload = zone_cargo1
	B738DR_zone_cargo2_payload = zone_cargo2
	
	fill_zone_weight()
	
	if simDR_engine_on[0] == 0 and simDR_engine_on[1] == 0 and B738DR_batbus_status == 0 then
		if simDR_on_ground[0] ~= 0 and simDR_on_ground[1] ~= 0 and simDR_on_ground[2] ~= 0 then
			turn_around = 0
		end
	-- elseif (simDR_engine_on[0] ~= 0 or simDR_engine_on[1] ~= 0) and B738DR_batbus_status ~= 0 then
	elseif simDR_on_ground[0] == 0 and simDR_on_ground[1] == 0 and simDR_on_ground[2] == 0 and B738DR_batbus_status ~= 0 then
		turn_around = 1
	end
	
	fire_service()
	
	B738_auto_flight()
	
	was_replay = 0
	
	load_save(1)
	
	jbr_opt()
	
end

function after_replay()
	if simDR_on_ground[0] == 0 and simDR_on_ground[1] == 0 and simDR_on_ground[2] == 0 then
		B738DR_hide_gpu = 1
		B738DR_hide_asu = 1
		B738DR_de_ice_truck_hide = 1
		B738DR_de_ice_truck_act = 0
		de_ice_apply_time = 0
		B738DR_hide_airstairs = 1
		B738DR_water_stream1 = 0
		B738DR_water_stream2 = 0
	elseif simDR_aircraft_groundspeed > 0.08 then
		B738DR_hide_gpu = 1
		B738DR_hide_asu = 1
		B738DR_de_ice_truck_hide = 1
		B738DR_de_ice_truck_act = 0
		de_ice_apply_time = 0
		B738DR_hide_airstairs = 1
		B738DR_water_stream1 = 0
		B738DR_water_stream2 = 0
	end
	
	door_ratio_fwd_L = 0
	door_ratio_fwd_R = 0
	door_ratio_aft_L = 0
	door_ratio_aft_R = 0
	door_ratio_fwd_cargo = 0
	door_ratio_aft_cargo = 0
	door_ratio_emerg1 = 0
	door_ratio_emerg2 = 0
	door_ratio_emerg3 = 0
	door_ratio_emerg4 = 0
	door_ratio_emerg5 = 0
	door_ratio_emerg6 = 0
	door_ratio_emerg5_lu = 0
	door_ratio_emerg6_lu = 0
	door_ratio_aft1 = 0
	door_ratio_aft2 = 0
	
	B738_fps()
	was_replay = 1
end


-- --*************************************************************************************--
-- --** 				               SUB-MODULE PROCESSING       	        			 **--
-- --*************************************************************************************--

-- -- dofile("")

