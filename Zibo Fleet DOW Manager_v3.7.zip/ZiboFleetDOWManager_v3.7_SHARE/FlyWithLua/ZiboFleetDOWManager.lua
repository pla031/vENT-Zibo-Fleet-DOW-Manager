-- Zibo Fleet BW / DOW Manager v3.7
-- X-Plane 12 / FlyWithLua NG
-- Loads only when Zibo 737 is active.

local aircraft_path = string.lower(AIRCRAFT_PATH or "")
local is_zibo = string.find(aircraft_path,"b737-800x",1,true) ~= nil or string.find(aircraft_path,"zibo",1,true) ~= nil or string.find(aircraft_path,"b738x",1,true) ~= nil
if not is_zibo then logMsg("[ZiboFleetDOW] Zibo 737 not detected - script disabled.") return end
if not SUPPORTS_FLOATING_WINDOWS then logMsg("[ZiboFleetDOW] Floating windows are not supported.") return end

dataref("zfdow_empty_kg","sim/aircraft/weight/acf_m_empty","writable")
dataref("zfdow_payload_kg","sim/flightmodel/weight/m_fixed","readonly")
dataref("zfdow_total_kg","sim/flightmodel/weight/m_total","readonly")
dataref("zfdow_zibo_oew_kg","laminar/B738/oew_kg","writable")
dataref("zfdow_fa_fwd_kg","laminar/B738/fa_fwd_kg","writable")
dataref("zfdow_fa_aft_kg","laminar/B738/fa_aft_kg","writable")
dataref("zfdow_galley_fwd_kg","laminar/B738/galley_fwd_kg","writable")
dataref("zfdow_galley_aft_kg","laminar/B738/galley_aft_kg","writable")
dataref("zfdow_trigger_cargo","laminar/B738/tab/zone_cargo1_payload","writable")

local MAX_FA_FWD,MAX_FA_AFT,MAX_GALLEY_FWD,MAX_GALLEY_AFT = 190.5,190.5,1177.0,1225.0
zfdow_fleet={}; zfdow_window=nil; zfdow_selected=nil; zfdow_selected_reg="-"; zfdow_selected_dow="-"
zfdow_target_oew=0; zfdow_target_dow=0; zfdow_target_payload=0; zfdow_message="Select aircraft registration."
zfdow_csv_path=SCRIPT_DIRECTORY.."ZiboFleetDOW.csv"; zfdow_sync_state=0; zfdow_sync_delay=0; zfdow_saved_cargo=0; zfdow_temp_cargo=0

local function trim(s) return (s:gsub("^%s+",""):gsub("%s+$","")) end
local function round1(v) return math.floor(v*10+0.5)/10 end

function zfdow_load_csv()
    zfdow_fleet={}
    local file=io.open(zfdow_csv_path,"r")
    if not file then zfdow_message="ERROR: ZiboFleetDOW.csv not found."; logMsg("[ZiboFleetDOW] CSV not found: "..zfdow_csv_path); return end
    local first_line=true
    for line in file:lines() do
        line=trim(line)
        if line~="" and string.sub(line,1,1)~="#" then
            if first_line and string.find(string.lower(line),"registration",1,true) then first_line=false
            else
                first_line=false
                local reg,bw,a,b,c,d=string.match(line,"^%s*([^,]+)%s*,%s*([^,]+)%s*,%s*([^,]+)%s*,%s*([^,]+)%s*,%s*([^,]+)%s*,%s*([^,]+)%s*$")
                bw=tonumber(bw); a=tonumber(a); b=tonumber(b); c=tonumber(c); d=tonumber(d)
                if reg and bw and a and b and c and d then table.insert(zfdow_fleet,{registration=trim(reg),bw=bw,dowA=a,dowB=b,dowC=c,dowD=d})
                else logMsg("[ZiboFleetDOW] Invalid CSV line: "..line) end
            end
        end
    end
    file:close(); table.sort(zfdow_fleet,function(a,b) return a.registration<b.registration end)
    zfdow_message=string.format("%d aircraft loaded.",#zfdow_fleet); logMsg("[ZiboFleetDOW] "..zfdow_message)
end

function zfdow_start_payload_sync()
    zfdow_saved_cargo=zfdow_trigger_cargo
    if zfdow_saved_cargo>=0.1 then zfdow_temp_cargo=zfdow_saved_cargo-0.1 else zfdow_temp_cargo=zfdow_saved_cargo+0.1 end
    zfdow_sync_delay=3; zfdow_sync_state=1
end

function zfdow_process_sync()
    if zfdow_selected then zfdow_empty_kg=zfdow_selected.bw; zfdow_zibo_oew_kg=zfdow_target_oew end
    if zfdow_sync_state==0 then return end
    if zfdow_sync_state==1 then
        if zfdow_sync_delay>0 then zfdow_sync_delay=zfdow_sync_delay-1; return end
        zfdow_trigger_cargo=zfdow_temp_cargo; zfdow_sync_state=2; zfdow_sync_delay=2; return
    end
    if zfdow_sync_state==2 then
        if zfdow_sync_delay>0 then zfdow_sync_delay=zfdow_sync_delay-1; return end
        zfdow_trigger_cargo=zfdow_saved_cargo; zfdow_sync_state=3; zfdow_sync_delay=5; return
    end
    if zfdow_sync_state==3 then
        if zfdow_sync_delay>0 then zfdow_sync_delay=zfdow_sync_delay-1; return end
        zfdow_sync_state=0
        logMsg(string.format("[ZiboFleetDOW] Sync completed | Target OEW %.1f | Zibo OEW %.1f | Payload %.1f | Total %.1f",zfdow_target_oew,zfdow_zibo_oew_kg,zfdow_payload_kg,zfdow_total_kg))
    end
end

function zfdow_clear_operational_weights() zfdow_fa_fwd_kg=0; zfdow_fa_aft_kg=0; zfdow_galley_fwd_kg=0; zfdow_galley_aft_kg=0 end

function zfdow_select_aircraft(index)
    local a=zfdow_fleet[index]; if not a then return end
    zfdow_selected=a; zfdow_selected_reg=a.registration; zfdow_selected_dow="-"; zfdow_target_oew=a.bw; zfdow_target_dow=a.bw; zfdow_target_payload=0
    zfdow_empty_kg=a.bw; zfdow_clear_operational_weights(); zfdow_zibo_oew_kg=a.bw; zfdow_start_payload_sync()
    zfdow_message=string.format("%s selected | BW %.0f kg",a.registration,a.bw)
end

function zfdow_apply_dow(letter)
    if not zfdow_selected then zfdow_message="Select aircraft registration first."; return end
    local target=letter=="A" and zfdow_selected.dowA or letter=="B" and zfdow_selected.dowB or letter=="C" and zfdow_selected.dowC or letter=="D" and zfdow_selected.dowD or nil
    if not target then return end
    local bw=zfdow_selected.bw; local op=target-bw
    if op<0 then zfdow_message="ERROR: DOW is lower than BW."; return end
    if op>MAX_FA_FWD+MAX_FA_AFT+MAX_GALLEY_FWD+MAX_GALLEY_AFT then zfdow_message="ERROR: Operational weight exceeds available capacity."; return end
    local fw=op/2; local aw=op-fw; local ff=math.min(fw,MAX_FA_FWD); local fa=math.min(aw,MAX_FA_AFT); local gf=fw-ff; local ga=aw-fa
    if gf>MAX_GALLEY_FWD then local e=gf-MAX_GALLEY_FWD; gf=MAX_GALLEY_FWD; ga=ga+e end
    if ga>MAX_GALLEY_AFT then local e=ga-MAX_GALLEY_AFT; ga=MAX_GALLEY_AFT; gf=gf+e end
    if gf>MAX_GALLEY_FWD or ga>MAX_GALLEY_AFT then zfdow_message="ERROR: Unable to distribute operational weight."; return end
    ff=round1(ff); fa=round1(fa); gf=round1(gf); ga=round1(op-ff-fa-gf)
    zfdow_empty_kg=bw; zfdow_fa_fwd_kg=ff; zfdow_fa_aft_kg=fa; zfdow_galley_fwd_kg=gf; zfdow_galley_aft_kg=ga
    zfdow_selected_dow=letter; zfdow_target_dow=target; zfdow_target_oew=target; zfdow_target_payload=op; zfdow_zibo_oew_kg=target; zfdow_start_payload_sync()
    zfdow_message=string.format("%s | DOW %s | %.0f kg",zfdow_selected.registration,letter,target)
end

function zfdow_reset_current()
    if not zfdow_selected then return end
    zfdow_selected_dow="-"; zfdow_target_oew=zfdow_selected.bw; zfdow_target_dow=zfdow_selected.bw; zfdow_target_payload=0
    zfdow_empty_kg=zfdow_selected.bw; zfdow_clear_operational_weights(); zfdow_zibo_oew_kg=zfdow_selected.bw; zfdow_start_payload_sync()
    zfdow_message=string.format("%s reset to BW %.0f kg.",zfdow_selected.registration,zfdow_selected.bw)
end

function zfdow_deselect_aircraft()
    zfdow_selected=nil; zfdow_selected_reg="-"; zfdow_selected_dow="-"; zfdow_target_oew=0; zfdow_target_dow=0; zfdow_target_payload=0; zfdow_message="Select aircraft registration."
end

function zfdow_build_window(wnd,x,y)
    imgui.TextUnformatted("ZIBO 737 - Fleet BW / DOW Manager"); imgui.Separator()
    if not zfdow_selected then
        imgui.TextUnformatted("Select aircraft registration:"); imgui.Separator()
        for i,a in ipairs(zfdow_fleet) do if imgui.Button(string.format("%s   |   BW %.0f kg",a.registration,a.bw)) then zfdow_select_aircraft(i) end end
        imgui.Separator(); if imgui.Button("Reload fleet CSV") then zfdow_load_csv() end; imgui.TextUnformatted(zfdow_message); return
    end
    imgui.TextUnformatted(string.format("Registration: %s",zfdow_selected_reg)); imgui.TextUnformatted(string.format("Basic Weight: %.0f kg",zfdow_selected.bw)); imgui.Separator(); imgui.TextUnformatted("Select DOW configuration:")
    if imgui.Button(string.format("DOW A   %.0f kg",zfdow_selected.dowA)) then zfdow_apply_dow("A") end
    if imgui.Button(string.format("DOW B   %.0f kg",zfdow_selected.dowB)) then zfdow_apply_dow("B") end
    if imgui.Button(string.format("DOW C   %.0f kg",zfdow_selected.dowC)) then zfdow_apply_dow("C") end
    if imgui.Button(string.format("DOW D   %.0f kg",zfdow_selected.dowD)) then zfdow_apply_dow("D") end
    if zfdow_selected_dow~="-" then
        imgui.Separator(); imgui.TextUnformatted(string.format("Selected DOW: %s",zfdow_selected_dow)); imgui.TextUnformatted(string.format("Target DOW: %.0f kg",zfdow_target_dow)); imgui.TextUnformatted(string.format("Operational Weight: %.1f kg",zfdow_target_payload)); imgui.Separator()
        imgui.TextUnformatted(string.format("FA FWD: %.1f kg",zfdow_fa_fwd_kg)); imgui.TextUnformatted(string.format("FA AFT: %.1f kg",zfdow_fa_aft_kg)); imgui.TextUnformatted(string.format("GALLEYS F: %.1f kg",zfdow_galley_fwd_kg)); imgui.TextUnformatted(string.format("GALLEYS R: %.1f kg",zfdow_galley_aft_kg)); imgui.Separator()
        imgui.TextUnformatted(string.format("Zibo OEW: %.0f kg",zfdow_zibo_oew_kg)); imgui.TextUnformatted(string.format("X-Plane Payload: %.1f kg",zfdow_payload_kg)); imgui.TextUnformatted(string.format("X-Plane Total Weight: %.0f kg",zfdow_total_kg)); if zfdow_sync_state~=0 then imgui.TextUnformatted("Synchronizing with Zibo...") end
    end
    imgui.Separator(); if imgui.Button("Reset DOW") then zfdow_reset_current() end; imgui.SameLine(); if imgui.Button("Change aircraft") then zfdow_deselect_aircraft() end; imgui.TextUnformatted(zfdow_message)
end

function zfdow_window_closed(wnd) zfdow_window=nil end
function zfdow_show_window()
    if zfdow_window~=nil then float_wnd_bring_to_front(zfdow_window); return end
    zfdow_window=float_wnd_create(540,680,1,true); float_wnd_set_title(zfdow_window,"Zibo Fleet BW / DOW Manager"); float_wnd_set_imgui_builder(zfdow_window,"zfdow_build_window"); float_wnd_set_onclose(zfdow_window,"zfdow_window_closed")
end

zfdow_load_csv(); do_every_frame("zfdow_process_sync()")
add_macro("Zibo Fleet BW DOW Manager","zfdow_show_window()")
create_command("FlyWithLua/ZiboFleetDOW/show","Open Zibo Fleet BW/DOW Manager","zfdow_show_window()","","")
logMsg("[ZiboFleetDOW] v3.7 loaded successfully.")
